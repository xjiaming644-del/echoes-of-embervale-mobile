class_name NPCScheduler
extends Node

var npc_states: Dictionary = {}
var _astars: Dictionary = {}
var _rumor_cooldown: float = 0.0


func init_npcs(zone_mgr: ZoneManager) -> void:
	npc_states.clear()
	_rebuild_nav_grids(zone_mgr)
	for n in DataRegistry.get_all_npcs():
		var d: Dictionary = n
		var nid: String = str(d.get("id", ""))
		var sched: Array = d.get("schedule", [])
		var start_zone: String = str(d.get("home_zone", "town"))
		var start_grid: Vector2i = Vector2i(10, 10)
		var act: String = "散步"
		if sched.size() > 0:
			var first: Dictionary = sched[0]
			start_zone = str(first.get("zone", start_zone))
			start_grid = Vector2i(int(first.get("x", 10)), int(first.get("y", 10)))
			act = str(first.get("activity", ""))
		npc_states[nid] = {
			"id": nid,
			"name": str(d.get("name", nid)),
			"zone": start_zone,
			"pos": Vector2(start_grid.x * ZoneManager.TILE_SIZE + 16, start_grid.y * ZoneManager.TILE_SIZE + 16),
			"target_zone": start_zone,
			"target_grid": start_grid,
			"path": [],
			"dir": 0,
			"anim_t": 0.0,
			"moving": false,
			"activity": act,
			"bubble": "",
			"bubble_timer": 0.0,
		}


func _rebuild_nav_grids(zone_mgr: ZoneManager) -> void:
	_astars.clear()
	for zid in ["farm", "ranch", "town", "lake", "secret_woods", "farmhouse"]:
		var sz: Vector2i = zone_mgr.get_zone_size(zid)
		var astar: AStarGrid2D = AStarGrid2D.new()
		astar.region = Rect2i(0, 0, sz.x, sz.y)
		astar.cell_size = Vector2(ZoneManager.TILE_SIZE, ZoneManager.TILE_SIZE)
		astar.diagonal_mode = AStarGrid2D.DIAGONAL_MODE_NEVER
		astar.update()
		for y in range(sz.y):
			for x in range(sz.x):
				if not zone_mgr.is_walkable(zid, Vector2i(x, y)):
					astar.set_point_solid(Vector2i(x, y), true)
		_astars[zid] = astar


func compute_path(zone_id: String, from_grid: Vector2i, to_grid: Vector2i) -> Array:
	if not _astars.has(zone_id):
		return []
	var astar: AStarGrid2D = _astars[zone_id]
	if not astar.is_in_boundsv(from_grid) or not astar.is_in_boundsv(to_grid):
		return []
	# Ensure destination isn't solid
	if astar.is_point_solid(to_grid):
		return []
	var id_path: PackedVector2Array = astar.get_point_path(from_grid, to_grid)
	var out: Array = []
	for pt in id_path:
		out.append(Vector2(pt.x + 16.0, pt.y + 16.0))
	return out


func update_schedules_for_hour(hour: int) -> void:
	var fest_spots: Dictionary = {
		"linxia": Vector2i(15, 10),
		"horn": Vector2i(18, 10),
		"ache": Vector2i(14, 12),
		"mei": Vector2i(17, 10),
		"suwan": Vector2i(20, 11),
		"kailuo": Vector2i(13, 11),
	}
	for n in DataRegistry.get_all_npcs():
		var d: Dictionary = n
		var nid: String = str(d.get("id", ""))
		if not npc_states.has(nid):
			continue

		var st: Dictionary = npc_states[nid]
		var tz: String = "town"
		var tg: Vector2i = Vector2i(12, 10)
		var act: String = ""

		if GameState.spouse_id == nid and (hour < 9 or hour >= 18):
			tz = "farmhouse"
			tg = Vector2i(6, 5)
			act = "在家准备温馨餐点"
			st["bubble"] = "💕 欢迎回家~"
			st["bubble_timer"] = 4.5
		elif GameState.is_harvest_festival_day() and hour >= 10 and hour <= 18 and fest_spots.has(nid):
			tz = "town"
			tg = fest_spots[nid]
			act = "参加山谷丰收品鉴庆典"
		else:
			var sched: Array = d.get("schedule", [])
			if GameState.weather in ["rain", "storm"]:
				var r_sched: Array = d.get("rain_schedule", [])
				if r_sched.size() > 0:
					sched = r_sched
			var chosen: Dictionary = {}
			for entry in sched:
				var e: Dictionary = entry
				if int(e.get("hour", 6)) <= hour:
					chosen = e
			if chosen.is_empty() and sched.size() > 0:
				chosen = sched[0]
			if chosen.is_empty():
				continue
			tz = str(chosen.get("zone", "town"))
			tg = Vector2i(int(chosen.get("x", 12)), int(chosen.get("y", 10)))
			act = str(chosen.get("activity", ""))

		st["activity"] = act
		if str(st.get("zone", "")) != tz:
			st["zone"] = tz
			st["pos"] = Vector2(tg.x * ZoneManager.TILE_SIZE + 16, tg.y * ZoneManager.TILE_SIZE + 16)
			st["path"] = []
		else:
			var cur_g: Vector2i = Vector2i(int(st["pos"].x / ZoneManager.TILE_SIZE), int(st["pos"].y / ZoneManager.TILE_SIZE))
			if cur_g != tg:
				var p: Array = compute_path(tz, cur_g, tg)
				if p.size() > 1:
					p.remove_at(0)
				st["path"] = p
		st["target_zone"] = tz
		st["target_grid"] = tg
		npc_states[nid] = st


func tick(delta: float) -> void:
	var speed: float = 64.0
	for nid in npc_states.keys():
		var st: Dictionary = npc_states[nid]
		var bt: float = float(st.get("bubble_timer", 0.0))
		if bt > 0.0:
			bt = maxf(0.0, bt - delta)
			st["bubble_timer"] = bt
			if bt <= 0.0:
				st["bubble"] = ""

		var path: Array = st.get("path", [])
		if path.size() > 0:
			var target: Vector2 = path[0]
			var pos: Vector2 = st["pos"]
			var diff: Vector2 = target - pos
			if diff.length() < 3.0:
				st["pos"] = target
				path.remove_at(0)
				st["path"] = path
				st["moving"] = path.size() > 0
			else:
				var step_v: Vector2 = diff.normalized() * speed * delta
				if step_v.length() > diff.length():
					step_v = diff
				st["pos"] = pos + step_v
				st["moving"] = true
				st["anim_t"] = float(st.get("anim_t", 0.0)) + delta * 6.0
				if absf(diff.x) > absf(diff.y):
					st["dir"] = 2 if diff.x > 0 else 1
				else:
					st["dir"] = 0 if diff.y > 0 else 3
		else:
			st["moving"] = false
		npc_states[nid] = st

	_rumor_cooldown -= delta
	if _rumor_cooldown <= 0.0:
		_rumor_cooldown = 4.0
		check_rumor_encounters()


func check_rumor_encounters() -> void:
	var ids: Array = npc_states.keys()
	for i in range(ids.size()):
		for j in range(i + 1, ids.size()):
			var st_a: Dictionary = npc_states[ids[i]]
			var st_b: Dictionary = npc_states[ids[j]]
			if str(st_a.get("zone", "")) != str(st_b.get("zone", "")):
				continue
			var d_px: float = (st_a["pos"] as Vector2).distance_to(st_b["pos"] as Vector2)
			if d_px <= ZoneManager.TILE_SIZE * 3.2:
				var spread_fact: String = WorldMemory.try_spread_rumor(str(ids[i]), str(ids[j]))
				if not spread_fact.is_empty():
					st_a["bubble"] = "💬 传闻交流"
					st_a["bubble_timer"] = 3.5
					st_b["bubble"] = "💬 原来如此!"
					st_b["bubble_timer"] = 3.5
					npc_states[ids[i]] = st_a
					npc_states[ids[j]] = st_b
					return


func get_npcs_in_zone(zone_id: String) -> Array:
	var out: Array = []
	for nid in npc_states.keys():
		var st: Dictionary = npc_states[nid]
		if str(st.get("zone", "")) == zone_id:
			out.append(st)
	return out


func find_npc_near_pos(zone_id: String, world_pos: Vector2, max_dist: float = 44.0) -> String:
	var best_id: String = ""
	var best_d: float = max_dist
	for st in get_npcs_in_zone(zone_id):
		var d: float = (st["pos"] as Vector2).distance_to(world_pos)
		if d < best_d:
			best_d = d
			best_id = str(st.get("id", ""))
	return best_id


func give_gift(npc_id: String, item_id: String) -> Dictionary:
	var f: Dictionary = GameState.npc_friendship.get(npc_id, {"points": 0, "talked_today": false, "gifted_today": false})
	if bool(f.get("gifted_today", false)):
		return {"ok": false, "msg": "今天已经送过礼物啦！"}
	var npc: Dictionary = DataRegistry.get_npc(npc_id)
	var loves: Array = npc.get("loves", [])
	var likes: Array = npc.get("likes", [])
	var dislikes: Array = npc.get("dislikes", [])
	var pts: int = 20
	var reaction: String = "谢谢你的礼物，我会好好收下的！"
	if loves.has(item_id):
		pts = 80
		reaction = "哇！！这正是我最梦寐以求的宝贝！太谢谢你了！"
	elif likes.has(item_id):
		pts = 45
		reaction = "真贴心，我很喜欢这个，多谢！"
	elif dislikes.has(item_id):
		pts = -25
		reaction = "呃……这个稍微有点不太合我的口味呢……"

	GameState.add_friendship(npc_id, pts)
	var updated_f: Dictionary = GameState.npc_friendship[npc_id]
	updated_f["gifted_today"] = true
	GameState.npc_friendship[npc_id] = updated_f
	AudioManager.play_sfx("harvest" if pts > 0 else "ui_click")
	return {"ok": true, "msg": reaction, "points": pts}


func serialize() -> Dictionary:
	var ser: Dictionary = {}
	for nid in npc_states.keys():
		var st: Dictionary = npc_states[nid]
		var p: Vector2 = st["pos"]
		ser[nid] = {
			"zone": str(st.get("zone", "town")),
			"x": p.x,
			"y": p.y,
			"dir": int(st.get("dir", 0)),
			"activity": str(st.get("activity", "")),
		}
	return ser


func deserialize(data: Dictionary, zone_mgr: ZoneManager) -> void:
	init_npcs(zone_mgr)
	for nid in data.keys():
		if npc_states.has(nid):
			var sd: Dictionary = data[nid]
			var st: Dictionary = npc_states[nid]
			st["zone"] = str(sd.get("zone", st["zone"]))
			st["pos"] = Vector2(float(sd.get("x", 320.0)), float(sd.get("y", 320.0)))
			st["dir"] = int(sd.get("dir", 0))
			st["activity"] = str(sd.get("activity", ""))
			npc_states[nid] = st
