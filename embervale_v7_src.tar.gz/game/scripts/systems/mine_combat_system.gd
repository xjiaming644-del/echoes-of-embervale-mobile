class_name MineCombatSystem
extends Node

var monsters: Array = []
var _next_uid: int = 1


func populate_floor(zone_mgr: ZoneManager, floor_num: int) -> void:
	monsters.clear()
	var count: int = clampi(2 + int(floor_num / 2), 2, 7)
	var rng: RandomNumberGenerator = RandomNumberGenerator.new()
	rng.seed = 4000 + floor_num * 73 + GameState.day * 19
	var spawned: int = 0
	var attempts: int = 0
	while spawned < count and attempts < 60:
		attempts += 1
		var gx: int = rng.randi_range(3, 18)
		var gy: int = rng.randi_range(2, 12)
		if not zone_mgr.is_walkable("mine", Vector2i(gx, gy)):
			continue
		var kind: String = "shadow_bug" if (floor_num >= 4 and rng.randf() < 0.45) else "slime"
		var max_hp: float = 28.0 + floor_num * 6.0 if kind == "slime" else 42.0 + floor_num * 8.0
		monsters.append({
			"uid": _next_uid,
			"kind": kind,
			"pos": Vector2(gx * ZoneManager.TILE_SIZE + 16, gy * ZoneManager.TILE_SIZE + 16),
			"vel": Vector2.ZERO,
			"hp": max_hp,
			"max_hp": max_hp,
			"dmg": 7.0 + floor_num * 1.5,
			"hit_flash": 0.0,
			"attack_cd": 0.0,
			"anim_t": rng.randf() * 4.0,
		})
		_next_uid += 1
		spawned += 1

	if floor_num % 10 == 0:
		var b_hp: float = 180.0 + floor_num * 8.0
		monsters.append({
			"uid": _next_uid,
			"kind": "echo_boss",
			"pos": Vector2(11 * ZoneManager.TILE_SIZE + 16, 7 * ZoneManager.TILE_SIZE + 16),
			"vel": Vector2.ZERO,
			"hp": b_hp,
			"max_hp": b_hp,
			"dmg": 14.0,
			"hit_flash": 0.0,
			"attack_cd": 0.0,
			"dash_cd": 3.0,
			"anim_t": 0.0,
		})
		_next_uid += 1
		EventBus.toast_message.emit("⚠️ 矿洞深处震动！【回响晶甲王】现身第 %d 层！" % floor_num, Color(1.0, 0.45, 0.75))


func populate_secret_woods(zone_mgr: ZoneManager) -> void:
	monsters.clear()
	var wisp_spots: Array = [Vector2i(9, 7), Vector2i(17, 8), Vector2i(15, 13)]
	for sp in wisp_spots:
		var p: Vector2i = sp
		if zone_mgr.is_walkable("secret_woods", p):
			monsters.append({
				"uid": _next_uid,
				"kind": "forest_wisp",
				"pos": Vector2(p.x * 32 + 16, p.y * 32 + 16),
				"vel": Vector2.ZERO,
				"hp": 52.0,
				"max_hp": 52.0,
				"dmg": 9.0,
				"hit_flash": 0.0,
				"attack_cd": 0.0,
				"anim_t": randf() * 4.0,
			})
			_next_uid += 1
	monsters.append({
		"uid": _next_uid,
		"kind": "ancient_treant",
		"pos": Vector2(13 * 32 + 16, 10 * 32 + 16),
		"vel": Vector2.ZERO,
		"hp": 240.0,
		"max_hp": 240.0,
		"dmg": 15.0,
		"hit_flash": 0.0,
		"attack_cd": 0.0,
		"dash_cd": 3.5,
		"anim_t": 0.0,
	})
	_next_uid += 1


func tick(delta: float, zone_mgr: ZoneManager, player_pos: Vector2, on_player_hit: Callable) -> void:
	var cz: String = GameState.current_zone
	if cz != "mine" and cz != "secret_woods":
		return
	for i in range(monsters.size() - 1, -1, -1):
		var m: Dictionary = monsters[i]
		m["anim_t"] = float(m.get("anim_t", 0.0)) + delta * 6.0
		if float(m.get("hit_flash", 0.0)) > 0.0:
			m["hit_flash"] = maxf(0.0, float(m["hit_flash"]) - delta)
		if float(m.get("attack_cd", 0.0)) > 0.0:
			m["attack_cd"] = maxf(0.0, float(m["attack_cd"]) - delta)

		var pos: Vector2 = m["pos"]
		var vel: Vector2 = m["vel"]
		if vel.length() > 8.0:
			var next_p: Vector2 = pos + vel * delta
			var ng: Vector2i = Vector2i(int(next_p.x / ZoneManager.TILE_SIZE), int(next_p.y / ZoneManager.TILE_SIZE))
			if zone_mgr.is_walkable(cz, ng):
				pos = next_p
			vel = vel.lerp(Vector2.ZERO, minf(1.0, delta * 9.0))
		else:
			var to_p: Vector2 = player_pos - pos
			var dist: float = to_p.length()
			var knd0: String = str(m.get("kind", ""))
			if knd0 == "echo_boss" or knd0 == "ancient_treant":
				var dcd: float = float(m.get("dash_cd", 3.0)) - delta
				if dcd <= 0.0 and dist < 280.0 and dist > 20.0:
					m["dash_cd"] = 3.4
					m["vel"] = to_p.normalized() * 220.0
				else:
					m["dash_cd"] = dcd
			if dist < 240.0 and dist > 16.0:
				var spd: float = 42.0 if knd0 == "slime" else (54.0 if (knd0 == "echo_boss" or knd0 == "ancient_treant") else 64.0)
				var cand: Vector2 = pos + to_p.normalized() * spd * delta
				var cg: Vector2i = Vector2i(int(cand.x / ZoneManager.TILE_SIZE), int(cand.y / ZoneManager.TILE_SIZE))
				if zone_mgr.is_walkable(cz, cg):
					pos = cand
			if dist <= 22.0 and float(m.get("attack_cd", 0.0)) <= 0.0:
				m["attack_cd"] = 1.0
				if on_player_hit.is_valid():
					on_player_hit.call(float(m.get("dmg", 8.0)))

		m["pos"] = pos
		m["vel"] = vel
		monsters[i] = m


func swing_blade_at(zone_mgr: ZoneManager, center: Vector2, facing_dir: Vector2) -> int:
	AudioManager.play_sfx("sword_swing")
	var hits: int = 0
	var base_dmg: float = 16.0 + GameState.get_skill_level("mining") * 2.5 + (GameState.get_tool_level("blade") - 1) * 10.0
	var dmg: float = base_dmg * (1.35 if GameState.has_keepsake("kailuo") else 1.0)

	# Also cut weeds in front
	var front_g: Vector2i = Vector2i(int((center.x + facing_dir.x * 26.0) / ZoneManager.TILE_SIZE), int((center.y + facing_dir.y * 26.0) / ZoneManager.TILE_SIZE))
	var obj: Dictionary = zone_mgr.get_object(GameState.current_zone, front_g)
	if not obj.is_empty() and str(obj.get("type", "")) == "weed":
		zone_mgr.remove_object(GameState.current_zone, front_g)
		zone_mgr.spawn_drop(GameState.current_zone, Vector2(front_g.x * 32 + 16, front_g.y * 32 + 16), "fiber", randi_range(1, 2))
		if randf() < 0.55:
			zone_mgr.spawn_drop(GameState.current_zone, Vector2(front_g.x * 32 + 16, front_g.y * 32 + 16), "hay", 1)
		AudioManager.play_sfx("chop")

	var cz2: String = GameState.current_zone
	if cz2 != "mine" and cz2 != "secret_woods":
		return 0

	for i in range(monsters.size() - 1, -1, -1):
		var m: Dictionary = monsters[i]
		var mp: Vector2 = m["pos"]
		var to_m: Vector2 = mp - center
		if to_m.length() <= 58.0 and (to_m.length() < 22.0 or to_m.normalized().dot(facing_dir.normalized()) > -0.20):
			hits += 1
			var new_hp: float = float(m.get("hp", 30.0)) - dmg
			m["hp"] = new_hp
			m["hit_flash"] = 0.18
			m["vel"] = to_m.normalized() * 190.0 if to_m.length() > 1.0 else facing_dir * 190.0
			AudioManager.play_sfx("monster_hit")
			EventBus.floating_text.emit(mp - Vector2(0, 12), "-%d" % int(dmg), Color(1.0, 0.38, 0.32))
			if new_hp <= 0.0:
				var kind: String = str(m.get("kind", "slime"))
				if kind == "echo_boss":
					zone_mgr.spawn_drop("mine", mp, "echo_crystal", 2)
					zone_mgr.spawn_drop("mine", mp, "gold_bar", 1)
					GameState.add_skill_xp("mining", 60)
					WorldMemory.record_fact("boss_defeated", "在矿洞第10层击败了【回响晶甲王】", "horn")
					EventBus.toast_message.emit("🏆 讨伐成功！击败【回响晶甲王】掉落回响水晶×2 与金锭×1！", Color(1.0, 0.88, 0.35))
					_ensure_mine_ladder(zone_mgr, Vector2i(int(mp.x / 32), int(mp.y / 32)))
				elif kind == "ancient_treant":
					zone_mgr.spawn_drop("secret_woods", mp, "seed_ancient_fruit", 2)
					zone_mgr.spawn_drop("secret_woods", mp, "hardwood", 5)
					zone_mgr.spawn_drop("secret_woods", mp, "echo_crystal", 1)
					GameState.add_skill_xp("foraging", 65)
					WorldMemory.record_fact("treant_defeated", "在迷雾秘林击败了【远古树精守护者】获得远古星露种子", "kailuo")
					EventBus.toast_message.emit("🌳 秘林传奇！击败【远古树精守护者】获得远古星露种子×2 与千年铁木×5！", Color(0.65, 1.0, 0.72))
				elif kind == "forest_wisp":
					zone_mgr.spawn_drop("secret_woods", mp, "spring_herb", 1)
					if randf() < 0.45:
						zone_mgr.spawn_drop("secret_woods", mp, "mystic_truffle", 1)
					GameState.add_skill_xp("foraging", 16)
				else:
					var drop_id: String = "slime_gel" if kind == "slime" else "bug_chitin"
					zone_mgr.spawn_drop("mine", mp, drop_id, randi_range(1, 2))
					if randf() < 0.25:
						zone_mgr.spawn_drop("mine", mp, "copper_ore", 1)
					GameState.add_skill_xp("mining", 14)
				monsters.remove_at(i)
				if cz2 == "mine" and monsters.is_empty():
					_ensure_mine_ladder(zone_mgr, Vector2i(int(mp.x / 32), int(mp.y / 32)))
			else:
				monsters[i] = m
	return hits


func _ensure_mine_ladder(zone_mgr: ZoneManager, near_grid: Vector2i) -> void:
	var mine: Dictionary = zone_mgr.get_zone("mine")
	var objs: Dictionary = mine.get("objects", {})
	for ok in objs.keys():
		var obj: Dictionary = objs[ok]
		if str(obj.get("type", "")) == "ladder_down":
			return
	zone_mgr.set_object("mine", near_grid, {"type": "ladder_down", "solid": false, "sprite": "objects/ladder_down.png", "label": "下行矿梯"})
	EventBus.toast_message.emit("🪜 矿洞深处显露出了通往下一层的矿梯！", Color(0.65, 0.95, 0.75))


func hit_mine_rock(zone_mgr: ZoneManager, pos: Vector2i) -> bool:
	var obj: Dictionary = zone_mgr.get_object("mine", pos)
	if obj.is_empty() or str(obj.get("type", "")) != "mine_rock":
		return false
	var hp: int = int(obj.get("hp", 2)) - (GameState.get_tool_level("pickaxe") + GameState.get_buff_tool_power())
	AudioManager.play_sfx("mine_hit")
	if hp > 0:
		obj["hp"] = hp
		zone_mgr.set_object("mine", pos, obj)
		return true

	var okind: String = str(obj.get("ore_kind", "rock"))
	var has_lad: bool = bool(obj.get("has_ladder", false))
	zone_mgr.remove_object("mine", pos)
	var wp: Vector2 = Vector2(pos.x * 32 + 16, pos.y * 32 + 16)
	var drop_id: String = "stone"
	var qty: int = randi_range(1, 3)
	if okind == "ore_copper":
		drop_id = "copper_ore"
	elif okind == "ore_iron":
		drop_id = "iron_ore"
	elif okind == "ore_gold":
		drop_id = "gold_ore"
	elif okind == "ore_crystal":
		drop_id = "echo_crystal"
		qty = 1
	zone_mgr.spawn_drop("mine", wp, drop_id, qty)
	GameState.add_skill_xp("mining", 8)
	if has_lad or randf() < 0.22:
		zone_mgr.set_object("mine", pos, {"type": "ladder_down", "solid": false, "sprite": "objects/ladder_down.png", "label": "下行矿梯"})
		EventBus.toast_message.emit("🪜 敲碎岩石发现了下行矿梯！", Color(0.7, 0.95, 0.7))
	return true
