class_name PetFishPondSystem
extends Node

var pet_pos: Vector2 = Vector2(240.0, 280.0)
var pet_dir: int = 0
var pet_moving: bool = false
var pet_anim_t: float = 0.0
var pet_bubble: String = ""
var _bubble_t: float = 0.0
var _treasure_cd: float = 38.0


func sync_pet_near_player(p_pos: Vector2) -> void:
	pet_pos = p_pos + Vector2(-28.0, 14.0)


func is_pet_active_in_zone(zid: String) -> bool:
	return zid in ["farm", "ranch", "town", "lake", "secret_woods", "coral_island"]


func tick(delta: float, zone_mgr: ZoneManager, player_pos: Vector2) -> void:
	if _bubble_t > 0.0:
		_bubble_t = maxf(0.0, _bubble_t - delta)
		if _bubble_t <= 0.0:
			pet_bubble = ""

	var zid: String = GameState.current_zone
	if not is_pet_active_in_zone(zid):
		pet_moving = false
		return

	var z: Dictionary = zone_mgr.get_zone(zid)
	var drops: Array = z.get("drops", [])
	var fetch_idx: int = -1
	var best_d: float = 165.0
	for i in range(drops.size()):
		var dd: Dictionary = drops[i]
		if float(dd.get("age", 1.0)) < 0.25:
			continue
		var dp: Vector2 = Vector2(float(dd.get("x", 0.0)), float(dd.get("y", 0.0)))
		var dist: float = dp.distance_to(player_pos)
		if dist > 20.0 and dist < best_d:
			best_d = dist
			fetch_idx = i

	var target: Vector2 = player_pos + Vector2(-28.0, 12.0)
	if fetch_idx >= 0:
		var target_drop: Dictionary = drops[fetch_idx]
		target = Vector2(float(target_drop.get("x", 0.0)), float(target_drop.get("y", 0.0)))
		if pet_pos.distance_to(target) < 18.0:
			var moved: Vector2 = target.move_toward(player_pos, 320.0 * delta)
			target_drop["x"] = moved.x
			target_drop["y"] = moved.y
			drops[fetch_idx] = target_drop

	var diff: Vector2 = target - pet_pos
	if diff.length() > 8.0:
		pet_moving = true
		pet_anim_t += delta * 8.0
		pet_dir = 1 if diff.x < 0.0 else 0
		var spd: float = 158.0 if fetch_idx >= 0 else 128.0
		pet_pos += diff.normalized() * minf(diff.length(), spd * delta)
	else:
		pet_moving = false

	# Occasional truffle/pearl sniffing in farm, secret_woods, or coral_island
	if zid in ["farm", "secret_woods", "coral_island"] and int(GameState.pet_data.get("affection", 80)) >= 80:
		_treasure_cd -= delta
		if _treasure_cd <= 0.0:
			_treasure_cd = 55.0
			try_dig_treasure(zone_mgr, zid)


func try_dig_treasure(zone_mgr: ZoneManager, zid: String) -> bool:
	var prize_id: String = "coral_pearl" if zid == "coral_island" else "mystic_truffle"
	zone_mgr.spawn_drop(zid, pet_pos + Vector2(0, 6), prize_id, 1, 0)
	var is_dog: bool = str(GameState.pet_data.get("kind", "cat")) == "dog"
	if prize_id == "coral_pearl":
		pet_bubble = "🐾 汪!刨到珍珠!" if is_dog else "🐾 喵!发现珍珠!"
	else:
		pet_bubble = "🐾 汪!挖到松露!" if is_dog else "🐾 喵!发现松露!"
	_bubble_t = 3.0
	AudioManager.play_sfx("harvest")
	return true


func try_pet_companion(click_pos: Vector2) -> bool:
	if not is_pet_active_in_zone(GameState.current_zone):
		return false
	if pet_pos.distance_to(click_pos) > 42.0:
		return false
	var pname: String = str(GameState.pet_data.get("name", "团子"))
	var is_dog: bool = str(GameState.pet_data.get("kind", "cat")) == "dog"
	if not bool(GameState.pet_data.get("petted_today", false)):
		GameState.pet_data["petted_today"] = true
		GameState.pet_data["affection"] = clampi(int(GameState.pet_data.get("affection", 80)) + 45, 0, 1000)
		pet_bubble = "❤️ 汪汪~" if is_dog else "❤️ 呼噜噜~"
		_bubble_t = 2.4
		AudioManager.play_sfx("harvest")
		EventBus.floating_text.emit(pet_pos - Vector2(0, 20), "🐾 %s 好感+45" % pname, Color(1.0, 0.65, 0.78))
	else:
		pet_bubble = "♪ 摇尾巴" if is_dog else "♪ 蹭蹭你"
		_bubble_t = 1.8
		AudioManager.play_sfx("ui_click")
	return true


func switch_pet_kind(kind: String) -> void:
	GameState.pet_data["kind"] = kind
	GameState.pet_data["name"] = "柴犬旺财" if kind == "dog" else "橘猫团子"
	pet_bubble = "🐶 汪!" if kind == "dog" else "🐱 喵!"
	_bubble_t = 2.2
	AudioManager.play_sfx("harvest")


func interact_fish_pond(held_slot_idx: int) -> bool:
	var cur_id: String = str(GameState.fish_pond.get("fish_id", ""))
	var cur_cnt: int = int(GameState.fish_pond.get("count", 0))
	var slot: Dictionary = GameState.inventory[held_slot_idx] if (held_slot_idx >= 0 and held_slot_idx < GameState.inventory.size()) else {}
	if not slot.is_empty():
		var iid: String = str(slot.get("id", ""))
		var def: Dictionary = DataRegistry.get_item(iid)
		if str(def.get("category", "")) == "fish":
			if cur_cnt == 0 or (cur_id == iid and cur_cnt < 5):
				GameState.consume_slot(held_slot_idx, 1)
				GameState.fish_pond["fish_id"] = iid
				GameState.fish_pond["count"] = cur_cnt + 1
				AudioManager.play_sfx("fish_cast")
				var fnm: String = str(def.get("name", iid))
				EventBus.toast_message.emit("🐟 已将【%s】放养入活水鱼塘（当前种群 %d/5，每日产出晶莹鱼籽）！" % [fnm, cur_cnt + 1], Color(0.55, 0.92, 1.0))
				return true

	if cur_cnt <= 0:
		EventBus.toast_message.emit("🐟 生态活水鱼塘（空置）：请手持任意钓到的鱼按 E 放养繁育，每日可收晶莹鱼籽！", Color(0.68, 0.90, 1.0))
	else:
		var fnm2: String = str(DataRegistry.get_item(cur_id).get("name", cur_id))
		EventBus.toast_message.emit("🐟 生态活水鱼塘：正在繁育【%s】 (%d/5 条) · 鱼籽可放入腌制桶做成黄金鱼籽酱！" % [fnm2, cur_cnt], Color(0.68, 0.96, 0.88))
	return true


func process_overnight(zone_mgr: ZoneManager) -> int:
	var cnt: int = int(GameState.fish_pond.get("count", 0))
	if cnt <= 0:
		return 0
	var days: int = int(GameState.fish_pond.get("days", 0)) + 1
	if days >= 2 and cnt < 5:
		cnt += 1
		days = 0
	GameState.fish_pond["count"] = cnt
	GameState.fish_pond["days"] = days
	var roe_qty: int = 2 if cnt >= 4 else 1
	zone_mgr.spawn_drop("farm", Vector2(20 * 32 + 16, 17 * 32 + 8), "fish_roe", roe_qty, 0)
	return roe_qty
