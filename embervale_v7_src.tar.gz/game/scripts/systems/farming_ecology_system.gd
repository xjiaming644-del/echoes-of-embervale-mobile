class_name FarmingEcologySystem
extends Node

const DIRS_4: Array = [Vector2i(1, 0), Vector2i(-1, 0), Vector2i(0, 1), Vector2i(0, -1)]


func get_farm_tile(zone_mgr: ZoneManager, pos: Vector2i, zone_id: String = "farm") -> Dictionary:
	var farm: Dictionary = zone_mgr.get_zone(zone_id)
	var ft: Dictionary = farm.get("farm_tiles", {})
	return ft.get(ZoneManager.key(pos), {})


func set_farm_tile(zone_mgr: ZoneManager, pos: Vector2i, data: Dictionary, zone_id: String = "farm") -> void:
	var farm: Dictionary = zone_mgr.get_zone(zone_id)
	var ft: Dictionary = farm.get("farm_tiles", {})
	ft[ZoneManager.key(pos)] = data


func till_tile(zone_mgr: ZoneManager, pos: Vector2i, zone_id: String = "farm") -> bool:
	if not zone_mgr.is_tillable(zone_id, pos):
		return false
	var existing: Dictionary = get_farm_tile(zone_mgr, pos, zone_id)
	if bool(existing.get("tilled", false)):
		return false
	if not GameState.consume_energy(2.0):
		EventBus.toast_message.emit("体力不足！", Color(1.0, 0.5, 0.4))
		return false
	var vitality: float = float(existing.get("soil_vitality", 85.0))
	var watered_today: bool = (zone_id in ["farm", "coral_island"]) and (GameState.weather in ["rain", "storm"])
	set_farm_tile(zone_mgr, pos, {
		"tilled": true,
		"watered": watered_today,
		"fertilizer": "",
		"soil_vitality": vitality,
		"crop": {},
	}, zone_id)
	GameState.add_skill_xp("farming", 3)
	AudioManager.play_sfx("till")
	return true


func water_tile(zone_mgr: ZoneManager, pos: Vector2i, zone_id: String = "farm") -> bool:
	var ft: Dictionary = get_farm_tile(zone_mgr, pos, zone_id)
	if not bool(ft.get("tilled", false)):
		return false
	if GameState.watering_can_water <= 0:
		EventBus.toast_message.emit("水壶没水了！去池塘边按左键装水", Color(0.5, 0.85, 1.0))
		return false
	if not GameState.consume_energy(1.5):
		EventBus.toast_message.emit("体力不足！", Color(1.0, 0.5, 0.4))
		return false
	GameState.watering_can_water -= 1
	ft["watered"] = true
	set_farm_tile(zone_mgr, pos, ft, zone_id)
	AudioManager.play_sfx("water")
	EventBus.player_stats_changed.emit()
	return true


func apply_fertilizer(zone_mgr: ZoneManager, pos: Vector2i, fert_id: String, zone_id: String = "farm") -> bool:
	var ft: Dictionary = get_farm_tile(zone_mgr, pos, zone_id)
	if not bool(ft.get("tilled", false)):
		return false
	if not str(ft.get("fertilizer", "")).is_empty():
		return false
	ft["fertilizer"] = fert_id
	ft["soil_vitality"] = minf(100.0, float(ft.get("soil_vitality", 80.0)) + 20.0)
	set_farm_tile(zone_mgr, pos, ft, zone_id)
	AudioManager.play_sfx("plant")
	return true


func plant_seed(zone_mgr: ZoneManager, pos: Vector2i, seed_item_id: String, zone_id: String = "farm") -> bool:
	var item_def: Dictionary = DataRegistry.get_item(seed_item_id)
	var crop_id: String = str(item_def.get("crop_id", ""))
	if crop_id.is_empty():
		return false
	if zone_id != "greenhouse" and zone_id != "coral_island" and not GameState.can_plant_in_current_season(crop_id):
		EventBus.toast_message.emit("当前季节不适合播种该作物！", Color(1.0, 0.6, 0.4))
		return false
	var ft: Dictionary = get_farm_tile(zone_mgr, pos, zone_id)
	if not bool(ft.get("tilled", false)):
		EventBus.toast_message.emit("需要先用锄头翻地再播种", Color(1.0, 0.8, 0.4))
		return false
	var existing_crop: Dictionary = ft.get("crop", {})
	if not existing_crop.is_empty():
		return false

	ft["crop"] = {
		"id": crop_id,
		"growth_days": 0.0,
		"mature": false,
		"regrow_timer": 0.0,
		"giant": false,
	}
	set_farm_tile(zone_mgr, pos, ft, zone_id)
	AudioManager.play_sfx("plant")
	return true


func evaluate_tile_ecology(zone_mgr: ZoneManager, pos: Vector2i, zone_id: String = "farm") -> Dictionary:
	var ft: Dictionary = get_farm_tile(zone_mgr, pos, zone_id)
	var crop: Dictionary = ft.get("crop", {})
	var result: Dictionary = {
		"speed_bonus": 0.0,
		"quality_bonus": 0.0,
		"yield_bonus": 0,
		"pest_shield": false,
		"soil_heal": 0.0,
		"monoculture_count": 0,
		"active_synergies": [],
		"links": [],
	}
	if crop.is_empty():
		return result

	var cid: String = str(crop.get("id", ""))
	var vitality: float = float(ft.get("soil_vitality", 80.0))
	var mono_rules: Dictionary = DataRegistry.get_monoculture_rules()
	if vitality >= float(mono_rules.get("high_vitality_threshold", 75)):
		result["quality_bonus"] = float(result["quality_bonus"]) + float(mono_rules.get("high_vitality_quality_bonus", 0.25))
	elif vitality < float(mono_rules.get("low_vitality_threshold", 30)):
		result["speed_bonus"] = float(result["speed_bonus"]) - float(mono_rules.get("low_vitality_speed_penalty", 0.25))

	if str(ft.get("fertilizer", "")) == "fertilizer_speed":
		result["speed_bonus"] = float(result["speed_bonus"]) + 0.25
	if GameState.has_keepsake("linxia"):
		result["speed_bonus"] = float(result["speed_bonus"]) + 0.15
	result["quality_bonus"] = float(result["quality_bonus"]) + GameState.get_buff_luck_bonus()

	var farm: Dictionary = zone_mgr.get_zone(zone_id)
	var all_tiles: Dictionary = farm.get("farm_tiles", {})
	var synergies: Array = DataRegistry.get_synergies()
	var seen_syn: Dictionary = {}

	# Check neighbors up to radius 2
	for dy in range(-2, 3):
		for dx in range(-2, 3):
			if dx == 0 and dy == 0:
				continue
			var np: Vector2i = pos + Vector2i(dx, dy)
			var dist: int = absi(dx) + absi(dy)
			var cheb: int = maxi(absi(dx), absi(dy))
			var nft: Dictionary = all_tiles.get(ZoneManager.key(np), {})
			var ncrop: Dictionary = nft.get("crop", {})
			if ncrop.is_empty():
				continue
			var ncid: String = str(ncrop.get("id", ""))
			if dist == 1 and ncid == cid:
				result["monoculture_count"] = int(result["monoculture_count"]) + 1

			for s in synergies:
				var syn: Dictionary = s
				var rad: int = int(syn.get("radius", 1))
				if cheb > rad:
					continue
				var ca: String = str(syn.get("crop_a", ""))
				var cb: String = str(syn.get("crop_b", ""))
				var matched: bool = false
				if (cid == ca and (cb == "*" or ncid == cb)) or (cid == cb and (ca == "*" or ncid == ca)) or (ca == ncid and cb == "*"):
					if ncid != cid:
						matched = true
				if matched:
					var sid: String = str(syn.get("id", ""))
					if not seen_syn.has(sid):
						seen_syn[sid] = true
						var active_list: Array = result["active_synergies"]
						active_list.append(str(syn.get("name", sid)))
						var etype: String = str(syn.get("effect_type", ""))
						var bval: float = float(syn.get("bonus_value", 0.0))
						if etype == "speed":
							result["speed_bonus"] = float(result["speed_bonus"]) + bval
						elif etype == "quality":
							result["quality_bonus"] = float(result["quality_bonus"]) + bval
						elif etype == "yield":
							result["yield_bonus"] = int(result["yield_bonus"]) + int(bval)
						elif etype == "pest_shield":
							result["pest_shield"] = true
					var links: Array = result["links"]
					links.append({"to": np, "color": str(syn.get("color_hex", "#66BB6A")), "name": str(syn.get("name", ""))})

			if cheb <= 1 and ncid == "clover":
				result["soil_heal"] = float(result["soil_heal"]) + 8.0

	return result


func get_all_ecology_links(zone_mgr: ZoneManager, zone_id: String = "farm") -> Array:
	var links: Array = []
	var seen_pairs: Dictionary = {}
	var farm: Dictionary = zone_mgr.get_zone(zone_id)
	var all_tiles: Dictionary = farm.get("farm_tiles", {})
	for k in all_tiles.keys():
		var pos: Vector2i = ZoneManager.parse_key(str(k))
		var eco: Dictionary = evaluate_tile_ecology(zone_mgr, pos, zone_id)
		var t_links: Array = eco.get("links", [])
		for lk in t_links:
			var d: Dictionary = lk
			var to_p: Vector2i = d["to"]
			var pair_key: String = "%s|%s" % [ZoneManager.key(pos), ZoneManager.key(to_p)]
			var rev_key: String = "%s|%s" % [ZoneManager.key(to_p), ZoneManager.key(pos)]
			if not seen_pairs.has(pair_key) and not seen_pairs.has(rev_key):
				seen_pairs[pair_key] = true
				links.append({"from": pos, "to": to_p, "color": str(d.get("color", "#66BB6A")), "name": str(d.get("name", ""))})
	return links


func harvest_crop(zone_mgr: ZoneManager, pos: Vector2i, zone_id: String = "farm") -> bool:
	var ft: Dictionary = get_farm_tile(zone_mgr, pos, zone_id)
	var crop: Dictionary = ft.get("crop", {})
	if crop.is_empty() or not bool(crop.get("mature", false)):
		return false
	var cid: String = str(crop.get("id", ""))
	var crop_def: Dictionary = DataRegistry.get_crop(cid)
	var eco: Dictionary = evaluate_tile_ecology(zone_mgr, pos, zone_id)

	var hmin: int = int(crop_def.get("harvest_min", 1))
	var hmax: int = int(crop_def.get("harvest_max", 1))
	var qty: int = randi_range(hmin, hmax) + int(eco.get("yield_bonus", 0))
	var is_giant: bool = bool(crop.get("giant", false))
	if is_giant:
		qty *= 4
		WorldMemory.record_fact("giant_crop_harvested", "在农场收获了不可思议的巨型%s" % str(crop_def.get("name", cid)), "linxia")

	var q_chance: float = float(eco.get("quality_bonus", 0.0)) + GameState.get_skill_level("farming") * 0.04
	var qual: int = 0
	var r: float = randf()
	if r < q_chance * 0.45:
		qual = 2
	elif r < q_chance:
		qual = 1

	GameState.add_item(cid, qty, qual)
	GameState.add_skill_xp("farming", 10)
	var syn_arr: Array = eco.get("active_synergies", [])
	if syn_arr.size() > 0:
		GameState.add_skill_xp("ecology", 8 * syn_arr.size())
	AudioManager.play_sfx("harvest")

	var world_p: Vector2 = Vector2(pos.x * ZoneManager.TILE_SIZE + 16, pos.y * ZoneManager.TILE_SIZE)
	var badge: String = "★" if qual == 2 else ("☆" if qual == 1 else "")
	EventBus.floating_text.emit(world_p, "+%d %s%s" % [qty, str(crop_def.get("name", cid)), badge], Color(0.95, 0.95, 0.45))

	var regrow: int = int(crop_def.get("regrow_days", 0))
	if regrow > 0 and not is_giant:
		crop["mature"] = false
		crop["regrow_timer"] = 0.0
		ft["crop"] = crop
	else:
		ft["crop"] = {}
	set_farm_tile(zone_mgr, pos, ft, zone_id)
	return true


func process_overnight(zone_mgr: ZoneManager) -> void:
	_process_zone_overnight(zone_mgr, "farm")
	_process_zone_overnight(zone_mgr, "greenhouse")
	_process_zone_overnight(zone_mgr, "coral_island")
	_run_sprinklers(zone_mgr)


func _process_zone_overnight(zone_mgr: ZoneManager, zone_id: String) -> void:
	var farm: Dictionary = zone_mgr.get_zone(zone_id)
	if farm.is_empty():
		return
	var all_tiles: Dictionary = farm.get("farm_tiles", {})
	var mono_rules: Dictionary = DataRegistry.get_monoculture_rules()
	var is_raining: bool = (zone_id in ["farm", "coral_island"]) and (GameState.weather in ["rain", "storm"])

	# Precompute ecology snapshot before updating growth
	var eco_cache: Dictionary = {}
	for k in all_tiles.keys():
		var pos: Vector2i = ZoneManager.parse_key(str(k))
		eco_cache[k] = evaluate_tile_ecology(zone_mgr, pos, zone_id)

	for k in all_tiles.keys():
		var ft: Dictionary = all_tiles[k]
		var crop: Dictionary = ft.get("crop", {})
		if crop.is_empty():
			var vit: float = float(ft.get("soil_vitality", 80.0))
			ft["soil_vitality"] = minf(100.0, vit + float(mono_rules.get("fallow_recovery_per_day", 5)))
			ft["watered"] = is_raining
			all_tiles[k] = ft
			continue

		var cid: String = str(crop.get("id", ""))
		if zone_id != "greenhouse" and zone_id != "coral_island" and not GameState.can_plant_in_current_season(cid):
			ft["crop"] = {}
			ft["watered"] = is_raining
			all_tiles[k] = ft
			continue

		var eco: Dictionary = eco_cache.get(k, {})
		var mono_cnt: int = int(eco.get("monoculture_count", 0))
		var loss: float = float(mono_rules.get("monoculture_vitality_loss", 8)) if mono_cnt >= int(mono_rules.get("same_neighbor_threshold", 3)) else float(mono_rules.get("normal_vitality_loss", 2))
		var heal: float = float(eco.get("soil_heal", 0.0))
		var vit2: float = 100.0 if GameState.golden_clock_built else clampf(float(ft.get("soil_vitality", 80.0)) - loss + heal, 5.0, 100.0)
		ft["soil_vitality"] = vit2

		if bool(ft.get("watered", false)) or is_raining:
			var crop_def: Dictionary = DataRegistry.get_crop(cid)
			var step: float = maxf(0.4, 1.0 + float(eco.get("speed_bonus", 0.0)))
			if not bool(crop.get("mature", false)):
				var regrow_d: int = int(crop_def.get("regrow_days", 0))
				var days_need: float = float(crop_def.get("days_to_grow", 4))
				if float(crop.get("growth_days", 0.0)) >= days_need and regrow_d > 0:
					var rt: float = float(crop.get("regrow_timer", 0.0)) + step
					crop["regrow_timer"] = rt
					if rt >= float(regrow_d):
						crop["mature"] = true
				else:
					var gd: float = float(crop.get("growth_days", 0.0)) + step
					crop["growth_days"] = gd
					if gd >= days_need:
						crop["mature"] = true
						if bool(crop_def.get("giant_capable", false)) and randf() < (0.12 + float(eco.get("yield_bonus", 0)) * 0.12):
							crop["giant"] = true
			ft["crop"] = crop

		ft["watered"] = is_raining
		all_tiles[k] = ft


func _run_sprinklers(zone_mgr: ZoneManager) -> void:
	for sz in ["farm", "coral_island"]:
		var farm: Dictionary = zone_mgr.get_zone(str(sz))
		var objs: Dictionary = farm.get("objects", {})
		var all_tiles: Dictionary = farm.get("farm_tiles", {})
		for ok in objs.keys():
			var obj: Dictionary = objs[ok]
			if str(obj.get("type", "")) != "machine":
				continue
			var mtype: String = str(obj.get("machine_type", ""))
			if mtype != "sprinkler" and mtype != "quality_sprinkler":
				continue
			var pos: Vector2i = ZoneManager.parse_key(str(ok))
			var offsets: Array = DIRS_4 if mtype == "sprinkler" else [
				Vector2i(-1, -1), Vector2i(0, -1), Vector2i(1, -1),
				Vector2i(-1, 0), Vector2i(1, 0),
				Vector2i(-1, 1), Vector2i(0, 1), Vector2i(1, 1),
			]
			for off in offsets:
				var tk: String = ZoneManager.key(pos + (off as Vector2i))
				if all_tiles.has(tk):
					var ft: Dictionary = all_tiles[tk]
					if bool(ft.get("tilled", false)):
						ft["watered"] = true
						all_tiles[tk] = ft
