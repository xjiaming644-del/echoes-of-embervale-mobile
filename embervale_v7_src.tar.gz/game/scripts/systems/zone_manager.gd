class_name ZoneManager
extends Node

const TILE_SIZE: int = 32

# Tile ids matching terrain_atlas.png (10x2):
const T_GRASS1: int = 0
const T_GRASS2: int = 1
const T_DIRT: int = 2
const T_COBBLE: int = 3
const T_WOOD: int = 4
const T_MINE_FLOOR: int = 5
const T_TILLED_DRY: int = 6
const T_TILLED_WET: int = 7
const T_WATER1: int = 8
const T_WATER2: int = 9
const T_MINE_WALL: int = 10
const T_HEDGE: int = 11
const T_CLIFF: int = 12
const T_SNOW: int = 13
const T_AUTUMN: int = 14
const T_RUG: int = 15
const T_SUMMER_GRASS: int = 16
const T_DOCK: int = 17
const T_PETAL_GRASS: int = 18
const T_SAND: int = 19

var zones: Dictionary = {}


static func key(pos: Vector2i) -> String:
	return "%d,%d" % [pos.x, pos.y]


static func parse_key(k: String) -> Vector2i:
	var parts: PackedStringArray = k.split(",")
	if parts.size() != 2:
		return Vector2i.ZERO
	return Vector2i(int(parts[0]), int(parts[1]))


func _ready() -> void:
	init_all_zones()


func init_all_zones() -> void:
	zones.clear()
	zones["farm"] = _build_farm()
	zones["farmhouse"] = _build_farmhouse()
	zones["greenhouse"] = _build_greenhouse()
	zones["ranch"] = _build_ranch()
	zones["secret_woods"] = _build_secret_woods()
	zones["town"] = _build_town()
	zones["lake"] = _build_lake()
	zones["coral_island"] = _build_coral_island()
	zones["mine"] = _build_mine(1)
	sync_farm_wonders()


func get_zone(zone_id: String) -> Dictionary:
	return zones.get(zone_id, {})


func get_zone_size(zone_id: String) -> Vector2i:
	var z: Dictionary = get_zone(zone_id)
	return Vector2i(int(z.get("width", 20)), int(z.get("height", 20)))


func get_tile(zone_id: String, pos: Vector2i) -> int:
	var z: Dictionary = get_zone(zone_id)
	var grid: Array = z.get("terrain", [])
	if pos.y < 0 or pos.y >= grid.size():
		return T_HEDGE
	var row: Array = grid[pos.y]
	if pos.x < 0 or pos.x >= row.size():
		return T_HEDGE
	return int(row[pos.x])


func is_water_tile(zone_id: String, pos: Vector2i) -> bool:
	var t: int = get_tile(zone_id, pos)
	return t == T_WATER1 or t == T_WATER2


func is_tillable(zone_id: String, pos: Vector2i) -> bool:
	if zone_id != "farm" and zone_id != "greenhouse" and zone_id != "coral_island":
		return false
	var t: int = get_tile(zone_id, pos)
	if zone_id == "greenhouse":
		return t == T_TILLED_DRY or t == T_TILLED_WET
	if not (t in [T_GRASS1, T_GRASS2, T_PETAL_GRASS, T_SUMMER_GRASS, T_AUTUMN, T_SNOW]):
		return false
	var z: Dictionary = get_zone(zone_id)
	var objs: Dictionary = z.get("objects", {})
	if objs.has(key(pos)):
		return false
	# Prevent tilling right in front of farmhouse door
	if zone_id == "farm" and pos.x >= 5 and pos.x <= 9 and pos.y >= 3 and pos.y <= 7:
		return false
	return true


func is_walkable(zone_id: String, pos: Vector2i) -> bool:
	var sz: Vector2i = get_zone_size(zone_id)
	if pos.x < 0 or pos.y < 0 or pos.x >= sz.x or pos.y >= sz.y:
		return false
	var t: int = get_tile(zone_id, pos)
	if t in [T_WATER1, T_WATER2, T_MINE_WALL, T_HEDGE, T_CLIFF]:
		return false
	var z: Dictionary = get_zone(zone_id)
	var objs: Dictionary = z.get("objects", {})
	var k: String = key(pos)
	if objs.has(k):
		var obj: Dictionary = objs[k]
		if bool(obj.get("solid", true)):
			return false
	var solids: Array = z.get("building_footprints", [])
	for rect_arr in solids:
		var r: Array = rect_arr
		if pos.x >= int(r[0]) and pos.x <= int(r[2]) and pos.y >= int(r[1]) and pos.y <= int(r[3]):
			return false
	return true


func get_warp_at(zone_id: String, pos: Vector2i) -> Dictionary:
	var z: Dictionary = get_zone(zone_id)
	var warps: Dictionary = z.get("warps", {})
	return warps.get(key(pos), {})


func get_object(zone_id: String, pos: Vector2i) -> Dictionary:
	var z: Dictionary = get_zone(zone_id)
	var objs: Dictionary = z.get("objects", {})
	return objs.get(key(pos), {})


func set_object(zone_id: String, pos: Vector2i, obj: Dictionary) -> void:
	var z: Dictionary = get_zone(zone_id)
	var objs: Dictionary = z.get("objects", {})
	objs[key(pos)] = obj


func remove_object(zone_id: String, pos: Vector2i) -> void:
	var z: Dictionary = get_zone(zone_id)
	var objs: Dictionary = z.get("objects", {})
	objs.erase(key(pos))


func spawn_drop(zone_id: String, world_pos: Vector2, item_id: String, count: int = 1, quality: int = 0) -> void:
	var z: Dictionary = get_zone(zone_id)
	var drops: Array = z.get("drops", [])
	drops.append({
		"x": world_pos.x + randf_range(-10.0, 10.0),
		"y": world_pos.y + randf_range(-8.0, 8.0),
		"vx": randf_range(-38.0, 38.0),
		"vy": randf_range(-26.0, 26.0),
		"z": 4.0,
		"vz": randf_range(110.0, 155.0),
		"age": 0.0,
		"item_id": item_id,
		"count": count,
		"quality": quality,
	})


func _make_grid(w: int, h: int, fill_tile: int) -> Array:
	var g: Array = []
	for y in range(h):
		var row: Array = []
		for x in range(w):
			row.append(fill_tile)
		g.append(row)
	return g


func _build_farm() -> Dictionary:
	var w: int = 34
	var h: int = 24
	var terrain: Array = _make_grid(w, h, T_GRASS1)
	var rng: RandomNumberGenerator = RandomNumberGenerator.new()
	rng.seed = 101

	for y in range(h):
		for x in range(w):
			if x == 0 or x == w - 1 or y == 0 or y == h - 1:
				terrain[y][x] = T_HEDGE
			elif rng.randf() < 0.22:
				terrain[y][x] = T_GRASS2

	# Paths (west to ranch, east to town, north to mine)
	for x in range(0, 34):
		terrain[11][x] = T_DIRT
		terrain[12][x] = T_DIRT
	for y in range(6, 12):
		terrain[y][7] = T_DIRT
	for y in range(0, 11):
		terrain[y][16] = T_DIRT
		terrain[y][17] = T_DIRT

	# Pond
	for y in range(16, 21):
		for x in range(23, 30):
			terrain[y][x] = T_WATER1 if (x + y) % 2 == 0 else T_WATER2
	for x in range(22, 31):
		terrain[15][x] = T_SAND
		terrain[21][x] = T_SAND

	var objects: Dictionary = {}
	# Shipping Bin & Starter Machines
	objects[key(Vector2i(11, 6))] = {"type": "shipping_bin", "solid": true, "sprite": "objects/shipping_bin.png", "label": "出货箱"}
	objects[key(Vector2i(10, 7))] = {"type": "machine", "machine_type": "chest", "solid": true, "sprite": "objects/machine_chest.png", "stored": [{"id": "fertilizer_speed", "count": 3, "quality": 0}]}
	objects[key(Vector2i(12, 7))] = {"type": "machine", "machine_type": "jar", "solid": true, "sprite": "objects/machine_jar.png", "processing": {}}
	objects[key(Vector2i(6, 7))] = {"type": "pet_bowl", "solid": true, "sprite": "objects/pet_bowl.png", "label": "萌宠小窝(按E切猫/狗)"}
	objects[key(Vector2i(20, 16))] = {"type": "fish_pond", "solid": true, "sprite": "objects/fish_pond.png", "label": "活水鱼塘(持鱼按E放养)"}
	objects[key(Vector2i(25, 5))] = {"type": "greenhouse_door", "solid": false, "sprite": "", "label": "四季温室(按E进入/修复)"}
	objects[key(Vector2i(2, 10))] = {"type": "ranch_sign", "solid": true, "sprite": "objects/ranch_sign.png", "label": "⬅️ 阳光牧场"}

	# Starter Welcome Farm Patch (6x4) with pre-planted companion crops!
	var farm_tiles: Dictionary = {}
	for py in range(13, 17):
		for px in range(6, 12):
			farm_tiles[key(Vector2i(px, py))] = {
				"tilled": true,
				"watered": true,
				"fertilizer": "",
				"soil_vitality": 90.0,
				"crop": {},
			}
	farm_tiles[key(Vector2i(7, 14))]["crop"] = {"id": "sunbell", "growth_days": 5.0, "mature": false, "regrow_timer": 0.0}
	farm_tiles[key(Vector2i(8, 14))]["crop"] = {"id": "moonberry", "growth_days": 7.0, "mature": false, "regrow_timer": 0.0}
	farm_tiles[key(Vector2i(7, 15))]["crop"] = {"id": "turnip", "growth_days": 3.0, "mature": false, "regrow_timer": 0.0}
	farm_tiles[key(Vector2i(8, 15))]["crop"] = {"id": "clover", "growth_days": 3.0, "mature": true, "regrow_timer": 0.0}

	# Natural debris (trees, rocks, weeds) outside starter area
	for y in range(2, h - 2):
		for x in range(2, w - 2):
			if terrain[y][x] in [T_DIRT, T_WATER1, T_WATER2, T_SAND]:
				continue
			if x <= 4 and y >= 9 and y <= 13:
				continue
			if x >= 4 and x <= 14 and y >= 2 and y <= 17:
				continue
			if x >= 15 and x <= 21 and y <= 17:
				continue
			if x >= 23 and x <= 29 and y >= 1 and y <= 7:
				continue
			var k: String = key(Vector2i(x, y))
			if objects.has(k):
				continue
			var roll: float = rng.randf()
			if roll < 0.055:
				objects[k] = {"type": "tree", "hp": 4, "solid": true, "sprite": "objects/tree.png"}
			elif roll < 0.10:
				objects[k] = {"type": "rock", "hp": 2, "solid": true, "sprite": "objects/rock.png"}
			elif roll < 0.15:
				objects[k] = {"type": "weed", "hp": 1, "solid": false, "sprite": "objects/weed.png"}

	var warps: Dictionary = {
		key(Vector2i(7, 6)): {"to_zone": "farmhouse", "spawn": [7, 9]},
		key(Vector2i(0, 11)): {"to_zone": "ranch", "spawn": [25, 11]},
		key(Vector2i(0, 12)): {"to_zone": "ranch", "spawn": [25, 12]},
		key(Vector2i(33, 11)): {"to_zone": "town", "spawn": [2, 11]},
		key(Vector2i(33, 12)): {"to_zone": "town", "spawn": [2, 12]},
		key(Vector2i(16, 0)): {"to_zone": "mine", "spawn": [11, 14]},
		key(Vector2i(17, 0)): {"to_zone": "mine", "spawn": [11, 14]},
	}

	return {
		"id": "farm",
		"name": "回响农场",
		"width": w,
		"height": h,
		"terrain": terrain,
		"farm_tiles": farm_tiles,
		"objects": objects,
		"drops": [],
		"warps": warps,
		"buildings": [
			{"sprite": "objects/house_farm.png", "grid_pos": [5, 3], "size_tiles": [5, 4], "label": "我的农舍"},
			{"sprite": "objects/greenhouse.png", "grid_pos": [24, 2], "size_tiles": [4, 3], "label": "四季生态温室"}
		],
		"building_footprints": [
			[5, 3, 6, 6],
			[8, 3, 9, 6],
			[5, 3, 9, 5],
			[24, 2, 27, 4],
		],
	}


func _build_greenhouse() -> Dictionary:
	var w: int = 14
	var h: int = 12
	var terrain: Array = _make_grid(w, h, T_WOOD)
	var farm_tiles: Dictionary = {}
	for y in range(h):
		for x in range(w):
			if x == 0 or x == w - 1 or y == 0 or y == h - 1:
				terrain[y][x] = T_MINE_WALL
			elif x >= 3 and x <= 10 and y >= 3 and y <= 8:
				terrain[y][x] = T_TILLED_DRY
				farm_tiles[key(Vector2i(x, y))] = {
					"tilled": true,
					"watered": true,
					"fertilizer": "fertilizer_speed",
					"soil_vitality": 100.0,
					"crop": {},
				}
	terrain[5][1] = T_WATER1
	terrain[6][1] = T_WATER2
	terrain[11][6] = T_DIRT
	terrain[11][7] = T_DIRT
	var warps: Dictionary = {
		key(Vector2i(6, 11)): {"to_zone": "farm", "spawn": [25, 6]},
		key(Vector2i(7, 11)): {"to_zone": "farm", "spawn": [25, 6]},
		key(Vector2i(6, 10)): {"to_zone": "farm", "spawn": [25, 6]},
		key(Vector2i(7, 10)): {"to_zone": "farm", "spawn": [25, 6]},
	}
	return {
		"id": "greenhouse",
		"name": "四季生态温室",
		"width": w,
		"height": h,
		"terrain": terrain,
		"farm_tiles": farm_tiles,
		"objects": {},
		"drops": [],
		"warps": warps,
		"buildings": [],
		"building_footprints": [],
	}


func _build_farmhouse() -> Dictionary:
	var w: int = 14
	var h: int = 12
	var terrain: Array = _make_grid(w, h, T_WOOD)
	for y in range(h):
		for x in range(w):
			if x == 0 or x == w - 1 or y == 0 or y == h - 1:
				terrain[y][x] = T_MINE_WALL
			elif x >= 5 and x <= 8 and y >= 4 and y <= 7:
				terrain[y][x] = T_RUG
	terrain[11][6] = T_DIRT
	terrain[11][7] = T_DIRT

	var objects: Dictionary = {
		key(Vector2i(2, 3)): {"type": "bed", "solid": true, "sprite": "objects/bed.png", "label": "床铺(按E睡眠)"},
		key(Vector2i(5, 2)): {"type": "tv", "solid": true, "sprite": "objects/tv.png", "label": "占卜电视(按E收看)"},
		key(Vector2i(8, 2)): {"type": "kitchen_stove", "solid": true, "sprite": "objects/kitchen_stove.png", "label": "料理灶台(按E下厨)"},
		key(Vector2i(11, 3)): {"type": "machine", "machine_type": "chest", "solid": true, "sprite": "objects/machine_chest.png", "stored": [{"id": "wood", "count": 15, "quality": 0}]},
	}
	var warps: Dictionary = {
		key(Vector2i(6, 11)): {"to_zone": "farm", "spawn": [7, 7]},
		key(Vector2i(7, 11)): {"to_zone": "farm", "spawn": [7, 7]},
		key(Vector2i(6, 10)): {"to_zone": "farm", "spawn": [7, 7]},
		key(Vector2i(7, 10)): {"to_zone": "farm", "spawn": [7, 7]},
	}
	return {
		"id": "farmhouse",
		"name": "农舍室内",
		"width": w,
		"height": h,
		"terrain": terrain,
		"farm_tiles": {},
		"objects": objects,
		"drops": [],
		"warps": warps,
		"buildings": [],
		"building_footprints": [],
	}


func _build_town() -> Dictionary:
	var w: int = 34
	var h: int = 22
	var terrain: Array = _make_grid(w, h, T_GRASS1)
	for y in range(h):
		for x in range(w):
			if x == 0 or x == w - 1 or y == 0 or y == h - 1:
				terrain[y][x] = T_HEDGE
			elif (x + y) % 5 == 0:
				terrain[y][x] = T_GRASS2
	# Roads & Plaza
	for x in range(0, w - 1):
		terrain[11][x] = T_COBBLE
		terrain[12][x] = T_COBBLE
	for y in range(8, 15):
		for x in range(12, 22):
			terrain[y][x] = T_COBBLE
	for y in range(5, 11):
		terrain[y][16] = T_COBBLE
		terrain[y][17] = T_COBBLE
	for y in range(12, h):
		terrain[y][16] = T_COBBLE
		terrain[y][17] = T_COBBLE
	# Shop walkways
	for y in range(7, 11):
		terrain[y][8] = T_COBBLE
		terrain[y][24] = T_COBBLE

	var objects: Dictionary = {
		key(Vector2i(8, 7)): {"type": "shop_counter", "shop_id": "linxia_shop", "solid": true, "sprite": "objects/machine_chest.png", "label": "林夏种子杂货店"},
		key(Vector2i(24, 7)): {"type": "shop_counter", "shop_id": "horn_smithy", "solid": true, "sprite": "objects/machine_furnace.png", "label": "霍恩铁匠铺"},
		key(Vector2i(14, 8)): {"type": "quest_board", "solid": true, "sprite": "objects/quest_board.png", "label": "每日悬赏栏"},
		key(Vector2i(19, 8)): {"type": "festival_judge", "solid": true, "sprite": "objects/festival_table.png", "label": "丰收品鉴评比台"},
		key(Vector2i(16, 13)): {"type": "fountain", "solid": true, "sprite": "objects/fountain.png", "label": "广场喷泉"},
		key(Vector2i(17, 4)): {"type": "echo_shrine", "solid": true, "sprite": "objects/echo_shrine.png", "label": "回响祭坛"},
		key(Vector2i(28, 10)): {"type": "carpenter_desk", "solid": true, "sprite": "objects/carpenter_desk.png", "label": "苏晚营造奇观台(扩建/奇观)"},
	}

	var warps: Dictionary = {
		key(Vector2i(0, 11)): {"to_zone": "farm", "spawn": [31, 11]},
		key(Vector2i(0, 12)): {"to_zone": "farm", "spawn": [31, 12]},
		key(Vector2i(16, 21)): {"to_zone": "lake", "spawn": [13, 2]},
		key(Vector2i(17, 21)): {"to_zone": "lake", "spawn": [14, 2]},
	}

	return {
		"id": "town",
		"name": "回响镇广场",
		"width": w,
		"height": h,
		"terrain": terrain,
		"farm_tiles": {},
		"objects": objects,
		"drops": [],
		"warps": warps,
		"buildings": [
			{"sprite": "objects/shop_linxia.png", "grid_pos": [5, 3], "size_tiles": [5, 4], "label": "林夏杂货店"},
			{"sprite": "objects/smithy_horn.png", "grid_pos": [22, 3], "size_tiles": [5, 4], "label": "霍恩铁匠铺"},
		],
		"building_footprints": [
			[5, 3, 9, 6],
			[22, 3, 26, 6],
		],
	}


func _build_lake() -> Dictionary:
	var w: int = 28
	var h: int = 20
	var terrain: Array = _make_grid(w, h, T_GRASS1)
	for y in range(h):
		for x in range(w):
			if x == 0 or x == w - 1 or y == 0 or y == h - 1:
				terrain[y][x] = T_HEDGE
			elif (x * 3 + y) % 7 == 0:
				terrain[y][x] = T_GRASS2
	for y in range(0, 8):
		terrain[y][13] = T_DIRT
		terrain[y][14] = T_DIRT
	for y in range(9, 18):
		for x in range(4, 24):
			terrain[y][x] = T_WATER1 if (x + y) % 2 == 0 else T_WATER2
	for x in range(3, 25):
		terrain[8][x] = T_SAND
	# Wooden pier
	for y in range(8, 14):
		terrain[y][13] = T_DOCK
		terrain[y][14] = T_DOCK

	var objects: Dictionary = {
		key(Vector2i(15, 12)): {
			"type": "island_ferry",
			"to_zone": "coral_island",
			"spawn": [14, 5],
			"solid": true,
			"sprite": "objects/island_boat.png",
			"label": "⛵ 星海渡船(按E扬帆珊瑚群岛)",
		}
	}
	_populate_lake_forage(objects)

	var warps: Dictionary = {
		key(Vector2i(13, 0)): {"to_zone": "town", "spawn": [16, 19]},
		key(Vector2i(14, 0)): {"to_zone": "town", "spawn": [17, 19]},
	}
	return {
		"id": "lake",
		"name": "低语湖畔",
		"width": w,
		"height": h,
		"terrain": terrain,
		"farm_tiles": {},
		"objects": objects,
		"drops": [],
		"warps": warps,
		"buildings": [],
		"building_footprints": [],
	}


func _populate_lake_forage(objects: Dictionary) -> void:
	var spots: Array = [Vector2i(5, 7), Vector2i(8, 8), Vector2i(20, 8), Vector2i(22, 6), Vector2i(18, 4)]
	var kinds: Array = ["wild_berry", "echo_shell", "spring_herb"]
	for i in range(spots.size()):
		var p: Vector2i = spots[i]
		var k: String = key(p)
		if not objects.has(k) and randf() < 0.7:
			var fid: String = str(kinds[i % kinds.size()])
			objects[k] = {"type": "forage", "item_id": fid, "solid": false, "sprite": "objects/forage_" + fid + ".png"}


func _build_mine(floor_num: int) -> Dictionary:
	var w: int = 22
	var h: int = 18
	var terrain: Array = _make_grid(w, h, T_MINE_FLOOR)
	for y in range(h):
		for x in range(w):
			if x == 0 or x == w - 1 or y == 0 or y == h - 1:
				terrain[y][x] = T_MINE_WALL

	var objects: Dictionary = {
		key(Vector2i(11, 15)): {"type": "ladder_up", "solid": false, "sprite": "objects/ladder_up.png", "label": "返回上层/农场"},
		key(Vector2i(9, 15)): {"type": "elevator", "solid": true, "sprite": "objects/elevator.png", "label": "矿洞电梯"},
	}

	var rng: RandomNumberGenerator = RandomNumberGenerator.new()
	rng.seed = 9000 + floor_num * 37 + GameState.day * 13
	var rock_coords: Array = []
	for y in range(2, 13):
		for x in range(2, 20):
			if abs(x - 11) <= 1 and y >= 11:
				continue
			if rng.randf() < 0.24:
				var ore_kind: String = "rock"
				var spr: String = "objects/rock.png"
				var ore_roll: float = rng.randf()
				if floor_num >= 8 and ore_roll < 0.08:
					ore_kind = "ore_crystal"
					spr = "objects/ore_crystal.png"
				elif floor_num >= 10 and ore_roll < 0.22:
					ore_kind = "ore_gold"
					spr = "objects/ore_gold.png"
				elif floor_num >= 5 and ore_roll < 0.40:
					ore_kind = "ore_iron"
					spr = "objects/ore_iron.png"
				elif ore_roll < 0.55:
					ore_kind = "ore_copper"
					spr = "objects/ore_copper.png"
				var p: Vector2i = Vector2i(x, y)
				objects[key(p)] = {
					"type": "mine_rock",
					"ore_kind": ore_kind,
					"hp": 2 + int(floor_num / 5),
					"solid": true,
					"sprite": spr,
					"has_ladder": false,
				}
				rock_coords.append(p)

	if rock_coords.size() > 0:
		var l_idx: int = rng.randi() % rock_coords.size()
		var lp: Vector2i = rock_coords[l_idx]
		var lk: String = key(lp)
		var lobj: Dictionary = objects[lk]
		lobj["has_ladder"] = true
		objects[lk] = lobj

	return {
		"id": "mine",
		"name": "回响矿洞 %d 层" % floor_num,
		"floor": floor_num,
		"width": w,
		"height": h,
		"terrain": terrain,
		"farm_tiles": {},
		"objects": objects,
		"drops": [],
		"warps": {},
		"buildings": [],
		"building_footprints": [],
	}


func enter_mine_floor(floor_num: int) -> void:
	GameState.mine_current_floor = maxi(1, floor_num)
	if GameState.mine_current_floor > GameState.mine_max_floor:
		GameState.mine_max_floor = GameState.mine_current_floor
		if GameState.mine_max_floor >= 5:
			WorldMemory.record_fact("mine_floor_5", "成功打通了回响矿洞第5层电梯", "horn")
	zones["mine"] = _build_mine(GameState.mine_current_floor)


func refresh_daily_forage() -> void:
	if zones.has("lake"):
		var lake: Dictionary = zones["lake"]
		_populate_lake_forage(lake.get("objects", {}))
	if zones.has("secret_woods"):
		var sw: Dictionary = zones["secret_woods"]
		_populate_secret_woods_resources(sw.get("objects", {}))
	if zones.has("coral_island"):
		var ci: Dictionary = zones["coral_island"]
		_populate_coral_island_forage(ci.get("objects", {}))


func sync_farm_wonders() -> void:
	if not zones.has("farm"):
		return
	var farm: Dictionary = zones["farm"]
	var objs: Dictionary = farm.get("objects", {})
	if GameState.obelisk_built:
		objs[key(Vector2i(15, 6))] = {"type": "obelisk", "solid": true, "sprite": "objects/obelisk.png", "label": "🔮 方尖传送塔(按E瞬移)"}
	if GameState.golden_clock_built:
		objs[key(Vector2i(19, 6))] = {"type": "golden_clock", "solid": true, "sprite": "objects/golden_clock.png", "label": "👑 黄金丰饶钟(+25%出货)"}
	if zones.has("farmhouse"):
		var fh: Dictionary = zones["farmhouse"]
		fh["name"] = "三阶星露庄园" if GameState.house_tier >= 3 else ("二阶双人婚房" if GameState.house_tier == 2 else "农舍与厨房")


func serialize() -> Dictionary:
	return zones.duplicate(true)


func _build_ranch() -> Dictionary:
	var w: int = 28
	var h: int = 20
	var terrain: Array = _make_grid(w, h, T_GRASS1)
	for y in range(h):
		for x in range(w):
			if x == 0 or x == w - 1 or y == 0 or y == h - 1:
				terrain[y][x] = T_HEDGE
			elif (x * 5 + y * 3) % 6 == 0:
				terrain[y][x] = T_GRASS2
	# Dirt path from Farm east gate to Barn & south gate to Secret Woods
	for x in range(10, w):
		terrain[11][x] = T_DIRT
		terrain[12][x] = T_DIRT
	for y in range(7, h):
		terrain[y][11] = T_DIRT
		terrain[y][12] = T_DIRT
	# Small drinking pond in southeast pasture
	for y in range(14, 17):
		for x in range(22, 26):
			terrain[y][x] = T_WATER1 if (x + y) % 2 == 0 else T_WATER2
	for x in range(21, 27):
		terrain[13][x] = T_SAND

	var objects: Dictionary = {
		key(Vector2i(6, 7)): {"type": "ranch_counter", "solid": true, "sprite": "objects/ranch_sign.png", "label": "动物领养牌(按E买鸡牛羊)"},
		key(Vector2i(15, 7)): {"type": "feed_trough", "solid": true, "sprite": "objects/feed_trough.png", "label": "饲草槽(按E添草/购草)"},
		key(Vector2i(18, 7)): {"type": "machine", "machine_type": "mayo", "item_id": "machine_mayo", "solid": true, "sprite": "objects/machine_mayo.png", "processing": {}, "stored": []},
		key(Vector2i(20, 7)): {"type": "machine", "machine_type": "cheese", "item_id": "machine_cheese", "solid": true, "sprite": "objects/machine_cheese.png", "processing": {}, "stored": []},
		key(Vector2i(3, 4)): {"type": "tree", "hp": 4, "solid": true, "sprite": "objects/tree.png"},
		key(Vector2i(24, 4)): {"type": "tree", "hp": 4, "solid": true, "sprite": "objects/tree.png"},
		key(Vector2i(3, 16)): {"type": "tree", "hp": 4, "solid": true, "sprite": "objects/tree.png"},
		key(Vector2i(9, 17)): {"type": "ranch_sign", "solid": true, "sprite": "objects/ranch_sign.png", "label": "⬇️ 迷雾秘林"},
	}

	var warps: Dictionary = {
		key(Vector2i(27, 11)): {"to_zone": "farm", "spawn": [2, 11]},
		key(Vector2i(27, 12)): {"to_zone": "farm", "spawn": [2, 12]},
		key(Vector2i(11, 19)): {"to_zone": "secret_woods", "spawn": [12, 2]},
		key(Vector2i(12, 19)): {"to_zone": "secret_woods", "spawn": [13, 2]},
	}

	return {
		"id": "ranch",
		"name": "阳光牧场",
		"width": w,
		"height": h,
		"terrain": terrain,
		"farm_tiles": {},
		"objects": objects,
		"drops": [],
		"warps": warps,
		"buildings": [
			{"sprite": "objects/barn_ranch.png", "grid_pos": [8, 2], "size_tiles": [6, 5], "label": "阳光红顶畜牧舍"}
		],
		"building_footprints": [
			[8, 2, 13, 6]
		],
	}


func _build_secret_woods() -> Dictionary:
	var w: int = 26
	var h: int = 20
	var terrain: Array = _make_grid(w, h, T_GRASS1)
	for y in range(h):
		for x in range(w):
			if x == 0 or x == w - 1 or y == 0 or y == h - 1:
				terrain[y][x] = T_HEDGE
			elif (x * 7 + y * 3) % 5 == 0:
				terrain[y][x] = T_GRASS2
	# Entrance path from north
	for y in range(0, 8):
		terrain[y][12] = T_DIRT
		terrain[y][13] = T_DIRT
	# Mystic spring pool in west glade
	for y in range(7, 12):
		for x in range(4, 9):
			terrain[y][x] = T_WATER1 if (x + y) % 2 == 0 else T_WATER2

	var objects: Dictionary = {
		key(Vector2i(3, 3)): {"type": "tree", "hp": 4, "solid": true, "sprite": "objects/tree.png"},
		key(Vector2i(22, 4)): {"type": "tree", "hp": 4, "solid": true, "sprite": "objects/tree.png"},
		key(Vector2i(4, 15)): {"type": "tree", "hp": 4, "solid": true, "sprite": "objects/tree.png"},
		key(Vector2i(21, 15)): {"type": "tree", "hp": 4, "solid": true, "sprite": "objects/tree.png"},
	}
	_populate_secret_woods_resources(objects)

	var warps: Dictionary = {
		key(Vector2i(12, 0)): {"to_zone": "ranch", "spawn": [11, 17]},
		key(Vector2i(13, 0)): {"to_zone": "ranch", "spawn": [12, 17]},
	}
	return {
		"id": "secret_woods",
		"name": "迷雾回响秘林",
		"width": w,
		"height": h,
		"terrain": terrain,
		"farm_tiles": {},
		"objects": objects,
		"drops": [],
		"warps": warps,
		"buildings": [],
		"building_footprints": [],
	}


func _populate_secret_woods_resources(objects: Dictionary) -> void:
	for st_p in [Vector2i(6, 5), Vector2i(19, 6), Vector2i(7, 14), Vector2i(18, 14)]:
		var sk: String = key(st_p)
		if not objects.has(sk):
			objects[sk] = {"type": "hardwood_stump", "hp": 3, "solid": true, "sprite": "objects/hardwood_stump.png", "label": "千年铁木古桩"}
	for tf_p in [Vector2i(10, 13), Vector2i(16, 11), Vector2i(14, 16)]:
		var tk: String = key(tf_p)
		if not objects.has(tk):
			objects[tk] = {"type": "forage", "item_id": "mystic_truffle", "solid": false, "sprite": "objects/forage_mystic_truffle.png", "label": "荧光松露"}


func deserialize(data: Dictionary) -> void:
	if data.is_empty():
		init_all_zones()
	else:
		zones = data.duplicate(true)
		if not zones.has("greenhouse"):
			zones["greenhouse"] = _build_greenhouse()
		if not zones.has("ranch"):
			zones["ranch"] = _build_ranch()
		if not zones.has("secret_woods"):
			zones["secret_woods"] = _build_secret_woods()
		if not zones.has("coral_island"):
			zones["coral_island"] = _build_coral_island()
		if zones.has("lake"):
			var lk_objs: Dictionary = (zones["lake"] as Dictionary).get("objects", {})
			if not lk_objs.has(key(Vector2i(15, 12))):
				lk_objs[key(Vector2i(15, 12))] = {
					"type": "island_ferry",
					"to_zone": "coral_island",
					"spawn": [14, 5],
					"solid": true,
					"sprite": "objects/island_boat.png",
					"label": "⛵ 星海渡船(按E扬帆珊瑚群岛)",
				}
		sync_farm_wonders()


func _build_coral_island() -> Dictionary:
	var w: int = 30
	var h: int = 20
	var terrain: Array = _make_grid(w, h, T_WATER1)
	for y in range(h):
		for x in range(w):
			if x <= 1 or x >= w - 2 or y <= 1 or y >= h - 2:
				terrain[y][x] = T_WATER1 if (x + y) % 2 == 0 else T_WATER2
			elif x <= 3 or x >= w - 4 or y <= 3 or y >= h - 4:
				terrain[y][x] = T_SAND
			else:
				terrain[y][x] = T_SUMMER_GRASS if (x * 3 + y * 5) % 4 != 0 else T_GRASS2
	# North arrival wooden pier & South fishing boardwalk
	for y in range(1, 6):
		terrain[y][14] = T_DOCK
		terrain[y][15] = T_DOCK
	for y in range(15, 19):
		terrain[y][14] = T_DOCK
		terrain[y][15] = T_DOCK
	# Warm sandy footpath linking pier, trader & plantation
	for x in range(8, 21):
		terrain[6][x] = T_SAND

	var farm_tiles: Dictionary = {}
	# Starter tropical companion plot (ripe golden pineapple + star coffee!)
	for tx in range(11, 15):
		for ty in range(9, 12):
			var c_data: Dictionary = {}
			if tx == 11 and ty == 9:
				c_data = {"id": "pineapple", "growth_days": 7.0, "mature": true, "regrow_timer": 0.0, "giant": false}
			elif tx == 12 and ty == 9:
				c_data = {"id": "star_coffee", "growth_days": 5.0, "mature": true, "regrow_timer": 0.0, "giant": false}
			elif tx == 11 and ty == 10:
				c_data = {"id": "star_coffee", "growth_days": 3.0, "mature": false, "regrow_timer": 0.0, "giant": false}
			farm_tiles[key(Vector2i(tx, ty))] = {
				"tilled": true,
				"watered": true,
				"fertilizer": "",
				"soil_vitality": 95.0,
				"crop": c_data,
			}

	var objects: Dictionary = {
		key(Vector2i(16, 3)): {
			"type": "island_ferry",
			"to_zone": "lake",
			"spawn": [14, 12],
			"solid": true,
			"sprite": "objects/island_boat.png",
			"label": "⛵ 返航渡船(按E回低语湖)",
		},
		key(Vector2i(8, 5)): {
			"type": "shop_counter",
			"shop_id": "island_trader",
			"solid": true,
			"sprite": "objects/festival_table.png",
			"label": "🏝️ 珊瑚热带货栈(凤梨/咖啡)",
		},
		key(Vector2i(19, 5)): {
			"type": "shipping_bin",
			"solid": true,
			"sprite": "objects/shipping_bin.png",
			"label": "海岛出货箱",
		},
		key(Vector2i(13, 10)): {
			"type": "machine",
			"machine_type": "quality_sprinkler",
			"item_id": "machine_quality_sprinkler",
			"solid": true,
			"sprite": "objects/machine_quality_sprinkler.png",
			"processing": {},
			"stored": [],
		},
		key(Vector2i(21, 9)): {
			"type": "machine",
			"machine_type": "keg",
			"item_id": "machine_keg",
			"solid": true,
			"sprite": "objects/machine_keg.png",
			"processing": {},
			"stored": [],
		},
		key(Vector2i(5, 5)): {"type": "palm_tree", "hp": 4, "solid": true, "sprite": "objects/palm_tree.png"},
		key(Vector2i(24, 5)): {"type": "palm_tree", "hp": 4, "solid": true, "sprite": "objects/palm_tree.png"},
		key(Vector2i(5, 14)): {"type": "palm_tree", "hp": 4, "solid": true, "sprite": "objects/palm_tree.png"},
		key(Vector2i(24, 14)): {"type": "palm_tree", "hp": 4, "solid": true, "sprite": "objects/palm_tree.png"},
	}
	_populate_coral_island_forage(objects)

	return {
		"id": "coral_island",
		"name": "星露珊瑚群岛",
		"width": w,
		"height": h,
		"terrain": terrain,
		"farm_tiles": farm_tiles,
		"objects": objects,
		"drops": [],
		"warps": {},
		"buildings": [],
		"building_footprints": [],
	}


func _populate_coral_island_forage(objects: Dictionary) -> void:
	for pp in [Vector2i(6, 16), Vector2i(22, 16)]:
		var pk: String = key(pp)
		if not objects.has(pk):
			objects[pk] = {"type": "forage", "item_id": "coral_pearl", "solid": false, "sprite": "objects/forage_coral_pearl.png", "label": "南海星光珍珠"}
	for sp_pos in [Vector2i(9, 16), Vector2i(19, 16), Vector2i(25, 10)]:
		var sk: String = key(sp_pos)
		if not objects.has(sk):
			objects[sk] = {"type": "forage", "item_id": "starfish_shell", "solid": false, "sprite": "objects/forage_starfish_shell.png", "label": "珊瑚红海星"}
