class_name ArtisanSystem
extends Node


func place_machine(zone_mgr: ZoneManager, zone_id: String, pos: Vector2i, item_id: String) -> bool:
	if not zone_mgr.is_walkable(zone_id, pos):
		return false
	var item_def: Dictionary = DataRegistry.get_item(item_id)
	var mtype: String = str(item_def.get("placeable_type", ""))
	if mtype.is_empty():
		return false
	var obj: Dictionary = {
		"type": "machine",
		"machine_type": mtype,
		"item_id": item_id,
		"solid": mtype != "torch",
		"sprite": "objects/" + item_id + ".png",
		"processing": {},
		"stored": [],
	}
	zone_mgr.set_object(zone_id, pos, obj)
	AudioManager.play_sfx("plant")
	return true


func interact_machine(zone_mgr: ZoneManager, zone_id: String, pos: Vector2i, held_slot_idx: int) -> bool:
	var obj: Dictionary = zone_mgr.get_object(zone_id, pos)
	if obj.is_empty() or str(obj.get("type", "")) != "machine":
		return false
	var mtype: String = str(obj.get("machine_type", ""))

	# Chest opens quick deposit / withdraw or gives stored items
	if mtype == "chest":
		var stored: Array = obj.get("stored", [])
		if stored.size() > 0:
			var popped: Dictionary = stored.pop_back()
			GameState.add_item(str(popped.get("id", "")), int(popped.get("count", 1)), int(popped.get("quality", 0)))
			obj["stored"] = stored
			zone_mgr.set_object(zone_id, pos, obj)
			EventBus.toast_message.emit("从储物箱取出了 %s" % str(DataRegistry.get_item(str(popped.get("id", ""))).get("name", "")), Color(0.85, 0.9, 0.6))
			AudioManager.play_sfx("ui_click")
			return true
		elif held_slot_idx >= 0 and held_slot_idx < GameState.inventory.size():
			var hs: Dictionary = GameState.inventory[held_slot_idx]
			if not hs.is_empty() and str(DataRegistry.get_item(str(hs.get("id", ""))).get("category", "")) != "tool":
				stored.append(hs.duplicate(true))
				GameState.inventory[held_slot_idx] = {}
				obj["stored"] = stored
				zone_mgr.set_object(zone_id, pos, obj)
				EventBus.inventory_changed.emit()
				EventBus.toast_message.emit("已放入储物箱！", Color(0.85, 0.9, 0.6))
				AudioManager.play_sfx("ui_click")
				return true
		return false

	# If machine finished processing, collect!
	var proc: Dictionary = obj.get("processing", {})
	if not proc.is_empty():
		var rem_h: float = float(proc.get("remaining_hours", 1.0))
		if rem_h <= 0.0:
			var out_id: String = str(proc.get("output_id", ""))
			var out_cnt: int = int(proc.get("output_count", 1))
			GameState.add_item(out_id, out_cnt, 0)
			GameState.add_skill_xp("farming", 12)
			var out_name: String = str(DataRegistry.get_item(out_id).get("name", out_id))
			EventBus.floating_text.emit(Vector2(pos.x * 32 + 16, pos.y * 32), "✨ 获得 %s ×%d" % [out_name, out_cnt], Color(1.0, 0.88, 0.4))
			AudioManager.play_sfx("harvest")
			if out_id == "artisan_wine":
				WorldMemory.record_fact("artisan_mastery", "用橡木酿酒桶陈酿出了回响果酒", "mei")
			obj["processing"] = {}
			zone_mgr.set_object(zone_id, pos, obj)
			return true
		else:
			EventBus.toast_message.emit("加工中：还需 %.0f 小时" % ceilf(rem_h), Color(0.95, 0.85, 0.5))
			return true

	# Otherwise try inserting held item into machine
	var slot: Dictionary = GameState.inventory[held_slot_idx] if held_slot_idx >= 0 else {}
	if slot.is_empty():
		EventBus.toast_message.emit("请手持原料（蔬果/矿石）对着机器按 E 投入", Color(0.85, 0.85, 0.85))
		return false

	var in_id: String = str(slot.get("id", ""))
	var in_count: int = int(slot.get("count", 0))
	var item_def: Dictionary = DataRegistry.get_item(in_id)
	var crop_type: String = str(item_def.get("crop_type", ""))

	for r in DataRegistry.get_artisan_recipes():
		var rec: Dictionary = r
		if str(rec.get("machine_type", "")) != mtype:
			continue
		var need_cnt: int = int(rec.get("input_count", 1))
		var matches: bool = false
		if rec.has("input_id"):
			matches = (in_id == str(rec.get("input_id", "")))
		elif rec.has("accept_crop_types"):
			var types: Array = rec.get("accept_crop_types", [])
			matches = types.has(crop_type)
		if matches:
			if in_count < need_cnt:
				EventBus.toast_message.emit("需要 %d 个 %s！" % [need_cnt, str(item_def.get("name", in_id))], Color(1.0, 0.6, 0.4))
				return true
			GameState.consume_slot(held_slot_idx, need_cnt)
			var hrs: float = float(rec.get("hours", 4))
			obj["processing"] = {
				"output_id": str(rec.get("output_id", "")),
				"output_count": 1,
				"remaining_hours": hrs,
				"total_hours": hrs,
			}
			zone_mgr.set_object(zone_id, pos, obj)
			AudioManager.play_sfx("ui_click")
			EventBus.toast_message.emit("已投入加工，约 %d 小时后完成！" % int(hrs), Color(0.55, 0.95, 0.7))
			return true
	EventBus.toast_message.emit("该机器无法加工当前手持物品", Color(0.95, 0.65, 0.5))
	return false


func advance_hours(zone_mgr: ZoneManager, hours_passed: float) -> void:
	for zid in zone_mgr.zones.keys():
		var z: Dictionary = zone_mgr.zones[zid]
		var objs: Dictionary = z.get("objects", {})
		for ok in objs.keys():
			var obj: Dictionary = objs[ok]
			if str(obj.get("type", "")) != "machine":
				continue
			var proc: Dictionary = obj.get("processing", {})
			if not proc.is_empty():
				var rem: float = float(proc.get("remaining_hours", 0.0)) - hours_passed
				proc["remaining_hours"] = maxf(0.0, rem)
				obj["processing"] = proc
				objs[ok] = obj


func craft_recipe(recipe: Dictionary) -> bool:
	var ingredients: Array = recipe.get("ingredients", [])
	for ing in ingredients:
		var d: Dictionary = ing
		if GameState.count_item(str(d.get("id", ""))) < int(d.get("count", 1)):
			EventBus.toast_message.emit("制作材料不足！", Color(1.0, 0.5, 0.4))
			return false
	for ing in ingredients:
		var d2: Dictionary = ing
		GameState.remove_item(str(d2.get("id", "")), int(d2.get("count", 1)))
	var out_id: String = str(recipe.get("output_id", ""))
	var out_cnt: int = int(recipe.get("output_count", 1))
	GameState.add_item(out_id, out_cnt, 0)
	AudioManager.play_sfx("harvest")
	var out_name: String = str(DataRegistry.get_item(out_id).get("name", out_id))
	EventBus.toast_message.emit("🔨 制作成功：%s ×%d" % [out_name, out_cnt], Color(0.5, 0.95, 0.65))
	return true
