class_name RanchSystem
extends Node

const ANIMAL_SPECS: Dictionary = {
	"chicken": {
		"title": "白羽小母鸡",
		"price": 300,
		"product": "egg",
		"sprite": "animals/chicken.png",
		"frame_w": 32,
		"frame_h": 32,
		"speed": 34.0,
		"names": ["咯咯", "团团", "布丁", "小米", "蛋黄"],
	},
	"cow": {
		"title": "花斑奶牛",
		"price": 650,
		"product": "milk",
		"sprite": "animals/cow.png",
		"frame_w": 48,
		"frame_h": 48,
		"speed": 24.0,
		"names": ["奶糖", "哞哞", "可可", "奶油", "斑斑"],
	},
	"sheep": {
		"title": "云朵绵羊",
		"price": 800,
		"product": "wool",
		"sprite": "animals/sheep.png",
		"frame_w": 40,
		"frame_h": 40,
		"speed": 28.0,
		"names": ["朵朵", "棉花", "雪球", "绒绒", "软糖"],
	},
}

const PASTURE_MIN: Vector2 = Vector2(210.0, 276.0)
const PASTURE_MAX: Vector2 = Vector2(690.0, 496.0)

var _runtime_motion: Dictionary = {}


func tick(delta: float) -> void:
	for i in range(GameState.ranch_animals.size()):
		var a: Dictionary = GameState.ranch_animals[i]
		var aid: String = str(a.get("id", "a_%d" % i))
		if not _runtime_motion.has(aid):
			_runtime_motion[aid] = {
				"timer": randf_range(0.5, 2.8),
				"vel": Vector2.ZERO,
				"anim_t": randf() * 4.0,
				"bubble": "",
				"bubble_t": 0.0,
			}
		var st: Dictionary = _runtime_motion[aid]
		var bt: float = float(st.get("bubble_t", 0.0))
		if bt > 0.0:
			bt = maxf(0.0, bt - delta)
			st["bubble_t"] = bt
			if bt <= 0.0:
				st["bubble"] = ""

		var t: float = float(st.get("timer", 0.0)) - delta
		var vel: Vector2 = st.get("vel", Vector2.ZERO)
		var kind: String = str(a.get("kind", "chicken"))
		var spec: Dictionary = ANIMAL_SPECS.get(kind, ANIMAL_SPECS["chicken"])
		var spd: float = float(spec.get("speed", 28.0))

		if t <= 0.0:
			if randf() < 0.55:
				var ang: float = randf() * TAU
				vel = Vector2(cos(ang), sin(ang)) * spd
				t = randf_range(1.2, 2.8)
			else:
				vel = Vector2.ZERO
				t = randf_range(1.0, 2.4)

		var pos: Vector2 = Vector2(float(a.get("x", 380.0)), float(a.get("y", 340.0)))
		if vel.length() > 1.0:
			pos += vel * delta
			if pos.x < PASTURE_MIN.x or pos.x > PASTURE_MAX.x:
				vel.x = -vel.x
				pos.x = clampf(pos.x, PASTURE_MIN.x, PASTURE_MAX.x)
			if pos.y < PASTURE_MIN.y or pos.y > PASTURE_MAX.y:
				vel.y = -vel.y
				pos.y = clampf(pos.y, PASTURE_MIN.y, PASTURE_MAX.y)
			a["dir"] = 1 if vel.x < 0.0 else 0
			st["anim_t"] = float(st.get("anim_t", 0.0)) + delta * 6.0
		a["x"] = pos.x
		a["y"] = pos.y
		st["timer"] = t
		st["vel"] = vel
		_runtime_motion[aid] = st
		GameState.ranch_animals[i] = a


func get_animal_visual_state(a: Dictionary) -> Dictionary:
	var aid: String = str(a.get("id", ""))
	var st: Dictionary = _runtime_motion.get(aid, {})
	var vel: Vector2 = st.get("vel", Vector2.ZERO)
	return {
		"moving": vel.length() > 1.0,
		"anim_t": float(st.get("anim_t", 0.0)),
		"bubble": str(st.get("bubble", "")),
	}


func pet_nearby_animal(world_pos: Vector2) -> bool:
	var best_idx: int = -1
	var best_d: float = 54.0
	for i in range(GameState.ranch_animals.size()):
		var a: Dictionary = GameState.ranch_animals[i]
		var ap: Vector2 = Vector2(float(a.get("x", 0.0)), float(a.get("y", 0.0)))
		var d: float = ap.distance_to(world_pos)
		if d < best_d:
			best_d = d
			best_idx = i
	if best_idx < 0:
		return false

	var anim: Dictionary = GameState.ranch_animals[best_idx]
	var aid: String = str(anim.get("id", ""))
	var aname: String = str(anim.get("name", "小动物"))
	var apos: Vector2 = Vector2(float(anim.get("x", 0.0)), float(anim.get("y", 0.0)))
	if not _runtime_motion.has(aid):
		_runtime_motion[aid] = {"timer": 1.0, "vel": Vector2.ZERO, "anim_t": 0.0, "bubble": "", "bubble_t": 0.0}
	var st: Dictionary = _runtime_motion[aid]

	if not bool(anim.get("petted_today", false)):
		anim["petted_today"] = true
		anim["affection"] = clampi(int(anim.get("affection", 50)) + 40, 0, 1000)
		GameState.ranch_animals[best_idx] = anim
		GameState.add_skill_xp("farming", 6)
		st["bubble"] = "❤️ 开心!"
		st["bubble_t"] = 2.2
		_runtime_motion[aid] = st
		AudioManager.play_sfx("harvest")
		var hearts: int = int(int(anim.get("affection", 0)) / 200)
		EventBus.floating_text.emit(apos - Vector2(0, 24), "❤️ %s 好感+40 (%d/5♥)" % [aname, hearts], Color(1.0, 0.58, 0.72))
	else:
		st["bubble"] = "♪ 咕咕~"
		st["bubble_t"] = 1.6
		_runtime_motion[aid] = st
		AudioManager.play_sfx("ui_click")
		var hearts2: int = int(int(anim.get("affection", 0)) / 200)
		var fed_s: String = "已吃饱" if bool(anim.get("fed_today", true)) else "待喂草"
		EventBus.toast_message.emit("🐾 %s 今天已被抚摸过啦（好感 %d/5♥ · %s）" % [aname, hearts2, fed_s], Color(0.98, 0.88, 0.58))
	return true


func adopt_animal(kind: String) -> Dictionary:
	if not ANIMAL_SPECS.has(kind):
		return {"ok": false, "msg": "未知动物类型"}
	if GameState.ranch_animals.size() >= 12:
		return {"ok": false, "msg": "阳光牧场最多可饲养 12 只动物！"}
	var spec: Dictionary = ANIMAL_SPECS[kind]
	var cost: int = int(spec.get("price", 300))
	if GameState.gold < cost:
		return {"ok": false, "msg": "金币不足（需要 %dG）！" % cost}

	GameState.gold -= cost
	var names: Array = spec.get("names", ["小可爱"])
	var idx: int = GameState.ranch_animals.size()
	var pick_name: String = str(names[idx % names.size()])
	var new_anim: Dictionary = {
		"id": "anim_%d_%d" % [GameState.day, idx + 1],
		"kind": kind,
		"name": pick_name,
		"affection": 50,
		"petted_today": false,
		"fed_today": true,
		"x": randf_range(PASTURE_MIN.x + 30.0, PASTURE_MAX.x - 30.0),
		"y": randf_range(PASTURE_MIN.y + 24.0, PASTURE_MAX.y - 24.0),
		"dir": 0,
	}
	GameState.ranch_animals.append(new_anim)
	AudioManager.play_sfx("fish_catch")
	EventBus.player_stats_changed.emit()
	WorldMemory.record_fact("ranch_adopted", "在阳光牧场新领养了可爱的%s「%s」" % [str(spec.get("title", "")), pick_name], "mei")
	return {"ok": true, "name": pick_name, "title": str(spec.get("title", ""))}


func refill_trough_from_inventory() -> int:
	var have: int = GameState.count_item("hay")
	if have <= 0:
		return 0
	var space: int = maxi(0, 30 - GameState.trough_hay)
	var move_cnt: int = mini(have, space)
	if move_cnt <= 0:
		return 0
	var taken: int = GameState.remove_item("hay", move_cnt)
	GameState.trough_hay += taken
	AudioManager.play_sfx("plant")
	return taken


func process_overnight(zone_mgr: ZoneManager) -> int:
	var produced: int = 0
	var can_graze_outdoors: bool = (GameState.get_season() != "winter") and (GameState.weather == "sunny")
	for i in range(GameState.ranch_animals.size()):
		var a: Dictionary = GameState.ranch_animals[i]
		var fed: bool = false
		if can_graze_outdoors:
			fed = true
		elif GameState.trough_hay > 0:
			GameState.trough_hay -= 1
			fed = true

		if fed:
			var kind: String = str(a.get("kind", "chicken"))
			var spec: Dictionary = ANIMAL_SPECS.get(kind, ANIMAL_SPECS["chicken"])
			var prod_id: String = str(spec.get("product", "egg"))
			var aff: int = int(a.get("affection", 50))
			var qual: int = 0
			if aff >= 600 and randf() < 0.45:
				qual = 2
			elif aff >= 260 and randf() < 0.55:
				qual = 1
			var drop_pos: Vector2 = Vector2(float(a.get("x", 384.0)), float(a.get("y", 340.0)) + 14.0)
			zone_mgr.spawn_drop("ranch", drop_pos, prod_id, 1, qual)
			a["affection"] = clampi(aff + 10, 0, 1000)
			produced += 1

		a["fed_today"] = fed
		a["petted_today"] = false
		GameState.ranch_animals[i] = a
	return produced
