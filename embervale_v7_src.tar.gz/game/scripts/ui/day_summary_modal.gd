class_name DaySummaryModal
extends Control

var title_lbl: Label = null
var body_lbl: Label = null


func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	theme = UITheme.build_theme()
	visible = false
	_build_ui()


func _build_ui() -> void:
	var dim: ColorRect = ColorRect.new()
	dim.set_anchors_preset(Control.PRESET_FULL_RECT)
	dim.color = Color(0.03, 0.05, 0.09, 0.85)
	add_child(dim)

	var center: CenterContainer = CenterContainer.new()
	center.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(center)

	var panel: PanelContainer = PanelContainer.new()
	panel.custom_minimum_size = Vector2(540, 390)
	center.add_child(panel)

	var v: VBoxContainer = VBoxContainer.new()
	v.add_theme_constant_override("separation", 12)
	panel.add_child(v)

	title_lbl = Label.new()
	title_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title_lbl.add_theme_font_size_override("font_size", 20)
	title_lbl.add_theme_color_override("font_color", Color(1.0, 0.86, 0.4))
	v.add_child(title_lbl)

	body_lbl = Label.new()
	body_lbl.size_flags_vertical = Control.SIZE_EXPAND_FILL
	body_lbl.add_theme_font_size_override("font_size", 15)
	v.add_child(body_lbl)

	var btn: Button = Button.new()
	btn.text = "迎接新的一天 ☀️"
	btn.custom_minimum_size = Vector2(220, 46)
	btn.pressed.connect(func():
		visible = false
		GameState.time_paused = false
		AudioManager.play_sfx("rooster_morning")
	)
	v.add_child(btn)


func show_summary(summary: Dictionary) -> void:
	visible = true
	GameState.time_paused = true
	title_lbl.text = "🌙 第%d年 %s第%d日 夜间出货结算" % [
		int(summary.get("year", 1)),
		str(summary.get("season_name", "春")),
		int(summary.get("day", 1)),
	]
	var cat: Dictionary = summary.get("by_cat", {})
	var lines: Array = [
		"🌾 农产作物收益： %d G" % int(cat.get("farming", 0)),
		"🍷 工匠深加工：   %d G" % int(cat.get("artisan", 0)),
		"🐟 湖溪渔获收益： %d G" % int(cat.get("fishing", 0)),
		"⛏️ 矿产与采集：   %d G" % int(cat.get("mining", 0)),
		"─────────────────────────────",
		"💰 今日总入账：   +%d G" % int(summary.get("total_gold", 0)),
	]
	var fest: int = int(summary.get("festival_bonus", 0))
	if fest > 0:
		lines.append("🎉 丰收品鉴日 1.5x 庆典溢价： +%d G" % fest)
	var pen: int = int(summary.get("faint_penalty", 0))
	if pen > 0:
		lines.append("🏥 昨晚力竭救援医疗费： -%d G" % pen)
	var perf: Dictionary = GameState.compute_valley_perfection()
	lines.append("")
	lines.append("🌤️ 明日天气：%s   |   🏆 山谷完美度：%d%%" % [GameState.get_weather_name(), int(perf.get("percent", 0))])
	body_lbl.text = "\n".join(lines)
