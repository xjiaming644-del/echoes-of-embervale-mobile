class_name FairyIdleModal
extends Control

var title_lbl: Label = null
var rate_lbl: Label = null
var report_lbl: Label = null
var claim_offline_btn: Button = null
var instant_patrol_btn: Button = null
var close_btn: Button = null
var card_panel: PanelContainer = null

var _pending_elapsed_sec: int = 0


func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	visible = false
	theme = UITheme.build_theme()
	_build_ui()


func _build_ui() -> void:
	var dim: ColorRect = ColorRect.new()
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	dim.color = Color(0.04, 0.06, 0.05, 0.72)
	dim.gui_input.connect(func(ev: InputEvent):
		if (ev is InputEventScreenTouch and (ev as InputEventScreenTouch).pressed) or (ev is InputEventMouseButton and (ev as InputEventMouseButton).pressed and (ev as InputEventMouseButton).button_index == MOUSE_BUTTON_LEFT):
			close_modal()
			dim.accept_event()
	)
	add_child(dim)

	var center: CenterContainer = CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	center.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(center)

	card_panel = PanelContainer.new()
	card_panel.custom_minimum_size = Vector2(560, 340)
	card_panel.mouse_filter = Control.MOUSE_FILTER_STOP
	center.add_child(card_panel)

	var vbox: VBoxContainer = VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 12)
	card_panel.add_child(vbox)

	var header: HBoxContainer = HBoxContainer.new()
	vbox.add_child(header)

	title_lbl = Label.new()
	title_lbl.text = "🧚 星露森灵值班小屋 · 手机通勤轻放置护肝系统"
	title_lbl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	title_lbl.add_theme_font_size_override("font_size", 18)
	title_lbl.add_theme_color_override("font_color", Color(0.98, 0.90, 0.48))
	header.add_child(title_lbl)

	close_btn = Button.new()
	close_btn.text = "✕ 关闭"
	close_btn.custom_minimum_size = Vector2(96, 44)
	close_btn.pressed.connect(close_modal)
	header.add_child(close_btn)

	rate_lbl = Label.new()
	rate_lbl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	rate_lbl.add_theme_font_size_override("font_size", 14)
	rate_lbl.add_theme_color_override("font_color", Color(0.72, 0.98, 0.80))
	vbox.add_child(rate_lbl)

	var report_box: PanelContainer = PanelContainer.new()
	report_box.add_theme_stylebox_override(
		"panel",
		UITheme.make_card_style(Color(0.12, 0.16, 0.12, 0.95), Color(0.56, 0.88, 0.58, 0.92), 8)
	)
	vbox.add_child(report_box)

	report_lbl = Label.new()
	report_lbl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	report_lbl.custom_minimum_size = Vector2(510, 110)
	report_lbl.add_theme_font_size_override("font_size", 14)
	report_box.add_child(report_lbl)

	var btn_row: HBoxContainer = HBoxContainer.new()
	btn_row.alignment = BoxContainer.ALIGNMENT_CENTER
	btn_row.add_theme_constant_override("separation", 12)
	vbox.add_child(btn_row)

	claim_offline_btn = Button.new()
	claim_offline_btn.custom_minimum_size = Vector2(240, 48)
	claim_offline_btn.add_theme_font_size_override("font_size", 14)
	claim_offline_btn.pressed.connect(_on_claim_offline)
	btn_row.add_child(claim_offline_btn)

	instant_patrol_btn = Button.new()
	instant_patrol_btn.custom_minimum_size = Vector2(250, 48)
	instant_patrol_btn.add_theme_font_size_override("font_size", 14)
	instant_patrol_btn.pressed.connect(_on_instant_patrol)
	btn_row.add_child(instant_patrol_btn)


func open_modal(override_elapsed_sec: int = -1) -> void:
	var now_ts: int = int(Time.get_unix_time_from_system())
	if override_elapsed_sec >= 0:
		_pending_elapsed_sec = override_elapsed_sec
	else:
		_pending_elapsed_sec = maxi(0, now_ts - GameState.last_active_unix_ts) if GameState.last_active_unix_ts > 0 else 0
	visible = true
	GameState.time_paused = true
	refresh()


func close_modal() -> void:
	visible = false
	GameState.time_paused = false


func refresh() -> void:
	var prev: Dictionary = GameState.preview_offline_fairy_rewards(_pending_elapsed_sec)
	var hr_gold: int = int(prev.get("hourly_gold", 60))
	var pond_cnt: int = int(GameState.fish_pond.get("count", 0))
	rate_lbl.text = "🌿 当前森灵离线值班效率：%d G / 小时（基于庄园 Lv.%d · 牧场动物 %d 只 · 鱼塘 %d 条 · 单次最高累计 12 小时）" % [
		hr_gold, GameState.house_tier, GameState.ranch_animals.size(), pond_cnt
	]

	var claimable: bool = bool(prev.get("claimable", false))
	if claimable:
		var mins: int = int(_pending_elapsed_sec / 60)
		var items_arr: Array = prev.get("items", [])
		var item_txts: Array = []
		for raw_it in items_arr:
			var it: Dictionary = raw_it
			var idef: Dictionary = DataRegistry.get_item(str(it.get("id", "")))
			item_txts.append("%s×%d" % [str(idef.get("name", "")), int(it.get("count", 1))])
		var loot_str: String = "、".join(item_txts) if item_txts.size() > 0 else "晨露祝福"
		report_lbl.text = "✨ 欢迎回来！在你忙于工作/通勤离开的 %d 分钟里，值班小森灵帮你打理了庄园：\n• 累计代收晨露礼金：+%d G\n• 采集农牧鲜货：%s\n• 森灵泉水恢复体力：+%.0f" % [
			mins, int(prev.get("gold_gain", 0)), loot_str, maxf(15.0, float(prev.get("energy_gain", 15.0)))
		]
		claim_offline_btn.text = "🎁 领取离线收益 (+%dG)" % int(prev.get("gold_gain", 0))
		claim_offline_btn.disabled = false
	else:
		var wait_m: int = maxi(1, 10 - int(_pending_elapsed_sec / 60))
		report_lbl.text = "🌱 小森灵正在田间与牧场勤快巡逻中！\n• 锁屏或切出游戏满 10 分钟回来，即可自动结算离线金币与农牧鲜货（还差约 %d 分钟）。\n• 上班摸鱼只有 1 分钟？可点击右侧【每日免费即时巡收】立刻收获 2 小时森灵战利品！" % wait_m
		claim_offline_btn.text = "⏳ 离线满10分钟可领"
		claim_offline_btn.disabled = true

	if GameState.fairy_daily_instant_used:
		instant_patrol_btn.text = "✅ 今日免费巡收已领"
		instant_patrol_btn.disabled = true
	else:
		instant_patrol_btn.text = "⚡ 免费即时巡收2h (+%dG)" % (hr_gold * 2)
		instant_patrol_btn.disabled = false


func _on_claim_offline() -> void:
	var res: Dictionary = GameState.claim_offline_fairy_rewards(_pending_elapsed_sec, false)
	if bool(res.get("ok", false)):
		_pending_elapsed_sec = 0
		AudioManager.play_sfx("fish_catch")
		EventBus.toast_message.emit(
			"🧚 已收下森灵离线战报：+%d G · %s！" % [int(res.get("gold_gain", 0)), str(res.get("items_summary", ""))],
			Color(0.62, 1.0, 0.78)
		)
		refresh()


func _on_instant_patrol() -> void:
	var res: Dictionary = GameState.claim_offline_fairy_rewards(7200, true)
	if bool(res.get("ok", false)):
		AudioManager.play_sfx("fish_catch")
		EventBus.toast_message.emit(
			"⚡ 森灵即时巡收大丰收：+%d G · %s！" % [int(res.get("gold_gain", 0)), str(res.get("items_summary", ""))],
			Color(1.0, 0.90, 0.42)
		)
		refresh()
