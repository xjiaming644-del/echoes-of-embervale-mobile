class_name FairyIdleModal
extends Control

var title_lbl: Label = null
var rate_lbl: Label = null
var report_lbl: Label = null
var claim_offline_btn: Button = null
var claim_double_btn: Button = null
var instant_patrol_btn: Button = null
var blind_box_btn: Button = null
var close_btn: Button = null
var card_panel: PanelContainer = null

var _pending_elapsed_sec: int = 0
var _ad_busy: bool = false


func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	visible = false
	theme = UITheme.build_theme()
	_build_ui()


func _build_ui() -> void:
	var dim: ColorRect = ColorRect.new()
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	dim.color = Color(0.04, 0.06, 0.05, 0.72)
	dim.gui_input.connect(func(ev: InputEvent):
		if (ev is InputEventScreenTouch and (ev as InputEventScreenTouch).pressed) or (ev is InputEventMouseButton and (ev as InputEventMouseButton).pressed and (ev as InputEventMouseButton).button_index == MOUSE_BUTTON_LEFT):
			close_modal()
			dim.accept_event()
	)
	add_child(dim)

	var center: CenterContainer = CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	center.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(center)

	card_panel = PanelContainer.new()
	card_panel.custom_minimum_size = Vector2(580, 380)
	card_panel.mouse_filter = Control.MOUSE_FILTER_STOP
	center.add_child(card_panel)

	var vbox: VBoxContainer = VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 10)
	card_panel.add_child(vbox)

	var header: HBoxContainer = HBoxContainer.new()
	vbox.add_child(header)

	title_lbl = Label.new()
	title_lbl.text = "🧚 星露森灵小屋 · 离线挂机 & 幸运盲盒"
	title_lbl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	title_lbl.add_theme_font_size_override("font_size", 18)
	title_lbl.add_theme_color_override("font_color", Color(0.98, 0.90, 0.48))
	header.add_child(title_lbl)

	close_btn = Button.new()
	close_btn.text = "✕ 关闭"
	close_btn.custom_minimum_size = Vector2(96, 44)
	close_btn.pressed.connect(close_modal)
	header.add_child(close_btn)

	rate_lbl = Label.new()
	rate_lbl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	rate_lbl.add_theme_font_size_override("font_size", 13)
	rate_lbl.add_theme_color_override("font_color", Color(0.72, 0.98, 0.80))
	vbox.add_child(rate_lbl)

	var report_box: PanelContainer = PanelContainer.new()
	report_box.add_theme_stylebox_override(
		"panel",
		UITheme.make_card_style(Color(0.12, 0.16, 0.12, 0.95), Color(0.56, 0.88, 0.58, 0.92), 8)
	)
	vbox.add_child(report_box)

	report_lbl = Label.new()
	report_lbl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	report_lbl.custom_minimum_size = Vector2(530, 108)
	report_lbl.add_theme_font_size_override("font_size", 14)
	report_box.add_child(report_lbl)

	var btn_row: HFlowContainer = HFlowContainer.new()
	btn_row.alignment = FlowContainer.ALIGNMENT_CENTER
	btn_row.add_theme_constant_override("h_separation", 10)
	btn_row.add_theme_constant_override("v_separation", 8)
	vbox.add_child(btn_row)

	claim_offline_btn = Button.new()
	claim_offline_btn.custom_minimum_size = Vector2(248, 46)
	claim_offline_btn.add_theme_font_size_override("font_size", 13)
	claim_offline_btn.pressed.connect(_on_claim_offline)
	btn_row.add_child(claim_offline_btn)

	claim_double_btn = Button.new()
	claim_double_btn.custom_minimum_size = Vector2(262, 46)
	claim_double_btn.add_theme_font_size_override("font_size", 13)
	claim_double_btn.pressed.connect(_on_claim_double_offline)
	btn_row.add_child(claim_double_btn)

	instant_patrol_btn = Button.new()
	instant_patrol_btn.custom_minimum_size = Vector2(248, 46)
	instant_patrol_btn.add_theme_font_size_override("font_size", 13)
	instant_patrol_btn.pressed.connect(_on_instant_patrol)
	btn_row.add_child(instant_patrol_btn)

	blind_box_btn = Button.new()
	blind_box_btn.custom_minimum_size = Vector2(262, 46)
	blind_box_btn.add_theme_font_size_override("font_size", 13)
	blind_box_btn.pressed.connect(_on_blind_box_pressed)
	btn_row.add_child(blind_box_btn)


func open_modal(override_elapsed_sec: int = -1) -> void:
	var now_ts: int = int(Time.get_unix_time_from_system())
	if override_elapsed_sec >= 0:
		_pending_elapsed_sec = override_elapsed_sec
	else:
		_pending_elapsed_sec = maxi(0, now_ts - GameState.last_active_unix_ts) if GameState.last_active_unix_ts > 0 else 0
	visible = true
	GameState.time_paused = true
	refresh()


func close_modal() -> void:
	visible = false
	GameState.time_paused = false


func refresh() -> void:
	var prev: Dictionary = GameState.preview_offline_fairy_rewards(_pending_elapsed_sec)
	var hr_gold: int = int(prev.get("hourly_gold", 60))
	var pond_cnt: int = int(GameState.fish_pond.get("count", 0))
	rate_lbl.text = "🌿 森灵值班效率：%d G/小时（庄园Lv.%d · 牧场%d只 · 鱼塘%d条 · 最高累计12小时）" % [
		hr_gold, GameState.house_tier, GameState.ranch_animals.size(), pond_cnt
	]

	var claimable: bool = bool(prev.get("claimable", false))
	var base_g: int = int(prev.get("gold_gain", 0))
	if claimable:
		var mins: int = int(_pending_elapsed_sec / 60)
		var items_arr: Array = prev.get("items", [])
		var item_txts: Array = []
		for raw_it in items_arr:
			var it: Dictionary = raw_it
			var idef: Dictionary = DataRegistry.get_item(str(it.get("id", "")))
			item_txts.append("%s×%d" % [str(idef.get("name", "")), int(it.get("count", 1))])
		var loot_str: String = "、".join(item_txts) if item_txts.size() > 0 else "晨露祝福"
		report_lbl.text = "✨ 欢迎回来！在你离开的 %d 分钟里，值班小森灵帮你打理了庄园：\n• 代收晨露礼金：+%d G（点【小剧场双倍】可领 +%d G 与双倍鲜货！）\n• 采集农牧鲜货：%s  |  恢复体力：+%.0f" % [
			mins, base_g, base_g * 2, loot_str, maxf(15.0, float(prev.get("energy_gain", 15.0)))
		]
		claim_offline_btn.text = "🎁 普通领取 (+%dG)" % base_g
		claim_offline_btn.disabled = _ad_busy
		claim_double_btn.text = "🎬 小剧场双倍领 (+%dG)" % (base_g * 2)
		claim_double_btn.disabled = _ad_busy
	else:
		var wait_m: int = maxi(1, 10 - int(_pending_elapsed_sec / 60))
		report_lbl.text = "🌱 小森灵正在田间与牧场勤快巡逻中！\n• 锁屏或切出满 10 分钟回来即可领离线礼金与鲜货（差约 %d 分钟，支持小剧场双倍领奖）。\n• 下方每日免费赠送 1 次【即时巡收2h】与【星露幸运盲盒】！" % wait_m
		claim_offline_btn.text = "⏳ 离线满10分钟可领"
		claim_offline_btn.disabled = true
		claim_double_btn.text = "🎬 离线满10分钟可双倍"
		claim_double_btn.disabled = true

	if GameState.fairy_daily_instant_used:
		instant_patrol_btn.text = "✅ 今日免费巡收已领"
		instant_patrol_btn.disabled = true
	else:
		instant_patrol_btn.text = "⚡ 免费即时巡收2h (+%dG)" % (hr_gold * 2)
		instant_patrol_btn.disabled = _ad_busy

	if GameState.daily_blind_box_draws == 0:
		blind_box_btn.text = "🎁 每日星露盲盒 (免费抽)"
		blind_box_btn.disabled = _ad_busy
	elif GameState.daily_blind_box_draws == 1:
		blind_box_btn.text = "🎬 小剧场再抽一次盲盒"
		blind_box_btn.disabled = _ad_busy
	else:
		blind_box_btn.text = "✅ 今日盲盒已抽满(2/2)"
		blind_box_btn.disabled = true


func _on_claim_offline() -> void:
	var res: Dictionary = GameState.claim_offline_fairy_rewards(_pending_elapsed_sec, false, 1)
	if bool(res.get("ok", false)):
		_pending_elapsed_sec = 0
		AudioManager.play_sfx("fish_catch")
		EventBus.toast_message.emit(
			"🧚 已收下森灵离线战报：+%d G · %s！" % [int(res.get("gold_gain", 0)), str(res.get("items_summary", ""))],
			Color(0.62, 1.0, 0.78)
		)
		refresh()


func _on_claim_double_offline() -> void:
	if _ad_busy:
		return
	_ad_busy = true
	refresh()
	var target_sec: int = _pending_elapsed_sec
	AdRewardBridge.request_rewarded_ad(self, "fairy_offline_2x", func():
		_ad_busy = false
		var res: Dictionary = GameState.claim_offline_fairy_rewards(target_sec, false, 2)
		if bool(res.get("ok", false)):
			_pending_elapsed_sec = 0
			AudioManager.play_sfx("fish_catch")
			EventBus.toast_message.emit(
				"🎬 双倍暴击！收下森灵双倍离线战报：+%d G · %s！" % [int(res.get("gold_gain", 0)), str(res.get("items_summary", ""))],
				Color(1.0, 0.90, 0.36)
			)
		refresh()
	)


func _on_instant_patrol() -> void:
	var res: Dictionary = GameState.claim_offline_fairy_rewards(7200, true, 1)
	if bool(res.get("ok", false)):
		AudioManager.play_sfx("fish_catch")
		EventBus.toast_message.emit(
			"⚡ 森灵即时巡收大丰收：+%d G · %s！" % [int(res.get("gold_gain", 0)), str(res.get("items_summary", ""))],
			Color(1.0, 0.90, 0.42)
		)
		refresh()


func _on_blind_box_pressed() -> void:
	if GameState.daily_blind_box_draws == 0:
		var res: Dictionary = GameState.open_starlight_blind_box(false)
		if bool(res.get("ok", false)):
			AudioManager.play_sfx("fish_catch")
			EventBus.toast_message.emit(
				"🎁 星露幸运盲盒开出：%s×%d + 礼金 %dG！" % [str(res.get("item_name", "")), int(res.get("count", 1)), int(res.get("gold_bonus", 0))],
				Color(0.98, 0.86, 0.42)
			)
			refresh()
	elif GameState.daily_blind_box_draws == 1 and not _ad_busy:
		_ad_busy = true
		refresh()
		AdRewardBridge.request_rewarded_ad(self, "daily_blind_box_extra", func():
			_ad_busy = false
			var res2: Dictionary = GameState.open_starlight_blind_box(true)
			if bool(res2.get("ok", false)):
				AudioManager.play_sfx("fish_catch")
				EventBus.toast_message.emit(
					"🎬 加抽盲盒惊喜大礼：%s×%d + 礼金 %dG！" % [str(res2.get("item_name", "")), int(res2.get("count", 1)), int(res2.get("gold_bonus", 0))],
					Color(1.0, 0.88, 0.38)
				)
			refresh()
		)
