class_name HUDOverlay
extends Control

var zone_label: Label = null
var time_label: Label = null
var gold_label: Label = null
var water_label: Label = null
var buff_label: Label = null
var lens_badge: Label = null
var held_name_label: Label = null
var energy_bar: ProgressBar = null
var hp_bar: ProgressBar = null
var energy_txt: Label = null
var hp_txt: Label = null
var toast_label: Label = null
var tutorial_panel: PanelContainer = null
var tutorial_label: Label = null
var inspector_panel: PanelContainer = null
var inspector_label: Label = null
var tl_panel_ref: PanelContainer = null
var tr_panel_ref: PanelContainer = null
var br_panel_ref: PanelContainer = null
var hb_wrap_ref: VBoxContainer = null
var hb_grid_ref: GridContainer = null
var help_lbl_ref: Label = null
var mute_btn: Button = null
var mobile_btn: Button = null
var orient_btn: Button = null
var fairy_btn: Button = null
var postcard_btn: Button = null
var is_portrait_layout: bool = false
var _toast_timer: float = 0.0

var hotbar_slots: Array = []

signal action_button_pressed(action_name: String)


func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	theme = UITheme.build_theme()
	_build_ui()
	EventBus.time_changed.connect(func(_d, _s, _y, _h, _m, _w): refresh())
	EventBus.player_stats_changed.connect(refresh)
	EventBus.inventory_changed.connect(refresh)
	EventBus.zone_changed.connect(func(_z): refresh())
	EventBus.toast_message.connect(show_toast)
	EventBus.audio_mute_changed.connect(func(_m: bool): _update_mute_button())
	refresh()


func _process(delta: float) -> void:
	if _toast_timer > 0.0:
		_toast_timer -= delta
		if _toast_timer <= 0.0 and toast_label != null:
			toast_label.visible = false


func _build_ui() -> void:
	# Top-left Guide & Quick Buttons
	var tl_panel: PanelContainer = PanelContainer.new()
	tl_panel_ref = tl_panel
	tl_panel.position = Vector2(14, 14)
	tl_panel.custom_minimum_size = Vector2(360, 0)
	add_child(tl_panel)
	var tl_vbox: VBoxContainer = VBoxContainer.new()
	tl_panel.add_child(tl_vbox)

	zone_label = Label.new()
	zone_label.add_theme_font_size_override("font_size", 17)
	zone_label.add_theme_color_override("font_color", Color(0.98, 0.88, 0.48))
	tl_vbox.add_child(zone_label)

	var help_lbl: Label = Label.new()
	help_lbl_ref = help_lbl
	help_lbl.text = "WASD移动(Shift疾跑) · 左键使用 · E交互 · N地图 · F11全屏\nTab生态 · B背包 · M日志 · F5/F8存读 · F9热更 · F10静音"
	help_lbl.add_theme_font_size_override("font_size", 12)
	help_lbl.add_theme_color_override("font_color", Color(0.92, 0.86, 0.74))
	tl_vbox.add_child(help_lbl)

	var btn_row: HFlowContainer = HFlowContainer.new()
	btn_row.add_theme_constant_override("h_separation", 4)
	btn_row.add_theme_constant_override("v_separation", 4)
	btn_row.custom_minimum_size = Vector2(412, 0)
	tl_vbox.add_child(btn_row)
	for pair in [["Tab生态", "toggle_lens"], ["B背包", "open_inv"], ["N地图", "open_map"], ["M日志", "open_mem"], ["F9热更", "reload_assets"]]:
		var b: Button = Button.new()
		b.text = str(pair[0])
		b.custom_minimum_size = Vector2(0, 32)
		b.add_theme_font_size_override("font_size", 12)
		var act: String = str(pair[1])
		b.pressed.connect(func(): action_button_pressed.emit(act))
		btn_row.add_child(b)
	mobile_btn = Button.new()
	mobile_btn.text = "📱触屏"
	mobile_btn.custom_minimum_size = Vector2(0, 32)
	mobile_btn.add_theme_font_size_override("font_size", 12)
	mobile_btn.pressed.connect(func(): action_button_pressed.emit("toggle_mobile"))
	btn_row.add_child(mobile_btn)
	orient_btn = Button.new()
	orient_btn.text = "🔄竖屏"
	orient_btn.custom_minimum_size = Vector2(0, 32)
	orient_btn.add_theme_font_size_override("font_size", 12)
	orient_btn.pressed.connect(func(): action_button_pressed.emit("toggle_portrait"))
	btn_row.add_child(orient_btn)
	fairy_btn = Button.new()
	fairy_btn.text = "🧚森灵"
	fairy_btn.custom_minimum_size = Vector2(0, 32)
	fairy_btn.add_theme_font_size_override("font_size", 12)
	fairy_btn.pressed.connect(func(): action_button_pressed.emit("open_fairy"))
	btn_row.add_child(fairy_btn)
	postcard_btn = Button.new()
	postcard_btn.text = "📸打卡"
	postcard_btn.custom_minimum_size = Vector2(0, 32)
	postcard_btn.add_theme_font_size_override("font_size", 12)
	postcard_btn.pressed.connect(func(): action_button_pressed.emit("capture_postcard"))
	btn_row.add_child(postcard_btn)
	mute_btn = Button.new()
	mute_btn.custom_minimum_size = Vector2(0, 32)
	mute_btn.add_theme_font_size_override("font_size", 12)
	mute_btn.pressed.connect(func(): action_button_pressed.emit("toggle_mute"))
	btn_row.add_child(mute_btn)
	_update_mute_button()

	# Top-right Stardew Clock & Gold Card
	var tr_panel: PanelContainer = PanelContainer.new()
	tr_panel_ref = tr_panel
	tr_panel.set_anchors_preset(Control.PRESET_TOP_RIGHT)
	tr_panel.offset_left = -272
	tr_panel.offset_top = 14
	tr_panel.offset_right = -14
	tr_panel.offset_bottom = 166
	add_child(tr_panel)
	var tr_vbox: VBoxContainer = VBoxContainer.new()
	tr_panel.add_child(tr_vbox)

	time_label = Label.new()
	time_label.add_theme_font_size_override("font_size", 15)
	tr_vbox.add_child(time_label)

	gold_label = Label.new()
	gold_label.add_theme_font_size_override("font_size", 19)
	gold_label.add_theme_color_override("font_color", Color(1.0, 0.86, 0.32))
	tr_vbox.add_child(gold_label)

	water_label = Label.new()
	water_label.add_theme_font_size_override("font_size", 13)
	water_label.add_theme_color_override("font_color", Color(0.62, 0.90, 1.0))
	tr_vbox.add_child(water_label)

	buff_label = Label.new()
	buff_label.add_theme_font_size_override("font_size", 12)
	buff_label.add_theme_color_override("font_color", Color(1.0, 0.88, 0.45))
	buff_label.visible = false
	tr_vbox.add_child(buff_label)

	lens_badge = Label.new()
	lens_badge.add_theme_font_size_override("font_size", 12)
	lens_badge.add_theme_color_override("font_color", Color(0.55, 0.98, 0.65))
	lens_badge.visible = false
	lens_badge.text = "🌿 生态共鸣透镜开启中 (Tab)"
	tr_vbox.add_child(lens_badge)

	# Toast Banner Top-Center (framed dark walnut pill so it never clashes with world signs below)
	toast_label = Label.new()
	toast_label.set_anchors_preset(Control.PRESET_TOP_WIDE)
	toast_label.offset_top = 14
	toast_label.offset_left = 392
	toast_label.offset_right = -286
	toast_label.offset_bottom = 58
	toast_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	toast_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	toast_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	toast_label.add_theme_font_size_override("font_size", 14)
	var toast_sb: StyleBoxFlat = UITheme.make_card_style(Color(0.12, 0.08, 0.05, 0.94), Color(0.90, 0.68, 0.30, 0.96), 8)
	toast_sb.content_margin_top = 5
	toast_sb.content_margin_bottom = 5
	toast_sb.content_margin_left = 12
	toast_sb.content_margin_right = 12
	toast_label.add_theme_stylebox_override("normal", toast_sb)
	toast_label.visible = false
	add_child(toast_label)

	# Tutorial Guide Pill Card neatly framed below top-left panel
	tutorial_panel = PanelContainer.new()
	tutorial_panel.position = Vector2(14, 142)
	tutorial_panel.custom_minimum_size = Vector2(390, 0)
	tutorial_panel.add_theme_stylebox_override("panel", UITheme.make_card_style(Color(0.14, 0.22, 0.14, 0.93), Color(0.52, 0.88, 0.48, 0.95), 7))
	tutorial_panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(tutorial_panel)
	tutorial_label = Label.new()
	tutorial_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	tutorial_label.custom_minimum_size = Vector2(368, 0)
	tutorial_label.add_theme_font_size_override("font_size", 12)
	tutorial_label.add_theme_color_override("font_color", Color(0.76, 1.0, 0.82))
	tutorial_panel.add_child(tutorial_label)

	# Bottom-Center Hotbar (10x1 in Landscape, auto-reflows to 5x2 thumb deck in Portrait!)
	var hb_wrap: VBoxContainer = VBoxContainer.new()
	hb_wrap_ref = hb_wrap
	hb_wrap.set_anchors_preset(Control.PRESET_BOTTOM_WIDE)
	hb_wrap.offset_top = -94
	hb_wrap.offset_bottom = -12
	hb_wrap.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(hb_wrap)

	held_name_label = Label.new()
	held_name_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	held_name_label.add_theme_font_size_override("font_size", 14)
	held_name_label.add_theme_color_override("font_color", Color(1.0, 0.96, 0.82))
	hb_wrap.add_child(held_name_label)

	var hb_center: CenterContainer = CenterContainer.new()
	hb_center.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hb_wrap.add_child(hb_center)

	var hb_panel: PanelContainer = PanelContainer.new()
	hb_center.add_child(hb_panel)
	var hb_row: GridContainer = GridContainer.new()
	hb_grid_ref = hb_row
	hb_row.columns = GameState.HOTBAR_SIZE
	hb_row.add_theme_constant_override("h_separation", 6)
	hb_row.add_theme_constant_override("v_separation", 6)
	hb_panel.add_child(hb_row)

	for i in range(GameState.HOTBAR_SIZE):
		var slot_btn: Button = Button.new()
		slot_btn.custom_minimum_size = Vector2(50, 50)
		var idx: int = i
		slot_btn.pressed.connect(func():
			GameState.selected_hotbar = idx
			refresh()
		)
		var icon_rect: TextureRect = TextureRect.new()
		icon_rect.set_anchors_preset(Control.PRESET_FULL_RECT)
		icon_rect.offset_left = 6
		icon_rect.offset_top = 6
		icon_rect.offset_right = -6
		icon_rect.offset_bottom = -6
		icon_rect.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		icon_rect.mouse_filter = Control.MOUSE_FILTER_IGNORE
		slot_btn.add_child(icon_rect)

		var num_lbl: Label = Label.new()
		num_lbl.text = str((i + 1) % 10)
		num_lbl.position = Vector2(3, 1)
		num_lbl.add_theme_font_size_override("font_size", 10)
		num_lbl.add_theme_color_override("font_color", Color(0.75, 0.78, 0.82))
		slot_btn.add_child(num_lbl)

		var cnt_lbl: Label = Label.new()
		cnt_lbl.set_anchors_preset(Control.PRESET_BOTTOM_RIGHT)
		cnt_lbl.offset_left = -28
		cnt_lbl.offset_top = -18
		cnt_lbl.offset_right = -3
		cnt_lbl.offset_bottom = -1
		cnt_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
		cnt_lbl.add_theme_font_size_override("font_size", 12)
		slot_btn.add_child(cnt_lbl)

		hb_row.add_child(slot_btn)
		hotbar_slots.append({"btn": slot_btn, "icon": icon_rect, "cnt": cnt_lbl})

	# Bottom-Right Energy & HP Bars
	var br_panel: PanelContainer = PanelContainer.new()
	br_panel_ref = br_panel
	br_panel.set_anchors_preset(Control.PRESET_BOTTOM_RIGHT)
	br_panel.offset_left = -226
	br_panel.offset_top = -94
	br_panel.offset_right = -14
	br_panel.offset_bottom = -14
	add_child(br_panel)
	var br_v: VBoxContainer = VBoxContainer.new()
	br_panel.add_child(br_v)

	energy_txt = Label.new()
	energy_txt.add_theme_font_size_override("font_size", 12)
	br_v.add_child(energy_txt)
	energy_bar = ProgressBar.new()
	energy_bar.custom_minimum_size = Vector2(180, 12)
	energy_bar.show_percentage = false
	energy_bar.modulate = Color(0.45, 0.95, 0.45)
	br_v.add_child(energy_bar)

	hp_txt = Label.new()
	hp_txt.add_theme_font_size_override("font_size", 12)
	br_v.add_child(hp_txt)
	hp_bar = ProgressBar.new()
	hp_bar.custom_minimum_size = Vector2(180, 12)
	hp_bar.show_percentage = false
	hp_bar.modulate = Color(0.95, 0.35, 0.35)
	br_v.add_child(hp_bar)

	# Bottom-Left Smart Tile Inspector Card
	inspector_panel = PanelContainer.new()
	inspector_panel.set_anchors_preset(Control.PRESET_BOTTOM_LEFT)
	inspector_panel.offset_left = 14
	inspector_panel.offset_top = -94
	inspector_panel.offset_right = 356
	inspector_panel.offset_bottom = -14
	inspector_panel.visible = false
	add_child(inspector_panel)
	inspector_label = Label.new()
	inspector_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	inspector_label.add_theme_font_size_override("font_size", 12)
	inspector_label.add_theme_color_override("font_color", Color(0.88, 0.96, 0.88))
	inspector_panel.add_child(inspector_label)


func set_inspector_text(txt: String) -> void:
	if inspector_panel == null or inspector_label == null:
		return
	if txt.is_empty():
		inspector_panel.visible = false
	else:
		inspector_label.text = txt
		inspector_panel.visible = true


func show_toast(text: String, col: Color = Color.WHITE) -> void:
	if toast_label == null:
		return
	toast_label.text = text
	toast_label.add_theme_color_override("font_color", col)
	toast_label.visible = true
	_toast_timer = 3.2


func _update_mute_button() -> void:
	if mute_btn != null:
		mute_btn.text = "🔇开启" if AudioManager.muted else "🔊静音"


func set_lens_indicator(active: bool) -> void:
	if lens_badge != null:
		lens_badge.visible = active


func apply_orientation_layout(portrait: bool) -> void:
	is_portrait_layout = portrait
	if orient_btn != null:
		orient_btn.text = "🔄横屏" if portrait else "🔄竖屏"
	if hb_grid_ref != null:
		hb_grid_ref.columns = 5 if portrait else GameState.HOTBAR_SIZE
	if hb_wrap_ref != null:
		hb_wrap_ref.offset_top = -158 if portrait else -94
		hb_wrap_ref.offset_bottom = -10 if portrait else -12
	if help_lbl_ref != null:
		help_lbl_ref.visible = not portrait
	if tl_panel_ref != null:
		tl_panel_ref.position = Vector2(10, 12) if portrait else Vector2(14, 14)
		tl_panel_ref.custom_minimum_size = Vector2(436, 0) if portrait else Vector2(430, 0)
	if tr_panel_ref != null:
		tr_panel_ref.offset_left = -250 if portrait else -272
		tr_panel_ref.offset_top = 12 if portrait else 14
		tr_panel_ref.offset_right = -10 if portrait else -14
		tr_panel_ref.offset_bottom = 162 if portrait else 166
	if br_panel_ref != null:
		if portrait:
			br_panel_ref.set_anchors_preset(Control.PRESET_TOP_RIGHT)
			br_panel_ref.offset_left = -250
			br_panel_ref.offset_top = 168
			br_panel_ref.offset_right = -10
			br_panel_ref.offset_bottom = 248
		else:
			br_panel_ref.set_anchors_preset(Control.PRESET_BOTTOM_RIGHT)
			br_panel_ref.offset_left = -226
			br_panel_ref.offset_top = -94
			br_panel_ref.offset_right = -14
			br_panel_ref.offset_bottom = -14
	if toast_label != null:
		if portrait:
			toast_label.offset_top = 256
			toast_label.offset_left = 20
			toast_label.offset_right = -20
			toast_label.offset_bottom = 302
		else:
			toast_label.offset_top = 14
			toast_label.offset_left = 454
			toast_label.offset_right = -286
			toast_label.offset_bottom = 58
	if tutorial_panel != null:
		tutorial_panel.position = Vector2(10, 140) if portrait else Vector2(14, 178)
	if inspector_panel != null:
		if portrait:
			inspector_panel.set_anchors_preset(Control.PRESET_BOTTOM_WIDE)
			inspector_panel.offset_left = 176
			inspector_panel.offset_top = -226
			inspector_panel.offset_right = -176
			inspector_panel.offset_bottom = -164
		else:
			inspector_panel.set_anchors_preset(Control.PRESET_BOTTOM_LEFT)
			inspector_panel.offset_left = 14
			inspector_panel.offset_top = -94
			inspector_panel.offset_right = 356
			inspector_panel.offset_bottom = -14


func refresh() -> void:
	if time_label == null:
		return
	_update_mute_button()
	var fh_title: String = "🏡 三阶星露庄园" if GameState.house_tier >= 3 else ("🏡 二阶双人婚房" if GameState.house_tier == 2 else "🍳 农舍与厨房")
	var zone_names: Dictionary = {
		"farm": "🏡 回响农场",
		"farmhouse": fh_title,
		"greenhouse": "🌿 四季生态温室",
		"ranch": "🐄 阳光牧场",
		"secret_woods": "🌲 迷雾回响秘林",
		"town": "⛲ 回响镇广场",
		"lake": "🌊 低语湖畔",
		"coral_island": "🏖️ 星露珊瑚群岛",
		"mine": "⛏️ 回响矿洞 %d 层" % GameState.mine_current_floor,
	}
	zone_label.text = str(zone_names.get(GameState.current_zone, GameState.current_zone))
	if tutorial_label != null and tutorial_panel != null:
		var ttxt: String = GameState.get_tutorial_prompt()
		tutorial_label.text = ttxt
		tutorial_panel.visible = not ttxt.is_empty()
	var fest_str: String = "  🎉品鉴日(1.5x)" if GameState.is_harvest_festival_day() else ""
	time_label.text = "第%d年 %s第%d日  %s · %s%s" % [
		GameState.year, GameState.get_season_name(), GameState.day, GameState.get_time_string(), GameState.get_weather_name(), fest_str
	]
	gold_label.text = "💰 %d G" % GameState.gold
	water_label.text = "💧 水壶水量：%d / %d" % [GameState.watering_can_water, GameState.max_watering_can]
	if buff_label != null:
		var btxt: String = GameState.get_active_buff_text()
		buff_label.text = btxt
		buff_label.visible = not btxt.is_empty()

	energy_bar.max_value = GameState.max_energy
	energy_bar.value = GameState.energy
	energy_txt.text = "⚡ 体力 %d / %d" % [int(GameState.energy), int(GameState.max_energy)]

	hp_bar.max_value = GameState.max_hp
	hp_bar.value = GameState.hp
	hp_txt.text = "❤️ 生命 %d / %d" % [int(GameState.hp), int(GameState.max_hp)]

	for i in range(hotbar_slots.size()):
		var ui_s: Dictionary = hotbar_slots[i]
		var btn: Button = ui_s["btn"]
		var icon_r: TextureRect = ui_s["icon"]
		var cnt_l: Label = ui_s["cnt"]
		var inv_s: Dictionary = GameState.inventory[i]
		if i == GameState.selected_hotbar:
			btn.add_theme_stylebox_override("normal", UITheme.make_card_style(Color(0.28, 0.34, 0.22, 1.0), Color(1.0, 0.85, 0.32, 1.0), 6))
		else:
			btn.remove_theme_stylebox_override("normal")
		if inv_s.is_empty():
			icon_r.texture = null
			cnt_l.text = ""
		else:
			var iid: String = str(inv_s.get("id", ""))
			var item_def: Dictionary = DataRegistry.get_item(iid)
			icon_r.texture = AssetRegistry.get_icon(str(item_def.get("icon_id", iid)))
			var cnt: int = int(inv_s.get("count", 1))
			cnt_l.text = str(cnt) if cnt > 1 else ""

	var sel: Dictionary = GameState.get_selected_slot()
	if sel.is_empty():
		held_name_label.text = "空手"
	else:
		var def: Dictionary = DataRegistry.get_item(str(sel.get("id", "")))
		held_name_label.text = "%s — %s" % [str(def.get("name", "")), str(def.get("description", ""))]
