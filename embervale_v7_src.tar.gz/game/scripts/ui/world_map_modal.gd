class_name WorldMapModal
extends Control

signal fast_travel_requested(zone_id: String, spawn_grid: Vector2i)

var npc_scheduler: NPCScheduler = null
var map_canvas: Control = null
var status_lbl: Label = null

const MAP_NODES: Array = [
	{"id": "ranch", "name": "🐄 阳光牧场", "pos": Vector2(100, 175), "color": Color(0.56, 0.84, 0.42), "spawn": Vector2i(14, 11), "travel": true},
	{"id": "farm", "name": "🏡 回响农场", "pos": Vector2(280, 175), "color": Color(0.46, 0.78, 0.38), "spawn": Vector2i(10, 10), "travel": true},
	{"id": "farmhouse", "name": "🍳 农舍与厨房", "pos": Vector2(220, 78), "color": Color(0.88, 0.62, 0.36), "spawn": Vector2i(6, 9), "travel": false},
	{"id": "greenhouse", "name": "🌿 四季温室", "pos": Vector2(350, 78), "color": Color(0.38, 0.86, 0.72), "spawn": Vector2i(6, 9), "travel": false},
	{"id": "mine", "name": "⛏️ 回响矿洞", "pos": Vector2(280, 290), "color": Color(0.62, 0.58, 0.76), "spawn": Vector2i(11, 14), "travel": false},
	{"id": "town", "name": "⛲ 回响镇广场", "pos": Vector2(465, 175), "color": Color(0.86, 0.76, 0.48), "spawn": Vector2i(16, 11), "travel": true},
	{"id": "lake", "name": "🎣 低语湖畔", "pos": Vector2(465, 290), "color": Color(0.38, 0.72, 0.94), "spawn": Vector2i(13, 6), "travel": true},
	{"id": "secret_woods", "name": "🌲 迷雾秘林", "pos": Vector2(100, 290), "color": Color(0.28, 0.78, 0.54), "spawn": Vector2i(12, 3), "travel": true},
	{"id": "coral_island", "name": "🏖️ 珊瑚群岛", "pos": Vector2(625, 290), "color": Color(0.24, 0.90, 0.86), "spawn": Vector2i(14, 5), "travel": true},
]

const MAP_EDGES: Array = [
	[0, 1], [1, 2], [1, 3], [1, 4], [1, 5], [5, 6], [0, 7], [6, 8]
]


func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	theme = UITheme.build_theme()
	visible = false
	_build_ui()


func _build_ui() -> void:
	var dim: ColorRect = ColorRect.new()
	dim.set_anchors_preset(Control.PRESET_FULL_RECT)
	dim.color = Color(0.05, 0.03, 0.02, 0.58)
	add_child(dim)

	var center: CenterContainer = CenterContainer.new()
	center.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(center)

	var panel: PanelContainer = PanelContainer.new()
	panel.custom_minimum_size = Vector2(760, 500)
	center.add_child(panel)

	var v: VBoxContainer = VBoxContainer.new()
	v.add_theme_constant_override("separation", 10)
	panel.add_child(v)

	var hdr: HBoxContainer = HBoxContainer.new()
	v.add_child(hdr)
	var t: Label = Label.new()
	t.text = "🗺️ 回响山谷手绘全景导览图（村民实时动向 & 户外快捷漫步）"
	t.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	t.add_theme_font_size_override("font_size", 18)
	t.add_theme_color_override("font_color", Color(1.0, 0.88, 0.48))
	hdr.add_child(t)

	var cb: Button = Button.new()
	cb.text = "✕ 关闭 [N]"
	cb.custom_minimum_size = Vector2(120, 44)
	cb.pressed.connect(func(): visible = false; GameState.time_paused = false)
	hdr.add_child(cb)

	map_canvas = Control.new()
	map_canvas.custom_minimum_size = Vector2(700, 355)
	map_canvas.draw.connect(_draw_map)
	v.add_child(map_canvas)

	status_lbl = Label.new()
	status_lbl.add_theme_font_size_override("font_size", 13)
	status_lbl.add_theme_color_override("font_color", Color(0.95, 0.88, 0.72))
	v.add_child(status_lbl)

	var btn_row: HFlowContainer = HFlowContainer.new()
	btn_row.alignment = FlowContainer.ALIGNMENT_CENTER
	btn_row.add_theme_constant_override("h_separation", 8)
	btn_row.add_theme_constant_override("v_separation", 6)
	v.add_child(btn_row)

	var tip_l: Label = Label.new()
	tip_l.text = "⚡ 快捷前往户外区域："
	tip_l.add_theme_font_size_override("font_size", 13)
	btn_row.add_child(tip_l)

	for nd in MAP_NODES:
		var d: Dictionary = nd
		if not bool(d.get("travel", false)):
			continue
		var b: Button = Button.new()
		b.text = str(d.get("name", ""))
		var zid: String = str(d.get("id", "farm"))
		var sp: Vector2i = d["spawn"]
		b.pressed.connect(func():
			visible = false
			GameState.time_paused = false
			fast_travel_requested.emit(zid, sp)
		)
		btn_row.add_child(b)


func open_map() -> void:
	visible = true
	GameState.time_paused = true
	var anim_cnt: int = GameState.ranch_animals.size()
	var perf: Dictionary = GameState.compute_valley_perfection()
	status_lbl.text = "🐾 牧场动物：%d 只 · 饲草：%d 份  |  ⛏️ 矿洞最高：%d 层  |  🏆 山谷完美度：%d%%" % [
		anim_cnt, GameState.trough_hay, GameState.mine_max_floor, int(perf.get("percent", 0))
	]
	if map_canvas != null:
		map_canvas.queue_redraw()


func _draw_map() -> void:
	var f: Font = UITheme.get_font()
	var r_bg: Rect2 = Rect2(0, 0, map_canvas.size.x, map_canvas.size.y)
	map_canvas.draw_rect(r_bg, Color(0.18, 0.24, 0.16, 0.96))
	map_canvas.draw_rect(r_bg, Color(0.76, 0.56, 0.28, 0.9), false, 2.0)

	# Decorative river & hills
	map_canvas.draw_rect(Rect2(455, 275, 220, 68), Color(0.22, 0.48, 0.68, 0.45))

	# Roads
	for e in MAP_EDGES:
		var pair: Array = e
		var p1: Vector2 = (MAP_NODES[int(pair[0])] as Dictionary)["pos"]
		var p2: Vector2 = (MAP_NODES[int(pair[1])] as Dictionary)["pos"]
		map_canvas.draw_line(p1, p2, Color(0.42, 0.30, 0.18, 0.95), 8.0)
		map_canvas.draw_line(p1, p2, Color(0.84, 0.68, 0.44, 0.95), 4.0)

	# Group NPCs by zone
	var npcs_by_zone: Dictionary = {}
	if npc_scheduler != null:
		for zid in ["ranch", "farm", "farmhouse", "town", "lake", "secret_woods"]:
			var arr: Array = []
			for nst in npc_scheduler.get_npcs_in_zone(zid):
				arr.append(str((nst as Dictionary).get("name", "")))
			if arr.size() > 0:
				npcs_by_zone[zid] = arr

	for nd in MAP_NODES:
		var d: Dictionary = nd
		var zid: String = str(d.get("id", ""))
		var p: Vector2 = d["pos"]
		var col: Color = d["color"]
		var is_here: bool = (GameState.current_zone == zid)
		var box: Rect2 = Rect2(p.x - 68, p.y - 24, 136, 48)
		map_canvas.draw_rect(box, Color(0.16, 0.11, 0.08, 0.94))
		map_canvas.draw_rect(box, Color(1.0, 0.88, 0.32) if is_here else col, false, 3.0 if is_here else 2.0)
		map_canvas.draw_string(f, Vector2(box.position.x + 10, box.position.y + 22), str(d.get("name", "")), HORIZONTAL_ALIGNMENT_LEFT, -1, 13, Color(1.0, 0.96, 0.86))
		if is_here:
			map_canvas.draw_string(f, Vector2(box.position.x + 12, box.position.y + 40), "📍 你在这里", HORIZONTAL_ALIGNMENT_LEFT, -1, 11, Color(1.0, 0.86, 0.32))
		elif npcs_by_zone.has(zid):
			var names_txt: String = "👤 " + "·".join(npcs_by_zone[zid] as Array)
			map_canvas.draw_string(f, Vector2(box.position.x + 8, box.position.y + 40), names_txt, HORIZONTAL_ALIGNMENT_LEFT, -1, 10, Color(0.65, 0.95, 0.78))
