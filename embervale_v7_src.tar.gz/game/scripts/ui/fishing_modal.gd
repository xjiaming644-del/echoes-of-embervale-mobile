class_name FishingModal
extends Control

const TRACK_H: float = 280.0
var cur_bar_h: float = 76.0

var target_fish: Dictionary = {}
var bar_y: float = 180.0
var bar_vel: float = 0.0
var fish_y: float = 140.0
var fish_target_y: float = 100.0
var fish_timer: float = 0.0
var progress: float = 0.30
var perfect: bool = true
var active: bool = false
var has_treasure: bool = false
var treasure_y: float = 80.0
var treasure_prog: float = 0.0
var treasure_collected: bool = false
var last_treasure_reward: String = ""
var external_lift_held: bool = false
var _touch_lifting: bool = false
var _btn_lifting: bool = false

var track_draw: Control = null
var title_lbl: Label = null
var progress_bar: ProgressBar = null
var lift_btn: Button = null
var cancel_btn: Button = null


func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_STOP
	theme = UITheme.build_theme()
	visible = false
	_build_ui()


func _build_ui() -> void:
	var dim: ColorRect = ColorRect.new()
	dim.set_anchors_preset(Control.PRESET_FULL_RECT)
	dim.mouse_filter = Control.MOUSE_FILTER_PASS
	dim.color = Color(0, 0, 0, 0.5)
	add_child(dim)

	var center: CenterContainer = CenterContainer.new()
	center.set_anchors_preset(Control.PRESET_FULL_RECT)
	center.mouse_filter = Control.MOUSE_FILTER_PASS
	add_child(center)

	var panel: PanelContainer = PanelContainer.new()
	panel.custom_minimum_size = Vector2(380, 476)
	panel.mouse_filter = Control.MOUSE_FILTER_PASS
	center.add_child(panel)

	var v: VBoxContainer = VBoxContainer.new()
	v.add_theme_constant_override("separation", 10)
	v.mouse_filter = Control.MOUSE_FILTER_PASS
	panel.add_child(v)

	title_lbl = Label.new()
	title_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title_lbl.add_theme_font_size_override("font_size", 17)
	title_lbl.add_theme_color_override("font_color", Color(0.55, 0.92, 1.0))
	v.add_child(title_lbl)

	var hint: Label = Label.new()
	hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	hint.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	hint.custom_minimum_size = Vector2(340, 0)
	hint.text = "按住下方大按钮 / 屏幕任意处 / [空格/手柄A] 抬升绿条（悬停金宝箱可捞海底秘宝）！"
	hint.add_theme_font_size_override("font_size", 12)
	v.add_child(hint)

	var hbox: HBoxContainer = HBoxContainer.new()
	hbox.alignment = BoxContainer.ALIGNMENT_CENTER
	hbox.add_theme_constant_override("separation", 24)
	hbox.mouse_filter = Control.MOUSE_FILTER_PASS
	v.add_child(hbox)

	track_draw = Control.new()
	track_draw.custom_minimum_size = Vector2(64, TRACK_H)
	track_draw.mouse_filter = Control.MOUSE_FILTER_PASS
	track_draw.draw.connect(_on_draw_track)
	hbox.add_child(track_draw)

	progress_bar = ProgressBar.new()
	progress_bar.custom_minimum_size = Vector2(26, TRACK_H)
	progress_bar.fill_mode = ProgressBar.FILL_BOTTOM_TO_TOP
	progress_bar.max_value = 1.0
	progress_bar.show_percentage = false
	progress_bar.modulate = Color(0.45, 0.95, 0.55)
	progress_bar.mouse_filter = Control.MOUSE_FILTER_PASS
	hbox.add_child(progress_bar)

	lift_btn = Button.new()
	lift_btn.text = "🎣 按住抬升绿条"
	lift_btn.custom_minimum_size = Vector2(280, 52)
	lift_btn.add_theme_font_size_override("font_size", 16)
	lift_btn.add_theme_stylebox_override("normal", UITheme.make_card_style(Color(0.16, 0.38, 0.28, 0.96), Color(0.58, 0.98, 0.72, 0.98), 14))
	lift_btn.add_theme_stylebox_override("hover", UITheme.make_card_style(Color(0.22, 0.48, 0.34, 0.98), Color(0.78, 1.0, 0.84, 1.0), 14))
	lift_btn.add_theme_stylebox_override("pressed", UITheme.make_card_style(Color(0.12, 0.28, 0.20, 0.98), Color(1.0, 0.92, 0.46, 1.0), 14))
	lift_btn.button_down.connect(func(): _btn_lifting = true)
	lift_btn.button_up.connect(func(): _btn_lifting = false)
	v.add_child(lift_btn)

	cancel_btn = Button.new()
	cancel_btn.text = "✕ 收杆放弃 [Esc]"
	cancel_btn.custom_minimum_size = Vector2(200, 44)
	cancel_btn.pressed.connect(func(): _finish_fishing(false))
	v.add_child(cancel_btn)


func start_fishing(zone_id: String) -> void:
	if not GameState.consume_energy(4.0):
		EventBus.toast_message.emit("体力不足，无法抛竿！", Color(1.0, 0.5, 0.4))
		return
	target_fish = _pick_fish(zone_id)
	var base_bar: float = 100.0 if GameState.has_keepsake("ache") else 76.0
	cur_bar_h = clampf(base_bar * (1.0 + GameState.get_buff_fish_bonus()), 64.0, 150.0)
	bar_y = TRACK_H - cur_bar_h - 10.0
	bar_vel = 0.0
	fish_y = TRACK_H * 0.5
	fish_target_y = randf_range(24.0, TRACK_H - 24.0)
	fish_timer = 0.8
	progress = 0.30
	perfect = true
	has_treasure = randf() < 0.45
	treasure_y = randf_range(38.0, TRACK_H - 46.0)
	treasure_prog = 0.0
	treasure_collected = false
	last_treasure_reward = ""
	active = true
	visible = true
	GameState.time_paused = true
	title_lbl.text = "🎣 有大鱼咬钩了！"


func force_spawn_treasure(ty: float = 110.0) -> void:
	has_treasure = true
	treasure_y = clampf(ty, 30.0, TRACK_H - 30.0)
	treasure_prog = 0.0
	treasure_collected = false


func _pick_fish(zone_id: String) -> Dictionary:
	var candidates: Array = []
	var s: String = GameState.get_season()
	var w: String = GameState.weather
	for f in DataRegistry.get_fish_list():
		var fd: Dictionary = f
		var zs: Array = fd.get("zones", [])
		var ss: Array = fd.get("seasons", [])
		var ws: Array = fd.get("weathers", [])
		if zs.has(zone_id) and ss.has(s) and (ws.has(w) or ws.has("sunny")):
			if GameState.hour >= int(fd.get("min_hour", 6)) and GameState.hour <= int(fd.get("max_hour", 25)):
				candidates.append(fd)
	if candidates.is_empty():
		return DataRegistry.get_fish_list()[0]
	return candidates[randi() % candidates.size()]


func _process(delta: float) -> void:
	if not active:
		return
	var lifting: bool = Input.is_key_pressed(KEY_SPACE) or Input.is_mouse_button_pressed(MOUSE_BUTTON_LEFT) or Input.is_joy_button_pressed(0, JOY_BUTTON_A) or external_lift_held or _touch_lifting or _btn_lifting
	if lifting:
		bar_vel -= 680.0 * delta
	else:
		bar_vel += 560.0 * delta
	bar_vel = clampf(bar_vel, -340.0, 340.0)
	bar_y += bar_vel * delta
	if bar_y < 0.0:
		bar_y = 0.0
		bar_vel = 0.0
	elif bar_y > TRACK_H - cur_bar_h:
		bar_y = TRACK_H - cur_bar_h
		bar_vel = -bar_vel * 0.35

	var diff: float = float(target_fish.get("difficulty", 0.35))
	fish_timer -= delta
	if fish_timer <= 0.0:
		fish_timer = randf_range(0.55, 1.35) * (1.2 - diff * 0.5)
		var jump: float = 70.0 + diff * 140.0
		fish_target_y = clampf(fish_y + randf_range(-jump, jump), 18.0, TRACK_H - 18.0)

	var fish_spd: float = 90.0 + diff * 180.0
	fish_y = move_toward(fish_y, fish_target_y, fish_spd * delta)

	var inside: bool = (fish_y >= bar_y - 6.0) and (fish_y <= bar_y + cur_bar_h + 6.0)
	if inside:
		progress += 0.34 * delta
	else:
		perfect = false
		progress -= (0.16 + diff * 0.14) * delta

	if has_treasure and not treasure_collected:
		var on_chest: bool = (treasure_y >= bar_y - 4.0) and (treasure_y <= bar_y + cur_bar_h + 4.0)
		if on_chest:
			treasure_prog = minf(1.0, treasure_prog + 0.92 * delta)
			if treasure_prog >= 1.0:
				treasure_collected = true
				AudioManager.play_sfx("coin")
		else:
			treasure_prog = maxf(0.0, treasure_prog - 0.25 * delta)

	progress_bar.value = clampf(progress, 0.0, 1.0)
	track_draw.queue_redraw()

	if progress >= 1.0:
		_finish_fishing(true)
	elif progress <= 0.0:
		_finish_fishing(false)


func _on_draw_track() -> void:
	# Water background
	track_draw.draw_rect(Rect2(0, 0, 64, TRACK_H), Color(0.08, 0.24, 0.38, 1.0))
	track_draw.draw_rect(Rect2(0, 0, 64, TRACK_H), Color(0.45, 0.72, 0.90, 1.0), false, 2.0)

	# Catch bar
	var inside: bool = (fish_y >= bar_y - 6.0) and (fish_y <= bar_y + cur_bar_h + 6.0)
	var bar_col: Color = Color(0.32, 0.92, 0.45, 0.85) if inside else Color(0.28, 0.72, 0.42, 0.55)
	track_draw.draw_rect(Rect2(6, bar_y, 52, cur_bar_h), bar_col)
	track_draw.draw_rect(Rect2(6, bar_y, 52, cur_bar_h), Color(0.75, 1.0, 0.78, 0.95), false, 2.0)

	# Sunken Pirate Treasure Chest on track
	if has_treasure and not treasure_collected:
		var ctex: Texture2D = AssetRegistry.get_icon("machine_chest")
		if ctex != null:
			track_draw.draw_texture_rect(ctex, Rect2(20, treasure_y - 12, 24, 24), false)
		else:
			track_draw.draw_rect(Rect2(22, treasure_y - 9, 20, 18), Color(0.95, 0.78, 0.22))
		track_draw.draw_rect(Rect2(14, treasure_y - 17, 36, 4), Color(0.12, 0.08, 0.04, 0.88))
		track_draw.draw_rect(Rect2(14, treasure_y - 17, 36.0 * treasure_prog, 4), Color(1.0, 0.88, 0.28))

	# Fish icon
	var fid: String = str(target_fish.get("id", "fish_crucian"))
	var ftex: Texture2D = AssetRegistry.get_icon(fid)
	if ftex != null:
		track_draw.draw_texture_rect(ftex, Rect2(18, fish_y - 14, 28, 28), false)
	else:
		track_draw.draw_circle(Vector2(32, fish_y), 10.0, Color(0.95, 0.8, 0.3))


func _gui_input(event: InputEvent) -> void:
	if event is InputEventScreenTouch:
		var st: InputEventScreenTouch = event
		_touch_lifting = st.pressed
		accept_event()
	elif event is InputEventMouseButton:
		var mb: InputEventMouseButton = event
		if mb.button_index == MOUSE_BUTTON_LEFT:
			_touch_lifting = mb.pressed
			accept_event()


func _finish_fishing(won: bool) -> void:
	active = false
	_touch_lifting = false
	_btn_lifting = false
	external_lift_held = false
	visible = false
	GameState.time_paused = false
	if won:
		var fid: String = str(target_fish.get("id", "fish_crucian"))
		var fname: String = str(target_fish.get("name", fid))
		var qual: int = 2 if perfect else (1 if randf() < 0.35 else 0)
		GameState.add_item(fid, 1, qual)
		GameState.add_skill_xp("fishing", 18 + int(float(target_fish.get("difficulty", 0.3)) * 20))
		var chest_note: String = ""
		if treasure_collected:
			var pool: Array = ["coral_pearl", "echo_crystal", "gold_ore"] if GameState.current_zone == "coral_island" else ["echo_crystal", "gold_ore", "coral_pearl"]
			var prize: String = str(pool[randi() % pool.size()])
			last_treasure_reward = prize
			var p_def: Dictionary = DataRegistry.get_item(prize)
			var p_nm: String = str(p_def.get("name", prize))
			if GameState.add_item(prize, 1, 0):
				GameState.gold += 180
				chest_note = " + 🎁海底宝箱【%s & 180G】" % p_nm
			else:
				var fallback_g: int = 180 + int(p_def.get("sell_price", 150))
				GameState.gold += fallback_g
				chest_note = " + 🎁海底宝箱【背包已满折算 %dG】" % fallback_g
			EventBus.player_stats_changed.emit()
		AudioManager.play_sfx("fish_catch")
		EventBus.toast_message.emit("🐟 漂亮！成功钓起【%s】%s%s" % [fname, "（★完美金星!）" if qual == 2 else "", chest_note], Color(0.45, 0.95, 0.72))
		if bool(target_fish.get("is_legendary", false)) or float(target_fish.get("difficulty", 0.0)) >= 0.58:
			WorldMemory.record_fact("caught_rare_fish", "在山谷水域成功钓获了珍稀大鱼%s" % fname, "ache")
	else:
		AudioManager.play_sfx("ui_click")
		EventBus.toast_message.emit("🐟 哎呀，鱼儿脱钩游走了……", Color(1.0, 0.65, 0.45))
