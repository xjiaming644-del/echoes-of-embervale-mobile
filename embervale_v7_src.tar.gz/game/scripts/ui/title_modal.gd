class_name TitleModal
extends Control

var help_box: Label = null
var continue_btn: Button = null
var showcase_btn: Button = null

signal start_new_game()
signal continue_saved_game()
signal load_showcase_game()


func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	theme = UITheme.build_theme()
	_build_ui()


func _build_ui() -> void:
	var bg: ColorRect = ColorRect.new()
	bg.set_anchors_preset(Control.PRESET_FULL_RECT)
	bg.color = Color(0.06, 0.09, 0.13, 0.90)
	add_child(bg)

	var center: CenterContainer = CenterContainer.new()
	center.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(center)

	var panel: PanelContainer = PanelContainer.new()
	panel.custom_minimum_size = Vector2(620, 420)
	center.add_child(panel)

	var v: VBoxContainer = VBoxContainer.new()
	v.alignment = BoxContainer.ALIGNMENT_CENTER
	v.add_theme_constant_override("separation", 14)
	panel.add_child(v)

	var badge: Label = Label.new()
	badge.text = "v7.1 手机微信秒开版 · 横竖双模 & 森灵离线挂机 & 庄园打卡明信片"
	badge.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	badge.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	badge.add_theme_font_size_override("font_size", 13)
	badge.add_theme_color_override("font_color", Color(0.58, 0.96, 0.72))
	v.add_child(badge)

	var title: Label = Label.new()
	title.text = "🌱 星露物语：回响山谷"
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.add_theme_font_size_override("font_size", 34)
	title.add_theme_color_override("font_color", Color(1.0, 0.88, 0.42))
	v.add_child(title)

	var sub: Label = Label.new()
	sub.text = "伴生共鸣 · 阳光牧场 · 恋爱同居 · 珊瑚群岛热带庄园 · 四季原声 · 双终局奇观"
	sub.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	sub.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	sub.add_theme_font_size_override("font_size", 14)
	sub.add_theme_color_override("font_color", Color(0.92, 0.86, 0.76))
	v.add_child(sub)

	var btn_row: HFlowContainer = HFlowContainer.new()
	btn_row.alignment = FlowContainer.ALIGNMENT_CENTER
	btn_row.add_theme_constant_override("h_separation", 12)
	btn_row.add_theme_constant_override("v_separation", 10)
	v.add_child(btn_row)

	var new_b: Button = Button.new()
	new_b.text = "🌾 开始新农场试玩"
	new_b.custom_minimum_size = Vector2(180, 46)
	new_b.pressed.connect(func():
		visible = false
		GameState.time_paused = false
		AudioManager.play_sfx("rooster_morning")
		start_new_game.emit()
	)
	btn_row.add_child(new_b)

	continue_btn = Button.new()
	continue_btn.text = "📂 读取存档1"
	continue_btn.custom_minimum_size = Vector2(142, 46)
	continue_btn.disabled = not SaveManager.has_save(1)
	continue_btn.pressed.connect(func():
		visible = false
		GameState.time_paused = false
		continue_saved_game.emit()
	)
	btn_row.add_child(continue_btn)

	showcase_btn = Button.new()
	showcase_btn.text = "🌟 毕业体验档(槽2)"
	showcase_btn.custom_minimum_size = Vector2(168, 46)
	showcase_btn.disabled = not SaveManager.has_save(2)
	showcase_btn.pressed.connect(func():
		visible = false
		GameState.time_paused = false
		load_showcase_game.emit()
	)
	btn_row.add_child(showcase_btn)

	var guide_b: Button = Button.new()
	guide_b.text = "📖 操作速览"
	guide_b.custom_minimum_size = Vector2(140, 46)
	guide_b.pressed.connect(func():
		help_box.visible = not help_box.visible
	)
	btn_row.add_child(guide_b)

	help_box = Label.new()
	help_box.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	help_box.add_theme_font_size_override("font_size", 13)
	help_box.add_theme_color_override("font_color", Color(0.86, 0.92, 0.96))
	help_box.text = (
		"【手机触屏双模】左手虚拟摇杆 + 右手大尺寸使用/交互键 · 单手点地自动寻路&收菜对话 · 切后台毫秒级自动存档\n"
		+ "【键鼠/手柄畅玩】WASD/左摇杆移动 · 左键/X使用 · 右键/E/A交互 · Tab生态透镜 · B背包整理 · N全景地图 · M日志"
	)
	v.add_child(help_box)
