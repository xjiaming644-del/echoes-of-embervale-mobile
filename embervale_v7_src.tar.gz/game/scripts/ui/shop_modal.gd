class_name ShopModal
extends Control

var current_shop_id: String = "linxia_shop"
var title_lbl: Label = null
var gold_lbl: Label = null
var buy_list: VBoxContainer = null
var sell_list: VBoxContainer = null


func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	theme = UITheme.build_theme()
	visible = false
	_build_ui()


func _build_ui() -> void:
	var dim: ColorRect = ColorRect.new()
	dim.set_anchors_preset(Control.PRESET_FULL_RECT)
	dim.color = Color(0, 0, 0, 0.55)
	add_child(dim)

	var center: CenterContainer = CenterContainer.new()
	center.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(center)

	var panel: PanelContainer = PanelContainer.new()
	panel.custom_minimum_size = Vector2(900, 520)
	center.add_child(panel)

	var root_v: VBoxContainer = VBoxContainer.new()
	panel.add_child(root_v)

	var hdr: HBoxContainer = HBoxContainer.new()
	root_v.add_child(hdr)
	title_lbl = Label.new()
	title_lbl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	title_lbl.add_theme_font_size_override("font_size", 18)
	title_lbl.add_theme_color_override("font_color", Color(1.0, 0.88, 0.45))
	hdr.add_child(title_lbl)

	gold_lbl = Label.new()
	gold_lbl.add_theme_font_size_override("font_size", 18)
	gold_lbl.add_theme_color_override("font_color", Color(1.0, 0.84, 0.25))
	hdr.add_child(gold_lbl)

	var close_btn: Button = Button.new()
	close_btn.text = "✕ 离开商店"
	close_btn.custom_minimum_size = Vector2(126, 44)
	close_btn.pressed.connect(func(): visible = false; GameState.time_paused = false)
	hdr.add_child(close_btn)

	var split: HBoxContainer = HBoxContainer.new()
	split.size_flags_vertical = Control.SIZE_EXPAND_FILL
	split.add_theme_constant_override("separation", 14)
	root_v.add_child(split)

	var left_v: VBoxContainer = VBoxContainer.new()
	left_v.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	split.add_child(left_v)
	var bl_t: Label = Label.new()
	bl_t.text = "🛒 购入当季货物"
	left_v.add_child(bl_t)
	var sc1: ScrollContainer = ScrollContainer.new()
	sc1.size_flags_vertical = Control.SIZE_EXPAND_FILL
	left_v.add_child(sc1)
	buy_list = VBoxContainer.new()
	buy_list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	sc1.add_child(buy_list)

	var right_v: VBoxContainer = VBoxContainer.new()
	right_v.custom_minimum_size = Vector2(330, 0)
	split.add_child(right_v)
	var sl_t: Label = Label.new()
	sl_t.text = "💰 背包直接变现出售"
	right_v.add_child(sl_t)
	var sc2: ScrollContainer = ScrollContainer.new()
	sc2.size_flags_vertical = Control.SIZE_EXPAND_FILL
	right_v.add_child(sc2)
	sell_list = VBoxContainer.new()
	sell_list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	sc2.add_child(sell_list)


func open_shop(shop_id: String) -> void:
	current_shop_id = shop_id
	visible = true
	GameState.time_paused = true
	refresh()


func refresh() -> void:
	var sname: String = "🌿 林夏种子杂货店 (%s季货架)" % GameState.get_season_name()
	if current_shop_id == "horn_smithy":
		sname = "⚒️ 霍恩铁匠铺补给站"
	elif current_shop_id == "island_trader":
		sname = "🏝️ 珊瑚群岛热带货栈 (全年盛夏供应)"
	title_lbl.text = sname
	gold_lbl.text = "持有金币：%d G  " % GameState.gold

	for c in buy_list.get_children():
		c.queue_free()
	if current_shop_id == "horn_smithy":
		var upg_hdr: Label = Label.new()
		upg_hdr.text = "⚒️ 工具四阶锻造升级（提升范围与威力）"
		upg_hdr.add_theme_color_override("font_color", Color(1.0, 0.84, 0.35))
		buy_list.add_child(upg_hdr)
		var tool_meta: Array = [
			["hoe", "tool_hoe", "精铁锄头", "Lv2:1×3翻地 / Lv3+:3×3九宫"],
			["can", "tool_can", "铜制水壶", "Lv2:1×3浇水 / Lv3+:3×3九宫"],
			["axe", "tool_axe", "伐木斧", "大幅提升伐木效率"],
			["pickaxe", "tool_pickaxe", "矿工十字镐", "更快敲碎深层矿石"],
			["blade", "tool_blade", "猎镰短剑", "每级物理伤害 +10"],
		]
		for tm in tool_meta:
			var arr: Array = tm
			var ttype: String = str(arr[0])
			var titem: String = str(arr[1])
			var tname: String = str(arr[2])
			var tdesc: String = str(arr[3])
			var spec: Dictionary = GameState.get_tool_upgrade_spec(ttype)
			var urow: HBoxContainer = HBoxContainer.new()
			var uic: TextureRect = TextureRect.new()
			uic.custom_minimum_size = Vector2(32, 32)
			uic.texture = AssetRegistry.get_icon(titem)
			uic.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
			urow.add_child(uic)

			var uv: VBoxContainer = VBoxContainer.new()
			uv.size_flags_horizontal = Control.SIZE_EXPAND_FILL
			urow.add_child(uv)
			var ul1: Label = Label.new()
			var cur_l: int = int(spec.get("cur_level", 1))
			if bool(spec.get("maxed", false)):
				ul1.text = "%s [Lv.%d 耀金满阶]" % [tname, cur_l]
			else:
				var bname: String = str(DataRegistry.get_item(str(spec.get("bar_id", "copper_bar"))).get("name", "金属锭"))
				ul1.text = "%s (Lv.%d -> Lv.%d %s) · %s×%d + %dG" % [
					tname, cur_l, int(spec.get("next_level", 2)), str(spec.get("next_tier", "")),
					bname, int(spec.get("bar_count", 2)), int(spec.get("gold", 300))
				]
			uv.add_child(ul1)
			var ul2: Label = Label.new()
			ul2.text = tdesc
			ul2.add_theme_font_size_override("font_size", 11)
			ul2.add_theme_color_override("font_color", Color(0.75, 0.85, 0.90))
			uv.add_child(ul2)

			var ub: Button = Button.new()
			if bool(spec.get("maxed", false)):
				ub.text = "已满级"
				ub.disabled = true
			else:
				ub.text = "锻造"
				var bid: String = str(spec.get("bar_id", "copper_bar"))
				var bneed: int = int(spec.get("bar_count", 2))
				var gneed: int = int(spec.get("gold", 300))
				ub.disabled = (GameState.gold < gneed or GameState.count_item(bid) < bneed)
				ub.pressed.connect(func():
					var res: Dictionary = GameState.upgrade_tool(ttype)
					if bool(res.get("ok", false)):
						EventBus.toast_message.emit("⚒️ %s 锻造升级至 Lv.%d【%s】！" % [tname, int(res.get("level", 2)), str(res.get("tier", ""))], Color(1.0, 0.86, 0.35))
					refresh()
				)
			urow.add_child(ub)
			buy_list.add_child(urow)

		var sep: Label = Label.new()
		sep.text = "── 铁匠铺矿石与物资补给 ──"
		sep.add_theme_color_override("font_color", Color(0.8, 0.85, 0.9))
		buy_list.add_child(sep)

	var stock: Array = DataRegistry.get_shop_stock(current_shop_id, GameState.get_season())
	for it in stock:
		var d: Dictionary = it
		var iid: String = str(d.get("id", ""))
		var price: int = int(d.get("buy_price", 0))
		var row: HBoxContainer = HBoxContainer.new()
		var ic: TextureRect = TextureRect.new()
		ic.custom_minimum_size = Vector2(32, 32)
		ic.texture = AssetRegistry.get_icon(str(d.get("icon_id", iid)))
		ic.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		row.add_child(ic)

		var v: VBoxContainer = VBoxContainer.new()
		v.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		row.add_child(v)
		var l1: Label = Label.new()
		l1.text = "%s — %dG" % [str(d.get("name", iid)), price]
		v.add_child(l1)
		var l2: Label = Label.new()
		l2.text = str(d.get("description", ""))
		l2.add_theme_font_size_override("font_size", 11)
		l2.add_theme_color_override("font_color", Color(0.75, 0.80, 0.85))
		v.add_child(l2)

		for qty in [1, 5]:
			var b: Button = Button.new()
			b.text = "买%d" % qty
			b.disabled = GameState.gold < price * qty
			var qn: int = qty
			b.pressed.connect(func():
				if GameState.gold >= price * qn:
					GameState.gold -= price * qn
					GameState.add_item(iid, qn, 0)
					AudioManager.play_sfx("coin")
					EventBus.player_stats_changed.emit()
					refresh()
			)
			row.add_child(b)
		buy_list.add_child(row)

	for c in sell_list.get_children():
		c.queue_free()
	for i in range(GameState.inventory.size()):
		var s: Dictionary = GameState.inventory[i]
		if s.is_empty():
			continue
		var iid2: String = str(s.get("id", ""))
		var qual: int = int(s.get("quality", 0))
		var unit_p: int = GameState.get_sell_price(iid2, qual)
		if unit_p <= 0:
			continue
		var cnt: int = int(s.get("count", 1))
		var def2: Dictionary = DataRegistry.get_item(iid2)
		var row2: HBoxContainer = HBoxContainer.new()
		var lbl: Label = Label.new()
		lbl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		lbl.text = "%s ×%d (%dG/个)" % [str(def2.get("name", iid2)), cnt, unit_p]
		row2.add_child(lbl)
		var sb: Button = Button.new()
		sb.text = "全部卖出 +%dG" % (unit_p * cnt)
		var slot_idx: int = i
		sb.pressed.connect(func():
			GameState.gold += unit_p * cnt
			GameState.consume_slot(slot_idx, cnt)
			AudioManager.play_sfx("coin")
			EventBus.player_stats_changed.emit()
			refresh()
		)
		row2.add_child(sb)
		sell_list.add_child(row2)
