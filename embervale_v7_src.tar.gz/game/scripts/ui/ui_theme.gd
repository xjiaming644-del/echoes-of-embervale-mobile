class_name UITheme
extends RefCounted

static var _font: Font = null
static var _theme: Theme = null


static func get_font() -> Font:
	if _font == null:
		var sys_f: SystemFont = SystemFont.new()
		sys_f.font_names = PackedStringArray([
			"Microsoft YaHei",
			"PingFang SC",
			"Hiragino Sans GB",
			"Noto Sans CJK SC",
			"SimHei",
			"Apple Color Emoji",
			"Segoe UI Emoji",
			"Noto Color Emoji",
			"Arial",
		])
		sys_f.antialiasing = TextServer.FONT_ANTIALIASING_GRAY
		var bundled_path: String = "res://assets/fonts/embervale_cjk_subset.ttf"
		var emoji_path: String = "res://assets/fonts/embervale_emoji_subset.ttf"
		if ResourceLoader.exists(bundled_path):
			var loaded = ResourceLoader.load(bundled_path)
			if loaded is FontFile:
				var ff: FontFile = loaded
				var fb_list: Array[Font] = []
				if ResourceLoader.exists(emoji_path):
					var eloaded = ResourceLoader.load(emoji_path)
					if eloaded is FontFile:
						fb_list.append(eloaded)
				fb_list.append(sys_f)
				ff.fallbacks = fb_list
				_font = ff
				return _font
		_font = sys_f
	return _font


static func build_theme() -> Theme:
	if _theme != null:
		return _theme
	var t: Theme = Theme.new()
	var f: Font = get_font()
	t.default_font = f
	t.default_font_size = 15

	# Warm Stardew Valley walnut-wood & golden-amber RPG frame
	var panel_sb: StyleBoxFlat = StyleBoxFlat.new()
	panel_sb.bg_color = Color(0.18, 0.12, 0.08, 0.94)
	panel_sb.border_color = Color(0.86, 0.62, 0.28, 0.98)
	panel_sb.set_border_width_all(3)
	panel_sb.set_corner_radius_all(8)
	panel_sb.shadow_color = Color(0.05, 0.03, 0.01, 0.48)
	panel_sb.shadow_size = 4
	panel_sb.set_content_margin_all(12)
	t.set_stylebox("panel", "PanelContainer", panel_sb)

	var btn_normal: StyleBoxFlat = StyleBoxFlat.new()
	btn_normal.bg_color = Color(0.32, 0.20, 0.12, 1.0)
	btn_normal.border_color = Color(0.74, 0.52, 0.26, 0.95)
	btn_normal.set_border_width_all(2)
	btn_normal.set_corner_radius_all(6)
	btn_normal.set_content_margin_all(7)

	var btn_hover: StyleBoxFlat = btn_normal.duplicate()
	btn_hover.bg_color = Color(0.44, 0.28, 0.16, 1.0)
	btn_hover.border_color = Color(0.98, 0.84, 0.40, 1.0)

	var btn_pressed: StyleBoxFlat = btn_normal.duplicate()
	btn_pressed.bg_color = Color(0.24, 0.14, 0.08, 1.0)

	var btn_disabled: StyleBoxFlat = btn_normal.duplicate()
	btn_disabled.bg_color = Color(0.18, 0.14, 0.11, 0.72)
	btn_disabled.border_color = Color(0.40, 0.32, 0.24, 0.6)

	t.set_stylebox("normal", "Button", btn_normal)
	t.set_stylebox("hover", "Button", btn_hover)
	t.set_stylebox("pressed", "Button", btn_pressed)
	t.set_stylebox("disabled", "Button", btn_disabled)
	t.set_color("font_color", "Button", Color(0.99, 0.95, 0.86))
	t.set_color("font_hover_color", "Button", Color(1.0, 0.98, 0.90))
	t.set_color("font_color", "Label", Color(0.98, 0.94, 0.85))

	_theme = t
	return _theme


static func make_card_style(bg: Color = Color(0.24, 0.16, 0.10, 0.94), border: Color = Color(0.82, 0.58, 0.28, 0.92), radius: int = 8) -> StyleBoxFlat:
	var sb: StyleBoxFlat = StyleBoxFlat.new()
	sb.bg_color = bg
	sb.border_color = border
	sb.set_border_width_all(2)
	sb.set_corner_radius_all(radius)
	sb.set_content_margin_all(9)
	return sb
