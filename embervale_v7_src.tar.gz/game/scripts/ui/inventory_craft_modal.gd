class_name InventoryCraftModal
extends Control

var selected_slot: int = -1
var slot_buttons: Array = []
var craft_list: VBoxContainer = null
var skills_box: VBoxContainer = null
var info_label: Label = null
var eat_btn: Button = null
var split_btn: Button = null
var close_btn: Button = null

signal request_save(slot: int)
signal request_load(slot: int)


func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	theme = UITheme.build_theme()
	visible = false
	_build_ui()
	EventBus.inventory_changed.connect(refresh)
	EventBus.player_stats_changed.connect(refresh)


func _build_ui() -> void:
	var dim: ColorRect = ColorRect.new()
	dim.set_anchors_preset(Control.PRESET_FULL_RECT)
	dim.color = Color(0, 0, 0, 0.55)
	add_child(dim)

	var center: CenterContainer = CenterContainer.new()
	center.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(center)

	var panel: PanelContainer = PanelContainer.new()
	panel.custom_minimum_size = Vector2(920, 548)
	center.add_child(panel)

	var root_v: VBoxContainer = VBoxContainer.new()
	root_v.add_theme_constant_override("separation", 10)
	panel.add_child(root_v)

	# Header
	var hdr: HBoxContainer = HBoxContainer.new()
	hdr.add_theme_constant_override("separation", 10)
	root_v.add_child(hdr)
	var title: Label = Label.new()
	title.text = "🎒 背包、制造与存档 (点选互换 · 支持下方触屏食用/拆分)"
	title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	title.add_theme_font_size_override("font_size", 17)
	title.add_theme_color_override("font_color", Color(1.0, 0.88, 0.45))
	hdr.add_child(title)
	var sort_btn: Button = Button.new()
	sort_btn.text = "🧹 一键分类整理"
	sort_btn.custom_minimum_size = Vector2(142, 44)
	sort_btn.pressed.connect(_on_sort_pressed)
	hdr.add_child(sort_btn)
	close_btn = Button.new()
	close_btn.text = "✕ 关闭 [B]"
	close_btn.custom_minimum_size = Vector2(116, 44)
	close_btn.pressed.connect(func(): visible = false; GameState.time_paused = false)
	hdr.add_child(close_btn)

	# Body split
	var split: HBoxContainer = HBoxContainer.new()
	split.size_flags_vertical = Control.SIZE_EXPAND_FILL
	split.add_theme_constant_override("separation", 16)
	root_v.add_child(split)

	# Left: Inventory Grid + Skills
	var left_v: VBoxContainer = VBoxContainer.new()
	left_v.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	split.add_child(left_v)

	var grid: GridContainer = GridContainer.new()
	grid.columns = 9
	grid.add_theme_constant_override("h_separation", 6)
	grid.add_theme_constant_override("v_separation", 6)
	left_v.add_child(grid)

	for i in range(GameState.INVENTORY_SIZE):
		var b: Button = Button.new()
		b.custom_minimum_size = Vector2(48, 48)
		var idx: int = i
		b.gui_input.connect(func(ev: InputEvent):
			if ev is InputEventMouseButton and ev.pressed:
				var mb: InputEventMouseButton = ev
				if mb.button_index == MOUSE_BUTTON_LEFT:
					if mb.shift_pressed:
						_on_slot_shift_click(idx)
					else:
						_on_slot_left_click(idx)
				elif mb.button_index == MOUSE_BUTTON_RIGHT:
					_on_slot_right_click(idx)
		)
		var ic: TextureRect = TextureRect.new()
		ic.set_anchors_preset(Control.PRESET_FULL_RECT)
		ic.offset_left = 6
		ic.offset_top = 6
		ic.offset_right = -6
		ic.offset_bottom = -6
		ic.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		ic.mouse_filter = Control.MOUSE_FILTER_IGNORE
		b.add_child(ic)

		var cl: Label = Label.new()
		cl.set_anchors_preset(Control.PRESET_BOTTOM_RIGHT)
		cl.offset_left = -28
		cl.offset_top = -18
		cl.offset_right = -3
		cl.offset_bottom = -1
		cl.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
		cl.add_theme_font_size_override("font_size", 12)
		b.add_child(cl)
		grid.add_child(b)
		slot_buttons.append({"btn": b, "icon": ic, "cnt": cl})

	info_label = Label.new()
	info_label.text = "点击任意格子查看说明、互换顺序，或使用下方按钮食用/对半拆分"
	info_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	info_label.add_theme_font_size_override("font_size", 13)
	info_label.add_theme_color_override("font_color", Color(0.85, 0.92, 0.78))
	left_v.add_child(info_label)

	# Mobile-friendly touch action bar for selected inventory item (eat dish / split stack)
	var touch_act_row: HBoxContainer = HBoxContainer.new()
	touch_act_row.add_theme_constant_override("separation", 10)
	left_v.add_child(touch_act_row)

	eat_btn = Button.new()
	eat_btn.text = "🍽️ 食用/使用选中格"
	eat_btn.custom_minimum_size = Vector2(172, 42)
	eat_btn.disabled = true
	eat_btn.pressed.connect(func(): eat_selected_slot())
	touch_act_row.add_child(eat_btn)

	split_btn = Button.new()
	split_btn.text = "✂️ 对半拆分"
	split_btn.custom_minimum_size = Vector2(142, 42)
	split_btn.disabled = true
	split_btn.pressed.connect(func(): split_selected_slot())
	touch_act_row.add_child(split_btn)

	var sk_title: Label = Label.new()
	sk_title.text = "🌟 五维技能等级"
	sk_title.add_theme_color_override("font_color", Color(0.98, 0.86, 0.45))
	left_v.add_child(sk_title)
	skills_box = VBoxContainer.new()
	left_v.add_child(skills_box)

	# Save/Load quick row
	var sl_row: HBoxContainer = HBoxContainer.new()
	sl_row.add_theme_constant_override("separation", 8)
	left_v.add_child(sl_row)
	for s_idx in [1, 2]:
		var sb: Button = Button.new()
		sb.text = "💾 存档%d" % s_idx
		sb.custom_minimum_size = Vector2(104, 42)
		var slot_n: int = s_idx
		sb.pressed.connect(func(): request_save.emit(slot_n))
		sl_row.add_child(sb)
		var lb: Button = Button.new()
		lb.text = "📂 读档%d" % s_idx
		lb.custom_minimum_size = Vector2(104, 42)
		lb.pressed.connect(func(): request_load.emit(slot_n))
		sl_row.add_child(lb)

	# Right: Crafting List
	var right_v: VBoxContainer = VBoxContainer.new()
	right_v.custom_minimum_size = Vector2(390, 0)
	split.add_child(right_v)
	var cr_t: Label = Label.new()
	cr_t.text = "🔨 随身制造台"
	cr_t.add_theme_font_size_override("font_size", 16)
	cr_t.add_theme_color_override("font_color", Color(0.6, 0.95, 0.75))
	right_v.add_child(cr_t)

	var scroll: ScrollContainer = ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	right_v.add_child(scroll)
	craft_list = VBoxContainer.new()
	craft_list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	craft_list.add_theme_constant_override("separation", 6)
	scroll.add_child(craft_list)


func open_modal() -> void:
	selected_slot = -1
	visible = true
	GameState.time_paused = true
	refresh()


func _on_sort_pressed() -> void:
	selected_slot = -1
	GameState.sort_and_merge_inventory()
	AudioManager.play_sfx("ui_click")
	EventBus.toast_message.emit("🧹 背包已按工具与类别自动合并整理！", Color(0.68, 0.96, 0.78))
	refresh()


func eat_selected_slot() -> bool:
	if selected_slot < 0 or selected_slot >= GameState.INVENTORY_SIZE:
		return false
	var s: Dictionary = GameState.inventory[selected_slot]
	if s.is_empty():
		return false
	var iid: String = str(s.get("id", ""))
	var def: Dictionary = DataRegistry.get_item(iid)
	var en: float = float(def.get("energy_restore", 0))
	var h: float = float(def.get("hp_restore", 0))
	if en <= 0.0 and h <= 0.0:
		return false
	_on_slot_right_click(selected_slot)
	if (GameState.inventory[selected_slot] as Dictionary).is_empty():
		selected_slot = -1
	refresh()
	return true


func split_selected_slot() -> bool:
	if selected_slot < 0 or selected_slot >= GameState.INVENTORY_SIZE:
		return false
	if GameState.split_slot_half(selected_slot):
		selected_slot = -1
		AudioManager.play_sfx("ui_click")
		EventBus.toast_message.emit("✂️ 已将该格物品对半拆分至空位！", Color(0.85, 0.95, 0.75))
		refresh()
		return true
	return false


func _on_slot_shift_click(idx: int) -> void:
	if GameState.split_slot_half(idx):
		selected_slot = -1
		AudioManager.play_sfx("ui_click")
		EventBus.toast_message.emit("✂️ 已将该格物品对半拆分至空位！", Color(0.85, 0.95, 0.75))
		refresh()


func _on_slot_left_click(idx: int) -> void:
	if selected_slot == -1:
		selected_slot = idx
	elif selected_slot == idx:
		selected_slot = -1
	else:
		GameState.swap_slots(selected_slot, idx)
		selected_slot = -1
	refresh()


func _on_slot_right_click(idx: int) -> void:
	var s: Dictionary = GameState.inventory[idx]
	if s.is_empty():
		return
	var iid: String = str(s.get("id", ""))
	var def: Dictionary = DataRegistry.get_item(iid)
	var en: float = float(def.get("energy_restore", 0))
	var h: float = float(def.get("hp_restore", 0))
	if en > 0 or h > 0:
		GameState.heal_player(en, h)
		GameState.apply_food_buff(def)
		GameState.consume_slot(idx, 1)
		AudioManager.play_sfx("harvest")
		var bnm: String = str(def.get("buff_name", ""))
		var bstr: String = (" · ✨" + bnm) if not bnm.is_empty() else ""
		EventBus.toast_message.emit("享用了 %s (+%d体力 +%d生命%s)" % [str(def.get("name", iid)), int(en), int(h), bstr], Color(0.5, 0.95, 0.6))
		refresh()


func refresh() -> void:
	if slot_buttons.is_empty():
		return
	for i in range(GameState.INVENTORY_SIZE):
		var ui_s: Dictionary = slot_buttons[i]
		var btn: Button = ui_s["btn"]
		var ic: TextureRect = ui_s["icon"]
		var cl: Label = ui_s["cnt"]
		var s: Dictionary = GameState.inventory[i]
		if i == selected_slot:
			btn.add_theme_stylebox_override("normal", UITheme.make_card_style(Color(0.28, 0.36, 0.24, 1.0), Color(1.0, 0.85, 0.32, 1.0), 6))
		else:
			btn.remove_theme_stylebox_override("normal")
		if s.is_empty():
			ic.texture = null
			cl.text = ""
		else:
			var iid: String = str(s.get("id", ""))
			var def: Dictionary = DataRegistry.get_item(iid)
			ic.texture = AssetRegistry.get_icon(str(def.get("icon_id", iid)))
			var cnt: int = int(s.get("count", 1))
			cl.text = str(cnt) if cnt > 1 else ""

	var can_eat_sel: bool = false
	var can_split_sel: bool = false
	if selected_slot >= 0 and not (GameState.inventory[selected_slot] as Dictionary).is_empty():
		var ss: Dictionary = GameState.inventory[selected_slot]
		var def2: Dictionary = DataRegistry.get_item(str(ss.get("id", "")))
		can_eat_sel = (float(def2.get("energy_restore", 0)) > 0.0 or float(def2.get("hp_restore", 0)) > 0.0)
		can_split_sel = (bool(def2.get("stackable", true)) and int(ss.get("count", 1)) >= 2)
		info_label.text = "【%s】%s (单价 %dG)" % [str(def2.get("name", "")), str(def2.get("description", "")), GameState.get_sell_price(str(ss.get("id", "")), int(ss.get("quality", 0)))]
	else:
		info_label.text = "提示：前10格对应底部快捷栏；点选食物后可点『🍽️ 食用』补充体力与增益"
	if eat_btn != null:
		eat_btn.disabled = not can_eat_sel
	if split_btn != null:
		split_btn.disabled = not can_split_sel

	for c in skills_box.get_children():
		c.queue_free()
	for sk in GameState.SKILL_NAMES.keys():
		var d: Dictionary = GameState.skills.get(sk, {"level": 1, "xp": 0})
		var lbl: Label = Label.new()
		lbl.add_theme_font_size_override("font_size", 13)
		var lvl: int = int(d.get("level", 1))
		lbl.text = "%s: Lv.%d  (XP %d / %d)" % [str(GameState.SKILL_NAMES[sk]), lvl, int(d.get("xp", 0)), lvl * 60]
		skills_box.add_child(lbl)

	for c in craft_list.get_children():
		c.queue_free()
	for rec in DataRegistry.get_crafting_recipes():
		var rd: Dictionary = rec
		var out_id: String = str(rd.get("output_id", ""))
		var out_def: Dictionary = DataRegistry.get_item(out_id)
		var ings: Array = rd.get("ingredients", [])
		var ing_texts: Array = []
		var can_craft: bool = true
		for ig in ings:
			var idict: Dictionary = ig
			var ing_id: String = str(idict.get("id", ""))
			var need: int = int(idict.get("count", 1))
			var have: int = GameState.count_item(ing_id)
			if have < need:
				can_craft = false
			ing_texts.append("%s %d/%d" % [str(DataRegistry.get_item(ing_id).get("name", ing_id)), have, need])

		var card: PanelContainer = PanelContainer.new()
		card.add_theme_stylebox_override("panel", UITheme.make_card_style(Color(0.15, 0.20, 0.26, 0.95), Color(0.35, 0.45, 0.55, 0.8), 6))
		var row: HBoxContainer = HBoxContainer.new()
		card.add_child(row)

		var tex_r: TextureRect = TextureRect.new()
		tex_r.custom_minimum_size = Vector2(36, 36)
		tex_r.texture = AssetRegistry.get_icon(str(out_def.get("icon_id", out_id)))
		tex_r.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		row.add_child(tex_r)

		var txt_v: VBoxContainer = VBoxContainer.new()
		txt_v.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		row.add_child(txt_v)
		var nl: Label = Label.new()
		nl.text = "%s ×%d" % [str(out_def.get("name", out_id)), int(rd.get("output_count", 1))]
		nl.add_theme_font_size_override("font_size", 14)
		txt_v.add_child(nl)
		var il: Label = Label.new()
		il.text = ", ".join(ing_texts)
		il.add_theme_font_size_override("font_size", 12)
		il.add_theme_color_override("font_color", Color(0.75, 0.92, 0.78) if can_craft else Color(0.95, 0.62, 0.55))
		txt_v.add_child(il)

		var cb: Button = Button.new()
		cb.text = "制造"
		cb.disabled = not can_craft
		cb.pressed.connect(func():
			var art: ArtisanSystem = ArtisanSystem.new()
			art.craft_recipe(rd)
			art.free()
			refresh()
		)
		row.add_child(cb)
		craft_list.add_child(card)
