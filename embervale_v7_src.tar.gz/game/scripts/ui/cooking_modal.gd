class_name CookingModal
extends Control

var recipe_list_box: VBoxContainer = null
var buff_hint_lbl: Label = null


func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	theme = UITheme.build_theme()
	visible = false
	_build_ui()


func _build_ui() -> void:
	var dim: ColorRect = ColorRect.new()
	dim.set_anchors_preset(Control.PRESET_FULL_RECT)
	dim.color = Color(0.06, 0.04, 0.02, 0.56)
	add_child(dim)

	var center: CenterContainer = CenterContainer.new()
	center.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(center)

	var panel: PanelContainer = PanelContainer.new()
	panel.custom_minimum_size = Vector2(880, 530)
	center.add_child(panel)

	var root_v: VBoxContainer = VBoxContainer.new()
	root_v.add_theme_constant_override("separation", 10)
	panel.add_child(root_v)

	var hdr: HBoxContainer = HBoxContainer.new()
	root_v.add_child(hdr)

	var title: Label = Label.new()
	title.text = "🍳 农舍乡野料理灶台 — 烹饪家常美食与探索增益"
	title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	title.add_theme_font_size_override("font_size", 19)
	title.add_theme_color_override("font_color", Color(1.0, 0.88, 0.48))
	hdr.add_child(title)

	var close_b: Button = Button.new()
	close_b.text = "✕ 关闭 [Esc]"
	close_b.custom_minimum_size = Vector2(120, 44)
	close_b.pressed.connect(func(): visible = false; GameState.time_paused = false)
	hdr.add_child(close_b)

	buff_hint_lbl = Label.new()
	buff_hint_lbl.add_theme_font_size_override("font_size", 13)
	buff_hint_lbl.add_theme_color_override("font_color", Color(0.96, 0.84, 0.58))
	root_v.add_child(buff_hint_lbl)

	var sc: ScrollContainer = ScrollContainer.new()
	sc.size_flags_vertical = Control.SIZE_EXPAND_FILL
	root_v.add_child(sc)

	recipe_list_box = VBoxContainer.new()
	recipe_list_box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	recipe_list_box.add_theme_constant_override("separation", 8)
	sc.add_child(recipe_list_box)


func open_cooking() -> void:
	visible = true
	GameState.time_paused = true
	refresh()


func cook_dish(recipe: Dictionary, eat_now: bool = false) -> bool:
	var ingredients: Array = recipe.get("ingredients", [])
	for ing in ingredients:
		var d: Dictionary = ing
		if GameState.count_item(str(d.get("id", ""))) < int(d.get("count", 1)):
			EventBus.toast_message.emit("食材不足，先去农场收获或去牧场捡鸡蛋挤奶吧！", Color(1.0, 0.58, 0.42))
			return false
	for ing2 in ingredients:
		var d2: Dictionary = ing2
		GameState.remove_item(str(d2.get("id", "")), int(d2.get("count", 1)))

	var out_id: String = str(recipe.get("output_id", ""))
	var out_cnt: int = int(recipe.get("output_count", 1))
	var def: Dictionary = DataRegistry.get_item(out_id)
	var dname: String = str(def.get("name", out_id))
	AudioManager.play_sfx("harvest")
	WorldMemory.record_fact("cooked_meal", "在农舍厨房亲手烹制了香气四溢的【%s】" % dname, "linxia")

	if eat_now:
		var en: float = float(def.get("energy_restore", 50))
		var hp_r: float = float(def.get("hp_restore", 25))
		GameState.heal_player(en, hp_r)
		GameState.apply_food_buff(def)
		EventBus.toast_message.emit("🍽️ 享用了热腾腾的【%s】！+%d体力 & 激活【%s】！" % [
			dname, int(en), str(def.get("buff_name", "饱腹满足"))
		], Color(1.0, 0.88, 0.42))
	else:
		GameState.add_item(out_id, out_cnt, 0)
		EventBus.toast_message.emit("🍳 烹饪完成：【%s】已装入背包！" % dname, Color(0.55, 0.96, 0.68))

	refresh()
	return true


func refresh() -> void:
	if recipe_list_box == null:
		return
	var cur_b: String = GameState.get_active_buff_text()
	buff_hint_lbl.text = ("当前生效料理增益：" + cur_b) if not cur_b.is_empty() else "小贴士：食用料理不仅大幅恢复体力生命，还能获得【移速加快 / 碎岩威力 / 钓鱼绿条加宽】等强力状态！"

	for c in recipe_list_box.get_children():
		c.queue_free()

	for rec in DataRegistry.get_cooking_recipes():
		var r: Dictionary = rec
		var out_id: String = str(r.get("output_id", ""))
		var def: Dictionary = DataRegistry.get_item(out_id)
		var card: PanelContainer = PanelContainer.new()
		card.add_theme_stylebox_override("panel", UITheme.make_card_style())
		recipe_list_box.add_child(card)

		var row: HBoxContainer = HBoxContainer.new()
		row.add_theme_constant_override("separation", 12)
		card.add_child(row)

		var icon_r: TextureRect = TextureRect.new()
		icon_r.custom_minimum_size = Vector2(44, 44)
		icon_r.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		icon_r.texture = AssetRegistry.get_icon(out_id)
		row.add_child(icon_r)

		var mid_v: VBoxContainer = VBoxContainer.new()
		mid_v.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		mid_v.custom_minimum_size = Vector2(420, 0)
		row.add_child(mid_v)

		var nm_lbl: Label = Label.new()
		nm_lbl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		nm_lbl.text = "%s （售%dG · +%d体/+%d血 · ✨%s）" % [
			str(def.get("name", out_id)),
			int(def.get("sell_price", 100)),
			int(def.get("energy_restore", 50)),
			int(def.get("hp_restore", 25)),
			str(def.get("buff_name", "美味")),
		]
		nm_lbl.add_theme_font_size_override("font_size", 14)
		nm_lbl.add_theme_color_override("font_color", Color(1.0, 0.92, 0.62))
		mid_v.add_child(nm_lbl)

		var ing_parts: Array = []
		var can_cook: bool = true
		for ing in r.get("ingredients", []):
			var id_d: Dictionary = ing
			var iid: String = str(id_d.get("id", ""))
			var need: int = int(id_d.get("count", 1))
			var have: int = GameState.count_item(iid)
			if have < need:
				can_cook = false
			var inm: String = str(DataRegistry.get_item(iid).get("name", iid))
			ing_parts.append("%s %d/%d" % [inm, have, need])

		var sub_lbl: Label = Label.new()
		sub_lbl.text = "所需食材：" + "  ·  ".join(ing_parts)
		sub_lbl.add_theme_font_size_override("font_size", 12)
		sub_lbl.add_theme_color_override("font_color", Color(0.68, 0.96, 0.72) if can_cook else Color(0.92, 0.66, 0.58))
		mid_v.add_child(sub_lbl)

		var b_pack: Button = Button.new()
		b_pack.text = "🍳 装盘入包"
		b_pack.disabled = not can_cook
		var rec_copy: Dictionary = r.duplicate(true)
		b_pack.pressed.connect(func(): cook_dish(rec_copy, false))
		row.add_child(b_pack)

		var b_eat: Button = Button.new()
		b_eat.text = "🍽️ 现做现吃"
		b_eat.disabled = not can_cook
		b_eat.pressed.connect(func(): cook_dish(rec_copy, true))
		row.add_child(b_eat)
