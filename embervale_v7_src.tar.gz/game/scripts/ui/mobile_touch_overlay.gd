class_name MobileTouchOverlay
extends Control

signal action_use_primary()
signal action_interact()
signal toggle_sprint_changed(locked: bool)

var mobile_enabled: bool = false
var move_vector: Vector2 = Vector2.ZERO
var joy_sprinting: bool = false
var sprint_locked: bool = true
var is_use_held: bool = false

var joy_zone: Control = null
var right_cluster: Control = null
var sprint_btn: Button = null
var interact_btn: Button = null
var use_btn: Button = null

var _joy_center: Vector2 = Vector2(92.0, 92.0)
var _joy_knob: Vector2 = Vector2(92.0, 92.0)
var _joy_radius: float = 64.0
var _joy_active: bool = false
var _joy_touch_idx: int = -1
var _joy_mouse_dragging: bool = false


func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	theme = UITheme.build_theme()
	_build_controls()
	var auto_on: bool = (
		OS.has_feature("web")
		or OS.has_feature("mobile")
		or OS.has_feature("android")
		or OS.has_feature("ios")
		or DisplayServer.is_touchscreen_available()
	)
	set_mobile_enabled(auto_on)


func set_mobile_enabled(flag: bool) -> void:
	mobile_enabled = flag
	visible = flag
	if not flag:
		_reset_joystick()
		is_use_held = false


func apply_orientation_layout(portrait: bool) -> void:
	if joy_zone != null:
		if portrait:
			joy_zone.offset_left = 14
			joy_zone.offset_top = -362
			joy_zone.offset_right = 198
			joy_zone.offset_bottom = -178
		else:
			joy_zone.offset_left = 22
			joy_zone.offset_top = -284
			joy_zone.offset_right = 206
			joy_zone.offset_bottom = -100
	if right_cluster != null:
		if portrait:
			right_cluster.offset_left = -230
			right_cluster.offset_top = -364
			right_cluster.offset_right = -8
			right_cluster.offset_bottom = -178
		else:
			right_cluster.offset_left = -236
			right_cluster.offset_top = -286
			right_cluster.offset_right = -14
			right_cluster.offset_bottom = -100


func is_point_on_touch_controls(screen_pt: Vector2) -> bool:
	if not mobile_enabled or not visible:
		return false
	if joy_zone != null and joy_zone.get_global_rect().has_point(screen_pt):
		return true
	if right_cluster != null and right_cluster.get_global_rect().has_point(screen_pt):
		return true
	return false


func _build_controls() -> void:
	# 1. Left Virtual Thumbstick Zone (Bottom-Left, clear of top tutorial & bottom inspector)
	joy_zone = Control.new()
	joy_zone.set_anchors_preset(Control.PRESET_BOTTOM_LEFT)
	joy_zone.offset_left = 22
	joy_zone.offset_top = -284
	joy_zone.offset_right = 206
	joy_zone.offset_bottom = -100
	joy_zone.mouse_filter = Control.MOUSE_FILTER_STOP
	joy_zone.gui_input.connect(_on_joy_gui_input)
	joy_zone.draw.connect(_on_draw_joystick)
	add_child(joy_zone)

	# 2. Right Ergonomic Thumb Cluster (Bottom-Right above Energy/HP card)
	right_cluster = Control.new()
	right_cluster.set_anchors_preset(Control.PRESET_BOTTOM_RIGHT)
	right_cluster.offset_left = -236
	right_cluster.offset_top = -286
	right_cluster.offset_right = -14
	right_cluster.offset_bottom = -100
	right_cluster.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(right_cluster)

	sprint_btn = Button.new()
	sprint_btn.position = Vector2(106, 4)
	sprint_btn.custom_minimum_size = Vector2(112, 34)
	sprint_btn.add_theme_font_size_override("font_size", 12)
	sprint_btn.pressed.connect(func():
		sprint_locked = not sprint_locked
		_refresh_sprint_style()
		toggle_sprint_changed.emit(sprint_locked)
	)
	right_cluster.add_child(sprint_btn)
	_refresh_sprint_style()

	interact_btn = Button.new()
	interact_btn.text = "🤚 交互\n收菜/对话"
	interact_btn.position = Vector2(18, 92)
	interact_btn.custom_minimum_size = Vector2(88, 84)
	interact_btn.add_theme_font_size_override("font_size", 13)
	interact_btn.add_theme_stylebox_override(
		"normal",
		UITheme.make_card_style(Color(0.18, 0.34, 0.24, 0.90), Color(0.58, 0.96, 0.68, 0.96), 22)
	)
	interact_btn.add_theme_stylebox_override(
		"hover",
		UITheme.make_card_style(Color(0.24, 0.44, 0.30, 0.95), Color(0.78, 1.0, 0.82, 1.0), 22)
	)
	interact_btn.add_theme_stylebox_override(
		"pressed",
		UITheme.make_card_style(Color(0.14, 0.26, 0.18, 0.96), Color(1.0, 0.92, 0.48, 1.0), 22)
	)
	interact_btn.pressed.connect(func(): action_interact.emit())
	right_cluster.add_child(interact_btn)

	use_btn = Button.new()
	use_btn.text = "⚒️ 使用\n工具/播种"
	use_btn.position = Vector2(118, 52)
	use_btn.custom_minimum_size = Vector2(98, 96)
	use_btn.add_theme_font_size_override("font_size", 14)
	use_btn.add_theme_stylebox_override(
		"normal",
		UITheme.make_card_style(Color(0.38, 0.22, 0.12, 0.92), Color(1.0, 0.82, 0.36, 0.98), 26)
	)
	use_btn.add_theme_stylebox_override(
		"hover",
		UITheme.make_card_style(Color(0.48, 0.28, 0.15, 0.96), Color(1.0, 0.92, 0.52, 1.0), 26)
	)
	use_btn.add_theme_stylebox_override(
		"pressed",
		UITheme.make_card_style(Color(0.28, 0.16, 0.08, 0.96), Color(1.0, 0.94, 0.58, 1.0), 26)
	)
	use_btn.button_down.connect(func():
		is_use_held = true
		action_use_primary.emit()
	)
	use_btn.button_up.connect(func(): is_use_held = false)
	right_cluster.add_child(use_btn)


func _refresh_sprint_style() -> void:
	if sprint_btn == null:
		return
	sprint_btn.text = "🏃 疾跑:开" if sprint_locked else "🚶 疾跑:关"
	var bg: Color = Color(0.36, 0.26, 0.10, 0.92) if sprint_locked else Color(0.20, 0.15, 0.12, 0.84)
	var bd: Color = Color(1.0, 0.86, 0.34, 0.98) if sprint_locked else Color(0.62, 0.52, 0.40, 0.85)
	sprint_btn.add_theme_stylebox_override("normal", UITheme.make_card_style(bg, bd, 14))


func _on_joy_gui_input(event: InputEvent) -> void:
	if event is InputEventScreenTouch:
		var st: InputEventScreenTouch = event
		if st.pressed and not _joy_active:
			_joy_active = true
			_joy_touch_idx = st.index
			_update_joystick_from_local(st.position)
			accept_event()
		elif not st.pressed and st.index == _joy_touch_idx:
			_reset_joystick()
			accept_event()
	elif event is InputEventScreenDrag:
		var sd: InputEventScreenDrag = event
		if _joy_active and sd.index == _joy_touch_idx:
			_update_joystick_from_local(sd.position)
			accept_event()
	elif event is InputEventMouseButton:
		var mb: InputEventMouseButton = event
		if mb.button_index == MOUSE_BUTTON_LEFT:
			if mb.pressed:
				_joy_active = true
				_joy_mouse_dragging = true
				_update_joystick_from_local(mb.position)
				accept_event()
			elif _joy_mouse_dragging:
				_reset_joystick()
				accept_event()
	elif event is InputEventMouseMotion:
		var mm: InputEventMouseMotion = event
		if _joy_active and _joy_mouse_dragging:
			_update_joystick_from_local(mm.position)
			accept_event()


func simulate_joystick_offset(norm_offset: Vector2) -> void:
	var clamped: Vector2 = norm_offset
	if clamped.length() > 1.0:
		clamped = clamped.normalized()
	_joy_active = clamped.length() > 0.05
	_joy_knob = _joy_center + clamped * _joy_radius
	move_vector = clamped if _joy_active else Vector2.ZERO
	joy_sprinting = sprint_locked or (clamped.length() >= 0.72)
	if joy_zone != null:
		joy_zone.queue_redraw()


func _update_joystick_from_local(local_pt: Vector2) -> void:
	var delta_v: Vector2 = local_pt - _joy_center
	var dist: float = delta_v.length()
	if dist > _joy_radius:
		delta_v = delta_v.normalized() * _joy_radius
		dist = _joy_radius
	_joy_knob = _joy_center + delta_v
	if dist < 8.0:
		move_vector = Vector2.ZERO
		joy_sprinting = sprint_locked
	else:
		move_vector = delta_v / _joy_radius
		joy_sprinting = sprint_locked or ((dist / _joy_radius) >= 0.72)
	if joy_zone != null:
		joy_zone.queue_redraw()


func _reset_joystick() -> void:
	_joy_active = false
	_joy_touch_idx = -1
	_joy_mouse_dragging = false
	_joy_knob = _joy_center
	move_vector = Vector2.ZERO
	joy_sprinting = sprint_locked
	if joy_zone != null:
		joy_zone.queue_redraw()


func _on_draw_joystick() -> void:
	var f: Font = UITheme.get_font()
	var ring_bg: Color = Color(0.14, 0.10, 0.07, 0.58)
	var ring_bd: Color = Color(0.92, 0.72, 0.34, 0.85 if _joy_active else 0.58)
	joy_zone.draw_circle(_joy_center, _joy_radius, ring_bg)
	joy_zone.draw_arc(_joy_center, _joy_radius, 0.0, TAU, 40, ring_bd, 3.0)
	joy_zone.draw_arc(_joy_center, _joy_radius * 0.45, 0.0, TAU, 28, Color(0.86, 0.68, 0.36, 0.24), 1.5)
	# Directional hints
	for dir_pt in [Vector2(0, -48), Vector2(0, 48), Vector2(-48, 0), Vector2(48, 0)]:
		var dp: Vector2 = _joy_center + (dir_pt as Vector2)
		joy_zone.draw_circle(dp, 3.0, Color(1.0, 0.88, 0.55, 0.45))
	# Thumb knob
	var knob_c: Color = Color(0.96, 0.76, 0.32, 0.95) if _joy_active else Color(0.78, 0.58, 0.28, 0.82)
	joy_zone.draw_circle(_joy_knob + Vector2(0, 3), 26.0, Color(0, 0, 0, 0.32))
	joy_zone.draw_circle(_joy_knob, 26.0, knob_c)
	joy_zone.draw_arc(_joy_knob, 26.0, 0.0, TAU, 28, Color(1.0, 0.95, 0.74, 0.95), 2.2)
	if not _joy_active and f != null:
		joy_zone.draw_string(f, _joy_center + Vector2(-24, 5), "摇杆", HORIZONTAL_ALIGNMENT_CENTER, 48, 12, Color(1.0, 0.96, 0.86, 0.88))
