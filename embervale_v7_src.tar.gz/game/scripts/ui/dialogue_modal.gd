class_name DialogueModal
extends Control

var npc_scheduler: NPCScheduler = null
var current_npc_id: String = ""

var portrait_rect: TextureRect = null
var name_lbl: Label = null
var hearts_lbl: Label = null
var text_lbl: Label = null
var gift_btn: Button = null
var anchor_ref: MarginContainer = null


func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	theme = UITheme.build_theme()
	visible = false
	_build_ui()


func _build_ui() -> void:
	var dim: ColorRect = ColorRect.new()
	dim.set_anchors_preset(Control.PRESET_FULL_RECT)
	dim.color = Color(0, 0, 0, 0.35)
	dim.gui_input.connect(func(ev: InputEvent):
		if (ev is InputEventScreenTouch and (ev as InputEventScreenTouch).pressed) or (ev is InputEventMouseButton and (ev as InputEventMouseButton).pressed and (ev as InputEventMouseButton).button_index == MOUSE_BUTTON_LEFT):
			visible = false
			GameState.time_paused = false
			dim.accept_event()
	)
	add_child(dim)

	var anchor: MarginContainer = MarginContainer.new()
	anchor_ref = anchor
	anchor.set_anchors_preset(Control.PRESET_BOTTOM_WIDE)
	anchor.offset_top = -278
	anchor.offset_bottom = -108
	anchor.offset_left = 150
	anchor.offset_right = -150
	add_child(anchor)

	var panel: PanelContainer = PanelContainer.new()
	anchor.add_child(panel)
	var hbox: HBoxContainer = HBoxContainer.new()
	hbox.add_theme_constant_override("separation", 18)
	panel.add_child(hbox)

	var left_v: VBoxContainer = VBoxContainer.new()
	hbox.add_child(left_v)
	portrait_rect = TextureRect.new()
	portrait_rect.custom_minimum_size = Vector2(96, 96)
	portrait_rect.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	portrait_rect.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	left_v.add_child(portrait_rect)
	name_lbl = Label.new()
	name_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	name_lbl.add_theme_color_override("font_color", Color(1.0, 0.88, 0.45))
	left_v.add_child(name_lbl)
	hearts_lbl = Label.new()
	hearts_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	hearts_lbl.add_theme_font_size_override("font_size", 12)
	hearts_lbl.add_theme_color_override("font_color", Color(1.0, 0.45, 0.55))
	left_v.add_child(hearts_lbl)

	var right_v: VBoxContainer = VBoxContainer.new()
	right_v.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	hbox.add_child(right_v)

	text_lbl = Label.new()
	text_lbl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	text_lbl.size_flags_vertical = Control.SIZE_EXPAND_FILL
	text_lbl.add_theme_font_size_override("font_size", 16)
	right_v.add_child(text_lbl)

	var btn_row: HBoxContainer = HBoxContainer.new()
	btn_row.add_theme_constant_override("separation", 12)
	right_v.add_child(btn_row)
	gift_btn = Button.new()
	gift_btn.custom_minimum_size = Vector2(156, 44)
	gift_btn.pressed.connect(_on_gift_pressed)
	btn_row.add_child(gift_btn)

	var close_b: Button = Button.new()
	close_b.text = "✕ 再见 [Esc]"
	close_b.custom_minimum_size = Vector2(122, 44)
	close_b.pressed.connect(func(): visible = false; GameState.time_paused = false)
	btn_row.add_child(close_b)


func apply_orientation_layout(portrait: bool) -> void:
	if anchor_ref == null:
		return
	if portrait:
		anchor_ref.offset_left = 16
		anchor_ref.offset_right = -16
		anchor_ref.offset_top = -386
		anchor_ref.offset_bottom = -172
	else:
		anchor_ref.offset_left = 150
		anchor_ref.offset_right = -150
		anchor_ref.offset_top = -278
		anchor_ref.offset_bottom = -108


func open_npc(npc_id: String) -> void:
	current_npc_id = npc_id
	visible = true
	GameState.time_paused = true

	var npc: Dictionary = DataRegistry.get_npc(npc_id)
	portrait_rect.texture = AssetRegistry.get_tex(str(npc.get("portrait", "portraits/npc_%s.png" % npc_id)))
	_refresh_name_and_badge()

	var f: Dictionary = GameState.npc_friendship.get(npc_id, {"points": 50, "talked_today": false, "gifted_today": false})
	if not bool(f.get("talked_today", false)):
		GameState.add_friendship(npc_id, 20)
		var nf: Dictionary = GameState.npc_friendship[npc_id]
		nf["talked_today"] = true
		GameState.npc_friendship[npc_id] = nf

	_update_hearts()

	# Priority 0: 4-heart keepsake unlock
	var keepsake_granted: bool = _check_and_grant_keepsake(npc_id)
	if not keepsake_granted:
		# Priority 0b: 2-heart & 6-heart story events
		var heart_event_triggered: bool = _check_heart_event(npc_id)
		if not heart_event_triggered:
			# Priority 1: WorldMemory reactive dialogue / rumor
			var mem: Dictionary = WorldMemory.get_npc_memory_dialogue(npc_id)
			if not mem.is_empty():
				var prefix: String = "【听说传闻】" if bool(mem.get("is_rumor", false)) else "【山谷回响】"
				text_lbl.text = "%s%s" % [prefix, str(mem.get("text", ""))]
				var gift_id: String = str(mem.get("gift_item", ""))
				if not gift_id.is_empty():
					GameState.add_item(gift_id, 1, 0)
					var gname: String = str(DataRegistry.get_item(gift_id).get("name", gift_id))
					EventBus.toast_message.emit("🎁 %s 送给你一份关怀礼物：%s！" % [str(npc.get("name", "")), gname], Color(0.55, 0.95, 0.7))
			elif GameState.spouse_id == npc_id:
				var spouse_lines: Array = [
					"亲爱的，今天在农场别太劳累啦，家里有我打理，晚上早点回来一起吃热乎饭~",
					"能和你一起守着这座四季流转的回响庄园，是我最幸福的事。早晚记得抱抱咱家的小宠物哦！",
					"我把屋子收拾得暖洋洋的，明天一早也会帮你照看庄稼和饲草槽！"
				]
				text_lbl.text = "💕 " + str(spouse_lines[randi() % spouse_lines.size()])
			else:
				var greets: Array = npc.get("greetings", ["你好！"])
				text_lbl.text = str(greets[randi() % greets.size()])
				if WorldMemory.is_llm_enabled():
					WorldMemory.request_llm_line(npc_id, func(ai_line: String):
						if visible and current_npc_id == npc_id:
							text_lbl.text = ai_line
					)

	_refresh_gift_btn()


func _refresh_name_and_badge() -> void:
	var npc: Dictionary = DataRegistry.get_npc(current_npc_id)
	var badge: String = ""
	if GameState.spouse_id == current_npc_id:
		badge = "\n💍 挚爱伴侣"
	elif bool(GameState.dating_npcs.get(current_npc_id, false)):
		badge = "\n💐 恋人交往中"
	name_lbl.text = "%s\n(%s)%s" % [str(npc.get("name", current_npc_id)), str(npc.get("role", "")), badge]


func _check_and_grant_keepsake(npc_id: String) -> bool:
	if GameState.has_keepsake(npc_id) or GameState.get_friendship_hearts(npc_id) < 4:
		return false
	GameState.npc_keepsakes[npc_id] = true
	var info: Dictionary = {
		"linxia": {"title": "翠叶标本夹", "perk": "所有作物每日生长速度永久 +15%", "line": "认识你之后，山谷的植物都更有活力了！这枚【翠叶标本夹】送给你，能催发所有田块的生长灵气。"},
		"horn": {"title": "矮人护心镜", "perk": "矿洞探险物理受伤永久减免 35%", "line": "好小子，把咱俩交情放心里！老夫锻的【矮人护心镜】你戴好，矿洞怪物伤不到你分毫！"},
		"ache": {"title": "听涛骨笛", "perk": "钓鱼绿条范围永久加宽 30%", "line": "这支【听涛骨笛】送给懂水波的人——有它共鸣，湖里的鱼儿会更听你的节拍。"},
		"mei": {"title": "回响长明灯", "perk": "出货箱夜间总收益永久额外 +10%", "line": "孩子，你的真心温暖了整座山谷。收下这盏【回响长明灯】，让每笔收获都蒙受丰饶祝福。"},
		"suwan": {"title": "星盘鲁班尺", "perk": "日常移动速度永久额外 +12%", "line": "每次看你规划农场的样子都让我灵感迸发！收下这把【星盘鲁班尺】，愿你的每一步都轻盈如星风。"},
		"kailuo": {"title": "秘林探险靴", "perk": "猎镰剑与武器战斗伤害永久 +35%", "line": "哈哈，能跟上我探险脚步的伙伴可不多！这双【秘林探险靴】与剑术心得赠你，秘林树精也休想拦你！"},
	}
	var kd: Dictionary = info.get(npc_id, {})
	if kd.is_empty():
		return false
	text_lbl.text = "【★ 4心羁绊信物解锁：%s】\n%s" % [str(kd.get("title", "")), str(kd.get("line", ""))]
	AudioManager.play_sfx("fish_catch")
	EventBus.toast_message.emit("💝 获得羁绊信物【%s】：%s" % [str(kd.get("title", "")), str(kd.get("perk", ""))], Color(1.0, 0.86, 0.35))
	return true


func _check_heart_event(npc_id: String) -> bool:
	var hearts: int = GameState.get_friendship_hearts(npc_id)
	var events_db: Dictionary = {
		"linxia_2": "【🌸 2心剧情 · 温室夜露】林夏轻轻翻开植物手绘本：“其实我一直梦想让失传的远古星露果重现山谷……有你在，我觉得这个梦不再遥远了。”",
		"linxia_6": "【💖 6心剧情 · 萤火伴生】暮色下萤火虫绕着你们飞舞，林夏脸颊微红：“就像向阳铃离不开月露莓一样，不知不觉间，我每天最期待的就是看见你走过镇口。”",
		"ache_2": "【🎵 2心剧情 · 湖心泛音】阿澈拨动琴弦，水面泛起银色涟漪：“以前我只对着游鱼弹琴，现在有了愿意并肩听风的知音。”",
		"ache_6": "【💖 6心剧情 · 星河渔歌】阿澈将一枚发光贝壳放在你掌心：“这首新写的歌没有名字……因为每一个音符念出来都是你。”",
		"suwan_2": "【📐 2心剧情 · 星空屋檐】苏晚指着图纸上的双人露台：“建筑不只是木头与石头，更是承载两个人一日三餐的温暖容器。”",
		"suwan_6": "【💖 6心剧情 · 专属蓝图】苏晚羞涩地合上画册一角：“那张画着秋千、花圃和双人壁炉的庄园草图……其实是我悄悄为我们画的。”",
		"kailuo_2": "【🧭 2心剧情 · 秘林篝火】凯洛分给你半块烤松露：“走遍了那么多遗迹，唯有回响山谷的炊烟让我有了想停下脚步的冲动。”",
		"kailuo_6": "【💖 6心剧情 · 远古誓言】凯洛认真地注视着你：“再珍贵的传奇秘宝，也比不上每天傍晚推开门能看到你的笑容。”",
		"horn_2": "【⚒️ 2心剧情 · 炉火往事】霍恩爽朗大笑：“当年你爷爷也是这样扛着锄头来找我修工具，如今看你把农场打理得井井有条，老夫真高兴！”",
		"mei_2": "【🏮 2心剧情 · 祭坛微光】梅婆婆慈祥地为你添上一杯热茶：“山谷的回响从不辜负勤劳善良的孩子，愿四季常佑你的田园。”",
	}
	for tier in [6, 2]:
		if hearts >= tier:
			var ek: String = "%s_%d" % [npc_id, tier]
			if events_db.has(ek) and not bool(GameState.seen_heart_events.get(ek, false)):
				GameState.seen_heart_events[ek] = true
				GameState.add_friendship(npc_id, 30)
				_update_hearts()
				AudioManager.play_sfx("fish_catch")
				text_lbl.text = str(events_db[ek])
				EventBus.toast_message.emit("✨ 触发专属好感剧情事件（好感额外 +30）！", Color(1.0, 0.78, 0.88))
				return true
	return false


func _update_hearts() -> void:
	var h: int = GameState.get_friendship_hearts(current_npc_id)
	var s: String = ""
	for i in range(10):
		s += "♥" if i < h else "♡"
	hearts_lbl.text = s


func _refresh_gift_btn() -> void:
	var slot: Dictionary = GameState.get_selected_slot()
	if slot.is_empty():
		gift_btn.text = "🎁 赠送礼物 (请先在快捷栏选中非工具物品)"
		gift_btn.disabled = true
	else:
		var iid: String = str(slot.get("id", ""))
		var def: Dictionary = DataRegistry.get_item(iid)
		if str(def.get("category", "")) == "tool":
			gift_btn.text = "🎁 工具不能当礼物赠送"
			gift_btn.disabled = true
		elif iid == "bouquet":
			gift_btn.text = "💐 献上【定情花束】表白"
			gift_btn.disabled = false
		elif iid == "mermaid_pendant":
			gift_btn.text = "💍 献上【回响人鱼吊坠】求婚"
			gift_btn.disabled = false
		else:
			gift_btn.text = "🎁 赠送手中【%s】" % str(def.get("name", iid))
			gift_btn.disabled = false


func _on_gift_pressed() -> void:
	if npc_scheduler == null:
		return
	var slot: Dictionary = GameState.get_selected_slot()
	if slot.is_empty():
		return
	var iid: String = str(slot.get("id", ""))
	var npc: Dictionary = DataRegistry.get_npc(current_npc_id)
	var npc_name: String = str(npc.get("name", current_npc_id))
	var hearts: int = GameState.get_friendship_hearts(current_npc_id)

	if iid == "bouquet":
		if not bool(npc.get("marriageable", false)):
			text_lbl.text = "哈哈，这份心意太珍贵啦，留给与你心意相通的年轻伴侣吧！"
			return
		if GameState.spouse_id == current_npc_id or bool(GameState.dating_npcs.get(current_npc_id, false)):
			text_lbl.text = "💕 我们已经是彼此珍视的恋人啦！"
			return
		if hearts < 6:
			text_lbl.text = "（%s 有些羞涩：好感度达到 6 颗心后再献上定情花束表白吧！）" % npc_name
			return
		GameState.consume_slot(GameState.selected_hotbar, 1)
		GameState.dating_npcs[current_npc_id] = true
		GameState.add_friendship(current_npc_id, 60)
		AudioManager.play_sfx("fish_catch")
		text_lbl.text = "💐 %s 惊喜地接过定情花束，眼眸里满是星光：\n“原来你也怀着同样的心意……从今天起，请多多指教，我的恋人！”" % npc_name
		EventBus.toast_message.emit("💐 表白成功！你与 %s 正式成为恋人（满8心且2阶农舍即可求婚）！" % npc_name, Color(1.0, 0.72, 0.86))
		_refresh_name_and_badge()
		_update_hearts()
		_refresh_gift_btn()
		return

	if iid == "mermaid_pendant":
		if not bool(npc.get("marriageable", false)):
			text_lbl.text = "老身/老夫会为你证婚祝福的，去把吊坠送给心上人吧！"
			return
		if not GameState.spouse_id.is_empty():
			text_lbl.text = "你已经在回响山谷拥有相伴一生的挚爱伴侣啦！"
			return
		if GameState.house_tier < 2:
			text_lbl.text = "🏡 求婚前，请先前往小镇东侧【苏晚营造奇观台】将农舍扩建至二阶双人雅居哦！"
			return
		if hearts < 8:
			text_lbl.text = "（需要好感度达到 8 颗心以上，才能献上回响人鱼吊坠求婚哦！）"
			return
		GameState.consume_slot(GameState.selected_hotbar, 1)
		GameState.dating_npcs[current_npc_id] = true
		GameState.spouse_id = current_npc_id
		GameState.add_friendship(current_npc_id, 120)
		WorldMemory.record_fact("married", "与%s在回响祭坛许下终生誓言，步入了婚姻殿堂" % npc_name, current_npc_id)
		npc_scheduler.update_schedules_for_hour(GameState.hour)
		AudioManager.play_sfx("fish_catch")
		text_lbl.text = "💍 【回响婚礼誓言】\n%s 感动得热泪盈眶，郑重戴上人鱼吊坠：\n“无论春夏秋冬、晴雨风雪，我都愿与你共守这座回响庄园！今晚起我们就是一家人了！”" % npc_name
		EventBus.toast_message.emit("💍 求婚大成功！你与 %s 喜结连理，开启农舍甜蜜同居与晨间互助生活！" % npc_name, Color(1.0, 0.82, 0.92))
		_refresh_name_and_badge()
		_update_hearts()
		_refresh_gift_btn()
		return

	var res: Dictionary = npc_scheduler.give_gift(current_npc_id, iid)
	if bool(res.get("ok", false)):
		GameState.consume_slot(GameState.selected_hotbar, 1)
	text_lbl.text = str(res.get("msg", ""))
	_update_hearts()
	_refresh_gift_btn()
