class_name ShrineQuestModal
extends Control

var mode: String = "shrine" # "shrine" or "quest"
var title_lbl: Label = null
var content_list: VBoxContainer = null


func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	theme = UITheme.build_theme()
	visible = false
	_build_ui()


func _build_ui() -> void:
	var dim: ColorRect = ColorRect.new()
	dim.set_anchors_preset(Control.PRESET_FULL_RECT)
	dim.color = Color(0, 0, 0, 0.55)
	add_child(dim)

	var center: CenterContainer = CenterContainer.new()
	center.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(center)

	var panel: PanelContainer = PanelContainer.new()
	panel.custom_minimum_size = Vector2(780, 500)
	center.add_child(panel)

	var v: VBoxContainer = VBoxContainer.new()
	v.add_theme_constant_override("separation", 10)
	panel.add_child(v)

	var hdr: HBoxContainer = HBoxContainer.new()
	v.add_child(hdr)
	title_lbl = Label.new()
	title_lbl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	title_lbl.add_theme_font_size_override("font_size", 18)
	title_lbl.add_theme_color_override("font_color", Color(0.55, 0.96, 0.85))
	hdr.add_child(title_lbl)

	var close_b: Button = Button.new()
	close_b.text = "✕ 关闭 [Esc]"
	close_b.custom_minimum_size = Vector2(120, 44)
	close_b.pressed.connect(func(): visible = false; GameState.time_paused = false)
	hdr.add_child(close_b)

	var scroll: ScrollContainer = ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	v.add_child(scroll)

	content_list = VBoxContainer.new()
	content_list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	content_list.add_theme_constant_override("separation", 10)
	scroll.add_child(content_list)


func open_shrine() -> void:
	mode = "shrine"
	visible = true
	GameState.time_paused = true
	refresh()


func open_quest() -> void:
	mode = "quest"
	visible = true
	GameState.time_paused = true
	refresh()


func refresh() -> void:
	for c in content_list.get_children():
		c.queue_free()
	if mode == "shrine":
		title_lbl.text = "✨ 回响祭坛 — 四大季节灵脉收集包"
		_build_shrine_view()
	else:
		title_lbl.text = "📜 回响镇广场 — 今日居民悬赏委托"
		_build_quest_view()


func _build_shrine_view() -> void:
	for b in DataRegistry.get_bundles():
		var bd: Dictionary = b
		var bid: String = str(bd.get("id", ""))
		var prog: Dictionary = GameState.bundle_progress.get(bid, {"submitted": {}, "completed": false})
		var submitted: Dictionary = prog.get("submitted", {})
		var completed: bool = bool(prog.get("completed", false))

		var card: PanelContainer = PanelContainer.new()
		var border_col: Color = Color(0.4, 0.95, 0.65) if completed else Color(0.65, 0.55, 0.35)
		card.add_theme_stylebox_override("panel", UITheme.make_card_style(Color(0.14, 0.19, 0.24, 0.95), border_col, 8))
		var cv: VBoxContainer = VBoxContainer.new()
		card.add_child(cv)

		var top: HBoxContainer = HBoxContainer.new()
		cv.add_child(top)
		var bname: Label = Label.new()
		bname.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		bname.text = ("✅ " if completed else "🔮 ") + str(bd.get("name", bid)) + " — " + str(bd.get("reward_text", ""))
		bname.add_theme_color_override("font_color", Color(0.55, 0.98, 0.7) if completed else Color(1.0, 0.9, 0.55))
		top.add_child(bname)

		var desc: Label = Label.new()
		desc.text = str(bd.get("description", ""))
		desc.add_theme_font_size_override("font_size", 12)
		desc.add_theme_color_override("font_color", Color(0.75, 0.82, 0.88))
		cv.add_child(desc)

		var req_row: HBoxContainer = HBoxContainer.new()
		req_row.add_theme_constant_override("separation", 8)
		cv.add_child(req_row)
		for rq in bd.get("required_items", []):
			var rd: Dictionary = rq
			var iid: String = str(rd.get("id", ""))
			var need: int = int(rd.get("count", 1))
			var done_cnt: int = int(submitted.get(iid, 0))
			var have: int = GameState.count_item(iid)
			var iname: String = str(DataRegistry.get_item(iid).get("name", iid))

			var btn: Button = Button.new()
			if done_cnt >= need:
				btn.text = "✅ %s (%d/%d)" % [iname, need, need]
				btn.disabled = true
			else:
				btn.text = "献祭 %s (%d/%d) [持有:%d]" % [iname, done_cnt, need, have]
				btn.disabled = have <= 0
				btn.pressed.connect(func():
					submit_bundle_item(bid, iid)
					refresh()
				)
			req_row.add_child(btn)
		content_list.add_child(card)


func submit_bundle_item(bundle_id: String, item_id: String) -> bool:
	var bdef: Dictionary = {}
	for b in DataRegistry.get_bundles():
		if str((b as Dictionary).get("id", "")) == bundle_id:
			bdef = b
			break
	if bdef.is_empty():
		return false
	var prog: Dictionary = GameState.bundle_progress.get(bundle_id, {"submitted": {}, "completed": false})
	if bool(prog.get("completed", false)):
		return false
	var submitted: Dictionary = prog.get("submitted", {})
	var need_total: int = 0
	for rq in bdef.get("required_items", []):
		if str((rq as Dictionary).get("id", "")) == item_id:
			need_total = int((rq as Dictionary).get("count", 1))
	var cur: int = int(submitted.get(item_id, 0))
	var missing: int = need_total - cur
	if missing <= 0:
		return false
	var have: int = GameState.count_item(item_id)
	var give: int = mini(missing, have)
	if give <= 0:
		return false
	GameState.remove_item(item_id, give)
	submitted[item_id] = cur + give
	prog["submitted"] = submitted

	var all_done: bool = true
	for rq2 in bdef.get("required_items", []):
		var rqd: Dictionary = rq2
		if int(submitted.get(str(rqd.get("id", "")), 0)) < int(rqd.get("count", 1)):
			all_done = false
			break
	if all_done:
		prog["completed"] = true
		_grant_bundle_reward(bdef)
	GameState.bundle_progress[bundle_id] = prog
	AudioManager.play_sfx("harvest")
	return true


func _grant_bundle_reward(bdef: Dictionary) -> void:
	var rtype: String = str(bdef.get("reward_type", "item"))
	var ritem: String = str(bdef.get("reward_item_id", ""))
	var rcnt: int = int(bdef.get("reward_count", 1))
	var rgold: int = int(bdef.get("reward_gold", 0))
	GameState.gold += rgold
	if not ritem.is_empty():
		GameState.add_item(ritem, rcnt, 0)
	if rtype == "perk_speed":
		GameState.move_speed_bonus += 0.18
	elif rtype == "perk_energy":
		GameState.max_energy += 40.0
		GameState.energy = GameState.max_energy
	elif rtype == "perk_greenhouse":
		GameState.greenhouse_blessing = true
		for nid in GameState.npc_friendship.keys():
			GameState.add_friendship(str(nid), 250)
	WorldMemory.record_fact("bundle_completed", "在回响祭坛点亮了「%s」" % str(bdef.get("name", "")), "mei")
	AudioManager.play_sfx("fish_catch")
	EventBus.player_stats_changed.emit()
	EventBus.toast_message.emit("✨ 祭坛共鸣完成！获得：%s" % str(bdef.get("reward_text", "")), Color(0.55, 0.98, 0.72))


func _build_quest_view() -> void:
	var q: Dictionary = GameState.active_quest
	if q.is_empty():
		var empty_l: Label = Label.new()
		empty_l.text = "今日暂无新委托。"
		content_list.add_child(empty_l)
		return
	var card: PanelContainer = PanelContainer.new()
	var cv: VBoxContainer = VBoxContainer.new()
	cv.add_theme_constant_override("separation", 8)
	card.add_child(cv)

	var giver_id: String = str(q.get("giver", "linxia"))
	var giver_name: String = str(DataRegistry.get_npc(giver_id).get("name", giver_id))
	var iid: String = str(q.get("item_id", ""))
	var cnt: int = int(q.get("count", 1))
	var iname: String = str(DataRegistry.get_item(iid).get("name", iid))
	var have: int = GameState.count_item(iid)

	var t: Label = Label.new()
	t.text = "📌 %s（发布人：%s）" % [str(q.get("title", "")), giver_name]
	t.add_theme_font_size_override("font_size", 17)
	t.add_theme_color_override("font_color", Color(1.0, 0.88, 0.45))
	cv.add_child(t)

	var req_l: Label = Label.new()
	req_l.text = "交付需求：%s ×%d  （当前持有：%d）" % [iname, cnt, have]
	cv.add_child(req_l)

	var rew_l: Label = Label.new()
	rew_l.text = "完成奖励：%d G + %s好感度 +%d" % [int(q.get("reward_gold", 150)), giver_name, int(q.get("reward_friendship", 100))]
	rew_l.add_theme_color_override("font_color", Color(0.55, 0.95, 0.65))
	cv.add_child(rew_l)

	var btn: Button = Button.new()
	if GameState.quest_completed_today:
		btn.text = "✅ 今日悬赏已完成！"
		btn.disabled = true
	else:
		btn.text = "交付完成悬赏"
		btn.disabled = have < cnt
		btn.pressed.connect(func():
			GameState.remove_item(iid, cnt)
			GameState.gold += int(q.get("reward_gold", 150))
			GameState.add_friendship(giver_id, int(q.get("reward_friendship", 100)))
			GameState.quest_completed_today = true
			AudioManager.play_sfx("coin")
			EventBus.player_stats_changed.emit()
			EventBus.toast_message.emit("📜 悬赏交付成功！获得 %dG！" % int(q.get("reward_gold", 150)), Color(1.0, 0.88, 0.4))
			refresh()
		)
	cv.add_child(btn)
	content_list.add_child(card)
