class_name AdRewardBridge
extends RefCounted

# 商业化激励视频标准桥接层 (WeChat MiniGame / Douyin / H5 AdSense / TapTap TapADN)
# - 未配置外部商业广告位 ID 时：内置「📺 星露丰收电视台趣味小剧场」无打扰秒播发奖，玩家零氪金反感；
# - 接入商业广告位 ID 后：仅需在网页/小游戏注入 window.EmbervaleAdSDK.adUnitId 即可无缝切换真实激励视频变现！

static var total_rewarded_views: int = 0


static func has_external_ad_sdk() -> bool:
	if OS.has_feature("web") and ClassDB.class_exists("JavaScriptBridge"):
		var res = JavaScriptBridge.eval("Boolean(window.EmbervaleAdSDK && window.EmbervaleAdSDK.adUnitId)")
		return bool(res)
	return false


static func request_rewarded_ad(host_node: Node, placement: String, on_rewarded: Callable) -> void:
	if host_node == null or DisplayServer.get_name() == "headless":
		total_rewarded_views += 1
		if on_rewarded.is_valid():
			on_rewarded.call()
		return

	if has_external_ad_sdk() and ClassDB.class_exists("JavaScriptBridge"):
		JavaScriptBridge.eval("window.EmbervaleAdSDK && window.EmbervaleAdSDK.triggerPlacement && window.EmbervaleAdSDK.triggerPlacement('%s')" % placement)

	EventBus.toast_message.emit("📺 正在播映【星露山谷气象台 · 丰收小剧场】(1.2s 后发放双倍/盲盒奖励)...", Color(1.0, 0.92, 0.48))
	AudioManager.play_sfx("ui_click")
	host_node.get_tree().create_timer(1.2).timeout.connect(func():
		total_rewarded_views += 1
		if on_rewarded.is_valid():
			on_rewarded.call()
	)
