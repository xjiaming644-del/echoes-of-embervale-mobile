extends Node


func _is_packed_or_mobile_runtime() -> bool:
	if OS.has_feature("web") or OS.has_feature("mobile") or OS.has_feature("android") or OS.has_feature("ios"):
		return true
	var proj_abs: String = ProjectSettings.globalize_path("res://project.godot")
	return proj_abs.is_empty() or not FileAccess.file_exists(proj_abs)


func _get_save_dir() -> String:
	if _is_packed_or_mobile_runtime():
		var user_saves: String = ProjectSettings.globalize_path("user://saves")
		DirAccess.make_dir_recursive_absolute(user_saves)
		# Seed bundled Slot 2 showcase save into user://saves on first mobile/web boot!
		var dst_s2: String = user_saves.path_join("slot_2.json")
		if not FileAccess.file_exists(dst_s2) and FileAccess.file_exists("res://saves/slot_2.json"):
			var fa_in: FileAccess = FileAccess.open("res://saves/slot_2.json", FileAccess.READ)
			if fa_in != null:
				var raw_txt: String = fa_in.get_as_text()
				fa_in.close()
				var fa_out: FileAccess = FileAccess.open(dst_s2, FileAccess.WRITE)
				if fa_out != null:
					fa_out.store_string(raw_txt)
					fa_out.close()
		return user_saves
	var save_dir: String = ProjectSettings.globalize_path("res://saves")
	DirAccess.make_dir_recursive_absolute(save_dir)
	return save_dir


func _get_save_path(slot: int) -> String:
	return _get_save_dir().path_join("slot_%d.json" % slot)


func _get_backup_path(slot: int) -> String:
	return _get_save_dir().path_join("slot_%d.json.bak" % slot)


func _get_tmp_path(slot: int) -> String:
	return _get_save_dir().path_join("slot_%d.json.tmp" % slot)


func _parse_valid_save(abs_path: String) -> Dictionary:
	if not FileAccess.file_exists(abs_path):
		return {}
	var fa: FileAccess = FileAccess.open(abs_path, FileAccess.READ)
	if fa == null:
		return {}
	var text: String = fa.get_as_text()
	fa.close()
	if text.strip_edges().is_empty():
		return {}
	var j: JSON = JSON.new()
	if j.parse(text) != OK:
		return {}
	var parsed = j.data
	if typeof(parsed) != TYPE_DICTIONARY:
		return {}
	var doc: Dictionary = parsed
	if not doc.has("game_state") or typeof(doc.get("game_state")) != TYPE_DICTIONARY:
		return {}
	return doc


func _replace_file_atomic(src_tmp: String, dst_path: String) -> bool:
	if FileAccess.file_exists(dst_path):
		DirAccess.remove_absolute(dst_path)
	var err: int = DirAccess.rename_absolute(src_tmp, dst_path)
	if err == OK:
		return true
	var cp_err: int = DirAccess.copy_absolute(src_tmp, dst_path)
	if FileAccess.file_exists(src_tmp):
		DirAccess.remove_absolute(src_tmp)
	return cp_err == OK


func has_save(slot: int = 1) -> bool:
	if not _parse_valid_save(_get_save_path(slot)).is_empty():
		return true
	return not _parse_valid_save(_get_backup_path(slot)).is_empty()


func delete_save(slot: int) -> void:
	for p in [_get_save_path(slot), _get_backup_path(slot), _get_tmp_path(slot)]:
		var sp: String = str(p)
		if FileAccess.file_exists(sp):
			DirAccess.remove_absolute(sp)


func save_game(slot: int, zone_mgr: Node, npc_sched: Node) -> bool:
	var payload: Dictionary = {
		"version": 2,
		"saved_at": Time.get_datetime_string_from_system(),
		"game_state": GameState.serialize(),
		"world_memory": WorldMemory.serialize(),
		"zones": zone_mgr.serialize() if zone_mgr != null else {},
		"npcs": npc_sched.serialize() if npc_sched != null else {},
	}
	var json_text: String = JSON.stringify(payload, "  ")
	var path: String = _get_save_path(slot)
	var bak_path: String = _get_backup_path(slot)
	var tmp_path: String = _get_tmp_path(slot)

	if FileAccess.file_exists(tmp_path):
		DirAccess.remove_absolute(tmp_path)
	var fa: FileAccess = FileAccess.open(tmp_path, FileAccess.WRITE)
	if fa == null:
		return false
	fa.store_string(json_text)
	fa.flush()
	fa.close()

	if _parse_valid_save(tmp_path).is_empty():
		if FileAccess.file_exists(tmp_path):
			DirAccess.remove_absolute(tmp_path)
		return false

	# Rotate existing valid save into .bak before replacing primary slot file
	if not _parse_valid_save(path).is_empty():
		_replace_file_atomic(path, bak_path)
	elif FileAccess.file_exists(path):
		DirAccess.remove_absolute(path)

	if not _replace_file_atomic(tmp_path, path):
		return false

	# Sync verified primary save to .bak via staging so .bak always mirrors latest valid save
	var bak_tmp: String = bak_path + ".tmp"
	if FileAccess.file_exists(bak_tmp):
		DirAccess.remove_absolute(bak_tmp)
	if DirAccess.copy_absolute(path, bak_tmp) == OK:
		_replace_file_atomic(bak_tmp, bak_path)

	EventBus.toast_message.emit("💾 已安全保存至存档槽 %d" % slot, Color(0.45, 0.92, 0.65))
	return true


func load_game(slot: int, zone_mgr: Node, npc_sched: Node) -> bool:
	var path: String = _get_save_path(slot)
	var bak_path: String = _get_backup_path(slot)
	var doc: Dictionary = _parse_valid_save(path)
	var recovered_from_bak: bool = false

	if doc.is_empty():
		doc = _parse_valid_save(bak_path)
		if not doc.is_empty():
			recovered_from_bak = true
			if FileAccess.file_exists(path):
				DirAccess.remove_absolute(path)
			DirAccess.copy_absolute(bak_path, path)

	if doc.is_empty():
		if not FileAccess.file_exists(path) and not FileAccess.file_exists(bak_path):
			EventBus.toast_message.emit("存档槽 %d 为空！" % slot, Color(1.0, 0.55, 0.45))
		else:
			EventBus.toast_message.emit("⚠️ 存档槽 %d 损坏且无可用备份！" % slot, Color(1.0, 0.45, 0.45))
		return false

	var saved_gs: Dictionary = doc.get("game_state", {})
	var saved_ts: int = int(saved_gs.get("last_active_unix_ts", 0))
	var now_ts: int = int(Time.get_unix_time_from_system())
	var offline_sec: int = maxi(0, now_ts - saved_ts) if saved_ts > 0 else 0
	GameState.deserialize(saved_gs)
	GameState.set_meta("pending_offline_seconds", offline_sec)
	WorldMemory.deserialize(doc.get("world_memory", {}))
	if zone_mgr != null:
		zone_mgr.deserialize(doc.get("zones", {}))
	if npc_sched != null:
		npc_sched.deserialize(doc.get("npcs", {}), zone_mgr)
	EventBus.zone_changed.emit(GameState.current_zone)
	if recovered_from_bak:
		EventBus.toast_message.emit("🛡️ 存档槽 %d 主文件受损，已自动从备份恢复！" % slot, Color(1.0, 0.86, 0.42))
	else:
		EventBus.toast_message.emit("📂 已读取存档槽 %d" % slot, Color(0.55, 0.85, 1.0))
	return true


func ensure_graduate_showcase_save(slot: int, zone_mgr: Node, npc_sched: Node, force: bool = false) -> bool:
	if not force and has_save(slot):
		return true
	var snap_gs: Dictionary = GameState.serialize()
	var snap_wm: Dictionary = WorldMemory.serialize()
	var snap_zones: Dictionary = zone_mgr.serialize() if zone_mgr != null else {}
	var snap_npcs: Dictionary = npc_sched.serialize() if npc_sched != null else {}

	GameState.reset_new_game()
	if zone_mgr != null:
		zone_mgr.init_all_zones()
	GameState.day = 8
	GameState.season_idx = 1
	GameState.year = 1
	GameState.gold = 28800
	GameState.house_tier = 3
	GameState.max_energy = 180.0
	GameState.energy = 180.0
	GameState.max_hp = 120.0
	GameState.hp = 120.0
	GameState.tutorial_step = 6
	GameState.greenhouse_unlocked = true
	GameState.obelisk_built = true
	GameState.golden_clock_built = true
	GameState.mine_max_floor = 12
	GameState.spouse_id = "linxia"
	GameState.dating_npcs["linxia"] = true
	GameState.tool_levels = {"hoe": 4, "can": 4, "axe": 4, "pickaxe": 4, "blade": 4}
	GameState.fish_pond = {"fish_id": "fish_manta_ray", "count": 3}
	GameState.trough_hay = 24
	for nid in ["linxia", "horn", "ache", "mei", "suwan", "kailuo"]:
		var pts: int = 1000 if str(nid) == "linxia" else 520
		GameState.npc_friendship[str(nid)] = {"points": pts, "talked_today": false, "gifted_today": false}
		GameState.npc_keepsakes[str(nid)] = true
	GameState.add_item("artisan_espresso", 5, 0)
	GameState.add_item("pineapple", 4, 2)
	GameState.add_item("star_coffee", 6, 1)
	GameState.add_item("coral_pearl", 3, 0)
	GameState.add_item("ancient_fruit", 3, 2)
	GameState.add_item("artisan_caviar", 2, 0)
	GameState.add_item("dish_valley_feast", 2, 0)
	GameState.add_item("seed_pineapple", 6, 0)
	GameState.add_item("seed_star_coffee", 6, 0)
	WorldMemory.record_fact("coral_island_voyage", "乘星海渡船开辟了四季如夏的星露珊瑚群岛庄园", "ache")
	WorldMemory.record_fact("treant_defeated", "在迷雾回响秘林成功击败了远古树精守护者", "mei")
	if zone_mgr != null:
		zone_mgr.sync_farm_wonders()
	if npc_sched != null:
		npc_sched.init_npcs(zone_mgr)
		npc_sched.update_schedules_for_hour(GameState.hour)

	var ok: bool = save_game(slot, zone_mgr, npc_sched)
	if ok and not _is_packed_or_mobile_runtime():
		var vault_dir: String = ProjectSettings.globalize_path("res://../archives/saves_backup")
		DirAccess.make_dir_recursive_absolute(vault_dir)
		DirAccess.copy_absolute(_get_save_path(slot), vault_dir.path_join("slot_%d_graduate_showcase.json" % slot))

	# Restore pre-existing runtime state cleanly
	GameState.deserialize(snap_gs)
	WorldMemory.deserialize(snap_wm)
	if zone_mgr != null:
		zone_mgr.deserialize(snap_zones)
	if npc_sched != null:
		npc_sched.deserialize(snap_npcs, zone_mgr)
	return ok
