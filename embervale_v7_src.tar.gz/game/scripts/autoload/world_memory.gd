extends Node

var facts: Dictionary = {}
var rumor_log: Array = []
var _llm_config: Dictionary = {}


func _ready() -> void:
	_load_llm_config()


func _load_llm_config() -> void:
	var abs_p: String = ProjectSettings.globalize_path("res://config/ai_llm_config.json")
	if FileAccess.file_exists(abs_p):
		var fa: FileAccess = FileAccess.open(abs_p, FileAccess.READ)
		if fa != null:
			var parsed = JSON.parse_string(fa.get_as_text())
			fa.close()
			if typeof(parsed) == TYPE_DICTIONARY:
				_llm_config = parsed


func reset() -> void:
	facts.clear()
	rumor_log.clear()


func record_fact(fact_id: String, label: String, witness_npc: String = "") -> void:
	var known: Array = []
	if not witness_npc.is_empty():
		known.append(witness_npc)
	elif not facts.has(fact_id):
		# 默认第一个事件可能由相关村民目击或直接留在山谷空气中，但传闻系统会扩散
		var all_npcs: Array = DataRegistry.get_all_npcs()
		if all_npcs.size() > 0:
			var first_npc: Dictionary = all_npcs[0]
			known.append(str(first_npc.get("id", "linxia")))

	if facts.has(fact_id):
		var existing: Dictionary = facts[fact_id]
		var ex_known: Array = existing.get("known_by", [])
		if not witness_npc.is_empty() and not ex_known.has(witness_npc):
			ex_known.append(witness_npc)
		existing["day"] = GameState.day
		facts[fact_id] = existing
		return

	var entry: Dictionary = {
		"id": fact_id,
		"label": label,
		"day": GameState.day,
		"season": GameState.get_season_name(),
		"year": GameState.year,
		"known_by": known,
		"reacted_by": [],
	}
	facts[fact_id] = entry
	rumor_log.push_front("[第%d年%s第%d日] %s" % [GameState.year, GameState.get_season_name(), GameState.day, label])
	if rumor_log.size() > 30:
		rumor_log.resize(30)
	EventBus.world_fact_recorded.emit(fact_id)


func try_spread_rumor(npc_a: String, npc_b: String) -> String:
	for fid in facts.keys():
		var entry: Dictionary = facts[fid]
		var known: Array = entry.get("known_by", [])
		if known.has(npc_a) and not known.has(npc_b):
			known.append(npc_b)
			entry["known_by"] = known
			facts[fid] = entry
			var name_a: String = str(DataRegistry.get_npc(npc_a).get("name", npc_a))
			var name_b: String = str(DataRegistry.get_npc(npc_b).get("name", npc_b))
			rumor_log.push_front("💬 %s 把「%s」的消息告诉了 %s" % [name_a, str(entry.get("label", fid)), name_b])
			if rumor_log.size() > 30:
				rumor_log.resize(30)
			return str(fid)
		if known.has(npc_b) and not known.has(npc_a):
			known.append(npc_a)
			entry["known_by"] = known
			facts[fid] = entry
			var name_b2: String = str(DataRegistry.get_npc(npc_b).get("name", npc_b))
			var name_a2: String = str(DataRegistry.get_npc(npc_a).get("name", npc_a))
			rumor_log.push_front("💬 %s 把「%s」的消息告诉了 %s" % [name_b2, str(entry.get("label", fid)), name_a2])
			if rumor_log.size() > 30:
				rumor_log.resize(30)
			return str(fid)
	return ""


func get_npc_memory_dialogue(npc_id: String) -> Dictionary:
	var npc: Dictionary = DataRegistry.get_npc(npc_id)
	var reactions: Dictionary = npc.get("memory_reactions", {})
	for fid in facts.keys():
		if not reactions.has(fid):
			continue
		var entry: Dictionary = facts[fid]
		var reacted: Array = entry.get("reacted_by", [])
		if reacted.has(npc_id):
			continue
		var known: Array = entry.get("known_by", [])
		if not known.has(npc_id):
			known.append(npc_id)
			entry["known_by"] = known
		reacted.append(npc_id)
		entry["reacted_by"] = reacted
		facts[fid] = entry

		var rx: Dictionary = reactions[fid]
		var is_rumor: bool = known.size() > 1
		var line_text: String = str(rx.get("rumor" if is_rumor else "direct", rx.get("direct", "")))
		var gift_id: String = str(rx.get("gift_item", ""))
		return {
			"fact_id": fid,
			"text": line_text,
			"is_rumor": is_rumor,
			"gift_item": gift_id,
		}
	return {}


func is_llm_enabled() -> bool:
	return bool(_llm_config.get("enabled", false))


func request_llm_line(npc_id: String, callback: Callable) -> void:
	if not is_llm_enabled():
		return
	var npc: Dictionary = DataRegistry.get_npc(npc_id)
	var endpoint: String = str(_llm_config.get("endpoint_url", ""))
	if endpoint.is_empty():
		return
	var req: HTTPRequest = HTTPRequest.new()
	req.timeout = float(_llm_config.get("timeout_sec", 6.0))
	add_child(req)

	var recent_facts: String = ", ".join(rumor_log.slice(0, 3))
	var sys_prompt: String = "%s 你是%s(%s)。最近山谷动态：%s" % [
		str(_llm_config.get("system_prompt_prefix", "")),
		str(npc.get("name", npc_id)),
		str(npc.get("role", "村民")),
		recent_facts,
	]
	var payload: Dictionary = {
		"model": str(_llm_config.get("model", "qwen2.5:7b")),
		"messages": [
			{"role": "system", "content": sys_prompt},
			{"role": "user", "content": "和农夫打个招呼并点评一句今天的天气或最近传闻。"},
		],
		"temperature": float(_llm_config.get("temperature", 0.7)),
	}
	var headers: PackedStringArray = ["Content-Type: application/json"]
	var api_key: String = str(_llm_config.get("api_key", ""))
	if not api_key.is_empty():
		headers.append("Authorization: Bearer " + api_key)

	req.request_completed.connect(func(result: int, code: int, _h: PackedStringArray, body: PackedByteArray):
		req.queue_free()
		if result == HTTPRequest.RESULT_SUCCESS and code == 200:
			var parsed = JSON.parse_string(body.get_string_from_utf8())
			if typeof(parsed) == TYPE_DICTIONARY:
				var choices: Array = parsed.get("choices", [])
				if choices.size() > 0:
					var msg: Dictionary = choices[0].get("message", {})
					var content: String = str(msg.get("content", "")).strip_edges()
					if not content.is_empty() and callback.is_valid():
						callback.call(content)
	)
	req.request(endpoint, headers, HTTPClient.METHOD_POST, JSON.stringify(payload))


func serialize() -> Dictionary:
	return {"facts": facts.duplicate(true), "rumor_log": rumor_log.duplicate()}


func deserialize(data: Dictionary) -> void:
	facts = data.get("facts", {}).duplicate(true)
	rumor_log = data.get("rumor_log", []).duplicate()
