extends Node

const SEASONS: Array = ["spring", "summer", "autumn", "winter"]
const SEASON_NAMES: Dictionary = {"spring": "春", "summer": "夏", "autumn": "秋", "winter": "冬"}
const WEATHER_NAMES: Dictionary = {"sunny": "晴朗", "rain": "细雨", "storm": "雷雨", "snow": "飘雪"}
const DAYS_PER_SEASON: int = 28
const HOTBAR_SIZE: int = 10
const INVENTORY_SIZE: int = 36

const SKILL_NAMES: Dictionary = {
	"farming": "耕种",
	"ecology": "生态学",
	"mining": "采矿",
	"fishing": "钓鱼",
	"foraging": "采集",
}

var day: int = 1
var season_idx: int = 0
var year: int = 1
var hour: int = 6
var minute: int = 0
var weather: String = "sunny"
var tomorrow_weather: String = "sunny"
var time_paused: bool = false

var current_zone: String = "farm"
var player_grid: Vector2i = Vector2i(8, 8)
var gold: int = 500
var energy: float = 120.0
var max_energy: float = 120.0
var hp: float = 100.0
var max_hp: float = 100.0
var watering_can_water: int = 40
var max_watering_can: int = 40
var move_speed_bonus: float = 0.0
var greenhouse_blessing: bool = false
var selected_hotbar: int = 0

var inventory: Array = []
var skills: Dictionary = {}
var shipping_queue: Array = []
var last_day_summary: Dictionary = {}
var npc_friendship: Dictionary = {}
var mine_current_floor: int = 1
var mine_max_floor: int = 1
var bundle_progress: Dictionary = {}
var active_quest: Dictionary = {}
var quest_completed_today: bool = false
var fainted_last_night: bool = false
var tool_levels: Dictionary = {"hoe": 1, "can": 1, "axe": 1, "pickaxe": 1, "blade": 1}
var greenhouse_unlocked: bool = false
var tutorial_step: int = 0
var npc_keepsakes: Dictionary = {}
var festival_judged_season: int = -1
var active_buff: Dictionary = {}
var ranch_animals: Array = []
var trough_hay: int = 6
var house_tier: int = 1
var dating_npcs: Dictionary = {}
var spouse_id: String = ""
var seen_heart_events: Dictionary = {}
var obelisk_built: bool = false
var golden_clock_built: bool = false
var pet_data: Dictionary = {"kind": "cat", "name": "橘猫团子", "affection": 80, "petted_today": false}
var fish_pond: Dictionary = {"fish_id": "", "count": 0, "days": 0}
var collection_seen: Dictionary = {}
var last_active_unix_ts: int = 0
var fairy_daily_instant_used: bool = false

var _minute_accum: float = 0.0


func _ready() -> void:
	reset_new_game()


func reset_new_game() -> void:
	day = 1
	season_idx = 0
	year = 1
	hour = 6
	minute = 0
	weather = "sunny"
	tomorrow_weather = "sunny"
	time_paused = false
	current_zone = "farm"
	player_grid = Vector2i(8, 8)
	gold = 500
	max_energy = 120.0
	energy = 120.0
	max_hp = 100.0
	hp = 100.0
	watering_can_water = max_watering_can
	move_speed_bonus = 0.0
	greenhouse_blessing = false
	selected_hotbar = 0
	mine_current_floor = 1
	mine_max_floor = 1
	fainted_last_night = false
	tool_levels = {"hoe": 1, "can": 1, "axe": 1, "pickaxe": 1, "blade": 1}
	greenhouse_unlocked = false
	tutorial_step = 0
	npc_keepsakes = {}
	festival_judged_season = -1
	active_buff = {}
	trough_hay = 6
	house_tier = 1
	dating_npcs = {}
	spouse_id = ""
	seen_heart_events = {}
	obelisk_built = false
	golden_clock_built = false
	pet_data = {"kind": "cat", "name": "橘猫团子", "affection": 80, "petted_today": false}
	fish_pond = {"fish_id": "", "count": 0, "days": 0}
	collection_seen = {}
	last_active_unix_ts = int(Time.get_unix_time_from_system())
	fairy_daily_instant_used = false
	ranch_animals = [
		{
			"id": "anim_starter_1",
			"kind": "chicken",
			"name": "小黄鸡咯咯",
			"affection": 60,
			"petted_today": false,
			"fed_today": true,
			"x": 384.0,
			"y": 336.0,
			"dir": 0,
		}
	]

	inventory.clear()
	for i in range(INVENTORY_SIZE):
		inventory.append({})

	# Starter toolkit & seeds
	inventory[0] = {"id": "tool_hoe", "count": 1, "quality": 0}
	inventory[1] = {"id": "tool_can", "count": 1, "quality": 0}
	inventory[2] = {"id": "tool_axe", "count": 1, "quality": 0}
	inventory[3] = {"id": "tool_pickaxe", "count": 1, "quality": 0}
	inventory[4] = {"id": "tool_blade", "count": 1, "quality": 0}
	inventory[5] = {"id": "tool_rod", "count": 1, "quality": 0}
	inventory[6] = {"id": "seed_turnip", "count": 6, "quality": 0}
	inventory[7] = {"id": "seed_sunbell", "count": 4, "quality": 0}
	inventory[8] = {"id": "seed_moonberry", "count": 4, "quality": 0}
	inventory[9] = {"id": "seed_clover", "count": 4, "quality": 0}
	inventory[10] = {"id": "herbal_tea", "count": 2, "quality": 0}
	inventory[11] = {"id": "hay", "count": 6, "quality": 0}

	skills.clear()
	for sk in SKILL_NAMES.keys():
		skills[sk] = {"level": 1, "xp": 0}

	shipping_queue.clear()
	last_day_summary.clear()

	npc_friendship.clear()
	for npc in DataRegistry.get_all_npcs():
		var d: Dictionary = npc
		var nid: String = str(d.get("id", ""))
		npc_friendship[nid] = {"points": 50, "talked_today": false, "gifted_today": false}

	bundle_progress.clear()
	for b in DataRegistry.get_bundles():
		var bd: Dictionary = b
		var bid: String = str(bd.get("id", ""))
		bundle_progress[bid] = {"submitted": {}, "completed": false}

	_roll_daily_quest()
	WorldMemory.reset()
	EventBus.inventory_changed.emit()
	EventBus.player_stats_changed.emit()
	EventBus.time_changed.emit(day, get_season(), year, hour, minute, weather)


func get_season() -> String:
	return str(SEASONS[season_idx % 4])


func get_season_name() -> String:
	return str(SEASON_NAMES.get(get_season(), "春"))


func get_weather_name() -> String:
	return str(WEATHER_NAMES.get(weather, "晴朗"))


func get_time_string() -> String:
	var disp_h: int = hour % 24
	return "%02d:%02d" % [disp_h, minute]


func advance_time_minutes(mins: int) -> bool:
	minute += mins
	var crossed_hour: bool = false
	while minute >= 60:
		minute -= 60
		hour += 1
		crossed_hour = true
	EventBus.time_changed.emit(day, get_season(), year, hour, minute, weather)
	return crossed_hour


func roll_tomorrow_weather() -> void:
	var s: String = get_season()
	var r: float = randf()
	if s == "winter":
		tomorrow_weather = "snow" if r < 0.38 else "sunny"
	elif s == "summer":
		if r < 0.14:
			tomorrow_weather = "storm"
		elif r < 0.28:
			tomorrow_weather = "rain"
		else:
			tomorrow_weather = "sunny"
	else:
		tomorrow_weather = "rain" if r < 0.26 else "sunny"


func _roll_daily_quest() -> void:
	var pool: Array = DataRegistry.get_daily_quests_pool()
	if pool.is_empty():
		active_quest = {}
	else:
		var pick: Dictionary = pool[randi() % pool.size()]
		active_quest = pick.duplicate(true)
	quest_completed_today = false


func can_plant_in_current_season(crop_id: String) -> bool:
	if greenhouse_blessing:
		return true
	var crop: Dictionary = DataRegistry.get_crop(crop_id)
	var seasons: Array = crop.get("seasons", [])
	return seasons.has(get_season())


func get_selected_slot() -> Dictionary:
	if selected_hotbar < 0 or selected_hotbar >= inventory.size():
		return {}
	return inventory[selected_hotbar]


func add_item(item_id: String, count: int = 1, quality: int = 0) -> bool:
	if item_id.is_empty() or count <= 0:
		return false
	var item_def: Dictionary = DataRegistry.get_item(item_id)
	if item_def.is_empty():
		return false
	collection_seen[item_id] = true
	var stackable: bool = bool(item_def.get("stackable", true))
	var rem: int = count
	if stackable:
		for i in range(inventory.size()):
			var slot: Dictionary = inventory[i]
			if not slot.is_empty() and str(slot.get("id", "")) == item_id and int(slot.get("quality", 0)) == quality:
				slot["count"] = int(slot.get("count", 0)) + rem
				inventory[i] = slot
				EventBus.inventory_changed.emit()
				return true
	for i in range(inventory.size()):
		var slot2: Dictionary = inventory[i]
		if slot2.is_empty():
			if stackable:
				inventory[i] = {"id": item_id, "count": rem, "quality": quality}
				EventBus.inventory_changed.emit()
				return true
			else:
				inventory[i] = {"id": item_id, "count": 1, "quality": quality}
				rem -= 1
				if rem <= 0:
					EventBus.inventory_changed.emit()
					return true
	EventBus.inventory_changed.emit()
	return rem < count


func count_item(item_id: String) -> int:
	var total: int = 0
	for s in inventory:
		var slot: Dictionary = s
		if not slot.is_empty() and str(slot.get("id", "")) == item_id:
			total += int(slot.get("count", 0))
	return total


func remove_item(item_id: String, count: int = 1, quality: int = -1) -> int:
	var to_remove: int = count
	for i in range(inventory.size()):
		if to_remove <= 0:
			break
		var slot: Dictionary = inventory[i]
		if slot.is_empty() or str(slot.get("id", "")) != item_id:
			continue
		if quality >= 0 and int(slot.get("quality", 0)) != quality:
			continue
		var have: int = int(slot.get("count", 0))
		var take: int = mini(have, to_remove)
		have -= take
		to_remove -= take
		if have <= 0:
			inventory[i] = {}
		else:
			slot["count"] = have
			inventory[i] = slot
	EventBus.inventory_changed.emit()
	return count - to_remove


func consume_slot(slot_idx: int, count: int = 1) -> void:
	if slot_idx < 0 or slot_idx >= inventory.size():
		return
	var slot: Dictionary = inventory[slot_idx]
	if slot.is_empty():
		return
	var left: int = int(slot.get("count", 0)) - count
	if left <= 0:
		inventory[slot_idx] = {}
	else:
		slot["count"] = left
		inventory[slot_idx] = slot
	EventBus.inventory_changed.emit()


func swap_slots(idx_a: int, idx_b: int) -> void:
	if idx_a < 0 or idx_a >= inventory.size() or idx_b < 0 or idx_b >= inventory.size():
		return
	var tmp: Dictionary = inventory[idx_a]
	inventory[idx_a] = inventory[idx_b]
	inventory[idx_b] = tmp
	EventBus.inventory_changed.emit()


func consume_energy(amount: float) -> bool:
	if energy < amount:
		return false
	energy = maxf(0.0, energy - amount)
	EventBus.player_stats_changed.emit()
	return true


func heal_player(en: float, h: float) -> void:
	energy = minf(max_energy, energy + en)
	hp = minf(max_hp, hp + h)
	EventBus.player_stats_changed.emit()


func damage_player(amount: float) -> bool:
	hp = maxf(0.0, hp - amount)
	EventBus.player_stats_changed.emit()
	return hp <= 0.0


func add_skill_xp(skill_id: String, xp_gain: int) -> void:
	if not skills.has(skill_id):
		return
	var sk: Dictionary = skills[skill_id]
	var lvl: int = int(sk.get("level", 1))
	var xp: int = int(sk.get("xp", 0)) + xp_gain
	var need: int = lvl * 60
	while xp >= need and lvl < 10:
		xp -= need
		lvl += 1
		need = lvl * 60
		var sk_name: String = str(SKILL_NAMES.get(skill_id, skill_id))
		EventBus.skill_leveled_up.emit(sk_name, lvl)
		EventBus.toast_message.emit("🌟 技能升级！%s 达到 Lv.%d" % [sk_name, lvl], Color(1.0, 0.85, 0.3))
	sk["level"] = lvl
	sk["xp"] = xp
	skills[skill_id] = sk
	EventBus.player_stats_changed.emit()


func has_keepsake(npc_id: String) -> bool:
	return bool(npc_keepsakes.get(npc_id, false))


func get_tutorial_prompt() -> String:
	var steps: Array = [
		"🎯 新手引导 1/6：走到下方已开垦田块旁，按 [E] 或右键收获成熟的绿色三叶草",
		"🎯 新手引导 2/6：按 [1] 选中锄头，在旁边草地上按左键/空格翻出一块新耕地",
		"🎯 新手引导 3/6：按 [7]~[0] 选中任意种子，对着刚翻好的耕地按左键播种",
		"🎯 新手引导 4/6：按 [2] 选水壶，对着新播下的土地按左键浇水",
		"🎯 新手引导 5/6：按 [Tab] 键开启【生态共鸣透镜】，查看作物连线与地力热力图",
		"🎯 新手引导 6/6：沿右侧泥土路一直往东走，前往【回响镇广场】认识林夏与霍恩！",
	]
	if tutorial_step < 0 or tutorial_step >= steps.size():
		return ""
	return str(steps[tutorial_step])


func advance_tutorial(expected_step: int) -> void:
	if tutorial_step != expected_step:
		return
	tutorial_step += 1
	if tutorial_step == 6:
		gold += 150
		AudioManager.play_sfx("fish_catch")
		EventBus.toast_message.emit("🎓 新手引导全部完成！获得山谷开拓礼金 +150G！", Color(1.0, 0.88, 0.35))
	else:
		AudioManager.play_sfx("ui_click")
	EventBus.player_stats_changed.emit()


func is_harvest_festival_day() -> bool:
	return day == 14 or day == 28


func get_tool_level(tool_type: String) -> int:
	return int(tool_levels.get(tool_type, 1))


func get_tool_upgrade_spec(tool_type: String) -> Dictionary:
	var cur: int = get_tool_level(tool_type)
	if cur >= 4:
		return {"maxed": true, "cur_level": cur}
	var tier_names: Dictionary = {1: "普通", 2: "红铜", 3: "精钢", 4: "耀金"}
	var bars: Dictionary = {1: "copper_bar", 2: "iron_bar", 3: "gold_bar"}
	var golds: Dictionary = {1: 300, 2: 600, 3: 1200}
	return {
		"maxed": false,
		"cur_level": cur,
		"next_level": cur + 1,
		"next_tier": str(tier_names.get(cur + 1, "高阶")),
		"bar_id": str(bars.get(cur, "copper_bar")),
		"bar_count": 2,
		"gold": int(golds.get(cur, 300)),
	}


func upgrade_tool(tool_type: String) -> Dictionary:
	var spec: Dictionary = get_tool_upgrade_spec(tool_type)
	if bool(spec.get("maxed", false)):
		return {"ok": false, "msg": "该工具已达最高耀金级！"}
	var bar_id: String = str(spec.get("bar_id", "copper_bar"))
	var bar_need: int = int(spec.get("bar_count", 2))
	var gold_need: int = int(spec.get("gold", 300))
	if gold < gold_need or count_item(bar_id) < bar_need:
		return {"ok": false, "msg": "金币或金属锭不足！"}
	gold -= gold_need
	remove_item(bar_id, bar_need)
	var nxt: int = int(spec.get("next_level", 2))
	tool_levels[tool_type] = nxt
	AudioManager.play_sfx("harvest")
	EventBus.player_stats_changed.emit()
	return {"ok": true, "level": nxt, "tier": str(spec.get("next_tier", ""))}


func get_skill_level(skill_id: String) -> int:
	var sk: Dictionary = skills.get(skill_id, {})
	return int(sk.get("level", 1))


func get_sell_price(item_id: String, quality: int = 0) -> int:
	var item_def: Dictionary = DataRegistry.get_item(item_id)
	var base: int = int(item_def.get("sell_price", 0))
	if quality == 1:
		return int(round(base * 1.25))
	elif quality == 2:
		return int(round(base * 1.5))
	return base


func add_shipping_item(item_id: String, count: int, quality: int = 0) -> void:
	var unit: int = get_sell_price(item_id, quality)
	if unit <= 0:
		return
	shipping_queue.append({
		"id": item_id,
		"count": count,
		"quality": quality,
		"unit_price": unit,
	})


func settle_overnight_shipping() -> Dictionary:
	var by_cat: Dictionary = {"farming": 0, "artisan": 0, "fishing": 0, "mining": 0, "other": 0}
	var total_gold: int = 0
	var lines: Array = []
	for entry in shipping_queue:
		var d: Dictionary = entry
		var iid: String = str(d.get("id", ""))
		var cnt: int = int(d.get("count", 0))
		var unit: int = int(d.get("unit_price", 0))
		var sub: int = cnt * unit
		total_gold += sub
		var item_def: Dictionary = DataRegistry.get_item(iid)
		var cat: String = str(item_def.get("category", "other"))
		if cat in ["crop", "seed", "ranch"]:
			by_cat["farming"] = int(by_cat["farming"]) + sub
		elif cat in ["artisan", "dish"]:
			by_cat["artisan"] = int(by_cat["artisan"]) + sub
		elif cat == "fish":
			by_cat["fishing"] = int(by_cat["fishing"]) + sub
		elif cat in ["mineral", "bar", "forage"]:
			by_cat["mining"] = int(by_cat["mining"]) + sub
		else:
			by_cat["other"] = int(by_cat["other"]) + sub
		lines.append({"name": str(item_def.get("name", iid)), "count": cnt, "subtotal": sub})
	var fest_bonus: int = 0
	if is_harvest_festival_day() and total_gold > 0:
		fest_bonus = int(round(float(total_gold) * 0.5))
		total_gold += fest_bonus
		WorldMemory.record_fact("harvest_festival", "在山谷丰收品鉴日享受到 1.5 倍出货庆典溢价", "mei")
	if has_keepsake("mei") and total_gold > 0:
		total_gold += int(round(float(total_gold) * 0.1))
	if golden_clock_built and total_gold > 0:
		total_gold += int(round(float(total_gold) * 0.25))
	gold += total_gold
	shipping_queue.clear()

	var penalty: int = 0
	if fainted_last_night:
		penalty = mini(150, int(gold * 0.1))
		gold = maxi(0, gold - penalty)

	last_day_summary = {
		"day": day,
		"season_name": get_season_name(),
		"year": year,
		"total_gold": total_gold,
		"festival_bonus": fest_bonus,
		"by_cat": by_cat,
		"lines": lines,
		"faint_penalty": penalty,
	}
	return last_day_summary


func advance_to_next_morning() -> void:
	day += 1
	if day > DAYS_PER_SEASON:
		day = 1
		season_idx += 1
		if season_idx >= 4:
			season_idx = 0
			year += 1
	hour = 6
	minute = 0
	weather = tomorrow_weather
	roll_tomorrow_weather()
	energy = max_energy * (0.75 if fainted_last_night else 1.0)
	hp = max_hp
	fainted_last_night = false
	active_buff = {}
	pet_data["petted_today"] = false
	fairy_daily_instant_used = false
	for nid in npc_friendship.keys():
		var f: Dictionary = npc_friendship[nid]
		f["talked_today"] = false
		f["gifted_today"] = false
		npc_friendship[nid] = f
		if is_harvest_festival_day():
			add_friendship(str(nid), 30)
	_roll_daily_quest()
	EventBus.player_stats_changed.emit()
	EventBus.time_changed.emit(day, get_season(), year, hour, minute, weather)
	if is_harvest_festival_day():
		EventBus.toast_message.emit("🎉 今日是【山谷丰收品鉴日】！出货箱全品类享 1.5 倍庆典收购价，全员好感 +30！", Color(1.0, 0.85, 0.35))


func add_friendship(npc_id: String, pts: int) -> void:
	if not npc_friendship.has(npc_id):
		npc_friendship[npc_id] = {"points": 0, "talked_today": false, "gifted_today": false}
	var f: Dictionary = npc_friendship[npc_id]
	var cur: int = int(f.get("points", 0))
	f["points"] = clampi(cur + pts, 0, 2500)
	npc_friendship[npc_id] = f


func get_friendship_hearts(npc_id: String) -> int:
	var f: Dictionary = npc_friendship.get(npc_id, {})
	return int(int(f.get("points", 0)) / 250)


func apply_food_buff(item_def: Dictionary) -> void:
	var bid: String = str(item_def.get("buff_id", ""))
	if bid.is_empty():
		return
	active_buff = {
		"id": bid,
		"name": str(item_def.get("buff_name", "料理增益")),
		"speed": float(item_def.get("buff_speed", 0.0)),
		"power": int(item_def.get("buff_power", 0)),
		"fish": float(item_def.get("buff_fish", 0.0)),
		"luck": float(item_def.get("buff_luck", 0.0)),
		"hours_left": float(item_def.get("buff_hours", 4.0)),
	}
	EventBus.player_stats_changed.emit()


func tick_buff_hours(hrs: float) -> void:
	if active_buff.is_empty():
		return
	var rem: float = float(active_buff.get("hours_left", 0.0)) - hrs
	if rem <= 0.0:
		active_buff = {}
	else:
		active_buff["hours_left"] = rem
	EventBus.player_stats_changed.emit()


func get_total_move_speed_bonus() -> float:
	var suwan_perk: float = 0.12 if has_keepsake("suwan") else 0.0
	return move_speed_bonus + suwan_perk + float(active_buff.get("speed", 0.0))


func upgrade_house() -> Dictionary:
	if house_tier == 1:
		if gold < 1500 or count_item("wood") < 40 or count_item("stone") < 25:
			return {"ok": false, "msg": "需要 1500G + 木材×40 + 石料×25！"}
		gold -= 1500
		remove_item("wood", 40)
		remove_item("stone", 25)
		house_tier = 2
		max_energy = 150.0
		energy = max_energy
		AudioManager.play_sfx("fish_catch")
		WorldMemory.record_fact("house_upgraded", "将农场小屋扩建成了宽敞温馨的二阶双人婚房", "suwan")
		EventBus.player_stats_changed.emit()
		return {"ok": true, "tier": 2, "title": "二阶双人雅居（体力上限提升至150，解锁求婚同居！）"}
	elif house_tier == 2:
		if gold < 4000 or count_item("hardwood") < 10 or count_item("iron_bar") < 3:
			return {"ok": false, "msg": "需要 4000G + 千年铁木×10 + 铁锭×3！"}
		gold -= 4000
		remove_item("hardwood", 10)
		remove_item("iron_bar", 3)
		house_tier = 3
		max_energy = 180.0
		energy = max_energy
		AudioManager.play_sfx("fish_catch")
		WorldMemory.record_fact("house_upgraded", "将农舍升级为三阶星露庄园豪宅", "suwan")
		EventBus.player_stats_changed.emit()
		return {"ok": true, "tier": 3, "title": "三阶星露庄园（体力上限提升至180！）"}
	return {"ok": false, "msg": "农舍已达最高三阶庄园等级！"}


func build_obelisk() -> Dictionary:
	if obelisk_built:
		return {"ok": false, "msg": "回响方尖传送塔已建成！"}
	if gold < 3500 or count_item("echo_crystal") < 3 or count_item("hardwood") < 10:
		return {"ok": false, "msg": "需要 3500G + 回响水晶×3 + 千年铁木×10！"}
	gold -= 3500
	remove_item("echo_crystal", 3)
	remove_item("hardwood", 10)
	obelisk_built = true
	AudioManager.play_sfx("fish_catch")
	WorldMemory.record_fact("wonder_built", "在农场建成了闪耀星芒的【回响方尖传送塔】", "suwan")
	EventBus.player_stats_changed.emit()
	return {"ok": true}


func build_golden_clock() -> Dictionary:
	if golden_clock_built:
		return {"ok": false, "msg": "黄金丰饶钟已建成！"}
	if gold < 15000 or count_item("gold_bar") < 5 or count_item("echo_crystal") < 5:
		return {"ok": false, "msg": "需要 15000G + 金锭×5 + 回响水晶×5！"}
	gold -= 15000
	remove_item("gold_bar", 5)
	remove_item("echo_crystal", 5)
	golden_clock_built = true
	AudioManager.play_sfx("fish_catch")
	WorldMemory.record_fact("wonder_built", "建成了传说终局奇观【黄金丰饶钟】，山谷永沐丰饶金光", "suwan")
	EventBus.player_stats_changed.emit()
	return {"ok": true}


func split_slot_half(slot_idx: int) -> bool:
	if slot_idx < 0 or slot_idx >= inventory.size():
		return false
	var s: Dictionary = inventory[slot_idx]
	if s.is_empty():
		return false
	var cnt: int = int(s.get("count", 1))
	if cnt < 2:
		return false
	var empty_idx: int = -1
	for i in range(inventory.size()):
		if (inventory[i] as Dictionary).is_empty():
			empty_idx = i
			break
	if empty_idx < 0:
		return false
	var half: int = int(cnt / 2)
	s["count"] = cnt - half
	inventory[slot_idx] = s
	inventory[empty_idx] = {"id": str(s.get("id", "")), "count": half, "quality": int(s.get("quality", 0))}
	EventBus.inventory_changed.emit()
	return true


func sort_and_merge_inventory() -> void:
	var tools: Array = []
	var stacks: Dictionary = {}
	var non_stack: Array = []
	for i in range(inventory.size()):
		var s: Dictionary = inventory[i]
		if s.is_empty():
			continue
		var iid: String = str(s.get("id", ""))
		var def: Dictionary = DataRegistry.get_item(iid)
		var cat: String = str(def.get("category", ""))
		if cat == "tool":
			tools.append(s.duplicate(true))
		elif bool(def.get("stackable", true)):
			var k: String = "%s|%d" % [iid, int(s.get("quality", 0))]
			if stacks.has(k):
				var ex: Dictionary = stacks[k]
				ex["count"] = int(ex.get("count", 0)) + int(s.get("count", 1))
				stacks[k] = ex
			else:
				stacks[k] = s.duplicate(true)
		else:
			non_stack.append(s.duplicate(true))

	var merged: Array = []
	for k2 in stacks.keys():
		merged.append(stacks[k2])
	merged.sort_custom(func(a: Dictionary, b: Dictionary) -> bool:
		var da: Dictionary = DataRegistry.get_item(str(a.get("id", "")))
		var db: Dictionary = DataRegistry.get_item(str(b.get("id", "")))
		var ca: String = str(da.get("category", ""))
		var cb: String = str(db.get("category", ""))
		if ca != cb:
			return ca < cb
		return str(a.get("id", "")) < str(b.get("id", ""))
	)

	inventory.clear()
	for _i in range(INVENTORY_SIZE):
		inventory.append({})
	var write_i: int = 0
	for t in tools:
		if write_i < INVENTORY_SIZE:
			inventory[write_i] = t
			write_i += 1
	for ns in non_stack:
		if write_i < INVENTORY_SIZE:
			inventory[write_i] = ns
			write_i += 1
	for m in merged:
		if write_i < INVENTORY_SIZE:
			inventory[write_i] = m
			write_i += 1
	EventBus.inventory_changed.emit()


func compute_valley_perfection() -> Dictionary:
	var crop_total: int = maxi(1, DataRegistry.get_all_crops().size())
	var crop_done: int = 0
	for c in DataRegistry.get_all_crops():
		if collection_seen.has(str((c as Dictionary).get("id", ""))):
			crop_done += 1

	var fish_total: int = maxi(1, DataRegistry.get_fish_list().size())
	var fish_done: int = 0
	for f in DataRegistry.get_fish_list():
		if collection_seen.has(str((f as Dictionary).get("id", ""))):
			fish_done += 1

	var dish_total: int = maxi(1, DataRegistry.get_cooking_recipes().size())
	var dish_done: int = 0
	for r in DataRegistry.get_cooking_recipes():
		if collection_seen.has(str((r as Dictionary).get("output_id", ""))):
			dish_done += 1

	var friend_4h: int = 0
	for nid in npc_friendship.keys():
		if get_friendship_hearts(str(nid)) >= 4:
			friend_4h += 1

	var bundle_done: int = 0
	for bid in bundle_progress.keys():
		if bool((bundle_progress[bid] as Dictionary).get("completed", false)):
			bundle_done += 1

	var badges: Array = []
	if crop_done >= 4:
		badges.append("🌾 田园新秀")
	if ranch_animals.size() >= 3:
		badges.append("🐄 牧场大亨")
	if dish_done >= 3:
		badges.append("🍳 乡野大厨")
	if mine_max_floor >= 10:
		badges.append("⚔️ 晶甲讨伐者")
	if greenhouse_unlocked:
		badges.append("🌿 四季常青")
	if house_tier >= 2:
		badges.append("🏡 温馨扩建")
	if not spouse_id.is_empty():
		badges.append("💍 琴瑟和鸣")
	if int(fish_pond.get("count", 0)) >= 1:
		badges.append("🐟 鱼塘生态主")
	if obelisk_built:
		badges.append("🔮 空间行者")
	if golden_clock_built:
		badges.append("👑 黄金传奇")

	var pts: float = 0.0
	pts += (float(crop_done) / float(crop_total)) * 20.0
	pts += (float(fish_done) / float(fish_total)) * 15.0
	pts += (float(dish_done) / float(dish_total)) * 15.0
	pts += (float(friend_4h) / float(maxi(1, npc_friendship.size()))) * 15.0
	pts += (float(bundle_done) / float(maxi(1, bundle_progress.size()))) * 10.0
	pts += clampf(float(mine_max_floor) / 10.0, 0.0, 1.0) * 10.0
	pts += (5.0 if house_tier >= 2 else 0.0) + (5.0 if obelisk_built else 0.0) + (5.0 if golden_clock_built else 0.0)

	return {
		"percent": clampi(int(round(pts)), 0, 100),
		"crop_done": crop_done, "crop_total": crop_total,
		"fish_done": fish_done, "fish_total": fish_total,
		"dish_done": dish_done, "dish_total": dish_total,
		"friend_4h": friend_4h, "friend_total": npc_friendship.size(),
		"badges": badges,
	}


func get_buff_tool_power() -> int:
	return int(active_buff.get("power", 0))


func get_buff_fish_bonus() -> float:
	return float(active_buff.get("fish", 0.0))


func get_buff_luck_bonus() -> float:
	return float(active_buff.get("luck", 0.0))


func get_active_buff_text() -> String:
	if active_buff.is_empty():
		return ""
	return "🍲 %s (%.0fh)" % [str(active_buff.get("name", "")), ceilf(float(active_buff.get("hours_left", 1.0)))]


func serialize() -> Dictionary:
	return {
		"day": day, "season_idx": season_idx, "year": year,
		"hour": hour, "minute": minute, "weather": weather, "tomorrow_weather": tomorrow_weather,
		"current_zone": current_zone,
		"player_x": player_grid.x, "player_y": player_grid.y,
		"gold": gold, "energy": energy, "max_energy": max_energy,
		"hp": hp, "max_hp": max_hp,
		"watering_can_water": watering_can_water,
		"move_speed_bonus": move_speed_bonus,
		"greenhouse_blessing": greenhouse_blessing,
		"selected_hotbar": selected_hotbar,
		"inventory": inventory.duplicate(true),
		"skills": skills.duplicate(true),
		"shipping_queue": shipping_queue.duplicate(true),
		"npc_friendship": npc_friendship.duplicate(true),
		"mine_current_floor": mine_current_floor,
		"mine_max_floor": mine_max_floor,
		"bundle_progress": bundle_progress.duplicate(true),
		"active_quest": active_quest.duplicate(true),
		"quest_completed_today": quest_completed_today,
		"tool_levels": tool_levels.duplicate(true),
		"greenhouse_unlocked": greenhouse_unlocked,
		"tutorial_step": tutorial_step,
		"npc_keepsakes": npc_keepsakes.duplicate(true),
		"festival_judged_season": festival_judged_season,
		"active_buff": active_buff.duplicate(true),
		"ranch_animals": ranch_animals.duplicate(true),
		"trough_hay": trough_hay,
		"house_tier": house_tier,
		"dating_npcs": dating_npcs.duplicate(true),
		"spouse_id": spouse_id,
		"seen_heart_events": seen_heart_events.duplicate(true),
		"obelisk_built": obelisk_built,
		"golden_clock_built": golden_clock_built,
		"pet_data": pet_data.duplicate(true),
		"fish_pond": fish_pond.duplicate(true),
		"collection_seen": collection_seen.duplicate(true),
		"last_active_unix_ts": int(Time.get_unix_time_from_system()),
		"fairy_daily_instant_used": fairy_daily_instant_used,
	}


func deserialize(data: Dictionary) -> void:
	day = int(data.get("day", 1))
	season_idx = int(data.get("season_idx", 0))
	year = int(data.get("year", 1))
	hour = int(data.get("hour", 6))
	minute = int(data.get("minute", 0))
	weather = str(data.get("weather", "sunny"))
	tomorrow_weather = str(data.get("tomorrow_weather", "sunny"))
	current_zone = str(data.get("current_zone", "farm"))
	player_grid = Vector2i(int(data.get("player_x", 8)), int(data.get("player_y", 8)))
	gold = int(data.get("gold", 500))
	energy = float(data.get("energy", 120.0))
	max_energy = float(data.get("max_energy", 120.0))
	hp = float(data.get("hp", 100.0))
	max_hp = float(data.get("max_hp", 100.0))
	watering_can_water = int(data.get("watering_can_water", 40))
	move_speed_bonus = float(data.get("move_speed_bonus", 0.0))
	greenhouse_blessing = bool(data.get("greenhouse_blessing", false))
	selected_hotbar = int(data.get("selected_hotbar", 0))
	inventory = data.get("inventory", []).duplicate(true)
	while inventory.size() < INVENTORY_SIZE:
		inventory.append({})
	skills = data.get("skills", {}).duplicate(true)
	shipping_queue = data.get("shipping_queue", []).duplicate(true)
	npc_friendship = data.get("npc_friendship", {}).duplicate(true)
	mine_current_floor = int(data.get("mine_current_floor", 1))
	mine_max_floor = int(data.get("mine_max_floor", 1))
	bundle_progress = data.get("bundle_progress", {}).duplicate(true)
	active_quest = data.get("active_quest", {}).duplicate(true)
	quest_completed_today = bool(data.get("quest_completed_today", false))
	var loaded_tools: Dictionary = data.get("tool_levels", {})
	if not loaded_tools.is_empty():
		tool_levels = loaded_tools.duplicate(true)
	greenhouse_unlocked = bool(data.get("greenhouse_unlocked", false))
	tutorial_step = int(data.get("tutorial_step", 0))
	npc_keepsakes = data.get("npc_keepsakes", {}).duplicate(true)
	festival_judged_season = int(data.get("festival_judged_season", -1))
	active_buff = (data.get("active_buff", {}) as Dictionary).duplicate(true)
	var loaded_animals: Array = data.get("ranch_animals", [])
	if not loaded_animals.is_empty():
		ranch_animals = loaded_animals.duplicate(true)
	trough_hay = int(data.get("trough_hay", 6))
	house_tier = int(data.get("house_tier", 1))
	dating_npcs = (data.get("dating_npcs", {}) as Dictionary).duplicate(true)
	spouse_id = str(data.get("spouse_id", ""))
	seen_heart_events = (data.get("seen_heart_events", {}) as Dictionary).duplicate(true)
	obelisk_built = bool(data.get("obelisk_built", false))
	golden_clock_built = bool(data.get("golden_clock_built", false))
	var loaded_pet: Dictionary = data.get("pet_data", {})
	if not loaded_pet.is_empty():
		pet_data = loaded_pet.duplicate(true)
	var loaded_pond: Dictionary = data.get("fish_pond", {})
	if not loaded_pond.is_empty():
		fish_pond = loaded_pond.duplicate(true)
	collection_seen = (data.get("collection_seen", {}) as Dictionary).duplicate(true)
	last_active_unix_ts = int(data.get("last_active_unix_ts", int(Time.get_unix_time_from_system())))
	fairy_daily_instant_used = bool(data.get("fairy_daily_instant_used", false))
	for npc in DataRegistry.get_all_npcs():
		var nid: String = str((npc as Dictionary).get("id", ""))
		if not nid.is_empty() and not npc_friendship.has(nid):
			npc_friendship[nid] = {"points": 50, "talked_today": false, "gifted_today": false}
	EventBus.inventory_changed.emit()
	EventBus.player_stats_changed.emit()
	EventBus.time_changed.emit(day, get_season(), year, hour, minute, weather)


func get_fairy_hourly_gold() -> int:
	var pond_cnt: int = int(fish_pond.get("count", 0))
	var rate: int = 40 + ranch_animals.size() * 20 + house_tier * 25 + pond_cnt * 18
	if greenhouse_unlocked:
		rate += 35
	if golden_clock_built:
		rate += 55
	return rate


func preview_offline_fairy_rewards(elapsed_seconds: int = -1) -> Dictionary:
	var now_ts: int = int(Time.get_unix_time_from_system())
	var sec: int = elapsed_seconds
	if sec < 0:
		sec = maxi(0, now_ts - last_active_unix_ts) if last_active_unix_ts > 0 else 0
	var capped_sec: int = clampi(sec, 0, 43200)
	var hours: float = float(capped_sec) / 3600.0
	var hr_gold: int = get_fairy_hourly_gold()
	var est_gold: int = int(round(float(hr_gold) * hours))
	var bonus_items: Array = []
	if hours >= 0.25:
		if ranch_animals.size() > 0:
			bonus_items.append({"id": "egg", "count": clampi(int(ceilf(hours * 0.6)), 1, 4)})
		if greenhouse_unlocked or season_idx == 1:
			bonus_items.append({"id": "star_coffee", "count": clampi(int(ceilf(hours * 0.5)), 1, 3)})
		else:
			bonus_items.append({"id": "turnip", "count": clampi(int(ceilf(hours * 0.5)), 1, 3)})
	return {
		"elapsed_seconds": sec,
		"capped_seconds": capped_sec,
		"hours": hours,
		"hourly_gold": hr_gold,
		"gold_gain": est_gold,
		"energy_gain": minf(max_energy - energy, roundf(hours * 16.0)),
		"items": bonus_items,
		"claimable": sec >= 600,
	}


func claim_offline_fairy_rewards(elapsed_seconds: int = -1, is_daily_instant: bool = false) -> Dictionary:
	var eff_sec: int = 7200 if is_daily_instant else elapsed_seconds
	var prev: Dictionary = preview_offline_fairy_rewards(eff_sec)
	if is_daily_instant:
		if fairy_daily_instant_used:
			return {"ok": false, "reason": "今日免费森灵即时巡收已使用，明日清晨6:00刷新！"}
		fairy_daily_instant_used = true
	elif not bool(prev.get("claimable", false)):
		return {"ok": false, "reason": "离线满 10 分钟后可领取森灵值班收益"}

	var g_add: int = int(prev.get("gold_gain", 0))
	var e_add: float = float(prev.get("energy_gain", 0.0))
	var items_arr: Array = prev.get("items", [])
	var added_names: Array = []
	for raw_it in items_arr:
		var it: Dictionary = raw_it
		var iid: String = str(it.get("id", ""))
		var cnt: int = int(it.get("count", 1))
		var idef: Dictionary = DataRegistry.get_item(iid)
		var inm: String = str(idef.get("name", iid))
		if add_item(iid, cnt, 0):
			added_names.append("%s×%d" % [inm, cnt])
		else:
			g_add += int(idef.get("sell_price", 40)) * cnt
			added_names.append("%s×%d(背包满折算金币)" % [inm, cnt])

	gold += g_add
	energy = minf(max_energy, energy + maxf(15.0, e_add))
	last_active_unix_ts = int(Time.get_unix_time_from_system())
	EventBus.player_stats_changed.emit()
	EventBus.inventory_changed.emit()
	return {
		"ok": true,
		"hours": float(prev.get("hours", 2.0)),
		"gold_gain": g_add,
		"energy_gain": maxf(15.0, e_add),
		"items_summary": "、".join(added_names),
		"is_daily_instant": is_daily_instant,
	}
