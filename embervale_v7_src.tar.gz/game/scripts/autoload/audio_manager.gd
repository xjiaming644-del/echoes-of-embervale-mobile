extends Node

var _streams: Dictionary = {}
var _sources: Dictionary = {}
var _sfx_players: Array = []
var _sfx_idx: int = 0
var _bgm_player: AudioStreamPlayer = null
var muted: bool = false
var current_bgm_track: String = "valley_breeze_loop.wav"


func _ready() -> void:
	for i in range(8):
		var p: AudioStreamPlayer = AudioStreamPlayer.new()
		p.bus = "Master"
		add_child(p)
		_sfx_players.append(p)
	_bgm_player = AudioStreamPlayer.new()
	_bgm_player.bus = "Master"
	_bgm_player.volume_db = -14.0
	add_child(_bgm_player)
	reload_all()


func _parse_wav_file(abs_path: String) -> AudioStreamWAV:
	if not FileAccess.file_exists(abs_path):
		return null
	var bytes: PackedByteArray = FileAccess.get_file_as_bytes(abs_path)
	if bytes.size() < 44:
		return null
	if bytes.slice(0, 4).get_string_from_ascii() != "RIFF":
		return null
	if bytes.slice(8, 12).get_string_from_ascii() != "WAVE":
		return null

	var offset: int = 12
	var channels: int = 1
	var sample_rate: int = 44100
	var bits_per_sample: int = 16
	var pcm_data: PackedByteArray = PackedByteArray()

	while offset + 8 <= bytes.size():
		var chunk_id: String = bytes.slice(offset, offset + 4).get_string_from_ascii()
		var chunk_size: int = bytes.decode_u32(offset + 4)
		offset += 8
		if offset + chunk_size > bytes.size():
			break
		if chunk_id == "fmt ":
			channels = bytes.decode_u16(offset + 2)
			sample_rate = bytes.decode_u32(offset + 4)
			bits_per_sample = bytes.decode_u16(offset + 14)
		elif chunk_id == "data":
			pcm_data = bytes.slice(offset, offset + chunk_size)
			break
		offset += chunk_size
		if chunk_size % 2 == 1:
			offset += 1

	if pcm_data.is_empty():
		return null

	var stream: AudioStreamWAV = AudioStreamWAV.new()
	stream.mix_rate = sample_rate
	stream.stereo = (channels == 2)
	stream.format = AudioStreamWAV.FORMAT_16_BITS if bits_per_sample == 16 else AudioStreamWAV.FORMAT_8_BITS
	stream.data = pcm_data
	return stream


func _load_audio(rel_path: String) -> AudioStream:
	var dropin_abs: String = ProjectSettings.globalize_path("res://../art_dropin/audio/" + rel_path)
	var ext_stream: AudioStreamWAV = _parse_wav_file(dropin_abs)
	if ext_stream != null:
		_sources[rel_path] = "human_override"
		return ext_stream

	var builtin_abs: String = ProjectSettings.globalize_path("res://assets/audio/" + rel_path)
	var int_stream: AudioStreamWAV = _parse_wav_file(builtin_abs)
	if int_stream != null:
		_sources[rel_path] = "ai_placeholder"
		return int_stream

	var res_path: String = "res://assets/audio/" + rel_path
	if ResourceLoader.exists(res_path):
		var loaded = ResourceLoader.load(res_path)
		if loaded is AudioStream:
			_sources[rel_path] = "ai_placeholder"
			return loaded
	return null


func _configure_loop_if_needed(rel: String, st: AudioStream) -> void:
	if rel.ends_with("_loop.wav") and st is AudioStreamWAV:
		var wav: AudioStreamWAV = st
		wav.loop_mode = AudioStreamWAV.LOOP_FORWARD
		wav.loop_begin = 0
		var frames_by_len: int = int(round(wav.get_length() * float(wav.mix_rate)))
		if frames_by_len > 0:
			wav.loop_end = frames_by_len
		else:
			var bytes_per_frame: int = (2 if wav.format == AudioStreamWAV.FORMAT_16_BITS else 1) * (2 if wav.stereo else 1)
			wav.loop_end = maxi(1, int(wav.data.size() / bytes_per_frame))


func reload_all() -> int:
	_streams.clear()
	_sources.clear()
	var manifest: Dictionary = DataRegistry.get_art_manifest()
	var audio_list: Array = manifest.get("audio", [])
	for au in audio_list:
		var d: Dictionary = au
		var rel: String = str(d.get("rel_path", ""))
		if not rel.is_empty():
			var st: AudioStream = _load_audio(rel)
			if st != null:
				_configure_loop_if_needed(rel, st)
				_streams[rel] = st
	return count_human_overrides()


func count_human_overrides() -> int:
	var c: int = 0
	for k in _sources.keys():
		if str(_sources[k]) == "human_override":
			c += 1
	return c


func play_sfx(sfx_name: String, pitch_jitter: float = 0.05) -> void:
	if muted or DisplayServer.get_name() == "headless":
		return
	var rel: String = sfx_name if sfx_name.ends_with(".wav") else (sfx_name + ".wav")
	if not _streams.has(rel):
		var st: AudioStream = _load_audio(rel)
		if st != null:
			_streams[rel] = st
	if not _streams.has(rel):
		return
	var p: AudioStreamPlayer = _sfx_players[_sfx_idx]
	_sfx_idx = (_sfx_idx + 1) % _sfx_players.size()
	p.stream = _streams[rel]
	p.volume_db = -4.0
	p.pitch_scale = 1.0 + randf_range(-pitch_jitter, pitch_jitter)
	p.play()


func resolve_bgm_track(zone_id: String, season: String) -> String:
	if zone_id == "coral_island":
		return "bgm_island_loop.wav"
	if season == "summer":
		return "bgm_summer_loop.wav"
	elif season == "autumn":
		return "bgm_autumn_loop.wav"
	elif season == "winter":
		return "bgm_winter_loop.wav"
	return "valley_breeze_loop.wav"


func sync_bgm_for_context(zone_id: String, season: String) -> String:
	var target: String = resolve_bgm_track(zone_id, season)
	if not _streams.has(target):
		var loaded_st: AudioStream = _load_audio(target)
		if loaded_st != null:
			_configure_loop_if_needed(target, loaded_st)
			_streams[target] = loaded_st
		else:
			target = "valley_breeze_loop.wav"
	var changed: bool = (current_bgm_track != target)
	current_bgm_track = target
	if muted or DisplayServer.get_name() == "headless":
		return current_bgm_track
	if _bgm_player != null and _streams.has(target):
		if changed or not _bgm_player.playing or _bgm_player.stream != _streams[target]:
			_bgm_player.stream = _streams[target]
			_bgm_player.play()
	return current_bgm_track


func start_ambient_bgm() -> void:
	sync_bgm_for_context(GameState.current_zone, GameState.get_season())


func stop_ambient_bgm() -> void:
	if _bgm_player != null:
		_bgm_player.stop()


func set_muted(flag: bool) -> bool:
	muted = flag
	var master_idx: int = AudioServer.get_bus_index("Master")
	if master_idx >= 0:
		AudioServer.set_bus_mute(master_idx, muted)
	if muted:
		stop_ambient_bgm()
		for p in _sfx_players:
			var sp: AudioStreamPlayer = p
			if sp != null and sp.playing:
				sp.stop()
	else:
		if DisplayServer.get_name() != "headless":
			start_ambient_bgm()
	EventBus.audio_mute_changed.emit(muted)
	return muted


func toggle_mute() -> bool:
	return set_muted(not muted)
