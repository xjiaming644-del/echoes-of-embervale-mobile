extends Node

var _items: Dictionary = {}
var _items_list: Array = []
var _crops: Dictionary = {}
var _crops_list: Array = []
var _synergies: Array = []
var _monoculture_rules: Dictionary = {}
var _crafting_recipes: Array = []
var _artisan_recipes: Array = []
var _cooking_recipes: Array = []
var _npcs: Dictionary = {}
var _npcs_list: Array = []
var _fish_list: Array = []
var _bundles: Array = []
var _daily_quests_pool: Array = []
var _art_manifest: Dictionary = {}


func _ready() -> void:
	reload_all()


func _load_json(filename: String) -> Dictionary:
	var res_path: String = "res://data/" + filename
	var abs_path: String = ProjectSettings.globalize_path(res_path)
	var text: String = ""
	if FileAccess.file_exists(abs_path):
		var fa: FileAccess = FileAccess.open(abs_path, FileAccess.READ)
		if fa != null:
			text = fa.get_as_text()
			fa.close()
	elif FileAccess.file_exists(res_path):
		var fa2: FileAccess = FileAccess.open(res_path, FileAccess.READ)
		if fa2 != null:
			text = fa2.get_as_text()
			fa2.close()
	if text.is_empty():
		push_warning("DataRegistry failed to load: " + filename)
		return {}
	var parsed = JSON.parse_string(text)
	if typeof(parsed) == TYPE_DICTIONARY:
		return parsed
	push_warning("DataRegistry invalid JSON dictionary in: " + filename)
	return {}


func reload_all() -> void:
	_items.clear()
	_items_list.clear()
	var items_doc: Dictionary = _load_json("items.json")
	var raw_items: Array = items_doc.get("items", [])
	for it in raw_items:
		var d: Dictionary = it
		var iid: String = str(d.get("id", ""))
		if not iid.is_empty():
			_items[iid] = d
			_items_list.append(d)

	_crops.clear()
	_crops_list.clear()
	var crops_doc: Dictionary = _load_json("crops.json")
	var raw_crops: Array = crops_doc.get("crops", [])
	for cp in raw_crops:
		var d: Dictionary = cp
		var cid: String = str(d.get("id", ""))
		if not cid.is_empty():
			_crops[cid] = d
			_crops_list.append(d)

	var eco_doc: Dictionary = _load_json("ecology_rules.json")
	_synergies = eco_doc.get("synergies", [])
	_monoculture_rules = eco_doc.get("monoculture_rules", {})

	var rec_doc: Dictionary = _load_json("recipes.json")
	_crafting_recipes = rec_doc.get("crafting", [])
	_artisan_recipes = rec_doc.get("artisan", [])
	_cooking_recipes = rec_doc.get("cooking", [])

	_npcs.clear()
	_npcs_list.clear()
	var npcs_doc: Dictionary = _load_json("npcs.json")
	var raw_npcs: Array = npcs_doc.get("npcs", [])
	for npc in raw_npcs:
		var d: Dictionary = npc
		var nid: String = str(d.get("id", ""))
		if not nid.is_empty():
			_npcs[nid] = d
			_npcs_list.append(d)

	var fish_doc: Dictionary = _load_json("fish.json")
	_fish_list = fish_doc.get("fish", [])

	var qb_doc: Dictionary = _load_json("quests_and_bundles.json")
	_bundles = qb_doc.get("bundles", [])
	_daily_quests_pool = qb_doc.get("daily_quests_pool", [])

	_art_manifest = _load_json("art_manifest.json")


func get_item(id: String) -> Dictionary:
	return _items.get(id, {})


func get_all_items() -> Array:
	return _items_list


func get_crop(id: String) -> Dictionary:
	return _crops.get(id, {})


func get_all_crops() -> Array:
	return _crops_list


func get_synergies() -> Array:
	return _synergies


func get_monoculture_rules() -> Dictionary:
	return _monoculture_rules


func get_crafting_recipes() -> Array:
	return _crafting_recipes


func get_artisan_recipes() -> Array:
	return _artisan_recipes


func get_cooking_recipes() -> Array:
	return _cooking_recipes


func get_npc(id: String) -> Dictionary:
	return _npcs.get(id, {})


func get_all_npcs() -> Array:
	return _npcs_list


func get_fish_list() -> Array:
	return _fish_list


func get_bundles() -> Array:
	return _bundles


func get_daily_quests_pool() -> Array:
	return _daily_quests_pool


func get_art_manifest() -> Dictionary:
	return _art_manifest


func get_shop_stock(shop_id: String, season: String) -> Array:
	var stock: Array = []
	if shop_id == "linxia_shop":
		for it in _items_list:
			var d: Dictionary = it
			var cat: String = str(d.get("category", ""))
			var price: int = int(d.get("buy_price", 0))
			if price <= 0:
				continue
			if cat == "seed":
				var seasons: Array = d.get("seasons", [])
				if seasons.has(season) or GameState.greenhouse_blessing:
					stock.append(d)
			elif cat in ["fertilizer", "consumable"]:
				if str(d.get("id", "")) != "roasted_fish":
					stock.append(d)
	elif shop_id == "horn_smithy":
		for iid in ["copper_ore", "iron_ore", "gold_ore", "wood", "stone", "roasted_fish"]:
			var d: Dictionary = get_item(iid)
			if not d.is_empty():
				stock.append(d)
	elif shop_id == "island_trader":
		for iid2 in ["seed_pineapple", "seed_star_coffee", "artisan_espresso", "fertilizer_speed"]:
			var d2: Dictionary = get_item(iid2)
			if not d2.is_empty():
				stock.append(d2)
	return stock
