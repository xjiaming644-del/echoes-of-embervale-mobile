extends Node

var _textures: Dictionary = {}
var _sources: Dictionary = {}


func _ready() -> void:
	reload_all()


func _load_external_or_builtin(rel_path: String) -> Texture2D:
	if not OS.has_feature("web") and not OS.has_feature("android") and not OS.has_feature("ios"):
		var dropin_abs: String = ProjectSettings.globalize_path("res://../art_dropin/sprites/" + rel_path)
		if FileAccess.file_exists(dropin_abs):
			var img: Image = Image.load_from_file(dropin_abs)
			if img != null and not img.is_empty():
				_sources[rel_path] = "human_override"
				return ImageTexture.create_from_image(img)

		var builtin_abs: String = ProjectSettings.globalize_path("res://assets/sprites/" + rel_path)
		if FileAccess.file_exists(builtin_abs):
			var img2: Image = Image.load_from_file(builtin_abs)
			if img2 != null and not img2.is_empty():
				_sources[rel_path] = "ai_placeholder"
				return ImageTexture.create_from_image(img2)

	var res_path: String = "res://assets/sprites/" + rel_path
	if ResourceLoader.exists(res_path):
		var loaded = ResourceLoader.load(res_path)
		if loaded is Texture2D:
			_sources[rel_path] = "ai_placeholder"
			return loaded

	return null


func get_tex(rel_path: String) -> Texture2D:
	if _textures.has(rel_path):
		return _textures[rel_path]
	var tex: Texture2D = _load_external_or_builtin(rel_path)
	if tex != null:
		_textures[rel_path] = tex
	return tex


func get_icon(icon_id: String) -> Texture2D:
	return get_tex("icons/" + icon_id + ".png")


func get_source(rel_path: String) -> String:
	if not _sources.has(rel_path):
		get_tex(rel_path)
	return str(_sources.get(rel_path, "missing"))


func count_human_overrides() -> int:
	var c: int = 0
	for k in _sources.keys():
		if str(_sources[k]) == "human_override":
			c += 1
	return c


func reload_all() -> Dictionary:
	_textures.clear()
	_sources.clear()
	var manifest: Dictionary = DataRegistry.get_art_manifest()
	var sprites: Array = manifest.get("sprites", [])
	for sp in sprites:
		var d: Dictionary = sp
		var rel: String = str(d.get("rel_path", ""))
		if not rel.is_empty():
			get_tex(rel)
	var human_count: int = count_human_overrides()
	return {"human_sprites": human_count, "total_sprites": sprites.size()}
