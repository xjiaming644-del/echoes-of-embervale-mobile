class_name PlayerController
extends Node

var world_pos: Vector2 = Vector2(272.0, 272.0)
var facing: int = 0 # 0:down, 1:left, 2:right, 3:up
var facing_vec: Vector2 = Vector2(0, 1)
var anim_t: float = 0.0
var moving: bool = false
var action_timer: float = 0.0
var action_kind: String = ""
var invuln_timer: float = 0.0
var warp_cooldown: float = 0.0
var target_grid: Vector2i = Vector2i(8, 9)
var ranch_sys: RanchSystem = null
var pet_sys: PetFishPondSystem = null
var camera_shake: float = 0.0
var step_dust_accum: float = 0.0
var auto_walk_active: bool = false
var auto_walk_world: Vector2 = Vector2.ZERO
var auto_walk_grid: Vector2i = Vector2i(-1, -1)
var auto_walk_act_on_arrive: bool = false
var arrived_smart_act_pending: bool = false
var _stuck_timer: float = 0.0
var _last_walk_pos: Vector2 = Vector2.ZERO


func sync_pos_from_grid() -> void:
	world_pos = Vector2(
		GameState.player_grid.x * ZoneManager.TILE_SIZE + 16.0,
		GameState.player_grid.y * ZoneManager.TILE_SIZE + 16.0
	)


func get_grid() -> Vector2i:
	return Vector2i(
		int(floor(world_pos.x / ZoneManager.TILE_SIZE)),
		int(floor(world_pos.y / ZoneManager.TILE_SIZE))
	)


func tick(delta: float, zone_mgr: ZoneManager, move_input: Vector2, sprinting: bool, mouse_world: Vector2, ui_locked: bool) -> void:
	if action_timer > 0.0:
		action_timer = maxf(0.0, action_timer - delta)
	if camera_shake > 0.0:
		camera_shake = maxf(0.0, camera_shake - delta * 6.0)
	if invuln_timer > 0.0:
		invuln_timer = maxf(0.0, invuln_timer - delta)
	if warp_cooldown > 0.0:
		warp_cooldown = maxf(0.0, warp_cooldown - delta)

	if ui_locked:
		moving = false
		return

	var eff_move: Vector2 = move_input
	var eff_sprint: bool = sprinting
	if move_input.length() > 0.05:
		auto_walk_active = false
		auto_walk_act_on_arrive = false
	elif auto_walk_active:
		var pg_now: Vector2i = get_grid()
		var cheb_g: int = maxi(absi(auto_walk_grid.x - pg_now.x), absi(auto_walk_grid.y - pg_now.y))
		var dist_w: float = auto_walk_world.distance_to(world_pos)
		if dist_w <= 18.0 or (auto_walk_act_on_arrive and cheb_g <= 1 and dist_w <= 46.0):
			auto_walk_active = false
			face_toward_grid(auto_walk_grid)
			if auto_walk_act_on_arrive:
				arrived_smart_act_pending = true
				auto_walk_act_on_arrive = false
		else:
			eff_move = (auto_walk_world - world_pos).normalized()
			eff_sprint = true

	if eff_move.length() > 0.05:
		var before_p: Vector2 = world_pos
		moving = true
		anim_t += delta * (10.5 if eff_sprint else 7.5)
		step_dust_accum += delta * (6.5 if eff_sprint else 4.0)
		var norm: Vector2 = eff_move.normalized()
		if absf(norm.x) > absf(norm.y):
			facing = 2 if norm.x > 0.0 else 1
			facing_vec = Vector2(1.0 if norm.x > 0.0 else -1.0, 0.0)
		else:
			facing = 0 if norm.y > 0.0 else 3
			facing_vec = Vector2(0.0, 1.0 if norm.y > 0.0 else -1.0)

		var spd: float = (186.0 if eff_sprint else 136.0) * (1.0 + GameState.get_total_move_speed_bonus())
		var dx: Vector2 = Vector2(norm.x * spd * delta, 0.0)
		var dy: Vector2 = Vector2(0.0, norm.y * spd * delta)
		if _can_stand_at(zone_mgr, world_pos + dx):
			world_pos += dx
		if _can_stand_at(zone_mgr, world_pos + dy):
			world_pos += dy
		if auto_walk_active:
			if world_pos.distance_to(before_p) < 0.35:
				_stuck_timer += delta
				if _stuck_timer >= 0.32:
					auto_walk_active = false
					auto_walk_act_on_arrive = false
			else:
				_stuck_timer = 0.0
	else:
		moving = false

	GameState.player_grid = get_grid()
	if not arrived_smart_act_pending:
		_update_target_grid(mouse_world)
	_pickup_nearby_drops(zone_mgr, delta)

	if warp_cooldown <= 0.0:
		var warp: Dictionary = zone_mgr.get_warp_at(GameState.current_zone, GameState.player_grid)
		if not warp.is_empty():
			var to_z: String = str(warp.get("to_zone", "farm"))
			var sp: Array = warp.get("spawn", [8, 8])
			warp_to_zone(to_z, Vector2i(int(sp[0]), int(sp[1])))


func _can_stand_at(zone_mgr: ZoneManager, pos: Vector2) -> bool:
	var half: float = 9.0
	var corners: Array = [
		Vector2(pos.x - half, pos.y - 4.0),
		Vector2(pos.x + half, pos.y - 4.0),
		Vector2(pos.x - half, pos.y + 10.0),
		Vector2(pos.x + half, pos.y + 10.0),
	]
	for c in corners:
		var cp: Vector2 = c
		var g: Vector2i = Vector2i(int(floor(cp.x / ZoneManager.TILE_SIZE)), int(floor(cp.y / ZoneManager.TILE_SIZE)))
		if not zone_mgr.is_walkable(GameState.current_zone, g):
			return false
	return true


func _update_target_grid(mouse_world: Vector2) -> void:
	var mg: Vector2i = Vector2i(
		int(floor(mouse_world.x / ZoneManager.TILE_SIZE)),
		int(floor(mouse_world.y / ZoneManager.TILE_SIZE))
	)
	var pg: Vector2i = get_grid()
	var diff: Vector2i = mg - pg
	if absi(diff.x) <= 1 and absi(diff.y) <= 1:
		target_grid = mg
	else:
		target_grid = pg + Vector2i(int(round(facing_vec.x)), int(round(facing_vec.y)))


func _pickup_nearby_drops(zone_mgr: ZoneManager, delta: float) -> void:
	var z: Dictionary = zone_mgr.get_zone(GameState.current_zone)
	var drops: Array = z.get("drops", [])
	for i in range(drops.size() - 1, -1, -1):
		var d: Dictionary = drops[i]
		var age: float = float(d.get("age", 1.0)) + delta
		d["age"] = age
		var dz: float = float(d.get("z", 0.0))
		var dvz: float = float(d.get("vz", 0.0))
		if dz > 0.0 or dvz != 0.0:
			dvz -= 420.0 * delta
			dz += dvz * delta
			d["x"] = float(d.get("x", 0.0)) + float(d.get("vx", 0.0)) * delta
			d["y"] = float(d.get("y", 0.0)) + float(d.get("vy", 0.0)) * delta
			if dz <= 0.0:
				dz = 0.0
				if absf(dvz) > 45.0:
					dvz = -dvz * 0.42
					d["vx"] = float(d.get("vx", 0.0)) * 0.45
					d["vy"] = float(d.get("vy", 0.0)) * 0.45
				else:
					dvz = 0.0
					d["vx"] = 0.0
					d["vy"] = 0.0
			d["z"] = dz
			d["vz"] = dvz

		var dp: Vector2 = Vector2(float(d.get("x", 0.0)), float(d.get("y", 0.0)))
		var dist: float = dp.distance_to(world_pos)
		if age > 0.28 and dist < 64.0:
			var pulled: Vector2 = dp.move_toward(world_pos, 235.0 * delta)
			d["x"] = pulled.x
			d["y"] = pulled.y
			drops[i] = d
			if pulled.distance_to(world_pos) < 15.0:
				var iid: String = str(d.get("item_id", ""))
				var cnt: int = int(d.get("count", 1))
				var qual: int = int(d.get("quality", 0))
				if GameState.add_item(iid, cnt, qual):
					var nm: String = str(DataRegistry.get_item(iid).get("name", iid))
					var qstar: String = "★" if qual == 2 else ("☆" if qual == 1 else "")
					EventBus.floating_text.emit(world_pos - Vector2(0, 18), "+%d %s%s" % [cnt, nm, qstar], Color(0.75, 0.96, 1.0))
					AudioManager.play_sfx("ui_click")
					drops.remove_at(i)
		else:
			drops[i] = d


func set_tap_walk_target(target_w: Vector2, grid_p: Vector2i, act_when_near: bool) -> void:
	auto_walk_world = target_w
	auto_walk_grid = grid_p
	auto_walk_act_on_arrive = act_when_near
	arrived_smart_act_pending = false
	_stuck_timer = 0.0
	auto_walk_active = true


func face_toward_grid(gp: Vector2i) -> void:
	var pg: Vector2i = get_grid()
	var diff: Vector2i = gp - pg
	if diff != Vector2i.ZERO:
		if absi(diff.x) >= absi(diff.y):
			facing = 2 if diff.x > 0 else 1
			facing_vec = Vector2(1.0 if diff.x > 0 else -1.0, 0.0)
		else:
			facing = 0 if diff.y > 0 else 3
			facing_vec = Vector2(0.0, 1.0 if diff.y > 0 else -1.0)
	if absi(diff.x) <= 1 and absi(diff.y) <= 1:
		target_grid = gp
	else:
		target_grid = pg + Vector2i(int(round(facing_vec.x)), int(round(facing_vec.y)))


func warp_to_zone(to_zone: String, spawn_grid: Vector2i) -> void:
	auto_walk_active = false
	auto_walk_act_on_arrive = false
	arrived_smart_act_pending = false
	GameState.current_zone = to_zone
	GameState.player_grid = spawn_grid
	sync_pos_from_grid()
	warp_cooldown = 0.45
	EventBus.zone_changed.emit(to_zone)
	AudioManager.play_sfx("ui_click")


func take_damage(amount: float) -> void:
	if invuln_timer > 0.0:
		return
	invuln_timer = 0.85
	var final_dmg: float = amount * (0.65 if GameState.has_keepsake("horn") else 1.0)
	var died: bool = GameState.damage_player(final_dmg)
	EventBus.floating_text.emit(world_pos - Vector2(0, 20), "-%d HP" % int(final_dmg), Color(1.0, 0.3, 0.3))
	AudioManager.play_sfx("monster_hit")
	if died:
		GameState.fainted_last_night = true
		WorldMemory.record_fact("fainted_exhaustion", "昨晚在山谷中力竭晕倒被救回农舍", "horn")
		EventBus.toast_message.emit("😵 生命耗尽晕倒了，霍恩大叔把你送回了农舍...", Color(1.0, 0.45, 0.4))
		EventBus.sleep_requested.emit()


func _get_aoe_tiles(center: Vector2i, level: int) -> Array:
	var out: Array = []
	if level <= 1:
		out.append(center)
		return out
	if level == 2:
		var step: Vector2i = Vector2i(int(round(facing_vec.x)), int(round(facing_vec.y)))
		if step == Vector2i.ZERO:
			step = Vector2i(0, 1)
		out.append(center)
		out.append(center + step)
		out.append(center + step * 2)
		return out
	for dy in range(-1, 2):
		for dx in range(-1, 2):
			out.append(center + Vector2i(dx, dy))
	return out


func use_primary(zone_mgr: ZoneManager, farm_sys: FarmingEcologySystem, artisan_sys: ArtisanSystem, mine_sys: MineCombatSystem) -> void:
	var slot: Dictionary = GameState.get_selected_slot()
	if slot.is_empty():
		return
	var iid: String = str(slot.get("id", ""))
	var item_def: Dictionary = DataRegistry.get_item(iid)
	var cat: String = str(item_def.get("category", ""))
	action_timer = 0.24
	action_kind = ""

	if cat == "tool":
		var tt: String = str(item_def.get("tool_type", ""))
		action_kind = tt
		if tt in ["hoe", "axe", "pickaxe", "blade"]:
			camera_shake = 0.25
		if tt == "hoe":
			var h_lvl: int = GameState.get_tool_level("hoe")
			var any_tilled: bool = false
			for gp in _get_aoe_tiles(target_grid, h_lvl):
				if farm_sys.till_tile(zone_mgr, gp as Vector2i, GameState.current_zone):
					any_tilled = true
			if any_tilled:
				GameState.advance_tutorial(1)
		elif tt == "can":
			if zone_mgr.is_water_tile(GameState.current_zone, target_grid):
				GameState.watering_can_water = GameState.max_watering_can
				AudioManager.play_sfx("water")
				EventBus.player_stats_changed.emit()
				EventBus.toast_message.emit("💧 水壶已重新装满！", Color(0.5, 0.85, 1.0))
			else:
				var c_lvl: int = GameState.get_tool_level("can")
				var any_watered: bool = false
				for gp2 in _get_aoe_tiles(target_grid, c_lvl):
					if farm_sys.water_tile(zone_mgr, gp2 as Vector2i, GameState.current_zone):
						any_watered = true
				if any_watered:
					GameState.advance_tutorial(3)
		elif tt == "axe":
			_use_axe(zone_mgr, target_grid)
		elif tt == "pickaxe":
			_use_pickaxe(zone_mgr, farm_sys, mine_sys, target_grid)
		elif tt == "blade":
			mine_sys.swing_blade_at(zone_mgr, world_pos, facing_vec)
		elif tt == "rod":
			if zone_mgr.is_water_tile(GameState.current_zone, target_grid):
				AudioManager.play_sfx("fish_cast")
				EventBus.open_fishing.emit(GameState.current_zone)
			else:
				EventBus.toast_message.emit("请对着池塘或低语湖的水面抛竿！", Color(0.65, 0.85, 1.0))
	elif cat == "seed":
		if farm_sys.plant_seed(zone_mgr, target_grid, iid, GameState.current_zone):
			GameState.consume_slot(GameState.selected_hotbar, 1)
			GameState.advance_tutorial(2)
	elif cat == "fertilizer":
		if farm_sys.apply_fertilizer(zone_mgr, target_grid, iid, GameState.current_zone):
			GameState.consume_slot(GameState.selected_hotbar, 1)
	elif cat == "machine":
		if artisan_sys.place_machine(zone_mgr, GameState.current_zone, target_grid, iid):
			GameState.consume_slot(GameState.selected_hotbar, 1)
	elif int(item_def.get("energy_restore", 0)) > 0:
		var en: float = float(item_def.get("energy_restore", 0))
		var h: float = float(item_def.get("hp_restore", 0))
		GameState.heal_player(en, h)
		GameState.apply_food_buff(item_def)
		GameState.consume_slot(GameState.selected_hotbar, 1)
		AudioManager.play_sfx("harvest")
		var bname: String = str(item_def.get("buff_name", ""))
		var extra: String = (" · ✨" + bname) if not bname.is_empty() else ""
		EventBus.floating_text.emit(world_pos - Vector2(0, 18), "+%d体力 +%d生命%s" % [int(en), int(h), extra], Color(0.55, 0.98, 0.62))


func _use_axe(zone_mgr: ZoneManager, pos: Vector2i) -> void:
	var obj: Dictionary = zone_mgr.get_object(GameState.current_zone, pos)
	if obj.is_empty():
		return
	var otype: String = str(obj.get("type", ""))
	if otype != "tree" and otype != "palm_tree" and otype != "stump" and otype != "hardwood_stump":
		return
	if not GameState.consume_energy(2.0):
		EventBus.toast_message.emit("体力不足！", Color(1.0, 0.5, 0.4))
		return
	AudioManager.play_sfx("chop")
	var power: int = GameState.get_tool_level("axe") + GameState.get_buff_tool_power()
	var hp: int = int(obj.get("hp", 2)) - power
	if hp > 0:
		obj["hp"] = hp
		zone_mgr.set_object(GameState.current_zone, pos, obj)
		EventBus.floating_text.emit(Vector2(pos.x * 32 + 16, pos.y * 32), "砍击!", Color(0.95, 0.85, 0.6))
		return
	var wp: Vector2 = Vector2(pos.x * 32 + 16, pos.y * 32 + 16)
	if otype == "tree" or otype == "palm_tree":
		zone_mgr.set_object(GameState.current_zone, pos, {"type": "stump", "hp": 2, "solid": true, "sprite": "objects/stump.png"})
		zone_mgr.spawn_drop(GameState.current_zone, wp, "wood", randi_range(5, 8))
		if otype == "palm_tree" and randf() < 0.45:
			zone_mgr.spawn_drop(GameState.current_zone, wp + Vector2(6, -4), "pineapple", 1)
		GameState.add_skill_xp("foraging", 10)
	elif otype == "hardwood_stump":
		zone_mgr.remove_object(GameState.current_zone, pos)
		zone_mgr.spawn_drop(GameState.current_zone, wp, "hardwood", randi_range(2, 3))
		GameState.add_skill_xp("foraging", 14)
	else:
		zone_mgr.remove_object(GameState.current_zone, pos)
		zone_mgr.spawn_drop(GameState.current_zone, wp, "wood", 2)
		GameState.add_skill_xp("foraging", 10)


func _use_pickaxe(zone_mgr: ZoneManager, farm_sys: FarmingEcologySystem, mine_sys: MineCombatSystem, pos: Vector2i) -> void:
	if GameState.current_zone == "mine":
		if not GameState.consume_energy(2.0):
			EventBus.toast_message.emit("体力不足！", Color(1.0, 0.5, 0.4))
			return
		mine_sys.hit_mine_rock(zone_mgr, pos)
		return
	var obj: Dictionary = zone_mgr.get_object(GameState.current_zone, pos)
	if not obj.is_empty():
		var otype: String = str(obj.get("type", ""))
		if otype == "rock":
			if not GameState.consume_energy(2.0):
				return
			AudioManager.play_sfx("mine_hit")
			var power: int = GameState.get_tool_level("pickaxe") + GameState.get_buff_tool_power()
			var hp: int = int(obj.get("hp", 2)) - power
			if hp <= 0:
				zone_mgr.remove_object(GameState.current_zone, pos)
				zone_mgr.spawn_drop(GameState.current_zone, Vector2(pos.x * 32 + 16, pos.y * 32 + 16), "stone", randi_range(2, 4))
				GameState.add_skill_xp("mining", 5)
			else:
				obj["hp"] = hp
				zone_mgr.set_object(GameState.current_zone, pos, obj)
			return
		elif otype == "machine":
			var proc: Dictionary = obj.get("processing", {})
			var stored: Array = obj.get("stored", [])
			if proc.is_empty() and stored.is_empty():
				var ret_id: String = str(obj.get("item_id", ""))
				if not ret_id.is_empty():
					zone_mgr.remove_object(GameState.current_zone, pos)
					GameState.add_item(ret_id, 1, 0)
					AudioManager.play_sfx("mine_hit")
					return
	# Un-till empty soil
	if GameState.current_zone in ["farm", "coral_island"]:
		var ft: Dictionary = farm_sys.get_farm_tile(zone_mgr, pos, GameState.current_zone)
		if bool(ft.get("tilled", false)) and (ft.get("crop", {}) as Dictionary).is_empty():
			ft["tilled"] = false
			ft["watered"] = false
			farm_sys.set_farm_tile(zone_mgr, pos, ft, GameState.current_zone)
			AudioManager.play_sfx("till")


func interact(zone_mgr: ZoneManager, farm_sys: FarmingEcologySystem, artisan_sys: ArtisanSystem, npc_sched: NPCScheduler, mouse_world: Vector2) -> void:
	# 1. Nearby NPC check
	var npc_id: String = npc_sched.find_npc_near_pos(GameState.current_zone, mouse_world, 40.0)
	if npc_id.is_empty():
		npc_id = npc_sched.find_npc_near_pos(GameState.current_zone, world_pos + facing_vec * 24.0, 48.0)
	if not npc_id.is_empty():
		AudioManager.play_sfx("ui_click")
		EventBus.open_dialogue.emit(npc_id)
		return

	# 1b. Pet nearby ranch animal if in ranch
	if GameState.current_zone == "ranch" and ranch_sys != null:
		if ranch_sys.pet_nearby_animal(mouse_world) or ranch_sys.pet_nearby_animal(world_pos + facing_vec * 20.0):
			return

	# 2. Check object at target_grid (and player's own tile for ladders/forage)
	var check_positions: Array = [target_grid, get_grid()]
	for gp in check_positions:
		var pos: Vector2i = gp
		var obj: Dictionary = zone_mgr.get_object(GameState.current_zone, pos)
		if obj.is_empty():
			continue
		var otype: String = str(obj.get("type", ""))
		if otype == "shipping_bin":
			_ship_selected_item()
			return
		elif otype == "machine":
			artisan_sys.interact_machine(zone_mgr, GameState.current_zone, pos, GameState.selected_hotbar)
			return
		elif otype == "bed":
			EventBus.sleep_requested.emit()
			return
		elif otype == "tv":
			EventBus.tv_requested.emit()
			return
		elif otype == "shop_counter":
			AudioManager.play_sfx("ui_click")
			EventBus.open_shop.emit(str(obj.get("shop_id", "linxia_shop")))
			return
		elif otype == "echo_shrine":
			AudioManager.play_sfx("ui_click")
			EventBus.open_shrine.emit()
			return
		elif otype == "quest_board":
			AudioManager.play_sfx("ui_click")
			EventBus.open_quest_board.emit()
			return
		elif otype == "forage":
			var fid: String = str(obj.get("item_id", "wild_berry"))
			zone_mgr.remove_object(GameState.current_zone, pos)
			GameState.add_item(fid, 1, 0)
			GameState.add_skill_xp("foraging", 6)
			AudioManager.play_sfx("harvest")
			EventBus.floating_text.emit(Vector2(pos.x * 32 + 16, pos.y * 32), "+1 %s" % str(DataRegistry.get_item(fid).get("name", fid)), Color(0.65, 0.95, 0.65))
			return
		elif otype == "ladder_up":
			if GameState.mine_current_floor > 1:
				zone_mgr.enter_mine_floor(GameState.mine_current_floor - 1)
				warp_to_zone("mine", Vector2i(11, 14))
			else:
				warp_to_zone("farm", Vector2i(16, 2))
			return
		elif otype == "ladder_down":
			zone_mgr.enter_mine_floor(GameState.mine_current_floor + 1)
			warp_to_zone("mine", Vector2i(11, 14))
			return
		elif otype == "elevator":
			EventBus.elevator_requested.emit()
			return
		elif otype == "greenhouse_door":
			EventBus.greenhouse_door_requested.emit()
			return
		elif otype == "festival_judge":
			EventBus.festival_judge_requested.emit()
			return
		elif otype == "kitchen_stove":
			AudioManager.play_sfx("ui_click")
			EventBus.open_cooking.emit()
			return
		elif otype == "ranch_counter" or otype == "feed_trough":
			AudioManager.play_sfx("ui_click")
			EventBus.open_ranch_shop.emit()
			return
		elif otype == "ranch_sign":
			EventBus.toast_message.emit("⬅️ 沿泥土路往左走即可进入【阳光牧场】（往南还可探秘迷雾秘林）！", Color(0.98, 0.88, 0.52))
			return
		elif otype == "pet_bowl":
			AudioManager.play_sfx("ui_click")
			EventBus.open_pet_bowl.emit()
			return
		elif otype == "fish_pond":
			if pet_sys != null:
				pet_sys.interact_fish_pond(GameState.selected_hotbar)
			return
		elif otype == "carpenter_desk":
			AudioManager.play_sfx("ui_click")
			EventBus.open_carpenter.emit()
			return
		elif otype == "obelisk":
			AudioManager.play_sfx("ui_click")
			EventBus.open_obelisk.emit()
			return
		elif otype == "golden_clock":
			AudioManager.play_sfx("harvest")
			EventBus.toast_message.emit("👑 黄金丰饶钟正闪耀光芒：全农场田块地力永恒满分，所有出货享 +25% 传奇溢价！", Color(1.0, 0.88, 0.35))
			return
		elif otype == "island_ferry":
			var dest_z: String = str(obj.get("to_zone", "coral_island"))
			var sp_arr: Array = obj.get("spawn", [14, 5])
			warp_to_zone(dest_z, Vector2i(int(sp_arr[0]), int(sp_arr[1])))
			AudioManager.play_sfx("water")
			EventBus.toast_message.emit("⛵ 扬帆起航！已抵达【%s】！" % str(zone_mgr.get_zone(dest_z).get("name", dest_z)), Color(0.52, 0.96, 1.0))
			return

	# 3. Harvest mature crop on farm, greenhouse, or coral_island
	if GameState.current_zone in ["farm", "greenhouse", "coral_island"]:
		if farm_sys.harvest_crop(zone_mgr, target_grid, GameState.current_zone):
			GameState.advance_tutorial(0)
			return

	# 4. Pet loyal companion cat/dog outdoors
	if pet_sys != null:
		if pet_sys.try_pet_companion(mouse_world) or pet_sys.try_pet_companion(world_pos + facing_vec * 20.0):
			return


func _ship_selected_item() -> void:
	var slot: Dictionary = GameState.get_selected_slot()
	if slot.is_empty():
		var q_val: int = 0
		for e in GameState.shipping_queue:
			var d: Dictionary = e
			q_val += int(d.get("count", 0)) * int(d.get("unit_price", 0))
		EventBus.toast_message.emit("📦 出货箱待结算：%d 件物品（预计 +%dG）" % [GameState.shipping_queue.size(), q_val], Color(1.0, 0.85, 0.4))
		return
	var iid: String = str(slot.get("id", ""))
	var qual: int = int(slot.get("quality", 0))
	var price: int = GameState.get_sell_price(iid, qual)
	if price <= 0:
		EventBus.toast_message.emit("这件物品不能放入出货箱出售！", Color(1.0, 0.6, 0.45))
		return
	var qty: int = int(slot.get("count", 1))
	GameState.add_shipping_item(iid, qty, qual)
	GameState.consume_slot(GameState.selected_hotbar, qty)
	AudioManager.play_sfx("coin")
	var nm: String = str(DataRegistry.get_item(iid).get("name", iid))
	EventBus.toast_message.emit("📦 已投入出货箱：%s ×%d（今晚结算 +%dG）" % [nm, qty, price * qty], Color(0.95, 0.88, 0.45))
