class_name MainGame
extends Node2D

var zone_mgr: ZoneManager = null
var farm_sys: FarmingEcologySystem = null
var artisan_sys: ArtisanSystem = null
var npc_sched: NPCScheduler = null
var mine_sys: MineCombatSystem = null
var ranch_sys: RanchSystem = null
var pet_sys: PetFishPondSystem = null
var player: PlayerController = null
var renderer: WorldRenderer = null
var camera: Camera2D = null
var day_modulate: CanvasModulate = null

var ui_layer: CanvasLayer = null
var ui_root: Control = null
var hud: HUDOverlay = null
var mobile_overlay: MobileTouchOverlay = null
var inv_modal: InventoryCraftModal = null
var shop_modal: ShopModal = null
var dlg_modal: DialogueModal = null
var fish_modal: FishingModal = null
var shrine_modal: ShrineQuestModal = null
var summary_modal: DaySummaryModal = null
var title_modal: TitleModal = null
var cooking_modal: CookingModal = null
var map_modal: WorldMapModal = null
var fairy_modal: FairyIdleModal = null
var portrait_mode: bool = false
var _bg_pause_ts: int = 0
var journal_backdrop: ColorRect = null
var journal_panel: PanelContainer = null
var journal_body: Label = null
var popup_backdrop: ColorRect = null
var popup_panel: PanelContainer = null
var popup_title: Label = null
var popup_btns: HFlowContainer = null

var _clock_accum: float = 0.0
var _skip_ambient: bool = false
var _skip_title: bool = false


func _ready() -> void:
	_setup_systems()
	_setup_world_nodes()
	_setup_ui()
	_connect_signals()
	_on_zone_changed(GameState.current_zone)
	if not _skip_ambient and DisplayServer.get_name() != "headless":
		AudioManager.start_ambient_bgm()


func _setup_systems() -> void:
	zone_mgr = ZoneManager.new()
	zone_mgr.name = "ZoneManager"
	add_child(zone_mgr)

	farm_sys = FarmingEcologySystem.new()
	farm_sys.name = "FarmingEcologySystem"
	add_child(farm_sys)

	artisan_sys = ArtisanSystem.new()
	artisan_sys.name = "ArtisanSystem"
	add_child(artisan_sys)

	npc_sched = NPCScheduler.new()
	npc_sched.name = "NPCScheduler"
	add_child(npc_sched)
	npc_sched.init_npcs(zone_mgr)
	npc_sched.update_schedules_for_hour(GameState.hour)

	mine_sys = MineCombatSystem.new()
	mine_sys.name = "MineCombatSystem"
	add_child(mine_sys)

	ranch_sys = RanchSystem.new()
	ranch_sys.name = "RanchSystem"
	add_child(ranch_sys)

	pet_sys = PetFishPondSystem.new()
	pet_sys.name = "PetFishPondSystem"
	add_child(pet_sys)

	player = PlayerController.new()
	player.name = "PlayerController"
	player.ranch_sys = ranch_sys
	player.pet_sys = pet_sys
	add_child(player)
	player.sync_pos_from_grid()
	pet_sys.sync_pet_near_player(player.world_pos)
	SaveManager.ensure_graduate_showcase_save(2, zone_mgr, npc_sched, false)


func _setup_world_nodes() -> void:
	renderer = WorldRenderer.new()
	renderer.zone_mgr = zone_mgr
	renderer.farm_sys = farm_sys
	renderer.npc_sched = npc_sched
	renderer.mine_sys = mine_sys
	renderer.ranch_sys = ranch_sys
	renderer.pet_sys = pet_sys
	renderer.player = player
	add_child(renderer)

	camera = Camera2D.new()
	camera.zoom = Vector2(1.75, 1.75)
	camera.position = player.world_pos
	add_child(camera)
	camera.make_current()

	day_modulate = CanvasModulate.new()
	add_child(day_modulate)


func _setup_ui() -> void:
	ui_layer = CanvasLayer.new()
	add_child(ui_layer)

	ui_root = Control.new()
	ui_root.name = "UIRoot"
	ui_root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	ui_root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	ui_layer.add_child(ui_root)

	hud = HUDOverlay.new()
	ui_root.add_child(hud)

	mobile_overlay = MobileTouchOverlay.new()
	ui_root.add_child(mobile_overlay)

	inv_modal = InventoryCraftModal.new()
	ui_root.add_child(inv_modal)

	shop_modal = ShopModal.new()
	ui_root.add_child(shop_modal)

	dlg_modal = DialogueModal.new()
	dlg_modal.npc_scheduler = npc_sched
	ui_root.add_child(dlg_modal)

	fish_modal = FishingModal.new()
	ui_root.add_child(fish_modal)

	shrine_modal = ShrineQuestModal.new()
	ui_root.add_child(shrine_modal)

	summary_modal = DaySummaryModal.new()
	ui_root.add_child(summary_modal)

	cooking_modal = CookingModal.new()
	ui_root.add_child(cooking_modal)

	map_modal = WorldMapModal.new()
	map_modal.npc_scheduler = npc_sched
	ui_root.add_child(map_modal)

	fairy_modal = FairyIdleModal.new()
	ui_root.add_child(fairy_modal)

	title_modal = TitleModal.new()
	title_modal.visible = not _skip_title and DisplayServer.get_name() != "headless"
	if title_modal.visible:
		GameState.time_paused = true
	ui_root.add_child(title_modal)

	_build_journal_modal()
	_build_popup_modal()
	# Ensure mobile_overlay sits above fish_modal so right-hand Use button stays reachable while fishing
	ui_root.move_child(mobile_overlay, ui_root.get_child_count() - 1)


func _build_journal_modal() -> void:
	journal_backdrop = ColorRect.new()
	journal_backdrop.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	journal_backdrop.color = Color(0.04, 0.03, 0.02, 0.56)
	journal_backdrop.mouse_filter = Control.MOUSE_FILTER_STOP
	journal_backdrop.visible = false
	journal_backdrop.gui_input.connect(func(ev: InputEvent):
		if (ev is InputEventScreenTouch and (ev as InputEventScreenTouch).pressed) or (ev is InputEventMouseButton and (ev as InputEventMouseButton).pressed and (ev as InputEventMouseButton).button_index == MOUSE_BUTTON_LEFT):
			journal_panel.visible = false
			GameState.time_paused = false
			journal_backdrop.accept_event()
	)
	ui_root.add_child(journal_backdrop)

	journal_panel = PanelContainer.new()
	journal_panel.theme = UITheme.build_theme()
	journal_panel.set_anchors_preset(Control.PRESET_CENTER)
	journal_panel.offset_left = -360
	journal_panel.offset_top = -230
	journal_panel.offset_right = 360
	journal_panel.offset_bottom = 230
	journal_panel.visible = false
	journal_panel.visibility_changed.connect(func():
		if journal_backdrop != null:
			journal_backdrop.visible = journal_panel.visible
	)
	ui_root.add_child(journal_panel)

	var v: VBoxContainer = VBoxContainer.new()
	journal_panel.add_child(v)
	var hdr: HBoxContainer = HBoxContainer.new()
	v.add_child(hdr)
	var t: Label = Label.new()
	t.text = "📖 山谷回响记忆日志 & 伴生生态图鉴"
	t.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	t.add_theme_font_size_override("font_size", 18)
	t.add_theme_color_override("font_color", Color(1.0, 0.88, 0.45))
	hdr.add_child(t)
	var cb: Button = Button.new()
	cb.text = "✕ 关闭 [M]"
	cb.custom_minimum_size = Vector2(116, 44)
	cb.pressed.connect(func(): journal_panel.visible = false; GameState.time_paused = false)
	hdr.add_child(cb)

	var sc: ScrollContainer = ScrollContainer.new()
	sc.size_flags_vertical = Control.SIZE_EXPAND_FILL
	v.add_child(sc)
	journal_body = Label.new()
	journal_body.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	journal_body.custom_minimum_size = Vector2(670, 0)
	journal_body.add_theme_font_size_override("font_size", 14)
	sc.add_child(journal_body)


func _build_popup_modal() -> void:
	popup_backdrop = ColorRect.new()
	popup_backdrop.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	popup_backdrop.color = Color(0.04, 0.03, 0.02, 0.58)
	popup_backdrop.mouse_filter = Control.MOUSE_FILTER_STOP
	popup_backdrop.visible = false
	popup_backdrop.gui_input.connect(func(ev: InputEvent):
		if (ev is InputEventScreenTouch and (ev as InputEventScreenTouch).pressed) or (ev is InputEventMouseButton and (ev as InputEventMouseButton).pressed and (ev as InputEventMouseButton).button_index == MOUSE_BUTTON_LEFT):
			_close_popup()
			popup_backdrop.accept_event()
	)
	ui_root.add_child(popup_backdrop)

	popup_panel = PanelContainer.new()
	popup_panel.theme = UITheme.build_theme()
	popup_panel.set_anchors_preset(Control.PRESET_CENTER)
	popup_panel.offset_left = -320
	popup_panel.offset_top = -135
	popup_panel.offset_right = 320
	popup_panel.offset_bottom = 135
	popup_panel.visible = false
	popup_panel.visibility_changed.connect(func():
		if popup_backdrop != null:
			popup_backdrop.visible = popup_panel.visible
	)
	ui_root.add_child(popup_panel)

	var v: VBoxContainer = VBoxContainer.new()
	v.alignment = BoxContainer.ALIGNMENT_CENTER
	v.add_theme_constant_override("separation", 14)
	popup_panel.add_child(v)

	popup_title = Label.new()
	popup_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	popup_title.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	popup_title.custom_minimum_size = Vector2(580, 0)
	popup_title.add_theme_font_size_override("font_size", 15)
	v.add_child(popup_title)

	popup_btns = HFlowContainer.new()
	popup_btns.alignment = FlowContainer.ALIGNMENT_CENTER
	popup_btns.add_theme_constant_override("h_separation", 10)
	popup_btns.add_theme_constant_override("v_separation", 8)
	v.add_child(popup_btns)


func _connect_signals() -> void:
	EventBus.floating_text.connect(renderer.add_floating_text)
	EventBus.zone_changed.connect(_on_zone_changed)
	EventBus.open_shop.connect(func(sid): _close_all_modals(); shop_modal.open_shop(sid))
	EventBus.open_dialogue.connect(func(nid): _close_all_modals(); dlg_modal.open_npc(nid))
	EventBus.open_shrine.connect(func(): _close_all_modals(); shrine_modal.open_shrine())
	EventBus.open_quest_board.connect(func(): _close_all_modals(); shrine_modal.open_quest())
	EventBus.open_fishing.connect(func(zid): _close_all_modals(); fish_modal.start_fishing(zid))
	EventBus.sleep_requested.connect(_on_sleep_requested)
	EventBus.tv_requested.connect(_on_tv_requested)
	EventBus.elevator_requested.connect(_on_elevator_requested)
	EventBus.greenhouse_door_requested.connect(_on_greenhouse_door_requested)
	EventBus.festival_judge_requested.connect(_on_festival_judge_requested)
	EventBus.open_cooking.connect(func(): _close_all_modals(); cooking_modal.open_cooking())
	EventBus.open_ranch_shop.connect(_on_ranch_shop_requested)
	EventBus.open_world_map.connect(func(): _close_all_modals(); map_modal.open_map())
	EventBus.open_carpenter.connect(_on_carpenter_requested)
	EventBus.open_obelisk.connect(_on_obelisk_requested)
	EventBus.open_pet_bowl.connect(_on_pet_bowl_requested)

	map_modal.fast_travel_requested.connect(func(zid: String, sp: Vector2i):
		player.warp_to_zone(zid, sp)
		EventBus.toast_message.emit("🚶 漫步抵达了 %s" % str(zone_mgr.get_zone(zid).get("name", zid)), Color(0.75, 0.96, 0.78))
	)

	title_modal.start_new_game.connect(func():
		GameState.reset_new_game()
		zone_mgr.init_all_zones()
		npc_sched.init_npcs(zone_mgr)
		npc_sched.update_schedules_for_hour(GameState.hour)
		player.sync_pos_from_grid()
		_on_zone_changed("farm")
		if not _skip_ambient:
			AudioManager.start_ambient_bgm()
		hud.refresh()
	)
	title_modal.continue_saved_game.connect(func():
		if SaveManager.load_game(1, zone_mgr, npc_sched):
			player.sync_pos_from_grid()
			_on_zone_changed(GameState.current_zone)
			if not _skip_ambient:
				AudioManager.start_ambient_bgm()
			hud.refresh()
			_check_and_pop_offline_fairy()
	)
	title_modal.load_showcase_game.connect(func():
		if SaveManager.load_game(2, zone_mgr, npc_sched):
			player.sync_pos_from_grid()
			_on_zone_changed(GameState.current_zone)
			if not _skip_ambient:
				AudioManager.start_ambient_bgm()
			hud.refresh()
			EventBus.toast_message.emit("🌟 已载入【三阶星露庄园 & 珊瑚群岛】毕业演示档！按 N 或用方尖碑畅游全境！", Color(1.0, 0.88, 0.42))
	)

	mobile_overlay.action_use_primary.connect(func():
		if not is_any_modal_open():
			player.target_grid = player.get_grid() + Vector2i(int(round(player.facing_vec.x)), int(round(player.facing_vec.y)))
			player.use_primary(zone_mgr, farm_sys, artisan_sys, mine_sys)
	)
	mobile_overlay.action_interact.connect(func():
		if not is_any_modal_open():
			player.target_grid = player.get_grid() + Vector2i(int(round(player.facing_vec.x)), int(round(player.facing_vec.y)))
			player.interact(zone_mgr, farm_sys, artisan_sys, npc_sched, player.world_pos + player.facing_vec * 28.0)
	)

	inv_modal.request_save.connect(func(slot): SaveManager.save_game(slot, zone_mgr, npc_sched))
	inv_modal.request_load.connect(func(slot):
		if SaveManager.load_game(slot, zone_mgr, npc_sched):
			player.sync_pos_from_grid()
			inv_modal.visible = false
			GameState.time_paused = false
			_check_and_pop_offline_fairy()
	)

	hud.action_button_pressed.connect(func(act):
		if act == "toggle_lens":
			if not fish_modal.active:
				_toggle_lens()
		elif act == "open_inv":
			if inv_modal.visible:
				inv_modal.visible = false
				GameState.time_paused = false
			elif not fish_modal.active and not summary_modal.visible:
				_close_all_modals()
				inv_modal.open_modal()
		elif act == "open_map":
			if map_modal.visible:
				map_modal.visible = false
				GameState.time_paused = false
			elif not fish_modal.active and not summary_modal.visible:
				_close_all_modals()
				map_modal.open_map()
		elif act == "open_mem":
			if not fish_modal.active and not summary_modal.visible:
				_toggle_journal()
		elif act == "reload_assets":
			hot_reload_all()
		elif act == "toggle_mobile":
			toggle_mobile_controls()
		elif act == "toggle_portrait":
			toggle_portrait_mode()
		elif act == "open_fairy":
			if fairy_modal != null and fairy_modal.visible:
				fairy_modal.close_modal()
			elif not fish_modal.active and not summary_modal.visible:
				_close_all_modals()
				fairy_modal.open_modal()
		elif act == "capture_postcard":
			capture_farm_postcard()
		elif act == "toggle_mute":
			toggle_audio_mute()
	)


func is_any_modal_open() -> bool:
	return (
		(title_modal != null and title_modal.visible)
		or inv_modal.visible
		or shop_modal.visible
		or dlg_modal.visible
		or fish_modal.visible
		or shrine_modal.visible
		or summary_modal.visible
		or (cooking_modal != null and cooking_modal.visible)
		or (map_modal != null and map_modal.visible)
		or (fairy_modal != null and fairy_modal.visible)
		or journal_panel.visible
		or popup_panel.visible
	)


func _close_all_modals() -> void:
	inv_modal.visible = false
	shop_modal.visible = false
	dlg_modal.visible = false
	shrine_modal.visible = false
	if cooking_modal != null:
		cooking_modal.visible = false
	if map_modal != null:
		map_modal.visible = false
	if fairy_modal != null:
		fairy_modal.visible = false
	journal_panel.visible = false
	popup_panel.visible = false
	if not fish_modal.active and not summary_modal.visible:
		GameState.time_paused = false


func _toggle_lens() -> void:
	renderer.ecology_lens_active = not renderer.ecology_lens_active
	hud.set_lens_indicator(renderer.ecology_lens_active)
	AudioManager.play_sfx("ui_click")
	if renderer.ecology_lens_active:
		GameState.advance_tutorial(4)


func _toggle_journal() -> void:
	if journal_panel.visible:
		journal_panel.visible = false
		GameState.time_paused = false
	else:
		_close_all_modals()
		var perf: Dictionary = GameState.compute_valley_perfection()
		var badges: Array = perf.get("badges", [])
		var badge_str: String = "  ".join(badges) if badges.size() > 0 else "（尚在开拓中：多种植、下厨、探矿或扩建农舍即可点亮徽章！）"
		var spouse_txt: String = "单身开拓中"
		if not GameState.spouse_id.is_empty():
			spouse_txt = "💍 已与【%s】喜结连理" % str(DataRegistry.get_npc(GameState.spouse_id).get("name", GameState.spouse_id))
		var lines: Array = [
			"【🏆 山谷完美度总览：%d%%】" % int(perf.get("percent", 0)),
			"• 作物图鉴：%d/%d  |  鱼类图鉴：%d/%d  |  料理图鉴：%d/%d  |  4心挚友：%d/%d" % [
				int(perf.get("crop_done", 0)), int(perf.get("crop_total", 15)),
				int(perf.get("fish_done", 0)), int(perf.get("fish_total", 9)),
				int(perf.get("dish_done", 0)), int(perf.get("dish_total", 8)),
				int(perf.get("friend_4h", 0)), int(perf.get("friend_total", 6)),
			],
			"• 庄园等阶：Lv.%d  |  婚姻状态：%s  |  萌宠：%s (好感 %d)" % [
				GameState.house_tier, spouse_txt,
				str(GameState.pet_data.get("name", "橘猫团子")), int(GameState.pet_data.get("affection", 80)),
			],
			"• 已解锁荣誉徽章：%s" % badge_str,
			"",
			"【最近山谷传闻与玩家事迹】",
		]
		if WorldMemory.rumor_log.is_empty():
			lines.append("（山谷暂时风平浪静。多与村民交流、种植伴生作物、探险秘林与矿洞来书写回响事迹吧！）")
		else:
			for rl in WorldMemory.rumor_log:
				lines.append("• " + str(rl))
		lines.append("")
		lines.append("【伴生生态共鸣规则速查】")
		for syn in DataRegistry.get_synergies():
			var sd: Dictionary = syn
			lines.append("✦ %s：%s" % [str(sd.get("name", "")), str(sd.get("description", ""))])
		journal_body.text = "\n".join(lines)
		journal_panel.visible = true
		GameState.time_paused = true


func hot_reload_all() -> void:
	DataRegistry.reload_all()
	var sp_res: Dictionary = AssetRegistry.reload_all()
	var au_cnt: int = AudioManager.reload_all()
	var hs: int = int(sp_res.get("human_sprites", 0))
	EventBus.assets_reloaded.emit(hs, au_cnt)
	AudioManager.play_sfx("harvest")
	EventBus.toast_message.emit(
		"✨ 实时热重载完成！人工美术覆盖：%d/%d · 人工音效：%d" % [hs, int(sp_res.get("total_sprites", 0)), au_cnt],
		Color(0.55, 0.98, 0.72)
	)


func toggle_audio_mute() -> bool:
	var now_muted: bool = AudioManager.toggle_mute()
	if hud != null:
		hud.refresh()
	if not now_muted:
		AudioManager.play_sfx("ui_click")
	EventBus.toast_message.emit(
		"🔇 已开启全局静音 (按 F10 恢复声音)" if now_muted else "🔊 已恢复山谷音效与环境音乐",
		Color(0.92, 0.86, 0.68) if now_muted else Color(0.62, 0.96, 0.76)
	)
	return now_muted


func toggle_fullscreen() -> bool:
	if DisplayServer.get_name() == "headless":
		return false
	var cur_mode: int = DisplayServer.window_get_mode()
	var to_fs: bool = (cur_mode != DisplayServer.WINDOW_MODE_FULLSCREEN and cur_mode != DisplayServer.WINDOW_MODE_EXCLUSIVE_FULLSCREEN)
	if to_fs:
		DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_FULLSCREEN)
		EventBus.toast_message.emit("🖥️ 已切换至无边框全屏模式 (按 F11 返回窗口)", Color(0.68, 0.92, 1.0))
	else:
		DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_WINDOWED)
		EventBus.toast_message.emit("🪟 已返回桌面窗口模式 (按 F11 全屏)", Color(0.86, 0.92, 1.0))
	return to_fs


func toggle_mobile_controls() -> bool:
	if mobile_overlay == null:
		return false
	var next_on: bool = not mobile_overlay.mobile_enabled
	mobile_overlay.set_mobile_enabled(next_on)
	EventBus.toast_message.emit(
		"📱 手机触屏操控已开启：支持左摇杆 + 右大按键 + 单手点地寻路收菜！" if next_on else "🖱️ 已切换回纯键鼠紧凑界面",
		Color(0.58, 0.98, 0.78) if next_on else Color(0.88, 0.90, 0.96)
	)
	return next_on


func trigger_commute_autosave() -> bool:
	if zone_mgr == null or npc_sched == null:
		return false
	if title_modal != null and title_modal.visible:
		return false
	var ok: bool = SaveManager.save_game(1, zone_mgr, npc_sched)
	if ok and title_modal != null and title_modal.continue_btn != null:
		title_modal.continue_btn.disabled = false
	return ok


func _notification(what: int) -> void:
	if what == NOTIFICATION_APPLICATION_PAUSED or what == NOTIFICATION_APPLICATION_FOCUS_OUT or what == NOTIFICATION_WM_CLOSE_REQUEST:
		_bg_pause_ts = int(Time.get_unix_time_from_system())
		if DisplayServer.get_name() != "headless":
			trigger_commute_autosave()
	elif what == NOTIFICATION_APPLICATION_RESUMED or what == NOTIFICATION_APPLICATION_FOCUS_IN:
		if _bg_pause_ts > 0:
			var elapsed: int = maxi(0, int(Time.get_unix_time_from_system()) - _bg_pause_ts)
			_bg_pause_ts = 0
			if elapsed >= 600 and fairy_modal != null and not is_any_modal_open():
				fairy_modal.open_modal(elapsed)


func _check_and_pop_offline_fairy() -> void:
	if not GameState.has_meta("pending_offline_seconds"):
		return
	var off_sec: int = int(GameState.get_meta("pending_offline_seconds", 0))
	GameState.set_meta("pending_offline_seconds", 0)
	if off_sec >= 600 and fairy_modal != null:
		_close_all_modals()
		fairy_modal.open_modal(off_sec)


func toggle_portrait_mode() -> bool:
	return set_portrait_mode(not portrait_mode)


func set_portrait_mode(enable: bool) -> bool:
	portrait_mode = enable
	var root_win: Window = get_tree().root
	if root_win != null:
		root_win.content_scale_size = Vector2i(720, 1280) if enable else Vector2i(1280, 720)
	if DisplayServer.get_name() != "headless":
		if OS.has_feature("android") or OS.has_feature("ios") or OS.has_feature("mobile"):
			DisplayServer.screen_set_orientation(DisplayServer.SCREEN_PORTRAIT if enable else DisplayServer.SCREEN_SENSOR_LANDSCAPE)
		elif OS.has_feature("web"):
			if ClassDB.class_exists("JavaScriptBridge"):
				var orient_js: String = "portrait" if enable else "landscape"
				JavaScriptBridge.eval("window.__embervaleSetOrientation && window.__embervaleSetOrientation('%s')" % orient_js)
		else:
			var cur_mode: int = DisplayServer.window_get_mode()
			if cur_mode == DisplayServer.WINDOW_MODE_WINDOWED:
				DisplayServer.window_set_size(Vector2i(720, 1280) if enable else Vector2i(1280, 720))
	if camera != null:
		camera.zoom = Vector2(1.55, 1.55) if enable else Vector2(1.75, 1.75)
	if hud != null:
		hud.apply_orientation_layout(enable)
	if dlg_modal != null:
		dlg_modal.apply_orientation_layout(enable)
	if mobile_overlay != null:
		if enable and not mobile_overlay.mobile_enabled:
			mobile_overlay.set_mobile_enabled(true)
		mobile_overlay.apply_orientation_layout(enable)
	_fit_modals_to_viewport()
	EventBus.toast_message.emit(
		"📱 已切换至【竖屏单手掌中通勤模式】(5×2拇指栏+点地自动收菜)" if enable else "🖥️ 已切换至【横屏全景宽阔模式】",
		Color(0.68, 0.98, 0.82)
	)
	return portrait_mode


func _fit_modals_to_viewport() -> void:
	var scale_v: Vector2 = Vector2(0.75, 0.75) if portrait_mode else Vector2.ONE
	var modals: Array = [inv_modal, shop_modal, dlg_modal, cooking_modal, shrine_modal, map_modal, title_modal, summary_modal, fairy_modal]
	for m in modals:
		if m != null and m is Control:
			var ctrl: Control = m
			for ch in ctrl.get_children():
				if ch is CenterContainer:
					var cc: CenterContainer = ch
					if cc.get_child_count() > 0 and cc.get_child(0) is Control:
						var inner: Control = cc.get_child(0)
						inner.pivot_offset = inner.size * 0.5 if inner.size.x > 0 else inner.custom_minimum_size * 0.5
						inner.scale = scale_v
	if journal_panel != null:
		journal_panel.pivot_offset = Vector2(360, 230)
		journal_panel.scale = scale_v
	if popup_panel != null:
		popup_panel.pivot_offset = Vector2(320, 135)
		popup_panel.scale = scale_v


func capture_farm_postcard(save_override_path: String = "") -> String:
	var card_w: int = 720 if portrait_mode else 1280
	var card_h: int = 1280 if portrait_mode else 720
	var footer_h: int = 86
	var out_img: Image = Image.create(card_w, card_h + footer_h, false, Image.FORMAT_RGBA8)
	out_img.fill(Color(0.14, 0.10, 0.06, 1.0))

	if DisplayServer.get_name() != "headless":
		var vp_tex: ViewportTexture = get_viewport().get_texture()
		if vp_tex != null:
			var raw_vp: Image = vp_tex.get_image()
			if raw_vp != null and not raw_vp.is_empty():
				raw_vp.convert(Image.FORMAT_RGBA8)
				if raw_vp.get_width() != card_w or raw_vp.get_height() != card_h:
					raw_vp.resize(card_w, card_h, Image.INTERPOLATE_NEAREST)
				out_img.blit_rect(raw_vp, Rect2i(0, 0, card_w, card_h), Vector2i(0, 0))
	else:
		out_img.fill_rect(Rect2i(8, 8, card_w - 16, card_h - 16), Color(0.24, 0.48, 0.26, 1.0))

	# Stamp warm Stardew walnut-gold postcard frame, 4 farm/island crest icons, perfection bar & scan-to-play QR badge
	var gold_border: Color = Color(0.92, 0.70, 0.30, 1.0)
	var bronze_rule: Color = Color(0.58, 0.40, 0.20, 1.0)
	out_img.fill_rect(Rect2i(0, 0, card_w, 6), gold_border)
	out_img.fill_rect(Rect2i(0, card_h - 4, card_w, 4), gold_border)
	out_img.fill_rect(Rect2i(10, card_h + 6, card_w - 20, 2), bronze_rule)
	out_img.fill_rect(Rect2i(10, card_h + footer_h - 10, card_w - 20, 2), bronze_rule)
	out_img.fill_rect(Rect2i(0, card_h + footer_h - 6, card_w, 6), gold_border)
	out_img.fill_rect(Rect2i(0, 0, 6, card_h + footer_h), gold_border)
	out_img.fill_rect(Rect2i(card_w - 6, 0, 6, card_h + footer_h), gold_border)

	var crest_ids: Array = ["pineapple", "ancient_fruit", "coral_pearl", "artisan_espresso"]
	var crest_x: int = 18
	for cid_raw in crest_ids:
		var cid_s: String = str(cid_raw)
		var icon_tex: Texture2D = AssetRegistry.get_icon(cid_s)
		if icon_tex != null:
			var ic_img: Image = icon_tex.get_image()
			if ic_img != null and not ic_img.is_empty():
				ic_img.convert(Image.FORMAT_RGBA8)
				ic_img.resize(48, 48, Image.INTERPOLATE_NEAREST)
				out_img.fill_rect(Rect2i(crest_x - 2, card_h + 17, 52, 52), Color(0.24, 0.16, 0.10, 1.0))
				out_img.blend_rect(ic_img, Rect2i(0, 0, 48, 48), Vector2i(crest_x, card_h + 19))
				crest_x += 58

	var perf: Dictionary = GameState.compute_valley_perfection()
	var pct_val: int = int(perf.get("percent", 0))
	var bar_x: int = crest_x + 16
	var bar_right_limit: int = card_w - 104
	var bar_w: int = maxi(140, bar_right_limit - bar_x)
	var bar_y: int = card_h + 44
	# 5 milestone golden star pips above perfection bar
	for st_i in range(5):
		var pip_on: bool = (pct_val >= (st_i + 1) * 20)
		var pip_col: Color = Color(1.0, 0.86, 0.30, 1.0) if pip_on else Color(0.36, 0.26, 0.18, 1.0)
		var px_star: int = bar_x + st_i * 26
		out_img.fill_rect(Rect2i(px_star + 4, card_h + 18, 8, 16), pip_col)
		out_img.fill_rect(Rect2i(px_star, card_h + 22, 16, 8), pip_col)
	# Framed Valley Perfection progress bar
	out_img.fill_rect(Rect2i(bar_x - 2, bar_y - 2, bar_w + 4, 24), gold_border)
	out_img.fill_rect(Rect2i(bar_x, bar_y, bar_w, 20), Color(0.09, 0.06, 0.04, 1.0))
	var fill_w: int = clampi(int(round(float(bar_w - 4) * clampf(float(maxi(12, pct_val)) / 100.0, 0.12, 1.0))), 12, bar_w - 4)
	out_img.fill_rect(Rect2i(bar_x + 2, bar_y + 2, fill_w, 16), Color(0.36, 0.86, 0.48, 1.0))
	out_img.fill_rect(Rect2i(bar_x + 2, bar_y + 2, fill_w, 6), Color(0.72, 0.98, 0.68, 1.0))

	# Stamp Mobile Scan-to-Play QR badge in bottom-right of postcard footer
	var qr_img: Image = null
	var qr_ext: String = ProjectSettings.globalize_path("res://../reports/mobile_play_qrcode.png")
	if FileAccess.file_exists(qr_ext):
		qr_img = Image.load_from_file(qr_ext)
	if (qr_img == null or qr_img.is_empty()) and ResourceLoader.exists("res://assets/mobile_play_qrcode.png"):
		var qr_res = ResourceLoader.load("res://assets/mobile_play_qrcode.png")
		if qr_res is Texture2D:
			qr_img = (qr_res as Texture2D).get_image()
	var qr_box_x: int = card_w - 82
	var qr_box_y: int = card_h + 11
	out_img.fill_rect(Rect2i(qr_box_x - 3, qr_box_y - 3, 70, 70), gold_border)
	out_img.fill_rect(Rect2i(qr_box_x, qr_box_y, 64, 64), Color.WHITE)
	if qr_img != null and not qr_img.is_empty():
		qr_img.convert(Image.FORMAT_RGBA8)
		qr_img.resize(60, 60, Image.INTERPOLATE_NEAREST)
		out_img.blit_rect(qr_img, Rect2i(0, 0, 60, 60), Vector2i(qr_box_x + 2, qr_box_y + 2))

	var out_dir: String = ProjectSettings.globalize_path("user://postcards")
	DirAccess.make_dir_recursive_absolute(out_dir)
	var target_path: String = save_override_path if not save_override_path.is_empty() else out_dir.path_join("embervale_postcard_latest.png")
	out_img.save_png(target_path)

	if OS.has_feature("web") and ClassDB.class_exists("JavaScriptBridge"):
		var png_buf: PackedByteArray = out_img.save_png_to_buffer()
		JavaScriptBridge.download_buffer(png_buf, "星露物语_回响山谷_打卡明信片.png", "image/png")

	AudioManager.play_sfx("fish_catch")
	EventBus.toast_message.emit(
		"📸 庄园打卡明信片已保存！(第%d年%s · 完美度%d%%)" % [GameState.year, GameState.get_season_name(), pct_val],
		Color(1.0, 0.90, 0.46)
	)
	return target_path


func _has_interactable_at(grid_pos: Vector2i, world_pt: Vector2) -> bool:
	var zid: String = GameState.current_zone
	if not npc_sched.find_npc_near_pos(zid, world_pt, 36.0).is_empty():
		return true
	if zid == "ranch" and ranch_sys != null:
		for anim in GameState.ranch_animals:
			var ad: Dictionary = anim
			var ap: Vector2 = Vector2(float(ad.get("x", 0.0)), float(ad.get("y", 0.0)))
			if ap.distance_to(world_pt) <= 34.0:
				return true
	if pet_sys != null and pet_sys.is_pet_active_in_zone(zid) and pet_sys.pet_pos.distance_to(world_pt) <= 34.0:
		return true
	var obj: Dictionary = zone_mgr.get_object(zid, grid_pos)
	if not obj.is_empty():
		var otype: String = str(obj.get("type", ""))
		if otype in ["shipping_bin", "machine", "bed", "tv", "shop_counter", "echo_shrine", "quest_board", "forage", "ladder_up", "ladder_down", "elevator", "greenhouse_door", "festival_judge", "kitchen_stove", "ranch_counter", "feed_trough", "ranch_sign", "pet_bowl", "fish_pond", "carpenter_desk", "obelisk", "golden_clock", "island_ferry"]:
			return true
	if zid in ["farm", "greenhouse", "coral_island"]:
		var ft: Dictionary = farm_sys.get_farm_tile(zone_mgr, grid_pos, zid)
		var crop: Dictionary = ft.get("crop", {})
		if not crop.is_empty() and bool(crop.get("mature", false)):
			return true
	return false


func _has_tool_target_at(grid_pos: Vector2i) -> bool:
	var zid: String = GameState.current_zone
	var obj: Dictionary = zone_mgr.get_object(zid, grid_pos)
	if not obj.is_empty():
		var otype: String = str(obj.get("type", ""))
		if otype in ["tree", "palm_tree", "stump", "hardwood_stump", "rock", "mine_rock", "weed"]:
			return true
	if zone_mgr.is_water_tile(zid, grid_pos):
		return true
	if zid in ["farm", "greenhouse", "coral_island"]:
		var ft: Dictionary = farm_sys.get_farm_tile(zone_mgr, grid_pos, zid)
		if bool(ft.get("tilled", false)):
			return true
	return false


func execute_smart_tap_on_tile(grid_pos: Vector2i, world_pt: Vector2) -> String:
	player.face_toward_grid(grid_pos)
	player.target_grid = grid_pos
	if pet_sys != null and pet_sys.is_pet_active_in_zone(GameState.current_zone) and pet_sys.pet_pos.distance_to(world_pt) <= 34.0:
		if pet_sys.try_pet_companion(world_pt):
			return "pet"
	if _has_interactable_at(grid_pos, world_pt):
		player.interact(zone_mgr, farm_sys, artisan_sys, npc_sched, world_pt)
		return "interact"
	player.use_primary(zone_mgr, farm_sys, artisan_sys, mine_sys)
	return "use_primary"


func handle_world_tap_world(world_pt: Vector2) -> String:
	if is_any_modal_open():
		return "locked"
	var tap_grid: Vector2i = Vector2i(int(floor(world_pt.x / ZoneManager.TILE_SIZE)), int(floor(world_pt.y / ZoneManager.TILE_SIZE)))
	var pg: Vector2i = player.get_grid()
	var cheb: int = maxi(absi(tap_grid.x - pg.x), absi(tap_grid.y - pg.y))
	if cheb <= 1:
		player.auto_walk_active = false
		return execute_smart_tap_on_tile(tap_grid, world_pt)
	var should_act: bool = _has_interactable_at(tap_grid, world_pt) or _has_tool_target_at(tap_grid)
	player.set_tap_walk_target(world_pt, tap_grid, should_act)
	return "walk"


func _on_zone_changed(new_zone: String) -> void:
	zone_mgr.sync_farm_wonders()
	if renderer != null:
		renderer.floating_texts.clear()
		renderer.burst_particles.clear()
	if new_zone == "mine":
		mine_sys.populate_floor(zone_mgr, GameState.mine_current_floor)
	elif new_zone == "secret_woods":
		mine_sys.populate_secret_woods(zone_mgr)
	elif new_zone == "town":
		GameState.advance_tutorial(5)
	if pet_sys != null:
		pet_sys.sync_pet_near_player(player.world_pos)
	var sz: Vector2i = zone_mgr.get_zone_size(new_zone)
	camera.limit_left = 0
	camera.limit_top = 0
	camera.limit_right = sz.x * ZoneManager.TILE_SIZE
	camera.limit_bottom = sz.y * ZoneManager.TILE_SIZE
	camera.position = player.world_pos
	if not _skip_ambient:
		AudioManager.sync_bgm_for_context(new_zone, GameState.get_season())
	_update_day_tint()


func _on_sleep_requested() -> void:
	if GameState.fainted_last_night:
		execute_sleep_overnight()
		return
	_show_popup("🌙 结束今天并上床休息吗？\n（出货箱物品将在今夜结算金币，次日清晨恢复全满体力）", [
		{"text": "睡觉到明早", "cb": func(): popup_panel.visible = false; execute_sleep_overnight()},
		{"text": "再逛一会儿", "cb": func(): _close_popup()},
	])


func execute_sleep_overnight() -> void:
	GameState.time_paused = true
	if GameState.current_zone != "farmhouse":
		GameState.current_zone = "farmhouse"
		GameState.player_grid = Vector2i(3, 4)
		player.sync_pos_from_grid()
		_on_zone_changed("farmhouse")

	var summary: Dictionary = GameState.settle_overnight_shipping()
	# Advance machines remaining overnight hours (~6 hours sleep)
	artisan_sys.advance_hours(zone_mgr, 6.0)
	GameState.advance_to_next_morning()
	farm_sys.process_overnight(zone_mgr)
	if ranch_sys != null:
		ranch_sys.process_overnight(zone_mgr)
	if pet_sys != null:
		pet_sys.process_overnight(zone_mgr)
	_perform_spouse_morning_chore()
	zone_mgr.refresh_daily_forage()
	npc_sched.update_schedules_for_hour(GameState.hour)
	if not _skip_ambient:
		AudioManager.sync_bgm_for_context(GameState.current_zone, GameState.get_season())
	hud.refresh()
	summary_modal.show_summary(summary)


func _perform_spouse_morning_chore() -> void:
	if GameState.spouse_id.is_empty():
		return
	var sname: String = str(DataRegistry.get_npc(GameState.spouse_id).get("name", GameState.spouse_id))
	var farm: Dictionary = zone_mgr.get_zone("farm")
	var farm_tiles: Dictionary = farm.get("farm_tiles", {})
	var watered_cnt: int = 0
	for k in farm_tiles.keys():
		var ft: Dictionary = farm_tiles[k]
		if bool(ft.get("tilled", false)) and not bool(ft.get("watered", false)):
			ft["watered"] = true
			farm_tiles[k] = ft
			watered_cnt += 1
	GameState.trough_hay = mini(30, GameState.trough_hay + 3)
	GameState.add_item("dish_omelet", 1, 0)
	EventBus.toast_message.emit(
		"💕 早安！伴侣【%s】已帮你浇灌 %d 块农田、添好牧草，并准备了热腾腾的爱心【田园煎蛋卷】！" % [sname, watered_cnt],
		Color(1.0, 0.78, 0.88)
	)


func _close_popup() -> void:
	popup_panel.visible = false
	GameState.time_paused = false


func _upgrade_house_from_popup() -> void:
	var r: Dictionary = GameState.upgrade_house()
	_close_popup()
	zone_mgr.sync_farm_wonders()
	hud.refresh()
	if bool(r.get("ok", false)):
		EventBus.toast_message.emit("🏡 扩建完成！农舍已升至【%s】！" % str(r.get("title", "")), Color(1.0, 0.88, 0.42))
	else:
		EventBus.toast_message.emit(str(r.get("msg", "")), Color(1.0, 0.58, 0.45))


func _build_obelisk_from_popup() -> void:
	var r: Dictionary = GameState.build_obelisk()
	_close_popup()
	zone_mgr.sync_farm_wonders()
	if bool(r.get("ok", false)):
		EventBus.toast_message.emit("🔮 奇观落成！【回响方尖传送塔】已矗立在农场北侧，随时按 E 零耗时瞬移！", Color(0.68, 0.92, 1.0))
	else:
		EventBus.toast_message.emit(str(r.get("msg", "")), Color(1.0, 0.58, 0.45))


func _build_clock_from_popup() -> void:
	var r: Dictionary = GameState.build_golden_clock()
	_close_popup()
	zone_mgr.sync_farm_wonders()
	if bool(r.get("ok", false)):
		EventBus.toast_message.emit("👑 终局奇观落成！【黄金丰饶钟】闪耀农场：全田块地力永恒满分，所有出货享 +25% 溢价！", Color(1.0, 0.88, 0.32))
	else:
		EventBus.toast_message.emit(str(r.get("msg", "")), Color(1.0, 0.58, 0.45))


func _on_carpenter_requested() -> void:
	var w_cnt: int = GameState.count_item("wood")
	var s_cnt: int = GameState.count_item("stone")
	var hw_cnt: int = GameState.count_item("hardwood")
	var ib_cnt: int = GameState.count_item("iron_bar")
	var gb_cnt: int = GameState.count_item("gold_bar")
	var ec_cnt: int = GameState.count_item("echo_crystal")
	var txt: String = "📐 苏晚星象营造与传奇奇观台\n当前农舍：Lv.%d · 金币：%dG | 木:%d 石:%d 千年铁木:%d 铁锭:%d 金锭:%d 水晶:%d\n（扩建2阶婚房可解锁求婚同居与150体力上限；奇观建成后将永久矗立在农场院中！）" % [
		GameState.house_tier, GameState.gold, w_cnt, s_cnt, hw_cnt, ib_cnt, gb_cnt, ec_cnt
	]
	var btns: Array = []
	if GameState.house_tier == 1:
		btns.append({"text": "🏡 扩建二阶婚房 (1500G+木40+石25)", "cb": func(): _upgrade_house_from_popup()})
	elif GameState.house_tier == 2:
		btns.append({"text": "🏰 升三阶庄园 (4000G+铁木10+铁锭3)", "cb": func(): _upgrade_house_from_popup()})
	if not GameState.obelisk_built:
		btns.append({"text": "🔮 建方尖传送塔 (3500G+水晶3+铁木10)", "cb": func(): _build_obelisk_from_popup()})
	if not GameState.golden_clock_built:
		btns.append({"text": "👑 建黄金丰饶钟 (15000G+金锭5+水晶5)", "cb": func(): _build_clock_from_popup()})
	btns.append({"text": "离开", "cb": func(): _close_popup()})
	_show_popup(txt, btns)


func _obelisk_warp(zid: String, sp: Vector2i, mine_floor: int = 0) -> void:
	_close_popup()
	if zid == "mine" and mine_floor > 0:
		zone_mgr.enter_mine_floor(mine_floor)
	player.warp_to_zone(zid, sp)
	AudioManager.play_sfx("fish_catch")
	EventBus.toast_message.emit("🔮 星芒闪耀！已通过方尖传送塔瞬间抵达目的地！", Color(0.68, 0.94, 1.0))


func _on_obelisk_requested() -> void:
	var best_f: int = maxi(1, GameState.mine_max_floor)
	var btns: Array = [
		{"text": "🏖️ 星露珊瑚群岛", "cb": func(): _obelisk_warp("coral_island", Vector2i(14, 5))},
		{"text": "🌲 迷雾回响秘林", "cb": func(): _obelisk_warp("secret_woods", Vector2i(12, 3))},
		{"text": "⛏️ 矿洞第 %d 层" % best_f, "cb": func(): _obelisk_warp("mine", Vector2i(11, 14), best_f)},
		{"text": "🌊 低语湖垂钓栈桥", "cb": func(): _obelisk_warp("lake", Vector2i(13, 8))},
		{"text": "⛲ 回响镇中心广场", "cb": func(): _obelisk_warp("town", Vector2i(16, 11))},
		{"text": "🐄 阳光牧场", "cb": func(): _obelisk_warp("ranch", Vector2i(14, 11))},
		{"text": "取消", "cb": func(): _close_popup()},
	]
	_show_popup("🔮 回响方尖传送塔（空间零耗时折跃）\n请选择你要瞬间传送前往的山谷区域：", btns)


func _switch_pet_from_popup(kind: String) -> void:
	if pet_sys != null:
		pet_sys.switch_pet_kind(kind)
	_close_popup()
	EventBus.toast_message.emit("🐾 已切换随行萌宠伙伴为【%s】！" % str(GameState.pet_data.get("name", "")), Color(1.0, 0.84, 0.62))


func _on_pet_bowl_requested() -> void:
	var pname: String = str(GameState.pet_data.get("name", "橘猫团子"))
	var aff: int = int(GameState.pet_data.get("affection", 80))
	var txt: String = "🐾 农场萌宠温馨小窝\n当前随行伙伴：【%s】（亲密度 %d）\n（萌宠会在户外紧跟你的脚步、自动捡取附近掉落物，还会在农场与秘林刨出珍稀荧光松露！）" % [pname, aff]
	var btns: Array = [
		{"text": "🐱 唤出橘猫团子", "cb": func(): _switch_pet_from_popup("cat")},
		{"text": "🐶 唤出柴犬旺财", "cb": func(): _switch_pet_from_popup("dog")},
		{"text": "摸摸头离开", "cb": func(): _close_popup()},
	]
	_show_popup(txt, btns)


func _adopt_from_popup(kind: String) -> void:
	var r: Dictionary = ranch_sys.adopt_animal(kind)
	popup_panel.visible = false
	GameState.time_paused = false
	var msg: String = ("🎉 欢迎新成员：%s「%s」！" % [str(r.get("title", "")), str(r.get("name", ""))]) if bool(r.get("ok", false)) else str(r.get("msg", ""))
	EventBus.toast_message.emit(msg, Color(0.65, 0.98, 0.72))


func _buy_hay_from_popup() -> void:
	if GameState.gold >= 75 and GameState.trough_hay < 30:
		GameState.gold -= 75
		GameState.trough_hay = mini(30, GameState.trough_hay + 5)
		AudioManager.play_sfx("coin")
		EventBus.player_stats_changed.emit()
		EventBus.toast_message.emit("🌾 已添入 5 份清香牧草（饲草槽 %d/30）！" % GameState.trough_hay, Color(0.88, 0.96, 0.58))
	else:
		EventBus.toast_message.emit("金币不足或饲草槽已满！", Color(1.0, 0.58, 0.45))
	popup_panel.visible = false
	GameState.time_paused = false


func _on_ranch_shop_requested() -> void:
	var added_hay: int = ranch_sys.refill_trough_from_inventory() if ranch_sys != null else 0
	var hay_note: String = ("（已自动把背包里的 %d 份牧草添入饲草槽！）\n" % added_hay) if added_hay > 0 else ""
	var txt: String = "🐄 阳光牧场领养与饲草站\n%s当前牧场动物：%d/12 只 · 饲草槽余量：%d/30 份 · 金币：%dG\n（晴朗春夏秋动物可免费吃牧场青草，雨雪天消耗饲草槽牧草，次日清晨产出鲜蛋/牛奶/羊毛）" % [
		hay_note, GameState.ranch_animals.size(), GameState.trough_hay, GameState.gold
	]
	var btns: Array = [
		{"text": "🐔 领养小母鸡 (300G)", "cb": func(): _adopt_from_popup("chicken")},
		{"text": "🐄 领养花斑奶牛 (650G)", "cb": func(): _adopt_from_popup("cow")},
		{"text": "🐑 领养云朵绵羊 (800G)", "cb": func(): _adopt_from_popup("sheep")},
		{"text": "🌾 购5份牧草入槽 (75G)", "cb": func(): _buy_hay_from_popup()},
		{"text": "离开", "cb": func(): popup_panel.visible = false; GameState.time_paused = false},
	]
	_show_popup(txt, btns)


func _on_tv_requested() -> void:
	var w_desc: String = str(GameState.WEATHER_NAMES.get(GameState.tomorrow_weather, "晴朗"))
	var tip: String = "明日预报为【%s】。记得用 Tab 查看农田生态共鸣连线！" % w_desc
	if GameState.tomorrow_weather in ["rain", "storm"]:
		tip = "明日将迎来【%s】！雨水会自动浇灌所有耕地，非常适宜去矿洞或湖畔垂钓。" % w_desc
	_show_popup("📺 山谷气象与农事频道\n\n" + tip, [
		{"text": "知道了", "cb": func(): popup_panel.visible = false; GameState.time_paused = false}
	])


func _on_elevator_requested() -> void:
	var btns: Array = []
	var max_f: int = GameState.mine_max_floor
	var floors: Array = [1]
	var f_step: int = 5
	while f_step <= max_f:
		floors.append(f_step)
		f_step += 5
	for fl in floors:
		var target_f: int = fl
		btns.append({"text": "第 %d 层" % target_f, "cb": func():
			popup_panel.visible = false
			GameState.time_paused = false
			zone_mgr.enter_mine_floor(target_f)
			player.warp_to_zone("mine", Vector2i(11, 14))
		})
	btns.append({"text": "取消", "cb": func(): popup_panel.visible = false; GameState.time_paused = false})
	_show_popup("🛗 矿洞升降电梯（已解锁最高第 %d 层）" % max_f, btns)


func _on_greenhouse_door_requested() -> void:
	if GameState.greenhouse_unlocked or GameState.greenhouse_blessing:
		player.warp_to_zone("greenhouse", Vector2i(6, 9))
		return
	var have_w: int = GameState.count_item("wood")
	var have_s: int = GameState.count_item("stone")
	var txt: String = "🌿 四季生态温室尚未修复！\n修复后可无视季节限制种植任何作物且永不枯萎。\n\n修复需求：木材 25 (%d/25) · 石料 15 (%d/15) · 金币 400G (%d/400)" % [have_w, have_s, GameState.gold]
	var can_fix: bool = have_w >= 25 and have_s >= 15 and GameState.gold >= 400
	var btns: Array = []
	if can_fix:
		btns.append({"text": "立即修复并进入", "cb": func():
			GameState.remove_item("wood", 25)
			GameState.remove_item("stone", 15)
			GameState.gold -= 400
			GameState.greenhouse_unlocked = true
			popup_panel.visible = false
			GameState.time_paused = false
			AudioManager.play_sfx("harvest")
			EventBus.player_stats_changed.emit()
			EventBus.toast_message.emit("🌿 四季生态温室修复完成！", Color(0.55, 0.98, 0.72))
			player.warp_to_zone("greenhouse", Vector2i(6, 9))
		})
	btns.append({"text": "暂不修复", "cb": func(): popup_panel.visible = false; GameState.time_paused = false})
	_show_popup(txt, btns)


func _on_festival_judge_requested() -> void:
	var cur_s: int = GameState.year * 4 + GameState.season_idx
	if GameState.festival_judged_season == cur_s:
		_show_popup("🏆 本季丰收品鉴评比已完成！下个季节再来展示你的新作物吧。", [
			{"text": "确定", "cb": func(): popup_panel.visible = false; GameState.time_paused = false}
		])
		return
	var slot: Dictionary = GameState.get_selected_slot()
	if slot.is_empty():
		_show_popup("🎉 山谷丰收品鉴台\n请在底部快捷栏选中一件自豪的【作物 / 工匠品 / 渔获】后按 E 参加评比！", [
			{"text": "知道了", "cb": func(): popup_panel.visible = false; GameState.time_paused = false}
		])
		return
	var iid: String = str(slot.get("id", ""))
	var def: Dictionary = DataRegistry.get_item(iid)
	var cat: String = str(def.get("category", ""))
	if not (cat in ["crop", "artisan", "fish"]):
		_show_popup("请选中农作物、工匠佳酿或鲜鱼参加评比！", [
			{"text": "确定", "cb": func(): popup_panel.visible = false; GameState.time_paused = false}
		])
		return
	var res: Dictionary = judge_festival_entry(iid, int(slot.get("quality", 0)))
	_show_popup("🏆 丰收品鉴结果：%s\n\n评语：%s\n奖励：+%dG，全镇村民好感 +%d！" % [
		str(res.get("rank", "")), str(res.get("comment", "")), int(res.get("gold", 0)), int(res.get("friendship", 0))
	], [
		{"text": "太棒了！", "cb": func(): popup_panel.visible = false; GameState.time_paused = false}
	])


func judge_festival_entry(item_id: String, quality: int) -> Dictionary:
	var val: int = GameState.get_sell_price(item_id, quality)
	var cur_s: int = GameState.year * 4 + GameState.season_idx
	GameState.festival_judged_season = cur_s
	var rank: String = "鼓励优胜奖"
	var reward_g: int = 100
	var reward_f: int = 20
	var comment: String = "色泽新鲜，大家都很看好你的农场前景！"
	if val >= 200 or (val >= 120 and quality >= 1):
		rank = "👑 金穗特等奖"
		reward_g = 500
		reward_f = 80
		comment = "绝世珍品！梅婆婆与林夏赞叹这正是生态共鸣的巅峰之作！"
	elif val >= 85:
		rank = "🥈 银穗佳作奖"
		reward_g = 250
		reward_f = 40
		comment = "品质上乘，味道醇厚，收获了镇民们的热烈掌声！"
	GameState.gold += reward_g
	for nid in GameState.npc_friendship.keys():
		GameState.add_friendship(str(nid), reward_f)
	AudioManager.play_sfx("fish_catch")
	EventBus.player_stats_changed.emit()
	return {"rank": rank, "gold": reward_g, "friendship": reward_f, "comment": comment}


func _show_popup(title_txt: String, buttons: Array) -> void:
	_close_all_modals()
	popup_title.text = title_txt
	for c in popup_btns.get_children():
		c.queue_free()
	for b in buttons:
		var bd: Dictionary = b
		var btn: Button = Button.new()
		btn.text = str(bd.get("text", "确定"))
		btn.custom_minimum_size = Vector2(128, 44)
		var cb: Callable = bd["cb"]
		btn.pressed.connect(cb)
		popup_btns.add_child(btn)
	popup_panel.visible = true
	GameState.time_paused = true


func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo:
		var ke: InputEventKey = event
		if ke.keycode == KEY_ESCAPE:
			if is_any_modal_open() and not fish_modal.active and not summary_modal.visible:
				_close_all_modals()
			return
		if ke.keycode == KEY_F9:
			hot_reload_all()
			return
		if ke.keycode == KEY_F10:
			toggle_audio_mute()
			return
		if ke.keycode == KEY_F11:
			toggle_fullscreen()
			return
		if ke.keycode == KEY_F5:
			SaveManager.save_game(1, zone_mgr, npc_sched)
			return
		if ke.keycode == KEY_F8:
			if SaveManager.load_game(1, zone_mgr, npc_sched):
				player.sync_pos_from_grid()
			return
		if ke.keycode == KEY_F6 and not is_any_modal_open():
			_advance_one_hour()
			EventBus.toast_message.emit("⏩ 时间快进 1 小时 -> %s" % GameState.get_time_string(), Color(0.85, 0.9, 1.0))
			return
		if ke.keycode == KEY_TAB and not fish_modal.active:
			_toggle_lens()
			return
		if ke.keycode == KEY_B or ke.keycode == KEY_I:
			if inv_modal.visible:
				inv_modal.visible = false
				GameState.time_paused = false
			elif not is_any_modal_open():
				inv_modal.open_modal()
			return
		if ke.keycode == KEY_M:
			if not fish_modal.active and not summary_modal.visible:
				_toggle_journal()
			return
		if ke.keycode == KEY_N:
			if not fish_modal.active and not summary_modal.visible:
				if map_modal.visible:
					map_modal.visible = false
					GameState.time_paused = false
				else:
					_close_all_modals()
					map_modal.open_map()
			return

		if not is_any_modal_open():
			var num_keys: Array = [KEY_1, KEY_2, KEY_3, KEY_4, KEY_5, KEY_6, KEY_7, KEY_8, KEY_9, KEY_0]
			var idx: int = num_keys.find(ke.keycode)
			if idx >= 0:
				GameState.selected_hotbar = idx
				hud.refresh()
				return
			if ke.keycode == KEY_SPACE:
				player.use_primary(zone_mgr, farm_sys, artisan_sys, mine_sys)
			elif ke.keycode == KEY_E:
				player.interact(zone_mgr, farm_sys, artisan_sys, npc_sched, get_global_mouse_position())

	elif event is InputEventScreenTouch and event.pressed and not is_any_modal_open():
		var st_ev: InputEventScreenTouch = event
		if mobile_overlay != null and mobile_overlay.is_point_on_touch_controls(st_ev.position):
			return
		var tap_w: Vector2 = get_canvas_transform().affine_inverse() * st_ev.position
		handle_world_tap_world(tap_w)

	elif event is InputEventMouseButton and event.pressed and not is_any_modal_open():
		var mb: InputEventMouseButton = event
		if mb.button_index == MOUSE_BUTTON_WHEEL_UP:
			GameState.selected_hotbar = (GameState.selected_hotbar + GameState.HOTBAR_SIZE - 1) % GameState.HOTBAR_SIZE
			hud.refresh()
		elif mb.button_index == MOUSE_BUTTON_WHEEL_DOWN:
			GameState.selected_hotbar = (GameState.selected_hotbar + 1) % GameState.HOTBAR_SIZE
			hud.refresh()
		elif mb.button_index == MOUSE_BUTTON_LEFT:
			if mobile_overlay != null and mobile_overlay.mobile_enabled:
				if not mobile_overlay.is_point_on_touch_controls(mb.position):
					handle_world_tap_world(get_global_mouse_position())
			else:
				player.use_primary(zone_mgr, farm_sys, artisan_sys, mine_sys)
		elif mb.button_index == MOUSE_BUTTON_RIGHT:
			player.interact(zone_mgr, farm_sys, artisan_sys, npc_sched, get_global_mouse_position())

	elif event is InputEventJoypadButton and event.pressed:
		var jb: InputEventJoypadButton = event
		handle_joypad_button(jb.button_index)


func handle_joypad_button(btn_idx: int) -> void:
	if btn_idx == JOY_BUTTON_B:
		if is_any_modal_open() and not fish_modal.active and not summary_modal.visible:
			_close_all_modals()
		return
	if btn_idx == JOY_BUTTON_Y:
		if inv_modal.visible:
			inv_modal.visible = false
			GameState.time_paused = false
		elif not is_any_modal_open():
			inv_modal.open_modal()
		return
	if btn_idx == JOY_BUTTON_BACK:
		if not fish_modal.active and not summary_modal.visible:
			if map_modal.visible:
				map_modal.visible = false
				GameState.time_paused = false
			else:
				_close_all_modals()
				map_modal.open_map()
		return
	if btn_idx == JOY_BUTTON_START:
		if not fish_modal.active and not summary_modal.visible:
			_toggle_journal()
		return
	if is_any_modal_open():
		return
	if btn_idx == JOY_BUTTON_LEFT_SHOULDER:
		GameState.selected_hotbar = (GameState.selected_hotbar + GameState.HOTBAR_SIZE - 1) % GameState.HOTBAR_SIZE
		hud.refresh()
	elif btn_idx == JOY_BUTTON_RIGHT_SHOULDER:
		GameState.selected_hotbar = (GameState.selected_hotbar + 1) % GameState.HOTBAR_SIZE
		hud.refresh()
	elif btn_idx == JOY_BUTTON_X:
		player.use_primary(zone_mgr, farm_sys, artisan_sys, mine_sys)
	elif btn_idx == JOY_BUTTON_A:
		player.interact(zone_mgr, farm_sys, artisan_sys, npc_sched, player.world_pos + player.facing_vec * 28.0)


func _advance_one_hour() -> void:
	for _i in range(6):
		var crossed: bool = GameState.advance_time_minutes(10)
		if crossed:
			artisan_sys.advance_hours(zone_mgr, 1.0)
			GameState.tick_buff_hours(1.0)
			npc_sched.update_schedules_for_hour(GameState.hour)
	_update_day_tint()


func _process(delta: float) -> void:
	var locked: bool = is_any_modal_open()
	if mobile_overlay != null:
		mobile_overlay.visible = mobile_overlay.mobile_enabled and (not locked or fish_modal.active)
		if fish_modal != null:
			fish_modal.external_lift_held = mobile_overlay.is_use_held
	if not locked and not GameState.time_paused:
		_clock_accum += delta
		if _clock_accum >= 0.75:
			_clock_accum -= 0.75
			var crossed: bool = GameState.advance_time_minutes(10)
			if crossed:
				artisan_sys.advance_hours(zone_mgr, 1.0)
				GameState.tick_buff_hours(1.0)
				npc_sched.update_schedules_for_hour(GameState.hour)
				_update_day_tint()
				if GameState.hour >= 26:
					GameState.fainted_last_night = true
					WorldMemory.record_fact("fainted_exhaustion", "深夜两点仍未入眠，在山谷力竭晕倒", "linxia")
					EventBus.toast_message.emit("🌙 深夜两点体力耗尽晕倒了……", Color(1.0, 0.5, 0.45))
					execute_sleep_overnight()

	var mv: Vector2 = Vector2.ZERO
	if not locked:
		if Input.is_key_pressed(KEY_W) or Input.is_key_pressed(KEY_UP) or Input.is_joy_button_pressed(0, JOY_BUTTON_DPAD_UP):
			mv.y -= 1.0
		if Input.is_key_pressed(KEY_S) or Input.is_key_pressed(KEY_DOWN) or Input.is_joy_button_pressed(0, JOY_BUTTON_DPAD_DOWN):
			mv.y += 1.0
		if Input.is_key_pressed(KEY_A) or Input.is_key_pressed(KEY_LEFT) or Input.is_joy_button_pressed(0, JOY_BUTTON_DPAD_LEFT):
			mv.x -= 1.0
		if Input.is_key_pressed(KEY_D) or Input.is_key_pressed(KEY_RIGHT) or Input.is_joy_button_pressed(0, JOY_BUTTON_DPAD_RIGHT):
			mv.x += 1.0
		var jx: float = Input.get_joy_axis(0, JOY_AXIS_LEFT_X)
		var jy: float = Input.get_joy_axis(0, JOY_AXIS_LEFT_Y)
		if absf(jx) > 0.22 or absf(jy) > 0.22:
			mv = Vector2(jx, jy)
		if mobile_overlay != null and mobile_overlay.mobile_enabled and mobile_overlay.move_vector.length() > 0.05:
			mv = mobile_overlay.move_vector

	var sprint: bool = Input.is_key_pressed(KEY_SHIFT) or Input.is_joy_button_pressed(0, JOY_BUTTON_LEFT_STICK) or Input.get_joy_axis(0, JOY_AXIS_TRIGGER_RIGHT) > 0.4
	if mobile_overlay != null and mobile_overlay.mobile_enabled and mobile_overlay.joy_sprinting:
		sprint = true
	var mpos: Vector2 = get_global_mouse_position()
	player.tick(delta, zone_mgr, mv, sprint, mpos, locked)
	if not locked and player.arrived_smart_act_pending:
		player.arrived_smart_act_pending = false
		var act_w: Vector2 = Vector2(player.auto_walk_grid.x * 32 + 16, player.auto_walk_grid.y * 32 + 16)
		execute_smart_tap_on_tile(player.auto_walk_grid, act_w)
	if not locked:
		npc_sched.tick(delta)
		if ranch_sys != null:
			ranch_sys.tick(delta)
		if pet_sys != null:
			pet_sys.tick(delta, zone_mgr, player.world_pos)
		mine_sys.tick(delta, zone_mgr, player.world_pos, func(dmg: float): player.take_damage(dmg))

	camera.position = camera.position.lerp(player.world_pos, minf(1.0, delta * 12.0))
	if player.camera_shake > 0.01:
		var mag: float = player.camera_shake * 5.0
		camera.offset = Vector2(randf_range(-mag, mag), randf_range(-mag, mag))
	else:
		camera.offset = Vector2.ZERO
	if hud != null:
		hud.set_inspector_text(get_tile_inspection_text(player.target_grid))
	renderer.tick_visuals(delta)


func get_tile_inspection_text(grid_pos: Vector2i) -> String:
	var zid: String = GameState.current_zone
	var lines: Array = []
	var obj: Dictionary = zone_mgr.get_object(zid, grid_pos)
	if not obj.is_empty():
		var otype: String = str(obj.get("type", ""))
		if otype == "machine":
			var iid: String = str(obj.get("item_id", "machine_" + str(obj.get("machine_type", ""))))
			var mname: String = str(DataRegistry.get_item(iid).get("name", str(obj.get("machine_type", "设备"))))
			var proc: Dictionary = obj.get("processing", {})
			if proc.is_empty():
				var stored: Array = obj.get("stored", [])
				if str(obj.get("machine_type", "")) == "chest":
					lines.append("📦 %s（已存 %d 格）" % [mname, stored.size()])
				else:
					lines.append("⚙️ %s（空闲：手持原料按 E 投入）" % mname)
			else:
				var rem: float = float(proc.get("remaining_hours", 0.0))
				var out_nm: String = str(DataRegistry.get_item(str(proc.get("output_id", ""))).get("name", "成品"))
				if rem <= 0.0:
					lines.append("✨ %s：%s 已完成！按 E 收取" % [mname, out_nm])
				else:
					lines.append("⏳ %s：正在制作 %s（剩 %.0f 小时）" % [mname, out_nm, ceilf(rem)])
		elif otype == "mine_rock":
			var okind: String = str(obj.get("ore_kind", "rock"))
			var rnames: Dictionary = {"rock": "岩石", "ore_copper": "铜矿脉", "ore_iron": "铁矿脉", "ore_gold": "金矿脉", "ore_crystal": "回响水晶矿"}
			lines.append("🪨 %s（剩余耐久 %d）" % [str(rnames.get(okind, "矿岩")), int(obj.get("hp", 2))])
		elif otype == "tree":
			lines.append("🌲 松橡树（斧头耐久 %d）" % int(obj.get("hp", 4)))
		elif otype == "hardwood_stump":
			lines.append("🪵 千年铁木古桩（斧头耐久 %d · 掉落千年铁木）" % int(obj.get("hp", 3)))
		elif otype == "fish_pond":
			var pcnt: int = int(GameState.fish_pond.get("count", 0))
			if pcnt > 0:
				var fnm: String = str(DataRegistry.get_item(str(GameState.fish_pond.get("fish_id", ""))).get("name", "鱼"))
				lines.append("🐟 活水鱼塘：繁育【%s】%d/5 条（每日产晶莹鱼籽）" % [fnm, pcnt])
			else:
				lines.append("🐟 活水鱼塘（手持鲜鱼按 E 放养繁育）")
		elif not str(obj.get("label", "")).is_empty():
			lines.append("🔎 %s（按 E 交互）" % str(obj.get("label", "")))

	if zid in ["farm", "greenhouse", "coral_island"]:
		var ft: Dictionary = farm_sys.get_farm_tile(zone_mgr, grid_pos, zid)
		if bool(ft.get("tilled", false)):
			var wet_txt: String = "💧已浇水" if bool(ft.get("watered", false)) else "🏜️待浇水"
			var vit: int = int(ft.get("soil_vitality", 80.0))
			var crop: Dictionary = ft.get("crop", {})
			if crop.is_empty():
				lines.append("🌱 耕地（%s · 地力 %d）" % [wet_txt, vit])
			else:
				var cid: String = str(crop.get("id", ""))
				var cdef: Dictionary = DataRegistry.get_crop(cid)
				var cname: String = str(cdef.get("name", cid))
				var mature: bool = bool(crop.get("mature", false))
				var prog_txt: String = "✅已成熟(按E收获)" if mature else ("生长 %.1f/%d天" % [float(crop.get("growth_days", 0.0)), int(cdef.get("days_to_grow", 4))])
				var eco: Dictionary = farm_sys.evaluate_tile_ecology(zone_mgr, grid_pos, zid)
				var syns: Array = eco.get("active_synergies", [])
				var syn_str: String = (" · ✨" + ",".join(syns)) if syns.size() > 0 else ""
				lines.append("🌾 %s：%s\n%s · 地力 %d%s" % [cname, prog_txt, wet_txt, vit, syn_str])

	return "\n".join(lines)


func _update_day_tint() -> void:
	if day_modulate == null:
		return
	var zid: String = GameState.current_zone
	if zid == "mine":
		day_modulate.color = Color(0.68, 0.68, 0.78)
		return
	if zid == "farmhouse" or zid == "greenhouse":
		day_modulate.color = Color(1.0, 0.97, 0.93)
		return
	if zid == "secret_woods":
		day_modulate.color = Color(0.88, 0.98, 0.93)
		return
	var h: float = float(GameState.hour) + float(GameState.minute) / 60.0
	if h < 7.5:
		day_modulate.color = Color(0.92, 0.94, 1.0)
	elif h < 16.5:
		day_modulate.color = Color(0.86, 0.90, 0.98) if GameState.weather in ["rain", "storm"] else Color.WHITE
	elif h < 19.5:
		day_modulate.color = Color(1.0, 0.84, 0.68)
	else:
		day_modulate.color = Color(0.48, 0.54, 0.74)
