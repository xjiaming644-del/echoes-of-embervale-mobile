class_name WorldRenderer
extends Node2D

var zone_mgr: ZoneManager = null
var farm_sys: FarmingEcologySystem = null
var npc_sched: NPCScheduler = null
var mine_sys: MineCombatSystem = null
var ranch_sys: RanchSystem = null
var pet_sys: PetFishPondSystem = null
var player: PlayerController = null

var ecology_lens_active: bool = false
var floating_texts: Array = []
var burst_particles: Array = []
var _time_accum: float = 0.0
var _rain_drops: Array = []
var _ambient_motes: Array = []
var _last_action_timer: float = 0.0
var _footstep_cd: float = 0.0


func _ready() -> void:
	for _i in range(65):
		_rain_drops.append(Vector2(randf() * 1280.0, randf() * 720.0))
	for i in range(22):
		_ambient_motes.append({
			"seed": float(i) * 1.73,
			"ox": randf_range(-380.0, 380.0),
			"oy": randf_range(-240.0, 240.0),
			"kind": "butterfly" if i % 4 == 0 else "mote",
			"tint": i % 3,
		})


func add_floating_text(wpos: Vector2, text: String, col: Color) -> void:
	floating_texts.append({"pos": wpos, "text": text, "color": col, "life": 1.4, "max_life": 1.4})


func spawn_burst(wpos: Vector2, kind: String) -> void:
	var base_col: Color = Color(0.76, 0.54, 0.34)
	if kind == "can":
		base_col = Color(0.48, 0.86, 1.0)
	elif kind == "axe":
		base_col = Color(0.84, 0.62, 0.36)
	elif kind == "pickaxe":
		base_col = Color(0.95, 0.88, 0.55)
	elif kind == "blade":
		base_col = Color(0.62, 0.94, 0.58)
	for _i in range(7):
		var ang: float = randf() * TAU
		var spd: float = randf_range(26.0, 72.0)
		burst_particles.append({
			"pos": wpos + Vector2(randf_range(-6.0, 6.0), randf_range(-6.0, 6.0)),
			"vel": Vector2(cos(ang) * spd, sin(ang) * spd - 34.0),
			"col": base_col,
			"life": randf_range(0.28, 0.48),
			"max_life": 0.48,
			"sz": randf_range(2.2, 3.8),
		})


func tick_visuals(delta: float) -> void:
	_time_accum += delta
	if player != null:
		if player.action_timer > 0.18 and _last_action_timer <= 0.02 and not player.action_kind.is_empty():
			var tpos: Vector2 = Vector2(player.target_grid.x * 32 + 16, player.target_grid.y * 32 + 16)
			spawn_burst(tpos, player.action_kind)
		_last_action_timer = player.action_timer

		if player.moving:
			_footstep_cd -= delta
			if _footstep_cd <= 0.0:
				_footstep_cd = 0.22
				burst_particles.append({
					"pos": player.world_pos + Vector2(randf_range(-4.0, 4.0), 8.0),
					"vel": Vector2(randf_range(-8.0, 8.0), -10.0),
					"col": Color(0.88, 0.82, 0.68, 0.55),
					"life": 0.30,
					"max_life": 0.30,
					"sz": 2.4,
				})

	for i in range(burst_particles.size() - 1, -1, -1):
		var bp: Dictionary = burst_particles[i]
		var lf: float = float(bp["life"]) - delta
		if lf <= 0.0:
			burst_particles.remove_at(i)
		else:
			var pv: Vector2 = bp["vel"]
			pv.y += 140.0 * delta
			bp["pos"] = (bp["pos"] as Vector2) + pv * delta
			bp["vel"] = pv
			bp["life"] = lf
			burst_particles[i] = bp

	for i in range(floating_texts.size() - 1, -1, -1):
		var ft: Dictionary = floating_texts[i]
		ft["life"] = float(ft["life"]) - delta
		var p: Vector2 = ft["pos"]
		p.y -= 26.0 * delta
		ft["pos"] = p
		if float(ft["life"]) <= 0.0:
			floating_texts.remove_at(i)
		else:
			floating_texts[i] = ft
	queue_redraw()


func _is_grass_id(tid: int) -> bool:
	return tid in [ZoneManager.T_GRASS1, ZoneManager.T_GRASS2, ZoneManager.T_PETAL_GRASS, ZoneManager.T_SUMMER_GRASS, ZoneManager.T_AUTUMN, ZoneManager.T_SNOW]


func _is_water_id(tid: int) -> bool:
	return tid == ZoneManager.T_WATER1 or tid == ZoneManager.T_WATER2


func _get_grid_tid(terrain: Array, x: int, y: int) -> int:
	if y < 0 or y >= terrain.size():
		return ZoneManager.T_GRASS1
	var r: Array = terrain[y]
	if x < 0 or x >= r.size():
		return ZoneManager.T_GRASS1
	return int(r[x])


func _draw() -> void:
	if zone_mgr == null:
		return
	var zid: String = GameState.current_zone
	var z: Dictionary = zone_mgr.get_zone(zid)
	if z.is_empty():
		return

	var font: Font = UITheme.get_font()
	var terrain: Array = z.get("terrain", [])
	var atlas: Texture2D = AssetRegistry.get_tex("tiles/terrain_atlas.png")
	var water_alt: bool = int(_time_accum * 1.6) % 2 == 1
	var season: String = GameState.get_season()
	var outdoor: bool = zid in ["farm", "ranch", "town", "lake", "secret_woods", "coral_island"]
	var season_tint: Color = _get_season_grass_tint(season) if outdoor else Color.WHITE
	if zid == "secret_woods":
		season_tint = season_tint * Color(0.86, 1.04, 0.94)
	elif zid == "coral_island":
		season_tint = Color(1.02, 1.08, 0.90)

	# 1. Base Terrain + Auto-Tiled Organic Grass Overhangs & Water Shorelines
	for y in range(terrain.size()):
		var row: Array = terrain[y]
		for x in range(row.size()):
			var tid: int = int(row[x])
			if tid == ZoneManager.T_WATER1 and water_alt:
				tid = ZoneManager.T_WATER2
			var col_idx: int = tid % 10
			var row_idx: int = int(tid / 10)
			var px: float = float(x * 32)
			var py: float = float(y * 32)
			var dst_rect: Rect2 = Rect2(px, py, 32, 32)
			var t_fw: float = float(atlas.get_width()) / 10.0 if atlas != null else 32.0
			var t_fh: float = float(atlas.get_height()) / 2.0 if atlas != null else 32.0
			var src_rect: Rect2 = Rect2(col_idx * t_fw, row_idx * t_fh, t_fw, t_fh)
			var tint: Color = season_tint if _is_grass_id(tid) else Color.WHITE
			if atlas != null:
				draw_texture_rect_region(atlas, dst_rect, src_rect, tint)
			else:
				draw_rect(dst_rect, Color(0.42, 0.66, 0.30) * tint)

			# Organic rounded grass fringes over roads, cobble & sand
			if tid in [ZoneManager.T_DIRT, ZoneManager.T_COBBLE, ZoneManager.T_SAND]:
				var g_dark: Color = Color(0.34, 0.56, 0.25) * season_tint
				var g_mid: Color = Color(0.43, 0.68, 0.31) * season_tint
				var n_up: bool = _is_grass_id(_get_grid_tid(terrain, x, y - 1))
				var n_dn: bool = _is_grass_id(_get_grid_tid(terrain, x, y + 1))
				var n_lt: bool = _is_grass_id(_get_grid_tid(terrain, x - 1, y))
				var n_rt: bool = _is_grass_id(_get_grid_tid(terrain, x + 1, y))
				var wave: int = (x * 7 + y * 13) % 3
				if n_up:
					draw_rect(Rect2(px, py, 32, 3 + wave), g_mid)
					draw_rect(Rect2(px + 4, py + 3 + wave, 8, 2), g_dark)
					draw_rect(Rect2(px + 20, py + 2 + wave, 7, 2), g_dark)
				if n_dn:
					draw_rect(Rect2(px, py + 29 - wave, 32, 3 + wave), g_mid)
					draw_rect(Rect2(px + 6, py + 27 - wave, 9, 2), g_dark)
				if n_lt:
					draw_rect(Rect2(px, py, 3 + wave, 32), g_mid)
					draw_rect(Rect2(px + 3 + wave, py + 8, 2, 8), g_dark)
				if n_rt:
					draw_rect(Rect2(px + 29 - wave, py, 3 + wave, 32), g_mid)
					draw_rect(Rect2(px + 27 - wave, py + 14, 2, 8), g_dark)
				if n_up and n_lt:
					draw_rect(Rect2(px, py, 9, 9), g_mid)
				if n_up and n_rt:
					draw_rect(Rect2(px + 23, py, 9, 9), g_mid)
				if n_dn and n_lt:
					draw_rect(Rect2(px, py + 23, 9, 9), g_mid)
				if n_dn and n_rt:
					draw_rect(Rect2(px + 23, py + 23, 9, 9), g_mid)

			# Water shoreline earthen bank & animated white foam
			elif _is_water_id(tid):
				var bank_c: Color = Color(0.44, 0.34, 0.22)
				var foam_a: float = 0.45 + 0.25 * sin(_time_accum * 3.0 + float(x + y))
				var foam_c: Color = Color(0.88, 0.97, 1.0, foam_a)
				if not _is_water_id(_get_grid_tid(terrain, x, y - 1)):
					draw_rect(Rect2(px, py, 32, 4), bank_c)
					draw_rect(Rect2(px + 2, py + 4, 28, 2), foam_c)
				if not _is_water_id(_get_grid_tid(terrain, x, y + 1)):
					draw_rect(Rect2(px, py + 29, 32, 3), bank_c)
					draw_rect(Rect2(px + 3, py + 27, 26, 2), foam_c)
				if not _is_water_id(_get_grid_tid(terrain, x - 1, y)):
					draw_rect(Rect2(px, py, 3, 32), bank_c)
					draw_rect(Rect2(px + 3, py + 3, 2, 26), foam_c)
				if not _is_water_id(_get_grid_tid(terrain, x + 1, y)):
					draw_rect(Rect2(px + 29, py, 3, 32), bank_c)
					draw_rect(Rect2(px + 27, py + 3, 2, 26), foam_c)

	# 1b. Ranch Wooden Pasture Fence Decoration & Upgraded Farmhouse Rug Trim
	if zid == "ranch":
		_draw_ranch_fence()
	elif zid == "farmhouse" and GameState.house_tier >= 2:
		var trim_col: Color = Color(0.95, 0.78, 0.32, 0.85) if GameState.house_tier >= 3 else Color(0.88, 0.52, 0.56, 0.75)
		draw_rect(Rect2(5 * 32 - 3, 4 * 32 - 3, 4 * 32 + 6, 4 * 32 + 6), trim_col, false, 3.0)
		_draw_warm_glow(Vector2(7 * 32, 5 * 32 + 16), 92.0, 0.85)

	# 2. Connected Farm, Greenhouse & Coral Island Soil Beds + Crops
	if zid == "farm" or zid == "greenhouse" or zid == "coral_island":
		var farm_tiles: Dictionary = z.get("farm_tiles", {})
		for k in farm_tiles.keys():
			var pos: Vector2i = ZoneManager.parse_key(str(k))
			var ft: Dictionary = farm_tiles[k]
			if not bool(ft.get("tilled", false)):
				continue
			var wet: bool = bool(ft.get("watered", false))
			_draw_connected_soil_tile(farm_tiles, pos, wet)

			# Fertilizer golden sparkles
			if not str(ft.get("fertilizer", "")).is_empty():
				draw_circle(Vector2(pos.x * 32 + 8, pos.y * 32 + 8), 2.0, Color(0.98, 0.84, 0.34))
				draw_circle(Vector2(pos.x * 32 + 23, pos.y * 32 + 24), 1.8, Color(0.98, 0.84, 0.34))

			# Ecology soil vitality heatmap
			if ecology_lens_active:
				var dst_r: Rect2 = Rect2(pos.x * 32, pos.y * 32, 32, 32)
				var vit: float = float(ft.get("soil_vitality", 80.0))
				var vcol: Color = Color(0.2, 0.9, 0.45, 0.16) if vit >= 75.0 else (Color(0.95, 0.78, 0.22, 0.18) if vit >= 35.0 else Color(0.95, 0.3, 0.25, 0.24))
				draw_rect(dst_r.grow(-2), vcol)
				draw_string(font, Vector2(pos.x * 32 + 3, pos.y * 32 + 28), "%d" % int(vit), HORIZONTAL_ALIGNMENT_LEFT, -1, 9, Color(0.95, 1.0, 0.92, 0.9))

			# Crop sprite
			var crop: Dictionary = ft.get("crop", {})
			if not crop.is_empty():
				var cid: String = str(crop.get("id", ""))
				var cdef: Dictionary = DataRegistry.get_crop(cid)
				var mature: bool = bool(crop.get("mature", false))
				var is_giant: bool = bool(crop.get("giant", false))
				if is_giant:
					var gtex: Texture2D = AssetRegistry.get_tex("crops/giant_%s.png" % cid)
					if gtex != null:
						draw_texture_rect(gtex, Rect2(pos.x * 32 - 8, pos.y * 32 - 20, 48, 48), false)
				else:
					var ctex: Texture2D = AssetRegistry.get_tex("crops/crop_%s.png" % cid)
					var days_need: float = maxf(1.0, float(cdef.get("days_to_grow", 4)))
					var prog: float = clampf(float(crop.get("growth_days", 0.0)) / days_need, 0.0, 1.0)
					var frame: int = 4 if mature else clampi(int(floor(prog * 4.0)), 0, 3)
					var sway: float = sin(_time_accum * 2.8 + float(pos.x) * 0.9) * 1.5 if frame >= 2 else 0.0
					if ctex != null:
						var c_fw: int = maxi(1, int(ctex.get_width() / 5))
						var c_fh: int = ctex.get_height()
						draw_texture_rect_region(ctex, Rect2(pos.x * 32 + sway, pos.y * 32 - 5, 32, 32), Rect2(frame * c_fw, 0, c_fw, c_fh))
					if mature:
						var pulse: float = 0.55 + 0.45 * sin(_time_accum * 5.0 + float(pos.y))
						draw_circle(Vector2(pos.x * 32 + 25, pos.y * 32 + 5), 3.0, Color(1.0, 0.95, 0.4, pulse))

	# 3. Ecology Lens Synergy Links (dynamic badge width & offset right of plot)
	if (zid == "farm" or zid == "greenhouse" or zid == "coral_island") and ecology_lens_active and farm_sys != null:
		var links: Array = farm_sys.get_all_ecology_links(zone_mgr, zid)
		var drawn_badges: Dictionary = {}
		var badge_list: Array = []
		var max_px: float = 0.0
		var min_py: float = 99999.0
		for lk in links:
			var d: Dictionary = lk
			var p1: Vector2 = Vector2((d["from"] as Vector2i).x * 32 + 16, (d["from"] as Vector2i).y * 32 + 16)
			var p2: Vector2 = Vector2((d["to"] as Vector2i).x * 32 + 16, (d["to"] as Vector2i).y * 32 + 16)
			var lcol: Color = Color.from_string(str(d.get("color", "#66BB6A")), Color(0.4, 0.95, 0.55))
			draw_line(p1, p2, Color(lcol.r, lcol.g, lcol.b, 0.85), 2.5, true)
			draw_circle(p1, 3.4, lcol)
			draw_circle(p2, 3.4, lcol)
			max_px = maxf(max_px, maxf(p1.x, p2.x))
			min_py = minf(min_py, minf(p1.y, p2.y))
			var sname: String = str(d.get("name", ""))
			if not sname.is_empty() and not drawn_badges.has(sname):
				drawn_badges[sname] = true
				badge_list.append({"name": sname, "col": lcol})
		for bi in range(badge_list.size()):
			var bd: Dictionary = badge_list[bi]
			var txt_b: String = "✨ " + str(bd["name"])
			var tw: float = font.get_string_size(txt_b, HORIZONTAL_ALIGNMENT_LEFT, -1, 11).x + 14.0
			var bx: float = max_px + 20.0
			var by: float = min_py + float(bi) * 20.0
			draw_rect(Rect2(bx, by - 13.0, tw, 17.0), Color(0.14, 0.10, 0.07, 0.90))
			draw_rect(Rect2(bx, by - 13.0, tw, 17.0), bd["col"], false, 1.2)
			draw_string(font, Vector2(bx + 6.0, by - 1.0), txt_b, HORIZONTAL_ALIGNMENT_LEFT, -1, 11, bd["col"])

	# 4. Collect Y-Sorted Drawables (Buildings, Objects, Ranch Animals, NPCs, Monsters, Player)
	var draw_list: Array = []

	for b in z.get("buildings", []):
		var bd2: Dictionary = b
		var gp: Array = bd2.get("grid_pos", [0, 0])
		var sz_t: Array = bd2.get("size_tiles", [5, 4])
		var bx2: float = float(gp[0]) * 32.0
		var by2: float = float(gp[1]) * 32.0
		var bw: float = float(sz_t[0]) * 32.0
		var bh: float = float(sz_t[1]) * 32.0
		draw_list.append({"y": by2 + bh, "kind": "building", "rect": Rect2(bx2, by2, bw, bh), "sprite": str(bd2.get("sprite", "")), "label": str(bd2.get("label", ""))})

	var objs: Dictionary = z.get("objects", {})
	for ok in objs.keys():
		var opos: Vector2i = ZoneManager.parse_key(str(ok))
		var obj: Dictionary = objs[ok]
		draw_list.append({"y": float(opos.y + 1) * 32.0, "kind": "object", "grid": opos, "obj": obj})

	var drops: Array = z.get("drops", [])
	for dr in drops:
		var dd: Dictionary = dr
		draw_list.append({"y": float(dd.get("y", 0.0)), "kind": "drop", "drop": dd})

	if zid == "ranch":
		for anim in GameState.ranch_animals:
			var ad: Dictionary = anim
			draw_list.append({"y": float(ad.get("y", 320.0)) + 10.0, "kind": "animal", "anim": ad})

	if npc_sched != null:
		for nst in npc_sched.get_npcs_in_zone(zid):
			var nd: Dictionary = nst
			var np: Vector2 = nd["pos"]
			draw_list.append({"y": np.y + 10.0, "kind": "npc", "npc": nd})

	if (zid == "mine" or zid == "secret_woods") and mine_sys != null:
		for m in mine_sys.monsters:
			var md: Dictionary = m
			var mp: Vector2 = md["pos"]
			draw_list.append({"y": mp.y + 10.0, "kind": "monster", "m": md})

	if pet_sys != null and pet_sys.is_pet_active_in_zone(zid):
		draw_list.append({"y": pet_sys.pet_pos.y + 8.0, "kind": "pet"})

	if player != null:
		draw_list.append({"y": player.world_pos.y + 10.0, "kind": "player"})

	draw_list.sort_custom(func(a: Dictionary, b: Dictionary) -> bool: return float(a["y"]) < float(b["y"]))

	for item in draw_list:
		var it: Dictionary = item
		var knd: String = str(it["kind"])
		if knd == "building":
			var btex: Texture2D = AssetRegistry.get_tex(str(it["sprite"]))
			var r: Rect2 = it["rect"]
			if btex != null:
				draw_texture_rect(btex, r, false)
			_draw_tag(font, Vector2(r.position.x + r.size.x * 0.5, r.position.y - 4.0), str(it["label"]), Color(1.0, 0.94, 0.76))
		elif knd == "object":
			_draw_object(it["grid"], it["obj"], font)
		elif knd == "drop":
			_draw_drop(it["drop"])
		elif knd == "animal":
			_draw_animal(it["anim"], font)
		elif knd == "npc":
			_draw_npc(it["npc"], font)
		elif knd == "monster":
			_draw_monster(it["m"], font)
		elif knd == "pet":
			_draw_pet(font)
		elif knd == "player":
			_draw_player()

	# 5. Soft Target Tile Cursor (corner brackets instead of harsh box) & Mobile Tap-to-Walk Ripple
	if player != null:
		if player.auto_walk_active:
			var r_rad: float = 9.0 + 4.5 * absf(sin(_time_accum * 5.0))
			draw_arc(player.auto_walk_world, r_rad, 0.0, TAU, 24, Color(1.0, 0.90, 0.42, 0.86), 2.2)
			draw_circle(player.auto_walk_world, 3.2, Color(1.0, 0.96, 0.68, 0.92))
		var tg: Vector2i = player.target_grid
		var cx: float = float(tg.x * 32)
		var cy: float = float(tg.y * 32)
		var cc: Color = Color(1.0, 0.92, 0.46, 0.82)
		draw_line(Vector2(cx + 2, cy + 2), Vector2(cx + 10, cy + 2), cc, 2.0)
		draw_line(Vector2(cx + 2, cy + 2), Vector2(cx + 2, cy + 10), cc, 2.0)
		draw_line(Vector2(cx + 30, cy + 2), Vector2(cx + 22, cy + 2), cc, 2.0)
		draw_line(Vector2(cx + 30, cy + 2), Vector2(cx + 30, cy + 10), cc, 2.0)
		draw_line(Vector2(cx + 2, cy + 30), Vector2(cx + 10, cy + 30), cc, 2.0)
		draw_line(Vector2(cx + 2, cy + 30), Vector2(cx + 2, cy + 22), cc, 2.0)
		draw_line(Vector2(cx + 30, cy + 30), Vector2(cx + 22, cy + 30), cc, 2.0)
		draw_line(Vector2(cx + 30, cy + 30), Vector2(cx + 30, cy + 22), cc, 2.0)

	# 6. Burst Particles, Ambient Butterflies/Leaves, Evening Lantern Glows & Weather
	for bp in burst_particles:
		var pd: Dictionary = bp
		var pa: float = clampf(float(pd["life"]) / float(pd["max_life"]), 0.0, 1.0)
		var pc: Color = pd["col"]
		pc.a *= pa
		var pp: Vector2 = pd["pos"]
		var psz: float = float(pd["sz"])
		draw_rect(Rect2(pp.x - psz * 0.5, pp.y - psz * 0.5, psz, psz), pc)

	_draw_ambient_and_lanterns(zid, z)
	_draw_weather(zid)

	# 7. Floating Texts with dark crisp outline
	for ft in floating_texts:
		var fd: Dictionary = ft
		var alpha: float = clampf(float(fd["life"]) / float(fd["max_life"]), 0.0, 1.0)
		var c: Color = fd["color"]
		c.a = alpha
		var fpos: Vector2 = fd["pos"]
		var ftxt: String = str(fd["text"])
		draw_string(font, fpos + Vector2(1, 1), ftxt, HORIZONTAL_ALIGNMENT_CENTER, -1, 13, Color(0.08, 0.04, 0.02, alpha * 0.85))
		draw_string(font, fpos, ftxt, HORIZONTAL_ALIGNMENT_CENTER, -1, 13, c)


func _draw_connected_soil_tile(farm_tiles: Dictionary, pos: Vector2i, wet: bool) -> void:
	var px: float = float(pos.x * 32)
	var py: float = float(pos.y * 32)
	var has_n: bool = bool((farm_tiles.get(ZoneManager.key(pos + Vector2i(0, -1)), {}) as Dictionary).get("tilled", false))
	var has_s: bool = bool((farm_tiles.get(ZoneManager.key(pos + Vector2i(0, 1)), {}) as Dictionary).get("tilled", false))
	var has_w: bool = bool((farm_tiles.get(ZoneManager.key(pos + Vector2i(-1, 0)), {}) as Dictionary).get("tilled", false))
	var has_e: bool = bool((farm_tiles.get(ZoneManager.key(pos + Vector2i(1, 0)), {}) as Dictionary).get("tilled", false))

	var soil_fill: Color = Color(0.37, 0.23, 0.14) if wet else Color(0.58, 0.40, 0.24)
	var furrow_c: Color = Color(0.27, 0.16, 0.10) if wet else Color(0.47, 0.31, 0.18)
	var rim_c: Color = Color(0.24, 0.15, 0.09) if wet else Color(0.40, 0.26, 0.15)

	var l_pad: float = 0.0 if has_w else 2.0
	var r_pad: float = 0.0 if has_e else 2.0
	var t_pad: float = 0.0 if has_n else 2.0
	var b_pad: float = 0.0 if has_s else 2.0
	var body: Rect2 = Rect2(px + l_pad, py + t_pad, 32.0 - l_pad - r_pad, 32.0 - t_pad - b_pad)
	draw_rect(body, soil_fill)

	# Outer organic soil rims only on exposed borders
	if not has_n:
		draw_rect(Rect2(body.position.x, body.position.y, body.size.x, 2.0), rim_c)
	if not has_s:
		draw_rect(Rect2(body.position.x, body.end.y - 2.0, body.size.x, 2.0), rim_c)
	if not has_w:
		draw_rect(Rect2(body.position.x, body.position.y, 2.0, body.size.y), rim_c)
	if not has_e:
		draw_rect(Rect2(body.end.x - 2.0, body.position.y, 2.0, body.size.y), rim_c)

	# Continuous horizontal furrow ridges
	for ry in [8.0, 16.0, 24.0]:
		draw_rect(Rect2(body.position.x + 2.0, py + ry, body.size.x - 4.0, 2.0), furrow_c)


func _draw_ranch_fence() -> void:
	var post_c: Color = Color(0.48, 0.30, 0.16)
	var rail_c: Color = Color(0.64, 0.43, 0.24)
	# Horizontal top & bottom pasture rails (x=6..21, y=8 and y=16, leaving north/south gates at x=11..12)
	for gx in range(6, 22):
		var fx: float = float(gx * 32)
		if gx != 11 and gx != 12:
			draw_rect(Rect2(fx, 8 * 32 + 12, 32, 4), rail_c)
			draw_rect(Rect2(fx, 8 * 32 + 20, 32, 3), post_c)
			draw_rect(Rect2(fx + 2, 8 * 32 + 8, 6, 18), post_c)
			draw_rect(Rect2(fx, 16 * 32 + 12, 32, 4), rail_c)
			draw_rect(Rect2(fx, 16 * 32 + 20, 32, 3), post_c)
			draw_rect(Rect2(fx + 2, 16 * 32 + 8, 6, 18), post_c)
	for gy in range(8, 17):
		var fy: float = float(gy * 32)
		draw_rect(Rect2(6 * 32 + 2, fy, 5, 32), rail_c)
		draw_rect(Rect2(21 * 32 + 25, fy, 5, 32), rail_c)


func _draw_tag(font: Font, center_pt: Vector2, txt: String, col: Color) -> void:
	if txt.is_empty():
		return
	var tw: float = font.get_string_size(txt, HORIZONTAL_ALIGNMENT_LEFT, -1, 10).x + 10.0
	var bx: float = center_pt.x - tw * 0.5
	draw_rect(Rect2(bx, center_pt.y - 12.0, tw, 15.0), Color(0.14, 0.09, 0.06, 0.78))
	draw_string(font, Vector2(bx + 5.0, center_pt.y - 1.0), txt, HORIZONTAL_ALIGNMENT_LEFT, -1, 10, col)


func _get_season_grass_tint(season: String) -> Color:
	if season == "summer":
		return Color(0.95, 1.04, 0.88)
	elif season == "autumn":
		return Color(1.18, 0.86, 0.56)
	elif season == "winter":
		return Color(1.20, 1.26, 1.36)
	return Color.WHITE


func _draw_object(pos: Vector2i, obj: Dictionary, font: Font) -> void:
	var spr: String = str(obj.get("sprite", ""))
	var tex: Texture2D = AssetRegistry.get_tex(spr)
	var otype: String = str(obj.get("type", ""))
	var px: float = float(pos.x * 32)
	var py: float = float(pos.y * 32)
	if otype == "obelisk":
		var pulse_o: float = 0.65 + 0.35 * sin(_time_accum * 3.4)
		draw_circle(Vector2(px + 16, py - 20), 42.0, Color(0.55, 0.38, 1.0, 0.14 * pulse_o))
		draw_circle(Vector2(px + 16, py - 24), 22.0, Color(0.45, 0.92, 1.0, 0.22 * pulse_o))
	elif otype == "golden_clock":
		var pulse_g: float = 0.70 + 0.30 * sin(_time_accum * 2.8)
		draw_circle(Vector2(px + 16, py - 22), 46.0, Color(1.0, 0.86, 0.30, 0.16 * pulse_g))
		draw_circle(Vector2(px + 16, py - 26), 24.0, Color(1.0, 0.95, 0.58, 0.24 * pulse_g))

	if tex != null:
		if otype == "tree" or otype == "palm_tree":
			var sway: float = sin(_time_accum * 1.8 + float(pos.x * 3 + pos.y)) * 1.8
			draw_texture_rect(tex, Rect2(px - 16.0 + sway, py - 62.0, 64, 96), false)
		elif otype == "island_ferry":
			var boat_bob: float = sin(_time_accum * 2.4 + float(pos.x)) * 2.2
			draw_texture_rect(tex, Rect2(px - 24.0, py - 24.0 + boat_bob, 80, 64), false)
		elif otype == "echo_shrine":
			draw_texture_rect(tex, Rect2(px - 48, py - 84, 128, 128), false)
		elif otype == "fountain":
			draw_texture_rect(tex, Rect2(px - 32, py - 56, 96, 96), false)
		elif otype == "quest_board":
			draw_texture_rect(tex, Rect2(px - 16, py - 30, 64, 64), false)
		elif otype == "shipping_bin":
			draw_texture_rect(tex, Rect2(px - 8, py - 16, 48, 48), false)
		elif otype == "bed":
			var bed_w: float = 64.0 if GameState.house_tier >= 2 else 48.0
			var bed_ox: float = -16.0 if GameState.house_tier >= 2 else -8.0
			draw_texture_rect(tex, Rect2(px + bed_ox, py - 24, bed_w, 64), false)
		elif otype == "tv":
			draw_texture_rect(tex, Rect2(px, py - 8, 32, 40), false)
		elif otype == "kitchen_stove" or otype == "carpenter_desk":
			draw_texture_rect(tex, Rect2(px - 16, py - 16, 64, 48), false)
		elif otype == "fish_pond":
			draw_texture_rect(tex, Rect2(px - 32, py - 16, 96, 64), false)
			var fcnt: int = int(GameState.fish_pond.get("count", 0))
			if fcnt > 0:
				var fid: String = str(GameState.fish_pond.get("fish_id", ""))
				var ftex: Texture2D = AssetRegistry.get_icon(fid)
				var fx_sway: float = sin(_time_accum * 2.2) * 18.0
				var fy_sway: float = cos(_time_accum * 3.1) * 5.0
				if ftex != null:
					draw_texture_rect(ftex, Rect2(px + 6 + fx_sway, py + 6 + fy_sway, 20, 20), false)
		elif otype == "obelisk" or otype == "golden_clock":
			draw_texture_rect(tex, Rect2(px - 16, py - 64, 64, 96), false)
		elif otype == "feed_trough":
			draw_texture_rect(tex, Rect2(px - 16, py - 4, 64, 36), false)
		elif otype == "ranch_counter" or otype == "ranch_sign":
			draw_texture_rect(tex, Rect2(px - 8, py - 14, 48, 48), false)
		elif otype == "festival_judge":
			draw_texture_rect(tex, Rect2(px - 16, py - 16, 64, 48), false)
		elif otype == "hardwood_stump" or otype == "pet_bowl":
			draw_texture_rect(tex, Rect2(px - 6, py - 10, 44, 42), false)
		elif not spr.is_empty():
			draw_texture_rect(tex, Rect2(px, py - 4, 32, 32), false)

	if otype == "machine":
		var proc: Dictionary = obj.get("processing", {})
		if not proc.is_empty():
			var rem: float = float(proc.get("remaining_hours", 0.0))
			var tot: float = maxf(1.0, float(proc.get("total_hours", 1.0)))
			if rem <= 0.0:
				var bob: float = sin(_time_accum * 6.0) * 3.0
				var out_tex: Texture2D = AssetRegistry.get_icon(str(proc.get("output_id", "")))
				draw_circle(Vector2(px + 16, py - 15 + bob), 11.5, Color(0.98, 0.94, 0.78, 0.95))
				if out_tex != null:
					draw_texture_rect(out_tex, Rect2(px + 7, py - 24 + bob, 18, 18), false)
			else:
				var pct: float = 1.0 - clampf(rem / tot, 0.0, 1.0)
				draw_rect(Rect2(px + 4, py - 9, 24, 5), Color(0.14, 0.09, 0.05, 0.9))
				draw_rect(Rect2(px + 5, py - 8, 22 * pct, 3), Color(0.45, 0.95, 0.55))

	var lbl: String = str(obj.get("label", ""))
	if not lbl.is_empty() and otype in ["shop_counter", "echo_shrine", "quest_board", "shipping_bin", "bed", "tv", "kitchen_stove", "carpenter_desk", "pet_bowl", "fish_pond", "obelisk", "golden_clock", "hardwood_stump", "ranch_counter", "feed_trough", "ranch_sign", "elevator", "ladder_up", "ladder_down", "festival_judge", "greenhouse_door", "island_ferry"]:
		var tag_y: float = py - 14.0
		if otype == "obelisk" or otype == "golden_clock":
			tag_y = py - 68.0
		elif otype == "echo_shrine":
			tag_y = py - 86.0
		elif otype == "fish_pond":
			tag_y = py - 20.0
		elif otype == "island_ferry":
			tag_y = py - 28.0
		_draw_tag(font, Vector2(px + 16.0, tag_y), lbl, Color(1.0, 0.94, 0.74))


func _draw_drop(d: Dictionary) -> void:
	var x: float = float(d.get("x", 0.0))
	var dz: float = float(d.get("z", 0.0))
	var hover: float = sin(_time_accum * 4.5 + x) * 2.2 if dz <= 0.1 else 0.0
	var y: float = float(d.get("y", 0.0)) - dz + hover
	var tex: Texture2D = AssetRegistry.get_icon(str(d.get("item_id", "")))
	draw_circle(Vector2(x, float(d.get("y", 0.0)) + 6.0), clampf(6.5 - dz * 0.08, 3.0, 6.5), Color(0, 0, 0, 0.28))
	if tex != null:
		draw_texture_rect(tex, Rect2(x - 10, y - 10, 20, 20), false)


func _draw_animal(ad: Dictionary, font: Font) -> void:
	var kind: String = str(ad.get("kind", "chicken"))
	var spec: Dictionary = RanchSystem.ANIMAL_SPECS.get(kind, RanchSystem.ANIMAL_SPECS["chicken"])
	var spr: String = str(spec.get("sprite", "animals/chicken.png"))
	var fw: int = int(spec.get("frame_w", 32))
	var fh: int = int(spec.get("frame_h", 32))
	var tex: Texture2D = AssetRegistry.get_tex(spr)
	var ax: float = float(ad.get("x", 384.0))
	var ay: float = float(ad.get("y", 336.0))
	var vst: Dictionary = ranch_sys.get_animal_visual_state(ad) if ranch_sys != null else {"moving": false, "anim_t": 0.0, "bubble": ""}
	var moving: bool = bool(vst.get("moving", false))
	var anim_t: float = float(vst.get("anim_t", 0.0))
	var frame: int = int(anim_t) % 4 if moving else 0
	var hop: float = absf(sin(anim_t * 2.5)) * 2.5 if moving else 0.0

	draw_circle(Vector2(ax, ay + 6.0), float(fw) * 0.30, Color(0, 0, 0, 0.24))
	if tex != null:
		var dst: Rect2 = Rect2(ax - float(fw) * 0.5, ay - float(fh) * 0.72 - hop, float(fw), float(fh))
		if int(ad.get("dir", 0)) == 1:
			dst.size.x = -dst.size.x
		var a_fw: int = maxi(1, int(tex.get_width() / 4))
		var a_fh: int = tex.get_height()
		draw_texture_rect_region(tex, dst, Rect2(frame * a_fw, 0, a_fw, a_fh))

	var bubble: String = str(vst.get("bubble", ""))
	if not bubble.is_empty():
		_draw_tag(font, Vector2(ax, ay - float(fh) * 0.75 - 6.0), bubble, Color(1.0, 0.72, 0.82))


func _draw_npc(nd: Dictionary, font: Font) -> void:
	var nid: String = str(nd.get("id", ""))
	var np: Vector2 = nd["pos"]
	var dir: int = int(nd.get("dir", 0))
	var moving: bool = bool(nd.get("moving", false))
	var frame: int = int(nd.get("anim_t", 0.0)) % 4 if moving else 0
	var tex: Texture2D = AssetRegistry.get_tex("characters/npc_%s.png" % nid)
	draw_circle(Vector2(np.x, np.y + 5.0), 8.0, Color(0, 0, 0, 0.24))
	if tex != null:
		var n_fw: int = maxi(1, int(tex.get_width() / 4))
		var n_fh: int = maxi(1, int(tex.get_height() / 4))
		draw_texture_rect_region(tex, Rect2(np.x - 16, np.y - 24, 32, 32), Rect2(frame * n_fw, dir * n_fh, n_fw, n_fh))
	_draw_tag(font, Vector2(np.x, np.y - 26.0), str(nd.get("name", nid)), Color(1.0, 0.96, 0.78))
	var bubble: String = str(nd.get("bubble", ""))
	if not bubble.is_empty():
		_draw_tag(font, Vector2(np.x, np.y - 43.0), bubble, Color(1.0, 0.88, 0.45))


func _draw_pet(font: Font) -> void:
	if pet_sys == null:
		return
	var kind: String = str(GameState.pet_data.get("kind", "cat"))
	var spr: String = "animals/pet_dog.png" if kind == "dog" else "animals/pet_cat.png"
	var tex: Texture2D = AssetRegistry.get_tex(spr)
	var pp: Vector2 = pet_sys.pet_pos
	var frame: int = int(pet_sys.pet_anim_t) % 4 if pet_sys.pet_moving else (int(_time_accum * 2.0) % 2)
	var hop: float = absf(sin(pet_sys.pet_anim_t * 2.2)) * 2.5 if pet_sys.pet_moving else 0.0
	draw_circle(Vector2(pp.x, pp.y + 5.0), 7.5, Color(0, 0, 0, 0.24))
	if tex != null:
		var dst: Rect2 = Rect2(pp.x - 16.0, pp.y - 24.0 - hop, 32.0, 32.0)
		if pet_sys.pet_dir == 1:
			dst.size.x = -32.0
		var pt_fw: int = maxi(1, int(tex.get_width() / 4))
		var pt_fh: int = tex.get_height()
		draw_texture_rect_region(tex, dst, Rect2(frame * pt_fw, 0, pt_fw, pt_fh))
	if not pet_sys.pet_bubble.is_empty():
		_draw_tag(font, Vector2(pp.x, pp.y - 28.0), pet_sys.pet_bubble, Color(1.0, 0.78, 0.88))


func _draw_monster(md: Dictionary, font: Font) -> void:
	var kind: String = str(md.get("kind", "slime"))
	var mp: Vector2 = md["pos"]
	var frame: int = int(md.get("anim_t", 0.0)) % 4
	var tex: Texture2D = AssetRegistry.get_tex("monsters/%s.png" % kind)
	var col: Color = Color(3.0, 3.0, 3.0, 1.0) if float(md.get("hit_flash", 0.0)) > 0.0 else Color.WHITE
	var is_boss: bool = (kind == "echo_boss" or kind == "ancient_treant")
	var sz: float = 64.0 if is_boss else 36.0
	draw_circle(Vector2(mp.x, mp.y + 6.0), sz * 0.28, Color(0, 0, 0, 0.28))
	if tex != null:
		var m_fw: int = maxi(1, int(tex.get_width() / 4))
		var m_fh: int = tex.get_height()
		draw_texture_rect_region(tex, Rect2(mp.x - sz * 0.5, mp.y - sz * 0.72, sz, sz), Rect2(frame * m_fw, 0, m_fw, m_fh), col)
	var hp_ratio: float = clampf(float(md.get("hp", 1.0)) / maxf(1.0, float(md.get("max_hp", 1.0))), 0.0, 1.0)
	var bar_w: float = 52.0 if is_boss else 26.0
	var bar_y: float = mp.y - (52.0 if is_boss else 30.0)
	draw_rect(Rect2(mp.x - bar_w * 0.5, bar_y, bar_w, 4), Color(0.15, 0.05, 0.05, 0.85))
	draw_rect(Rect2(mp.x - bar_w * 0.5, bar_y, bar_w * hp_ratio, 4), Color(0.95, 0.75, 0.25) if is_boss else Color(0.95, 0.3, 0.3))
	if is_boss:
		var btitle: String = "🌳 远古树精守护者" if kind == "ancient_treant" else "👑 回响晶甲王"
		_draw_tag(font, Vector2(mp.x, bar_y - 4.0), btitle, Color(0.65, 1.0, 0.75) if kind == "ancient_treant" else Color(1.0, 0.85, 0.35))


func _draw_player() -> void:
	var tex: Texture2D = AssetRegistry.get_tex("characters/player_sheet.png")
	var row: int = 4 if player.action_timer > 0.0 else player.facing
	var col: int = player.facing if player.action_timer > 0.0 else (int(player.anim_t) % 4 if player.moving else 0)
	var p: Vector2 = player.world_pos
	var hop: float = absf(sin(player.anim_t * 1.6)) * 1.5 if player.moving else 0.0
	var mod: Color = Color(1.0, 0.4, 0.4) if player.invuln_timer > 0.4 else Color.WHITE
	draw_circle(Vector2(p.x, p.y + 5.0), 8.5, Color(0, 0, 0, 0.26))
	if tex != null:
		var p_fw: int = maxi(1, int(tex.get_width() / 4))
		var p_fh: int = maxi(1, int(tex.get_height() / 6))
		draw_texture_rect_region(tex, Rect2(p.x - 16, p.y - 24 - hop, 32, 32), Rect2(col * p_fw, row * p_fh, p_fw, p_fh), mod)

	# Crisp tool/blade swing crescent arc
	if player.action_timer > 0.0:
		var prog: float = 1.0 - (player.action_timer / 0.24)
		var base_ang: float = player.facing_vec.angle()
		var a0: float = base_ang - 0.9 + prog * 0.5
		var a1: float = base_ang + 0.9
		var arc_col: Color = Color(1.0, 0.96, 0.78, clampf(1.0 - prog, 0.2, 0.9))
		draw_arc(p - Vector2(0, 6), 20.0, a0, a1, 10, arc_col, 3.0)


func _draw_warm_glow(pt: Vector2, radius: float, intensity: float) -> void:
	draw_circle(pt, radius, Color(1.0, 0.76, 0.32, 0.07 * intensity))
	draw_circle(pt, radius * 0.58, Color(1.0, 0.84, 0.44, 0.12 * intensity))
	draw_circle(pt, radius * 0.25, Color(1.0, 0.94, 0.68, 0.20 * intensity))


func _draw_ambient_and_lanterns(zid: String, z: Dictionary) -> void:
	var ppos: Vector2 = player.world_pos if player != null else Vector2(300, 300)
	var h: float = float(GameState.hour) + float(GameState.minute) / 60.0
	var outdoor: bool = zid in ["farm", "ranch", "town", "lake", "secret_woods"]

	# Warm lantern glows at dusk/night or in mine
	if zid == "mine":
		_draw_warm_glow(ppos - Vector2(0, 8), 78.0, 1.0)
	elif outdoor and h >= 17.5:
		var night_k: float = clampf((h - 17.5) / 2.0, 0.25, 1.0)
		_draw_warm_glow(ppos - Vector2(0, 8), 64.0, night_k * 0.85)
		for b in z.get("buildings", []):
			var bd: Dictionary = b
			var gp: Array = bd.get("grid_pos", [0, 0])
			var sz_t: Array = bd.get("size_tiles", [5, 4])
			var wx: float = (float(gp[0]) + float(sz_t[0]) * 0.5) * 32.0
			var wy: float = (float(gp[1]) + float(sz_t[1]) - 0.8) * 32.0
			_draw_warm_glow(Vector2(wx, wy), 72.0, night_k)
		var objs: Dictionary = z.get("objects", {})
		for ok in objs.keys():
			var obj: Dictionary = objs[ok]
			if str(obj.get("machine_type", "")) == "torch" or str(obj.get("type", "")) in ["fountain", "echo_shrine", "obelisk", "golden_clock"]:
				var op: Vector2i = ZoneManager.parse_key(str(ok))
				_draw_warm_glow(Vector2(op.x * 32 + 16, op.y * 32 + 8), 58.0, night_k)

	# Outdoor ambient butterflies / sunlit pollen / autumn leaves / night or secret_woods fireflies
	if not outdoor or GameState.weather != "sunny":
		return
	var season: String = GameState.get_season()
	for m in _ambient_motes:
		var md: Dictionary = m
		var sd: float = float(md["seed"])
		var mx: float = ppos.x + fmod(float(md["ox"]) + sin(_time_accum * 0.7 + sd) * 42.0 + _time_accum * 12.0, 720.0) - 360.0
		var my: float = ppos.y + fmod(float(md["oy"]) + cos(_time_accum * 0.9 + sd) * 28.0 + _time_accum * 6.0, 440.0) - 220.0
		if h >= 18.5 or zid == "secret_woods":
			var blink: float = 0.35 + 0.65 * absf(sin(_time_accum * 2.6 + sd * 2.0))
			var ff_col: Color = Color(0.55, 1.0, 0.78, blink * 0.88) if zid == "secret_woods" else Color(0.75, 1.0, 0.42, blink * 0.85)
			draw_circle(Vector2(mx, my), 2.6, ff_col)
		elif season == "autumn":
			draw_rect(Rect2(mx, my, 4, 3), Color(0.95, 0.52, 0.22, 0.78))
		elif str(md["kind"]) == "butterfly" and season in ["spring", "summer"]:
			var flap: float = absf(sin(_time_accum * 9.0 + sd)) * 3.2 + 1.0
			var bcol: Color = Color(1.0, 0.86, 0.42, 0.88) if int(md["tint"]) == 0 else Color(1.0, 0.68, 0.82, 0.88)
			draw_rect(Rect2(mx - flap, my - 2, flap, 4), bcol)
			draw_rect(Rect2(mx + 1, my - 2, flap, 4), bcol)
		else:
			draw_circle(Vector2(mx, my), 1.6, Color(1.0, 0.96, 0.72, 0.42))


func _draw_weather(zid: String) -> void:
	if zid in ["farmhouse", "greenhouse", "mine", "coral_island"]:
		return
	var w: String = GameState.weather
	if w != "rain" and w != "storm" and w != "snow":
		return
	var ppos: Vector2 = player.world_pos if player != null else Vector2(300, 300)
	for i in range(_rain_drops.size()):
		var pt: Vector2 = _rain_drops[i]
		var offset: Vector2 = Vector2(fmod(pt.x + _time_accum * (40.0 if w == "snow" else -90.0), 800.0) - 400.0, fmod(pt.y + _time_accum * (60.0 if w == "snow" else 340.0), 500.0) - 250.0)
		var wp: Vector2 = ppos + offset
		if w == "snow":
			draw_circle(wp, 2.0, Color(0.92, 0.96, 1.0, 0.78))
		else:
			draw_line(wp, wp + Vector2(-4, 12), Color(0.65, 0.82, 1.0, 0.55), 1.4)
