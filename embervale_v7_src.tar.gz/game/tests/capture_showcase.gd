extends Node2D

var mg: MainGame = null


func _ready() -> void:
	DisplayServer.window_set_title("回响山谷 - 实机截图巡检")
	get_tree().create_timer(15.0).timeout.connect(func():
		push_error("SHOWCASE TIMEOUT")
		get_tree().quit(0)
	)
	var main_sc: PackedScene = load("res://scenes/main.tscn")
	mg = main_sc.instantiate()
	mg._skip_ambient = true
	add_child(mg)
	call_deferred("_run_showcase")


func _save_shot(filename: String) -> void:
	await get_tree().process_frame
	await get_tree().process_frame
	var img: Image = get_viewport().get_texture().get_image()
	var out_dir: String = ProjectSettings.globalize_path("res://../reports/screenshots")
	DirAccess.make_dir_recursive_absolute(out_dir)
	var path: String = out_dir.path_join(filename)
	img.save_png(path)
	print("[SHOT] Saved: " + path)


func _run_showcase() -> void:
	await get_tree().process_frame
	await get_tree().process_frame

	# 0. Title Screen
	mg.title_modal.visible = true
	await _save_shot("00_title_screen.png")
	mg.title_modal.visible = false
	GameState.time_paused = false

	# 1. Farm Morning + Ecology Lens ON + Smart Tile Inspector + Tutorial Banner
	GameState.current_zone = "farm"
	GameState.player_grid = Vector2i(7, 13)
	mg.player.sync_pos_from_grid()
	mg.player.facing = 0
	mg.player.facing_vec = Vector2(0, 1)
	mg.player.target_grid = Vector2i(7, 14)
	mg._on_zone_changed("farm")
	mg.renderer.ecology_lens_active = true
	mg.hud.set_lens_indicator(true)
	mg.hud.set_inspector_text(mg.get_tile_inspection_text(Vector2i(7, 14)))
	mg.hud.show_toast("🌿 伴生生态共鸣透镜已激活：昼夜共生 +35% 生长速率！", Color(0.55, 0.98, 0.72))
	await _save_shot("01_farm_ecology_lens.png")

	# 2. Town Plaza + NPC Dialogue with WorldMemory
	mg.renderer.ecology_lens_active = false
	mg.hud.set_lens_indicator(false)
	WorldMemory.record_fact("giant_crop_harvested", "在农场种出了巨型作物", "linxia")
	mg.player.warp_to_zone("town", Vector2i(16, 12))
	mg.npc_sched.update_schedules_for_hour(12)
	mg.dlg_modal.open_npc("linxia")
	await _save_shot("02_town_dialogue.png")
	mg._close_all_modals()

	# 3. Mine Floor 5 Combat
	mg.zone_mgr.enter_mine_floor(5)
	mg.player.warp_to_zone("mine", Vector2i(11, 10))
	mg.mine_sys.populate_floor(mg.zone_mgr, 5)
	GameState.selected_hotbar = 4 # blade
	mg.hud.refresh()
	await _save_shot("03_mine_combat.png")

	# 4. Farm + Inventory & Crafting Modal
	mg.player.warp_to_zone("farm", Vector2i(9, 11))
	mg.inv_modal.open_modal()
	await _save_shot("04_inventory_crafting.png")
	mg._close_all_modals()

	# 5. Horn's Smithy Tool Upgrade UI
	GameState.add_item("copper_bar", 3, 0)
	mg.player.warp_to_zone("town", Vector2i(24, 8))
	mg.shop_modal.open_shop("horn_smithy")
	await _save_shot("05_smithy_tool_upgrades.png")
	mg._close_all_modals()

	# 6. Mine Floor 10 Echo Boss Fight
	mg.zone_mgr.enter_mine_floor(10)
	mg.player.warp_to_zone("mine", Vector2i(11, 10))
	mg.mine_sys.populate_floor(mg.zone_mgr, 10)
	GameState.selected_hotbar = 4
	mg.hud.refresh()
	await _save_shot("06_mine_floor10_boss.png")

	# 7. Sunny Ranch with Red Barn, Chickens, Cows & Sheep
	GameState.gold += 2000
	mg.ranch_sys.adopt_animal("cow")
	mg.ranch_sys.adopt_animal("sheep")
	mg.ranch_sys.adopt_animal("chicken")
	if GameState.ranch_animals.size() >= 3:
		(GameState.ranch_animals[0] as Dictionary)["x"] = 360.0
		(GameState.ranch_animals[0] as Dictionary)["y"] = 335.0
		(GameState.ranch_animals[1] as Dictionary)["x"] = 435.0
		(GameState.ranch_animals[1] as Dictionary)["y"] = 355.0
		(GameState.ranch_animals[2] as Dictionary)["x"] = 315.0
		(GameState.ranch_animals[2] as Dictionary)["y"] = 365.0
	mg.player.warp_to_zone("ranch", Vector2i(12, 10))
	mg.ranch_sys.pet_nearby_animal(Vector2(360.0, 335.0))
	mg.hud.show_toast("🐄 阳光牧场：每日抚摸动物提升好感，收获高星鲜蛋、牛奶与羊毛！", Color(1.0, 0.90, 0.52))
	await _save_shot("07_sunny_ranch_livestock.png")

	# 8. Farmhouse Kitchen Stove & Cooking Buffs Modal
	GameState.add_item("egg", 2, 0)
	GameState.add_item("turnip", 2, 0)
	GameState.add_item("clover", 2, 0)
	GameState.add_item("moonberry", 1, 0)
	mg.player.warp_to_zone("farmhouse", Vector2i(8, 4))
	mg.cooking_modal.open_cooking()
	await _save_shot("08_kitchen_cooking_buffs.png")
	mg._close_all_modals()

	# 9. v4.0 8th Zone: Secret Woods & Ancient Treant Boss + Shiba Companion
	mg.pet_sys.switch_pet_kind("dog")
	mg.player.warp_to_zone("secret_woods", Vector2i(13, 12))
	mg.player.facing = 3
	mg.player.facing_vec = Vector2(0, -1)
	mg.pet_sys.pet_pos = mg.player.world_pos + Vector2(-34.0, 12.0)
	mg.pet_sys.pet_bubble = "🐾 汪!发现秘林气息!"
	GameState.selected_hotbar = 4 # blade
	mg.hud.refresh()
	mg.hud.show_toast("🌲 第八区域【迷雾回响秘林】：砍伐千年铁木古桩，挑战远古树精守护者赢取远古星露种子！", Color(0.62, 1.0, 0.78))
	await _save_shot("09_secret_woods_treant.png")

	# 10. v4.0 Endgame Farm Wonders (Warp Obelisk + Golden Clock) + Ecological Fish Pond + Pet
	GameState.obelisk_built = true
	GameState.golden_clock_built = true
	GameState.fish_pond = {"fish_id": "fish_gold_carp", "count": 4, "days": 1}
	mg.zone_mgr.sync_farm_wonders()
	mg.player.warp_to_zone("farm", Vector2i(17, 10))
	mg.player.facing = 0
	mg.player.facing_vec = Vector2(0, 1)
	mg.pet_sys.pet_pos = mg.player.world_pos + Vector2(-32.0, 10.0)
	mg.pet_sys.pet_bubble = "❤️ 汪汪~"
	mg.hud.refresh()
	mg.hud.show_toast("👑 终局奇观落成：【回响方尖传送塔】零耗时折跃 &【黄金丰饶钟】锁满地力享 +25% 溢价！", Color(1.0, 0.88, 0.36))
	await _save_shot("10_farm_wonders_pond_pet.png")

	# 11. v4.0 Upgraded Farmhouse Marriage Co-op & Valley Perfection Tracker
	GameState.house_tier = 3
	GameState.max_energy = 180.0
	GameState.energy = 180.0
	GameState.dating_npcs["suwan"] = true
	GameState.spouse_id = "suwan"
	GameState.greenhouse_unlocked = true
	for cid_s in ["turnip", "sunbell", "moonberry", "clover", "ancient_fruit"]:
		GameState.collection_seen[cid_s] = true
	for did_s in ["dish_spring_salad", "dish_omelet", "dish_berry_muffin"]:
		GameState.collection_seen[did_s] = true
	mg.zone_mgr.sync_farm_wonders()
	mg.npc_sched.update_schedules_for_hour(20)
	mg.player.warp_to_zone("farmhouse", Vector2i(5, 5))
	mg._toggle_journal()
	await _save_shot("11_perfection_and_marriage.png")
	mg._close_all_modals()

	# 12. v5.0 9th Zone: Starlight Coral Island Tropical Plantation, Sailboat Ferry, Palm Trees & Tropical Synergy
	GameState.tutorial_step = 6
	mg.player.warp_to_zone("coral_island", Vector2i(14, 8))
	mg.player.facing = 0
	mg.player.facing_vec = Vector2(0, 1)
	mg.player.target_grid = Vector2i(11, 9)
	mg.renderer.ecology_lens_active = true
	mg.hud.set_lens_indicator(true)
	mg.pet_sys.pet_pos = mg.player.world_pos + Vector2(-34.0, 10.0)
	mg.pet_sys.pet_bubble = "🐾 汪!发现星光珍珠!"
	GameState.add_item("artisan_espresso", 2, 0)
	GameState.apply_food_buff(DataRegistry.get_item("artisan_espresso"))
	mg.hud.refresh()
	mg.hud.show_toast("🏝️ 第九区域【星露珊瑚群岛】：全年盛夏种黄金凤梨与星露咖啡，萃三倍浓缩咖啡享 +45% 疾驰！", Color(0.45, 0.98, 0.92))
	await _save_shot("12_coral_island_paradise.png")

	# 13. v6.0 Mobile Touch Edition: Left Virtual Thumbstick + Right Ergonomic Action Buttons + One-Handed Tap-to-Walk Ripple
	mg.mobile_overlay.set_mobile_enabled(true)
	mg.mobile_overlay.simulate_joystick_offset(Vector2(0.55, -0.35))
	mg.player.set_tap_walk_target(Vector2(11 * 32 + 16, 9 * 32 + 16), Vector2i(11, 9), true)
	GameState.selected_hotbar = 0
	mg.hud.refresh()
	mg.hud.show_toast("📱 v7.0 横屏双拇指模式：左手虚拟摇杆 + 右手大按键 + 单手点地自动寻路收菜！", Color(1.0, 0.92, 0.45))
	await _save_shot("13_mobile_touch_edition.png")

	# 14. v7.0 Forest Sprite Offline Idle Helper Welcome-Back Loot Modal
	mg._close_all_modals()
	mg.fairy_modal.open_modal(12600)
	await _save_shot("15_fairy_offline_idle_report.png")
	mg._close_all_modals()

	# 15. v7.0 Portrait One-Handed Subway Commute Mode (720x1280 Vertical Smartphone Screen!)
	mg.set_portrait_mode(true)
	mg.mobile_overlay.set_mobile_enabled(true)
	mg.mobile_overlay.simulate_joystick_offset(Vector2(0.45, -0.40))
	mg.hud.refresh()
	mg.hud.show_toast("📱 竖屏单手掌中模式：5×2双排拇指栏 + 点地自动收菜对话！", Color(0.68, 1.0, 0.84))
	await _save_shot("14_mobile_portrait_onehand.png")
	mg.set_portrait_mode(false)

	print("[SHOWCASE] All 16 GPU screenshots captured successfully.")
	get_tree().quit(0)
