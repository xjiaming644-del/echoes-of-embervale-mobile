extends Node

var passed: int = 0
var failed: int = 0


func _assert_true(cond: bool, msg: String) -> void:
	if cond:
		passed += 1
		print("[PASS] " + msg)
	else:
		failed += 1
		push_error("[FAIL] " + msg)
		print("[FAIL] " + msg)


func _ready() -> void:
	get_tree().create_timer(12.0).timeout.connect(func():
		push_error("TEST TIMEOUT")
		get_tree().quit(1)
	)
	call_deferred("_run_all")


func _run_all() -> void:
	print("=== 《星露物语：回响山谷》Godot 4.6 无头全系统仿真测试 ===")

	# Wait 1 frame so Autoloads finish _ready()
	await get_tree().process_frame

	var data_reg: Node = DataRegistry
	var asset_reg: Node = AssetRegistry
	var gs: Node = GameState
	var wm: Node = WorldMemory
	var sm: Node = SaveManager

	# 1. Data tables integrity
	var items: Array = data_reg.get_all_items()
	var crops: Array = data_reg.get_all_crops()
	var npcs: Array = data_reg.get_all_npcs()
	_assert_true(items.size() >= 99 and crops.size() == 15 and npcs.size() == 6,
		"1) JSON 数据表完整性校验 (items=%d, crops=%d, npcs=%d)" % [items.size(), crops.size(), npcs.size()])

	# 2. Art drop-in hot-swap test (non-destructively backup if present, verify fallback & override, then restore!)
	var test_rel: String = "icons/turnip.png"
	var dropin_path: String = ProjectSettings.globalize_path("res://../art_dropin/sprites/" + test_rel)
	var had_orig_dropin: bool = FileAccess.file_exists(dropin_path)
	var orig_dropin_bytes: PackedByteArray = FileAccess.get_file_as_bytes(dropin_path) if had_orig_dropin else PackedByteArray()
	if had_orig_dropin:
		DirAccess.remove_absolute(dropin_path)
	asset_reg.reload_all()
	var fallback_tag: String = asset_reg.get_source(test_rel)
	var test_img: Image = Image.create(32, 32, false, Image.FORMAT_RGBA8)
	test_img.fill(Color(0.9, 0.3, 0.4, 1.0))
	test_img.save_png(dropin_path)
	var reload_res: Dictionary = asset_reg.reload_all()
	var src_tag: String = asset_reg.get_source(test_rel)
	if had_orig_dropin:
		var restore_fa: FileAccess = FileAccess.open(dropin_path, FileAccess.WRITE)
		if restore_fa != null:
			restore_fa.store_buffer(orig_dropin_bytes)
			restore_fa.close()
	else:
		DirAccess.remove_absolute(dropin_path)
	asset_reg.reload_all()
	_assert_true(fallback_tag == "ai_placeholder" and src_tag == "human_override" and int(reload_res.get("human_sprites", 0)) >= 1,
		"2) art_dropin 人工美术零代码热替换覆盖与无损还原验证")

	# Instantiate MainGame in headless tree
	var main_scene: PackedScene = load("res://scenes/main.tscn")
	var mg: Node = main_scene.instantiate()
	mg.set("_skip_ambient", true)
	mg.set("_skip_title", true)
	get_tree().root.add_child(mg)
	await get_tree().process_frame

	var zm: ZoneManager = mg.get("zone_mgr")
	var fs: FarmingEcologySystem = mg.get("farm_sys")
	var art: ArtisanSystem = mg.get("artisan_sys")
	var ns: NPCScheduler = mg.get("npc_sched")
	var ms: MineCombatSystem = mg.get("mine_sys")
	var pl: PlayerController = mg.get("player")

	# 3. Farming + Ecology companion synergy test
	var p1: Vector2i = Vector2i(16, 16)
	var p2: Vector2i = Vector2i(17, 16)
	var tilled1: bool = fs.till_tile(zm, p1)
	var tilled2: bool = fs.till_tile(zm, p2)
	var watered1: bool = fs.water_tile(zm, p1)
	var watered2: bool = fs.water_tile(zm, p2)
	var planted1: bool = fs.plant_seed(zm, p1, "seed_sunbell")
	var planted2: bool = fs.plant_seed(zm, p2, "seed_moonberry")
	var eco1: Dictionary = fs.evaluate_tile_ecology(zm, p1)
	var syn_names: Array = eco1.get("active_synergies", [])
	_assert_true(tilled1 and tilled2 and watered1 and watered2 and planted1 and planted2 and syn_names.has("昼夜共生"),
		"3) 翻地->浇水->播种->[昼夜共生]伴生生态共鸣识别")

	# 4. Multi-day crop growth, sprinkler auto-watering, regrow & soil vitality
	zm.remove_object("farm", Vector2i(16, 17))
	gs.add_item("machine_quality_sprinkler", 1, 0)
	var sp_ok: bool = art.place_machine(zm, "farm", Vector2i(16, 17), "machine_quality_sprinkler")
	for _d in range(5):
		gs.weather = "rain" if _d == 1 else "sunny"
		fs.process_overnight(zm)
		gs.advance_to_next_morning()
	var ft_sunbell: Dictionary = fs.get_farm_tile(zm, p1)
	var sun_crop: Dictionary = ft_sunbell.get("crop", {})
	var ft_moon: Dictionary = fs.get_farm_tile(zm, p2)
	var harvested_sun: bool = fs.harvest_crop(zm, p1)
	var harvested_starter_moon: bool = fs.harvest_crop(zm, Vector2i(8, 14))
	var regrow_ft: Dictionary = fs.get_farm_tile(zm, Vector2i(8, 14))
	var regrow_crop: Dictionary = regrow_ft.get("crop", {})
	_assert_true(sp_ok and bool(sun_crop.get("mature", false)) and harvested_sun and bool(ft_moon.get("watered", false)) and harvested_starter_moon and not regrow_crop.is_empty() and not bool(regrow_crop.get("mature", true)),
		"4) 跨日生长、洒水器清晨浇水、成熟收获与复果作物周期验证")

	# 5. Artisan machine processing (jar + furnace)
	gs.add_item("turnip", 2, 0)
	gs.add_item("copper_ore", 5, 0)
	art.place_machine(zm, "farm", Vector2i(15, 16), "machine_furnace")
	var t_idx: int = -1
	var c_idx: int = -1
	for i in range(gs.inventory.size()):
		var sl: Dictionary = gs.inventory[i]
		if str(sl.get("id", "")) == "turnip":
			t_idx = i
		elif str(sl.get("id", "")) == "copper_ore":
			c_idx = i
	var jar_in: bool = art.interact_machine(zm, "farm", Vector2i(12, 7), t_idx)
	var fur_in: bool = art.interact_machine(zm, "farm", Vector2i(15, 16), c_idx)
	art.advance_hours(zm, 7.0)
	var before_pickles: int = gs.count_item("artisan_pickles")
	var before_bars: int = gs.count_item("copper_bar")
	art.interact_machine(zm, "farm", Vector2i(12, 7), -1)
	art.interact_machine(zm, "farm", Vector2i(15, 16), -1)
	_assert_true(jar_in and fur_in and gs.count_item("artisan_pickles") == before_pickles + 1 and gs.count_item("copper_bar") == before_bars + 1,
		"5) 果酱腌制桶与矿石熔炉加工计时及产物收取验证")

	# 6. Shipping bin overnight gold settlement
	var gold_before: int = gs.gold
	gs.add_shipping_item("artisan_pickles", 1, 0)
	var sum_res: Dictionary = gs.settle_overnight_shipping()
	_assert_true(int(sum_res.get("total_gold", 0)) == 165 and gs.gold == gold_before + 165,
		"6) 出货箱隔夜账单汇总与金币结算验证")

	# 7. Mine generation, rock mining & combat drops
	zm.enter_mine_floor(5)
	pl.warp_to_zone("mine", Vector2i(11, 14))
	ms.populate_floor(zm, 5)
	var mine_z: Dictionary = zm.get_zone("mine")
	var mine_objs: Dictionary = mine_z.get("objects", {})
	var broke_rock: bool = false
	for ok in mine_objs.keys():
		var obj: Dictionary = mine_objs[ok]
		if str(obj.get("type", "")) == "mine_rock":
			var gp: Vector2i = ZoneManager.parse_key(str(ok))
			for _h in range(4):
				ms.hit_mine_rock(zm, gp)
			broke_rock = true
			break
	var had_monsters: bool = ms.monsters.size() > 0
	var killed: int = 0
	if had_monsters:
		var m0: Dictionary = ms.monsters[0]
		var mp: Vector2 = m0["pos"]
		for _s in range(4):
			killed += ms.swing_blade_at(zm, mp - Vector2(16, 0), Vector2(1, 0))
	_assert_true(broke_rock and had_monsters and killed >= 1 and gs.mine_max_floor >= 5,
		"7) 矿洞第5层电梯解锁、挖矿与猎镰剑击杀怪物验证")

	# 8. NPC AStar pathfinding & WorldMemory rumor spread
	var path: Array = ns.compute_path("town", Vector2i(8, 8), Vector2i(16, 11))
	wm.record_fact("test_rumor", "玩家种出了神奇伴生花田", "linxia")
	var spread1: String = wm.try_spread_rumor("linxia", "horn")
	var spread2: String = wm.try_spread_rumor("linxia", "horn")
	var f_entry: Dictionary = wm.facts.get("test_rumor", {})
	var known_by: Array = f_entry.get("known_by", [])
	_assert_true(path.size() >= 4 and (spread1 == "test_rumor" or spread2 == "test_rumor") and known_by.has("horn"),
		"8) 村民 AStarGrid2D 寻路与 WorldMemory 传闻跨村民扩散验证")

	# 9. Echo Shrine bundle submission & reward unlock
	var shrine: ShrineQuestModal = mg.get("shrine_modal")
	gs.add_item("turnip", 2, 0)
	gs.add_item("sunbell", 1, 0)
	gs.add_item("moonberry", 1, 0)
	gs.add_item("clover", 2, 0)
	shrine.submit_bundle_item("bundle_spring_sprout", "turnip")
	shrine.submit_bundle_item("bundle_spring_sprout", "sunbell")
	shrine.submit_bundle_item("bundle_spring_sprout", "moonberry")
	shrine.submit_bundle_item("bundle_spring_sprout", "clover")
	var bp: Dictionary = gs.bundle_progress.get("bundle_spring_sprout", {})
	_assert_true(bool(bp.get("completed", false)) and gs.count_item("machine_quality_sprinkler") >= 2,
		"9) 回响祭坛收集包献祭完成与优质洒水器奖励发放验证")

	# 10. Save & Load round-trip integrity
	var saved_gold: int = gs.gold
	var saved_day: int = gs.day
	var saved_ok: bool = sm.save_game(3, zm, ns)
	gs.gold = 1
	gs.day = 99
	var loaded_ok: bool = sm.load_game(3, zm, ns)
	sm.delete_save(3)
	_assert_true(saved_ok and loaded_ok and gs.gold == saved_gold and gs.day == saved_day,
		"10) 完整世界状态 JSON 存档与读档一致性验证")

	# 11. Blacksmith tool upgrades & 3x3 AoE farming
	gs.gold += 2000
	gs.add_item("copper_bar", 2, 0)
	gs.add_item("iron_bar", 2, 0)
	var up1: Dictionary = gs.upgrade_tool("hoe")
	var up2: Dictionary = gs.upgrade_tool("hoe")
	var h_lvl: int = gs.get_tool_level("hoe")
	pl.warp_to_zone("farm", Vector2i(20, 6))
	pl.facing_vec = Vector2(0, 1)
	pl.target_grid = Vector2i(20, 7)
	for dy in range(-1, 2):
		for dx in range(-1, 2):
			zm.remove_object("farm", Vector2i(20 + dx, 7 + dy))
	gs.selected_hotbar = 0 # tool_hoe
	pl.use_primary(zm, fs, art, ms)
	var tilled_aoe_cnt: int = 0
	for dy2 in range(-1, 2):
		for dx2 in range(-1, 2):
			var ft_aoe: Dictionary = fs.get_farm_tile(zm, Vector2i(20 + dx2, 7 + dy2))
			if bool(ft_aoe.get("tilled", false)):
				tilled_aoe_cnt += 1
	_assert_true(bool(up1.get("ok", false)) and bool(up2.get("ok", false)) and h_lvl == 3 and tilled_aoe_cnt == 9,
		"11) 铁匠铺工具四阶锻造升级与 3x3 九宫格翻地验证")

	# 12. Harvest Festival Day 14 (1.5x shipping bonus + friendship)
	gs.day = 14
	var lin_pts_before: int = int((gs.npc_friendship.get("linxia", {}) as Dictionary).get("points", 0))
	var fest_gold_before: int = gs.gold
	gs.add_shipping_item("turnip", 2, 0) # 2 * 60 = 120 -> 1.5x = 180
	var fest_sum: Dictionary = gs.settle_overnight_shipping()
	gs.day = 13
	gs.advance_to_next_morning() # Advances to day 14 -> triggers festival +30 friendship
	var lin_pts_after: int = int((gs.npc_friendship.get("linxia", {}) as Dictionary).get("points", 0))
	_assert_true(gs.is_harvest_festival_day() and int(fest_sum.get("total_gold", 0)) == 180 and int(fest_sum.get("festival_bonus", 0)) == 60 and gs.gold == fest_gold_before + 180 and lin_pts_after >= lin_pts_before + 30,
		"12) 四季丰收品鉴日 1.5x 出货庆典溢价与全员好感加成验证")

	# 13. Smart Tile & Machine Inspector text generation
	var crop_insp: String = mg.get_tile_inspection_text(Vector2i(7, 14))
	var mach_insp: String = mg.get_tile_inspection_text(Vector2i(12, 7))
	_assert_true(crop_insp.contains("向阳铃") and crop_insp.contains("地力") and mach_insp.contains("果酱腌制桶"),
		"13) 智能地块与工匠机器实时探查信息生成验证")

	# 14. Four-Season Ecological Greenhouse (winter out-of-season growth)
	gs.greenhouse_unlocked = true
	gs.season_idx = 3 # winter
	var gh_plant_ok: bool = fs.plant_seed(zm, Vector2i(4, 4), "seed_turnip", "greenhouse")
	fs.water_tile(zm, Vector2i(4, 4), "greenhouse")
	fs.process_overnight(zm)
	var gh_ft: Dictionary = fs.get_farm_tile(zm, Vector2i(4, 4), "greenhouse")
	var gh_crop: Dictionary = gh_ft.get("crop", {})
	_assert_true(gh_plant_ok and not gh_crop.is_empty() and float(gh_crop.get("growth_days", 0.0)) >= 1.0,
		"14) 四季生态温室解锁与冬季反季节播种生长验证")

	# 15. Mine Floor 10 Echo Boss spawn & kill rewards
	zm.enter_mine_floor(10)
	pl.warp_to_zone("mine", Vector2i(11, 8))
	ms.populate_floor(zm, 10)
	var boss_found: bool = false
	var boss_pos: Vector2 = Vector2.ZERO
	for m in ms.monsters:
		var md: Dictionary = m
		if str(md.get("kind", "")) == "echo_boss":
			boss_found = true
			boss_pos = md["pos"]
			break
	if boss_found:
		for _b in range(25):
			ms.swing_blade_at(zm, boss_pos - Vector2(12, 0), Vector2(1, 0))
	var boss_still_alive: bool = false
	for m2 in ms.monsters:
		if str((m2 as Dictionary).get("kind", "")) == "echo_boss":
			boss_still_alive = true
	_assert_true(boss_found and not boss_still_alive and wm.facts.has("boss_defeated"),
		"15) 矿洞第10层回响晶甲王Boss生成与讨伐掉落验证")

	# 16. NPC 4-heart keepsake unlock & passive bonus
	var lin_f: Dictionary = gs.npc_friendship["linxia"]
	lin_f["points"] = 1050
	gs.npc_friendship["linxia"] = lin_f
	var dlg: DialogueModal = mg.get("dlg_modal")
	dlg.open_npc("linxia")
	dlg.visible = false
	gs.time_paused = false
	var gh_eco: Dictionary = fs.evaluate_tile_ecology(zm, Vector2i(4, 4), "greenhouse")
	_assert_true(gs.has_keepsake("linxia") and float(gh_eco.get("speed_bonus", 0.0)) >= 0.35,
		"16) 村民4心羁绊信物解锁与被动增益生效验证")

	# 17. Town Festival Judge & 6-step Tutorial progression
	gs.tutorial_step = 0
	var g_before_tut: int = gs.gold
	for ts in range(6):
		gs.advance_tutorial(ts)
	var judge_res: Dictionary = mg.call("judge_festival_entry", "ember_pumpkin", 2)
	_assert_true(gs.tutorial_step == 6 and gs.gold == g_before_tut + 150 + 500 and str(judge_res.get("rank", "")).contains("金穗"),
		"17) 广场丰收品鉴评比台评分奖励与新手引导推进验证")

	# 18. Sunny Ranch zone, animal adoption, petting affection & overnight egg/milk production
	var rs: RanchSystem = mg.get("ranch_sys")
	gs.gold += 1500
	var adopt_cow: Dictionary = rs.adopt_animal("cow")
	var adopt_sheep: Dictionary = rs.adopt_animal("sheep")
	pl.warp_to_zone("ranch", Vector2i(12, 10))
	var a0: Dictionary = gs.ranch_animals[0]
	var aff_before: int = int(a0.get("affection", 0))
	var pet_ok: bool = rs.pet_nearby_animal(Vector2(float(a0.get("x", 384.0)), float(a0.get("y", 336.0))))
	var aff_after: int = int((gs.ranch_animals[0] as Dictionary).get("affection", 0))
	gs.trough_hay = 10
	var prod_cnt: int = rs.process_overnight(zm)
	var ranch_drops: Array = zm.get_zone("ranch").get("drops", [])
	_assert_true(bool(adopt_cow.get("ok", false)) and bool(adopt_sheep.get("ok", false)) and pet_ok and aff_after > aff_before and prod_cnt >= 3 and ranch_drops.size() >= 3,
		"18) 阳光牧场动物领养、每日抚摸好感提升与隔夜产蛋产奶验证")

	# 19. Mayo & Cheese artisan machines processing
	gs.add_item("egg", 1, 0)
	gs.add_item("milk", 1, 0)
	var egg_slot: int = -1
	var milk_slot: int = -1
	for si in range(gs.inventory.size()):
		var sd_i: Dictionary = gs.inventory[si]
		if str(sd_i.get("id", "")) == "egg":
			egg_slot = si
		elif str(sd_i.get("id", "")) == "milk":
			milk_slot = si
	var mayo_in: bool = art.interact_machine(zm, "ranch", Vector2i(18, 7), egg_slot)
	var cheese_in: bool = art.interact_machine(zm, "ranch", Vector2i(20, 7), milk_slot)
	art.advance_hours(zm, 6.0)
	var mayo_before: int = gs.count_item("artisan_mayo")
	var cheese_before: int = gs.count_item("artisan_cheese")
	art.interact_machine(zm, "ranch", Vector2i(18, 7), -1)
	art.interact_machine(zm, "ranch", Vector2i(20, 7), -1)
	_assert_true(mayo_in and cheese_in and gs.count_item("artisan_mayo") == mayo_before + 1 and gs.count_item("artisan_cheese") == cheese_before + 1,
		"19) 蛋黄酱机与奶酪压制机牧场深加工验证")

	# 20. Farmhouse Kitchen Cooking & Timed Food Buff activation
	var cook_m: CookingModal = mg.get("cooking_modal")
	gs.add_item("egg", 1, 0)
	gs.add_item("turnip", 1, 0)
	var omelet_rec: Dictionary = {}
	for cr in data_reg.get_cooking_recipes():
		var cd_r: Dictionary = cr
		if str(cd_r.get("output_id", "")) == "dish_omelet":
			omelet_rec = cd_r
			break
	var cooked_and_ate: bool = cook_m.cook_dish(omelet_rec, true)
	var spd_bonus: float = gs.get_total_move_speed_bonus()
	_assert_true(cooked_and_ate and spd_bonus >= 0.25 and not gs.get_active_buff_text().is_empty(),
		"20) 农舍料理灶台烹饪【田园煎蛋卷】及实时移速 Buff 生效验证")

	# 21. Valley Overview Map & Fast Travel
	var map_m: WorldMapModal = mg.get("map_modal")
	map_m.open_map()
	map_m.fast_travel_requested.emit("lake", Vector2i(13, 6))
	map_m.visible = false
	gs.time_paused = false
	_assert_true(gs.current_zone == "lake" and gs.player_grid == Vector2i(13, 6),
		"21) 山谷手绘全景地图打开与户外区域快捷漫步传送验证")

	# 22. Parabolic Bouncing Loot Drop Physics & Magnetic Pickup
	zm.spawn_drop("lake", pl.world_pos + Vector2(10, 0), "echo_shell", 1, 0)
	var shell_before: int = gs.count_item("echo_shell")
	for _tk in range(12):
		pl.tick(0.08, zm, Vector2.ZERO, false, pl.world_pos, false)
	_assert_true(gs.count_item("echo_shell") >= shell_before + 1,
		"22) 抛物线弹跳掉落物重力结算与自动磁吸拾取验证")

	# 23. 6 Villagers, Farmhouse 3-tier Upgrade, Romance Confession, Marriage & Spouse Morning Chores
	gs.gold += 9000
	gs.add_item("wood", 50, 0)
	gs.add_item("stone", 30, 0)
	gs.add_item("hardwood", 15, 0)
	gs.add_item("iron_bar", 5, 0)
	var h_up2: Dictionary = gs.upgrade_house()
	var h_up3: Dictionary = gs.upgrade_house()
	var sw_f: Dictionary = gs.npc_friendship["suwan"]
	sw_f["points"] = 2100
	gs.npc_friendship["suwan"] = sw_f
	dlg.open_npc("suwan") # unlocks 4-heart keepsake
	dlg.open_npc("suwan") # triggers 6-heart story event
	gs.add_item("bouquet", 1, 0)
	gs.add_item("mermaid_pendant", 1, 0)
	for si2 in range(gs.inventory.size()):
		if str((gs.inventory[si2] as Dictionary).get("id", "")) == "bouquet":
			gs.selected_hotbar = si2
			break
	dlg._on_gift_pressed()
	var dated_ok: bool = bool(gs.dating_npcs.get("suwan", false))
	for si3 in range(gs.inventory.size()):
		if str((gs.inventory[si3] as Dictionary).get("id", "")) == "mermaid_pendant":
			gs.selected_hotbar = si3
			break
	dlg._on_gift_pressed()
	dlg.visible = false
	gs.time_paused = false
	ns.update_schedules_for_hour(20)
	var sw_zone_night: String = str((ns.npc_states["suwan"] as Dictionary).get("zone", ""))
	var dry_ft: Dictionary = fs.get_farm_tile(zm, Vector2i(7, 15))
	dry_ft["watered"] = false
	fs.set_farm_tile(zm, Vector2i(7, 15), dry_ft)
	var om_before: int = gs.count_item("dish_omelet")
	mg.call("_perform_spouse_morning_chore")
	var wet_after: bool = bool(fs.get_farm_tile(zm, Vector2i(7, 15)).get("watered", false))
	_assert_true(bool(h_up2.get("ok", false)) and bool(h_up3.get("ok", false)) and gs.house_tier == 3 and gs.has_keepsake("suwan") and gs.seen_heart_events.has("suwan_6") and dated_ok and gs.spouse_id == "suwan" and sw_zone_night == "farmhouse" and wet_after and gs.count_item("dish_omelet") == om_before + 1,
		"23) 6位村民好感剧情、三阶庄园扩建、花束表白/人鱼吊坠结婚同居与伴侣晨间家务验证")

	# 24. 8th Zone Secret Woods: Hardwood Stumps, Ancient Treant Boss & Ancient Starlight Fruit
	pl.warp_to_zone("secret_woods", Vector2i(12, 8))
	var had_stump: bool = str(zm.get_object("secret_woods", Vector2i(6, 5)).get("type", "")) == "hardwood_stump"
	for _ch in range(4):
		pl._use_axe(zm, Vector2i(6, 5))
	var stump_chopped: bool = zm.get_object("secret_woods", Vector2i(6, 5)).is_empty()
	var treant_pos: Vector2 = Vector2.ZERO
	var found_treant: bool = false
	for m_sw in ms.monsters:
		var md_sw: Dictionary = m_sw
		if str(md_sw.get("kind", "")) == "ancient_treant":
			found_treant = true
			treant_pos = md_sw["pos"]
			break
	if found_treant:
		for _swk in range(25):
			ms.swing_blade_at(zm, treant_pos - Vector2(12, 0), Vector2(1, 0))
	gs.add_item("seed_ancient_fruit", 1, 0)
	var af_plant_ok: bool = fs.plant_seed(zm, Vector2i(6, 6), "seed_ancient_fruit", "greenhouse")
	for _afd in range(15):
		fs.water_tile(zm, Vector2i(6, 6), "greenhouse")
		fs.process_overnight(zm)
	var af_harvest_ok: bool = fs.harvest_crop(zm, Vector2i(6, 6), "greenhouse")
	_assert_true(had_stump and stump_chopped and found_treant and wm.facts.has("treant_defeated") and af_plant_ok and af_harvest_ok and gs.count_item("ancient_fruit") >= 1,
		"24) 第八区域【迷雾回响秘林】铁木古桩砍伐、远古树精王讨伐与远古星露果种植验证")

	# 25. Loyal Pet Companion (Cat/Dog, Petting, Truffle Dig) & Fish Pond -> Golden Caviar
	var ps: PetFishPondSystem = mg.get("pet_sys")
	ps.switch_pet_kind("dog")
	gs.pet_data["petted_today"] = false
	var pet_comp_ok: bool = ps.try_pet_companion(ps.pet_pos)
	var dig_ok: bool = ps.try_dig_treasure(zm, "secret_woods")
	gs.add_item("fish_gold_carp", 1, 0)
	var carp_slot: int = -1
	for si4 in range(gs.inventory.size()):
		if str((gs.inventory[si4] as Dictionary).get("id", "")) == "fish_gold_carp":
			carp_slot = si4
			break
	ps.interact_fish_pond(carp_slot)
	var roe_produced: int = ps.process_overnight(zm)
	gs.add_item("fish_roe", 1, 0)
	zm.remove_object("farm", Vector2i(14, 16))
	gs.add_item("machine_jar", 1, 0)
	art.place_machine(zm, "farm", Vector2i(14, 16), "machine_jar")
	var roe_slot: int = -1
	for si5 in range(gs.inventory.size()):
		if str((gs.inventory[si5] as Dictionary).get("id", "")) == "fish_roe":
			roe_slot = si5
			break
	var cav_in: bool = art.interact_machine(zm, "farm", Vector2i(14, 16), roe_slot)
	art.advance_hours(zm, 7.0)
	var cav_before: int = gs.count_item("artisan_caviar")
	art.interact_machine(zm, "farm", Vector2i(14, 16), -1)
	_assert_true(str(gs.pet_data.get("kind", "")) == "dog" and pet_comp_ok and dig_ok and int(gs.fish_pond.get("count", 0)) >= 1 and roe_produced >= 1 and cav_in and gs.count_item("artisan_caviar") == cav_before + 1,
		"25) 萌宠伙伴(橘猫/柴犬)切换、抚摸寻宝与活水鱼塘产鱼籽酿造黄金鱼籽酱验证")

	# 26. Endgame Wonders (Warp Obelisk & Golden Clock +25% Shipping + 100 Vitality) & Valley Perfection
	gs.gold += 25000
	gs.add_item("echo_crystal", 10, 0)
	gs.add_item("hardwood", 15, 0)
	gs.add_item("gold_bar", 8, 0)
	var ob_res: Dictionary = gs.build_obelisk()
	var gc_res: Dictionary = gs.build_golden_clock()
	zm.sync_farm_wonders()
	var has_ob_obj: bool = str(zm.get_object("farm", Vector2i(15, 6)).get("type", "")) == "obelisk"
	var has_gc_obj: bool = str(zm.get_object("farm", Vector2i(19, 6)).get("type", "")) == "golden_clock"
	mg.call("_obelisk_warp", "lake", Vector2i(13, 8))
	fs.process_overnight(zm)
	var locked_vit: float = float(fs.get_farm_tile(zm, Vector2i(7, 14)).get("soil_vitality", 0.0))
	gs.day = 15
	gs.npc_keepsakes["mei"] = false
	gs.shipping_queue.clear()
	gs.add_shipping_item("ancient_fruit", 1, 0) # 750 * 1.25 = 938
	var gc_sum: Dictionary = gs.settle_overnight_shipping()
	var perf_d: Dictionary = gs.compute_valley_perfection()
	var p_badges: Array = perf_d.get("badges", [])
	_assert_true(bool(ob_res.get("ok", false)) and bool(gc_res.get("ok", false)) and has_ob_obj and has_gc_obj and gs.current_zone == "lake" and locked_vit >= 100.0 and int(gc_sum.get("total_gold", 0)) == 938 and int(perf_d.get("percent", 0)) >= 40 and p_badges.has("👑 黄金传奇") and p_badges.has("💍 琴瑟和鸣"),
		"26) 终局奇观【回响方尖传送塔】与【黄金丰饶钟】(锁满地力+1.25x出货)及山谷完美度徽章验证")

	# 27. Inventory 1-Click Sort/Merge & Shift Half-Stack Split
	gs.add_item("stone", 6, 0)
	var empty_s: int = -1
	for si6 in range(gs.inventory.size()):
		if (gs.inventory[si6] as Dictionary).is_empty():
			empty_s = si6
			break
	if empty_s >= 0:
		gs.inventory[empty_s] = {"id": "stone", "count": 4, "quality": 0}
	gs.sort_and_merge_inventory()
	var stone_slots_after_merge: int = 0
	var merged_stone_idx: int = -1
	for si7 in range(gs.inventory.size()):
		if str((gs.inventory[si7] as Dictionary).get("id", "")) == "stone":
			stone_slots_after_merge += 1
			merged_stone_idx = si7
	var split_ok: bool = gs.split_slot_half(merged_stone_idx)
	var stone_slots_after_split: int = 0
	for si8 in range(gs.inventory.size()):
		if str((gs.inventory[si8] as Dictionary).get("id", "")) == "stone":
			stone_slots_after_split += 1
	_assert_true(stone_slots_after_merge == 1 and split_ok and stone_slots_after_split == 2,
		"27) 背包一键分类合并整理与 Shift 半数拆分功能验证")

	# 28. Native Gamepad Button Dispatch Compatibility
	mg.call("_close_all_modals")
	var hb0: int = gs.selected_hotbar
	mg.handle_joypad_button(JOY_BUTTON_RIGHT_SHOULDER)
	var hb1: int = gs.selected_hotbar
	mg.handle_joypad_button(JOY_BUTTON_Y)
	var inv_opened_by_pad: bool = mg.inv_modal.visible
	mg.handle_joypad_button(JOY_BUTTON_B)
	var inv_closed_by_pad: bool = not mg.inv_modal.visible
	mg.handle_joypad_button(JOY_BUTTON_START)
	var jrn_opened_by_pad: bool = mg.journal_panel.visible
	mg.call("_close_all_modals")
	_assert_true(hb1 == (hb0 + 1) % gs.HOTBAR_SIZE and inv_opened_by_pad and inv_closed_by_pad and jrn_opened_by_pad,
		"28) 原生手柄 (Xbox/Switch/PS) 快捷栏切换与面板开关映射验证")

	# 29. Atomic Save (.tmp) & Corrupted/Truncated JSON .bak Auto-Recovery
	sm.delete_save(3)
	gs.gold = 7788
	gs.day = 19
	var s29_ok: bool = sm.save_game(3, zm, ns)
	var slot3_main: String = sm._get_save_path(3)
	var slot3_bak: String = sm._get_backup_path(3)
	var slot3_tmp: String = sm._get_tmp_path(3)
	var no_tmp_left: bool = not FileAccess.file_exists(slot3_tmp)
	var bak_exists: bool = FileAccess.file_exists(slot3_bak)
	var bad_fa: FileAccess = FileAccess.open(slot3_main, FileAccess.WRITE)
	if bad_fa != null:
		bad_fa.store_string("{corrupted_truncated_json")
		bad_fa.close()
	var has_s29: bool = sm.has_save(3)
	gs.gold = 1
	gs.day = 2
	var rec29_ok: bool = sm.load_game(3, zm, ns)
	var healed_main: bool = not sm._parse_valid_save(slot3_main).is_empty()
	sm.delete_save(3)
	_assert_true(s29_ok and no_tmp_left and bak_exists and has_s29 and rec29_ok and gs.gold == 7788 and gs.day == 19 and healed_main,
		"29) 存档原子写入 (.tmp) 与主存档截断损坏自动回退 (.bak) 自愈恢复验证")

	# 30. Zero-Warning Responsive Expand UIRoot Anchor Layout, F10/HUD Mute Toggle Sync & Headless-Safe F11 Fullscreen
	var vp_sz: Vector2 = mg.get_viewport_rect().size
	var ui_size_ok: bool = (vp_sz.x >= 1280.0 and vp_sz.y >= 720.0 and mg.ui_root.size == vp_sz and mg.hud.size == vp_sz and mg.mobile_overlay.size == vp_sz)
	AudioManager.set_muted(false)
	mg.hud.refresh()
	var btn_unmuted_txt: String = mg.hud.mute_btn.text
	mg.hud.action_button_pressed.emit("toggle_mute")
	var muted_after_hud: bool = AudioManager.muted
	var btn_muted_txt: String = mg.hud.mute_btn.text
	var unmuted_again: bool = not mg.toggle_audio_mute()
	var btn_restored_txt: String = mg.hud.mute_btn.text
	var fs_safe_noop: bool = not mg.toggle_fullscreen()
	_assert_true(ui_size_ok and btn_unmuted_txt == "🔊静音" and muted_after_hud and btn_muted_txt == "🔇开启" and unmuted_again and btn_restored_txt == "🔊静音" and fs_safe_noop,
		"30) UIRoot 全屏锚点零告警布局、F10/HUD 一键静音同步与 F11 全屏无头安全验证")

	# 31. 100% Full Drop-in Coverage (189/189 Stardew Sprites + 18/18 Stereo Acoustic WAVs & Dynamic Loop Frames)
	var sp_reload: Dictionary = AssetRegistry.reload_all()
	var au_human: int = AudioManager.reload_all()
	var t_atlas: Texture2D = AssetRegistry.get_tex("tiles/terrain_atlas.png")
	var p_sheet_tex: Texture2D = AssetRegistry.get_tex("characters/player_sheet.png")
	var crop_af_tex: Texture2D = AssetRegistry.get_tex("crops/crop_pineapple.png")
	var bgm_st: AudioStreamWAV = AudioManager._streams.get("bgm_island_loop.wav", null)
	var full_sp_ok: bool = (int(sp_reload.get("human_sprites", 0)) == 189 and int(sp_reload.get("total_sprites", 0)) == 189)
	var full_au_ok: bool = (au_human == 18 and bgm_st != null and bgm_st.stereo and bgm_st.loop_end == 352800)
	var hd_dims_ok: bool = (t_atlas != null and t_atlas.get_width() == 640 and p_sheet_tex != null and p_sheet_tex.get_width() == 256 and crop_af_tex != null and crop_af_tex.get_width() == 320)
	_assert_true(full_sp_ok and full_au_ok and hd_dims_ok,
		"31) 全量 189/189 星露谷像素精灵 + 18/18 立体声原声 WAV 100% 热替换覆盖与 2x 图集尺寸验证")

	# 32. v5.0 9th Zone Coral Island Ferry, Winter-Proof Pineapple/Coffee Synergy & Triple Espresso (+45% Speed)
	for si_clr in range(10, gs.inventory.size()):
		gs.inventory[si_clr] = {}
	gs.season_idx = 3 # Winter! Coral Island must still allow planting & growing tropical crops
	pl.warp_to_zone("lake", Vector2i(14, 12))
	pl.target_grid = Vector2i(15, 12)
	pl.interact(zm, fs, art, ns, pl.world_pos)
	var sailed_to_island: bool = (gs.current_zone == "coral_island")
	var island_insp: String = mg.get_tile_inspection_text(Vector2i(11, 9))
	var island_insp_ok: bool = (island_insp.find("黄金凤梨") >= 0 and island_insp.find("热带蕉林共鸣") >= 0)
	var island_eco: Dictionary = fs.evaluate_tile_ecology(zm, Vector2i(11, 9), "coral_island")
	var island_syns: Array = island_eco.get("active_synergies", [])
	var pa_before: int = gs.count_item("pineapple")
	var cf_before: int = gs.count_item("star_coffee")
	fs.harvest_crop(zm, Vector2i(11, 9), "coral_island")
	fs.harvest_crop(zm, Vector2i(12, 9), "coral_island")
	var winter_plant_ok: bool = fs.till_tile(zm, Vector2i(16, 10), "coral_island") and fs.plant_seed(zm, Vector2i(16, 10), "seed_pineapple", "coral_island")
	gs.add_item("star_coffee", 3, 0)
	var cf_slot: int = -1
	for si9 in range(gs.inventory.size()):
		if str((gs.inventory[si9] as Dictionary).get("id", "")) == "star_coffee" and int((gs.inventory[si9] as Dictionary).get("count", 0)) >= 3:
			cf_slot = si9
			break
	var esp_in: bool = art.interact_machine(zm, "coral_island", Vector2i(21, 9), cf_slot)
	art.advance_hours(zm, 4.0)
	var esp_before: int = gs.count_item("artisan_espresso")
	art.interact_machine(zm, "coral_island", Vector2i(21, 9), -1)
	gs.apply_food_buff(data_reg.get_item("artisan_espresso"))
	var esp_speed_ok: bool = is_equal_approx(float(gs.active_buff.get("speed", 0.0)), 0.45)
	_assert_true(sailed_to_island and island_insp_ok and island_syns.has("热带蕉林共鸣") and gs.count_item("pineapple") > pa_before and gs.count_item("star_coffee") > cf_before and winter_plant_ok and esp_in and gs.count_item("artisan_espresso") == esp_before + 1 and esp_speed_ok,
		"32) 第九区域【星露珊瑚群岛】渡船航行、寒冬恒温凤梨&咖啡伴生共鸣与三倍浓缩咖啡(+45%移速)验证")

	# 33. 5-Track Dynamic Seasonal & Coral Island Stereo BGM Context Switching
	var tr_sp: String = AudioManager.sync_bgm_for_context("farm", "spring")
	var tr_su: String = AudioManager.sync_bgm_for_context("town", "summer")
	var tr_au: String = AudioManager.sync_bgm_for_context("ranch", "autumn")
	var tr_wi: String = AudioManager.sync_bgm_for_context("lake", "winter")
	var tr_is: String = AudioManager.sync_bgm_for_context("coral_island", "winter")
	_assert_true(tr_sp == "valley_breeze_loop.wav" and tr_su == "bgm_summer_loop.wav" and tr_au == "bgm_autumn_loop.wav" and tr_wi == "bgm_winter_loop.wav" and tr_is == "bgm_island_loop.wav",
		"33) 四季与珊瑚群岛 5 首立体声背景乐 (春/夏/秋/冬/海岛) 动态情境自动切换验证")

	# 34. Fishing Minigame Sunken Pirate Treasure Chest Collection & Bonus Reward
	gs.energy = gs.max_energy
	gs.inventory[33] = {}
	gs.inventory[34] = {}
	gs.inventory[35] = {}
	var gold_b34: int = gs.gold
	mg.fish_modal.start_fishing("coral_island")
	mg.fish_modal.force_spawn_treasure(130.0)
	for _fi in range(25):
		mg.fish_modal.bar_y = 100.0
		mg.fish_modal.bar_vel = 0.0
		mg.fish_modal.fish_y = 130.0
		mg.fish_modal.fish_target_y = 130.0
		mg.fish_modal.fish_timer = 10.0
		mg.fish_modal._process(0.1)
		if not mg.fish_modal.active:
			break
	if mg.fish_modal.active:
		mg.fish_modal._finish_fishing(true)
	_assert_true(mg.fish_modal.treasure_collected and not mg.fish_modal.last_treasure_reward.is_empty() and gs.gold == gold_b34 + 180 and gs.count_item(mg.fish_modal.last_treasure_reward) >= 1,
		"34) 垂钓绿条【海底沉船宝箱】悬停打捞与珍宝金币额外奖励结算验证")

	# 35. Built-in Graduate Showcase Save (Slot 2) Non-Destructive Seeding & 1-Click Load
	var seeded_s2: bool = sm.ensure_graduate_showcase_save(2, zm, ns, true)
	gs.gold = 123
	gs.house_tier = 1
	var loaded_s2: bool = sm.load_game(2, zm, ns)
	var vault_s2: String = ProjectSettings.globalize_path("res://../archives/saves_backup/slot_2_graduate_showcase.json")
	_assert_true(seeded_s2 and loaded_s2 and gs.gold == 28800 and gs.house_tier == 3 and gs.obelisk_built and gs.golden_clock_built and FileAccess.file_exists(vault_s2),
		"35) 内置【毕业体验档(槽2)】自动生成、保险库备份与主菜单一键读取验证")

	# 36. Mobile Virtual Thumbstick Movement, Right Tactile Buttons & HUD Toggle
	mg._close_all_modals()
	mg.mobile_overlay.set_mobile_enabled(false)
	var mob_on: bool = mg.toggle_mobile_controls()
	pl.warp_to_zone("farm", Vector2i(10, 11))
	var x_before_joy: float = pl.world_pos.x
	mg.mobile_overlay.simulate_joystick_offset(Vector2(1.0, 0.0))
	for _mj in range(5):
		mg._process(0.08)
	var x_after_joy: float = pl.world_pos.x
	mg.mobile_overlay.simulate_joystick_offset(Vector2.ZERO)
	gs.selected_hotbar = 0 # hoe
	mg.mobile_overlay.action_use_primary.emit()
	_assert_true(mob_on and mg.mobile_overlay.visible and x_after_joy > x_before_joy + 18.0,
		"36) 手机触屏虚拟摇杆360度移动、右手大尺寸使用/交互按键与HUD触屏开关验证")

	# 37. One-Handed Commute Tap-to-Walk + Automatic Smart Harvest on Arrival
	pl.warp_to_zone("farm", Vector2i(8, 12))
	zm.remove_object("farm", Vector2i(11, 12))
	fs.set_farm_tile(zm, Vector2i(11, 12), {
		"tilled": true,
		"watered": true,
		"fertilizer": "",
		"soil_vitality": 90.0,
		"crop": {"id": "turnip", "growth_days": 4.0, "mature": true, "regrow_timer": 0.0, "giant": false},
	}, "farm")
	gs.inventory[35] = {}
	var turnip_b37: int = gs.count_item("turnip")
	var tap_mode: String = mg.handle_world_tap_world(Vector2(11 * 32 + 16, 12 * 32 + 16))
	for _tw in range(24):
		mg._process(0.06)
		if not pl.auto_walk_active and not pl.arrived_smart_act_pending:
			break
	mg._process(0.05)
	_assert_true(tap_mode == "walk" and not pl.auto_walk_active and gs.count_item("turnip") > turnip_b37,
		"37) 手机单手通勤【点地自动寻路 + 抵达自动智能收菜/对话】全链路验证")

	# 38. Mobile Commute Background Instant Auto-Save & Bundled Subset CJK Font Verification
	var font_bundled_ok: bool = (UITheme.get_font() is FontFile)
	mg.title_modal.visible = false
	gs.gold = 39888
	var commute_saved: bool = mg.trigger_commute_autosave()
	gs.gold = 10
	var commute_loaded: bool = sm.load_game(1, zm, ns)
	var restored_gold: int = gs.gold
	sm.delete_save(1)
	_assert_true(font_bundled_ok and commute_saved and commute_loaded and restored_gold == 39888,
		"38) 手机切后台/锁屏毫秒级自动存档 (trigger_commute_autosave) 与内置中文字体子集验证")

	# 39. Mobile Fishing Touch-Lift Button & Modal Backdrop Anti-Click-Through Isolation
	mg._close_all_modals()
	gs.energy = gs.max_energy
	mg.fish_modal.start_fishing("lake")
	var fish_btn_h_ok: bool = (mg.fish_modal.lift_btn != null and mg.fish_modal.lift_btn.custom_minimum_size.y >= 44.0 and mg.fish_modal.cancel_btn != null and mg.fish_modal.cancel_btn.custom_minimum_size.y >= 42.0)
	mg.fish_modal.bar_vel = 40.0
	mg.fish_modal._btn_lifting = true
	for _fl in range(3):
		mg.fish_modal._process(0.1)
	var lifted_by_touch_btn: bool = (mg.fish_modal.bar_vel < -80.0)
	mg.fish_modal._finish_fishing(false)
	mg._show_popup("测试手机弹窗全屏防误触蒙版", [{"text": "关闭", "cb": func(): mg._close_popup()}])
	var backdrop_blocks: bool = (mg.popup_backdrop != null and mg.popup_backdrop.visible and mg.popup_backdrop.mouse_filter == Control.MOUSE_FILTER_STOP)
	mg.hud.action_button_pressed.emit("open_inv")
	var mutex_modal_ok: bool = (not mg.popup_panel.visible and not mg.popup_backdrop.visible and mg.inv_modal.visible)
	mg._close_all_modals()
	_assert_true(fish_btn_h_ok and lifted_by_touch_btn and backdrop_blocks and mutex_modal_ok,
		"39) 手机钓鱼大尺寸按住抬升键、全屏触屏穿透修复与弹窗模态防误触互斥关闭验证")

	# 40. Mobile Inventory Touch Eat/Split Buttons, .pck PCM16 Loop Audio Frame Integrity & v6.0 Title Sync
	var imported_bgm = ResourceLoader.load("res://assets/audio/bgm_island_loop.wav")
	var pck_loop_ok: bool = false
	if imported_bgm is AudioStreamWAV:
		var ib_wav: AudioStreamWAV = imported_bgm
		AudioManager._configure_loop_if_needed("bgm_island_loop.wav", ib_wav)
		pck_loop_ok = (ib_wav.format == AudioStreamWAV.FORMAT_16_BITS and ib_wav.loop_end == 352800)
	gs.inventory[12] = {"id": "turnip", "count": 5, "quality": 0}
	gs.inventory[13] = {}
	gs.energy = 40.0
	mg.inv_modal.open_modal()
	mg.inv_modal._on_slot_left_click(12)
	var touch_btns_enabled: bool = (not mg.inv_modal.eat_btn.disabled and not mg.inv_modal.split_btn.disabled and mg.inv_modal.close_btn.custom_minimum_size.y >= 42.0)
	var ate_via_touch: bool = mg.inv_modal.eat_selected_slot()
	var energy_after_eat: float = gs.energy
	var split_via_touch: bool = mg.inv_modal.split_selected_slot()
	var split_slot_cnt: int = int((gs.inventory[12] as Dictionary).get("count", 0))
	mg._close_all_modals()
	_assert_true(pck_loop_ok and touch_btns_enabled and ate_via_touch and energy_after_eat > 40.0 and split_via_touch and split_slot_cnt == 2,
		"40) 手机背包触屏『食用/对半拆分』按钮、.pck 无损 PCM16 循环音频 352800 帧完整性与大热区关闭按钮验证")

	# 41. v7.0 Portrait One-Handed Commute Mode (720x1280 Dynamic Switch, 5x2 Hotbar Grid Reflow & Modal Fit)
	var entered_portrait: bool = mg.toggle_portrait_mode()
	var portrait_cols_ok: bool = (mg.hud.hb_grid_ref != null and mg.hud.hb_grid_ref.columns == 5 and mg.hud.is_portrait_layout)
	var portrait_scale_ok: bool = (get_tree().root.content_scale_size == Vector2i(720, 1280))
	var exited_portrait: bool = not mg.toggle_portrait_mode()
	var landscape_restored_ok: bool = (mg.hud.hb_grid_ref.columns == 10 and get_tree().root.content_scale_size == Vector2i(1280, 720))
	_assert_true(entered_portrait and portrait_cols_ok and portrait_scale_ok and exited_portrait and landscape_restored_ok,
		"41) v7.0 手机一键切换【竖屏单手掌中模式】(720x1280视口重排+5x2双排拇指栏+弹窗防裁切缩放)验证")

	# 42. v7.0 Forest Sprite Offline Idle Helper (Real-Clock Offline Loot Calculation + Daily Free Instant 2h Patrol)
	var g_before_fairy: int = gs.gold
	gs.fairy_daily_instant_used = false
	mg.hud.action_button_pressed.emit("open_fairy")
	var fairy_modal_opened: bool = (mg.fairy_modal != null and mg.fairy_modal.visible)
	var prev_3h: Dictionary = gs.preview_offline_fairy_rewards(10800)
	var claim_off_res: Dictionary = gs.claim_offline_fairy_rewards(10800, false)
	var claim_inst_res: Dictionary = gs.claim_offline_fairy_rewards(7200, true)
	var dup_inst_blocked: bool = not bool(gs.claim_offline_fairy_rewards(7200, true).get("ok", true))
	mg._close_all_modals()
	_assert_true(fairy_modal_opened and bool(prev_3h.get("claimable", false)) and bool(claim_off_res.get("ok", false)) and bool(claim_inst_res.get("ok", false)) and dup_inst_blocked and gs.gold > g_before_fairy + 300,
		"42) v7.0【星露森灵值班小屋】离线挂机时长收益结算与每日免费即时巡收防刷验证")

	# 43. v7.0 Shareable Farm Postcard PNG Generator (Framed Walnut-Gold Crest Snapshot)
	var tmp_card_path: String = ProjectSettings.globalize_path("user://postcards/qa_test_postcard.png")
	var saved_card_path: String = mg.capture_farm_postcard(tmp_card_path)
	var card_img: Image = Image.new()
	var card_load_ok: bool = (FileAccess.file_exists(saved_card_path) and card_img.load(saved_card_path) == OK)
	var card_dim_ok: bool = (card_load_ok and card_img.get_width() == 1280 and card_img.get_height() == 806)
	if FileAccess.file_exists(saved_card_path):
		DirAccess.remove_absolute(saved_card_path)
	_assert_true(card_load_ok and card_dim_ok,
		"43) v7.0【庄园打卡明信片】一键合成胡桃木金框纪念图 (1280x806 PNG) 与导出验证")

	# 44. v7.0 Portrait DialogueModal Narrow-Margin Anti-Overflow & Centered Journal Pivot Verification
	mg.set_portrait_mode(true)
	var dlg_portrait_ok: bool = (mg.dlg_modal.anchor_ref != null and mg.dlg_modal.anchor_ref.offset_left == 16 and mg.dlg_modal.anchor_ref.offset_right == -16 and mg.dlg_modal.anchor_ref.offset_bottom <= -170)
	var jrn_pivot_ok: bool = (mg.journal_panel.pivot_offset == Vector2(360, 230))
	mg.set_portrait_mode(false)
	var dlg_landscape_ok: bool = (mg.dlg_modal.anchor_ref.offset_left == 150 and mg.dlg_modal.anchor_ref.offset_bottom == -108)
	_assert_true(dlg_portrait_ok and jrn_pivot_ok and dlg_landscape_ok,
		"44) v7.0 竖屏模式 (720x1280) 下村民对话框窄边距避让 5x2 拇指栏与日志居中缩放锚点验证")

	# 45. v7.0 Postcard Footer Multi-Crest, Golden Perfection Bar & Scan-to-Play QR Badge Pixel Verification
	var rich_card_path: String = ProjectSettings.globalize_path("user://postcards/qa_rich_postcard.png")
	mg.capture_farm_postcard(rich_card_path)
	var rich_img: Image = Image.new()
	var rich_loaded: bool = (FileAccess.file_exists(rich_card_path) and rich_img.load(rich_card_path) == OK)
	var walnut_bg: Color = Color(0.14, 0.10, 0.06, 1.0)
	var bar_px_drawn: bool = rich_loaded and not rich_img.get_pixel(300, 720 + 50).is_equal_approx(walnut_bg)
	var qr_px_drawn: bool = rich_loaded and not rich_img.get_pixel(1280 - 50, 720 + 40).is_equal_approx(walnut_bg)
	if FileAccess.file_exists(rich_card_path):
		DirAccess.remove_absolute(rich_card_path)
	mg.set_portrait_mode(true)
	var p_card_path: String = ProjectSettings.globalize_path("user://postcards/qa_portrait_postcard.png")
	mg.capture_farm_postcard(p_card_path)
	var p_card_img: Image = Image.new()
	var p_card_ok: bool = (FileAccess.file_exists(p_card_path) and p_card_img.load(p_card_path) == OK and p_card_img.get_width() == 720 and p_card_img.get_height() == 1366)
	if FileAccess.file_exists(p_card_path):
		DirAccess.remove_absolute(p_card_path)
	mg.set_portrait_mode(false)
	_assert_true(bar_px_drawn and qr_px_drawn and p_card_ok,
		"45) v7.0 庄园打卡明信片底部四重徽章、完美度金条、扫码裂变二维码及竖屏 720x1366 尺寸验证")

	var report_lines: Array = [
		"# 《星露物语：回响山谷》Godot 4.6 无头自动化 QA 验证报告 (v7.0 手机横竖双模终极成品版)",
		"",
		"- 引擎版本：`Godot 4.6.1.stable`",
		"- 测试时间：`%s`" % Time.get_datetime_string_from_system(),
		"- 通过用例：`%d / %d`" % [passed, passed + failed],
		"- 失败用例：`%d`" % failed,
		"",
		"全部 45 项核心系统（99种物品&15种作物&6位村民数据驱动、189/189精灵与18/18立体声WAV 100%热替换与.pck无损PCM16内置全覆盖、七大伴生生态共鸣、跨日生长与洒水器、工匠深加工与三倍浓缩咖啡、出货箱结算、矿洞探险与10层晶甲王、A*寻路与传闻记忆、回响祭坛、存档读档、工具升阶3x3耕作、丰收品鉴日、智能地块探查、四季温室、6大羁绊信物与好感剧情演出、阳光牧场鸡牛羊、农舍料理灶台与实时Buff、三阶庄园扩建与恋爱求婚同居及伴侣晨间家务、第八区域迷雾秘林树精王、第九区域星露珊瑚群岛恒温种植与渡船航线、四季与海岛5首立体声背景乐动态切换、垂钓海底沉船宝箱打捞与手机触屏长按抬升键、萌宠随行刨珍珠松露、活水鱼塘繁育星海蝠鲼与黄金鱼籽酱、双终局奇观、山谷完美度徽章追踪、手机背包触屏一键食用/对半拆分与全弹窗防穿透模态遮罩、原生手柄支持、手机虚拟摇杆与右手大按键、单手通勤点地自动寻路收菜、切后台毫秒级自动存档、一键横竖屏切换(720x1280+5x2拇指栏+竖屏对话框自适应)、星露森灵离线挂机与每日免费巡收、庄园打卡明信片(含完美度金条与扫码二维码)及内置毕业体验档）均已在 Godot 4.6 无头环境中真实运行并通过断言。",
	]
	var rpt_path: String = ProjectSettings.globalize_path("res://../reports/qa_verification_report.md")
	var rfa: FileAccess = FileAccess.open(rpt_path, FileAccess.WRITE)
	if rfa != null:
		rfa.store_string("\n".join(report_lines))
		rfa.close()

	print("=== 测试结束：通过 %d 项，失败 %d 项 ===" % [passed, failed])
	get_tree().quit(0 if failed == 0 else 1)
