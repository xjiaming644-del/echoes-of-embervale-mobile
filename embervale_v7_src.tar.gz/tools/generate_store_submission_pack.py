#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
《星露物语：回响山谷》v8.0 商店提审全套物料生成器 & 合规隐私页/官方下载页构建工具
自动产出：
1) TapTap / Google Play / itch.io 标准尺寸宣传横幅与图标 (512x512, 1920x1080, 1080x608, 630x500)；
2) 精选横屏 (1280x720 x 5) 与竖屏 (720x1280) 商店提审实机截图集；
3) 商店提审必填的合规静态隐私政策页 (`privacy.html`) 与高转化官方手游下载专题页 (`store.html`)；
4) 可直接复制粘贴填表的《多渠道商店提审文案与推进SOP》(`store_copywriting_and_roadmap.md`)；
5) 支持 `--check` 只读完整性门禁校验。
"""
from __future__ import annotations

import argparse
import shutil
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SHOTS_DIR = ROOT / "reports" / "screenshots"
STORE_DIR = ROOT / "releases" / "store_submission_pack"
BUILD_WEB = ROOT / "build" / "web"


def _load_cjk_font(size: int):
    from PIL import ImageFont
    candidates = [
        ROOT / "game" / "assets" / "fonts" / "embervale_cjk_subset.ttf",
        Path(r"C:\Windows\Fonts\msyhbd.ttc"),
        Path(r"C:\Windows\Fonts\Dengb.ttf"),
        Path(r"C:\Windows\Fonts\simhei.ttf"),
    ]
    for c in candidates:
        if c.exists():
            try:
                return ImageFont.truetype(str(c), size=size)
            except Exception:
                pass
    return ImageFont.load_default()


def _compose_promo_banner(width: int, height: int, out_path: Path, subtitle: str) -> None:
    from PIL import Image, ImageDraw
    base_shot = SHOTS_DIR / "12_coral_island_paradise.png"
    inset_shot = SHOTS_DIR / "10_farm_wonders_pond_pet.png"
    bg = Image.new("RGBA", (width, height), (28, 19, 13, 255))

    if base_shot.exists():
        src = Image.open(base_shot).convert("RGBA")
        # Cover-fit resize
        scale = max(width / src.width, height / src.height)
        nw, nh = int(round(src.width * scale)), int(round(src.height * scale))
        resized = src.resize((nw, nh), Image.Resampling.NEAREST)
        ox = (nw - width) // 2
        oy = (nh - height) // 2
        bg.paste(resized.crop((ox, oy, ox + width, oy + height)), (0, 0))

    # Warm vignette & bottom Stardew walnut-wood title plaque
    overlay = Image.new("RGBA", (width, height), (0, 0, 0, 0))
    draw = ImageDraw.Draw(overlay)
    bar_h = max(130, int(height * 0.28))
    bar_y = height - bar_h
    draw.rectangle([0, bar_y, width, height], fill=(32, 20, 12, 232))
    draw.rectangle([0, bar_y, width, bar_y + 5], fill=(235, 182, 82, 255))
    draw.rectangle([0, 0, width - 1, height - 1], outline=(235, 182, 82, 255), width=6)

    # Optional inset card on wide banners
    if width >= 1000 and inset_shot.exists():
        ins = Image.open(inset_shot).convert("RGBA")
        iw = int(width * 0.25)
        ih = int(iw * ins.height / ins.width)
        ins_r = ins.resize((iw, ih), Image.Resampling.NEAREST)
        ix = width - iw - int(width * 0.035)
        iy = max(24, bar_y - ih + 18)
        draw.rounded_rectangle([ix - 5, iy - 5, ix + iw + 5, iy + ih + 5], radius=10, fill=(36, 22, 13, 245), outline=(245, 198, 92, 255), width=4)
        overlay.paste(ins_r, (ix, iy))

    icon_p = ROOT / "game" / "assets" / "app_icon_192.png"
    text_x = int(width * 0.04)
    if icon_p.exists():
        ic_sz = int(bar_h * 0.72)
        ic = Image.open(icon_p).convert("RGBA").resize((ic_sz, ic_sz), Image.Resampling.NEAREST)
        ic_y = bar_y + (bar_h - ic_sz) // 2
        overlay.paste(ic, (text_x, ic_y), ic)
        text_x += ic_sz + int(width * 0.022)

    title_f = _load_cjk_font(max(24, int(bar_h * 0.34)))
    sub_f = _load_cjk_font(max(14, int(bar_h * 0.17)))
    draw.text((text_x, bar_y + int(bar_h * 0.18)), "星露物语：回响山谷", font=title_f, fill=(255, 230, 128, 255))
    draw.text((text_x, bar_y + int(bar_h * 0.62)), subtitle, font=sub_f, fill=(235, 248, 226, 255))

    out = Image.alpha_composite(bg, overlay).convert("RGB")
    out.save(out_path, quality=95)


PRIVACY_HTML = """<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>《星露物语：回响山谷》隐私政策与个人信息保护声明</title>
  <style>
    body { max-width: 780px; margin: 0 auto; padding: 28px 18px; background: #1c130d; color: #f6ecd9; font: 15px/1.75 -apple-system, "PingFang SC", "Microsoft YaHei", sans-serif; }
    h1 { color: #ffd970; font-size: 24px; border-bottom: 2px solid #cfa04c; padding-bottom: 10px; }
    h2 { color: #9ef0b0; font-size: 18px; margin-top: 24px; }
    .card { background: #291b12; border: 1px solid #b58338; border-radius: 10px; padding: 16px 20px; }
    a { color: #ffd970; }
  </style>
</head>
<body>
  <h1>🌱《星露物语：回响山谷》用户隐私政策</h1>
  <div class="card">
    <p><strong>生效与更新日期：</strong>2026年11月23日 ｜ <strong>适用版本：</strong>Android 客户端、Web H5 手机端与桌面独立版</p>
    <p>《星露物语：回响山谷》（Echoes of Embervale）是一款纯本地单机模拟经营像素独立游戏。我们高度重视并严格保护玩家的个人隐私安全：</p>
    <h2>1. 我们收集的信息</h2>
    <p>本游戏核心玩法<strong>无需注册账号、不强制获取通讯录/定位/麦克风/相机权限，亦不向任何第三方服务器上传您的个人身份信息</strong>。所有农场存档、设置偏好与离线挂机时间戳均仅保存在您设备本地沙盒（Android 应用私有目录或浏览器本地 IndexedDB）中。</p>
    <h2>2. 本地存储与相册保存说明</h2>
    <p>当您主动点击游戏内「📸打卡」按钮生成庄园纪念明信片时，浏览器或系统仅在您主动触发下载操作时将生成的 PNG 图片保存至本地下载目录，不会读取您设备中的既有照片。</p>
    <h2>3. 未成年人保护与数据删除</h2>
    <p>您可随时在游戏内覆盖/删除存档，或通过卸载应用、清理浏览器站点数据彻底清除全部本地游戏数据。如有任何隐私咨询，可通过项目开源仓库主页提交反馈：<a href="https://github.com/xjiaming644-del/echoes-of-embervale-mobile">GitHub 项目支持页</a>。</p>
  </div>
</body>
</html>
"""

STORE_HTML = """<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
  <title>《星露物语：回响山谷》官方手机版下载与在线秒玩中心</title>
  <style>
    * { box-sizing: border-box; }
    body { margin: 0; background: #17100b; color: #fff4df; font-family: -apple-system, BlinkMacSystemFont, "PingFang SC", "Microsoft YaHei", sans-serif; }
    .hero { max-width: 860px; margin: 0 auto; padding: 26px 16px 48px; text-align: center; }
    .badge { display: inline-block; background: #2c4a32; border: 1px solid #6fe38c; color: #b8ffca; padding: 4px 12px; border-radius: 999px; font-size: 12px; font-weight: 600; }
    h1 { color: #ffe074; font-size: 28px; margin: 12px 0 8px; }
    .sub { color: #decbb2; font-size: 14px; margin-bottom: 22px; line-height: 1.6; }
    .cta-grid { display: flex; flex-wrap: wrap; gap: 12px; justify-content: center; margin-bottom: 26px; }
    .btn { display: inline-flex; align-items: center; justify-content: center; min-width: 230px; padding: 14px 22px; border-radius: 12px; font-size: 16px; font-weight: 700; text-decoration: none; transition: transform 0.12s; }
    .btn:active { transform: scale(0.97); }
    .btn-play { background: linear-gradient(180deg, #439b56, #2b6e3a); color: #ffffff; border: 2px solid #8df7a4; box-shadow: 0 6px 20px rgba(67,155,86,0.38); }
    .btn-apk { background: linear-gradient(180deg, #7c4b23, #523015); color: #ffe799; border: 2px solid #ebb257; }
    .features { display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 12px; text-align: left; margin-top: 18px; }
    .card { background: #261911; border: 1.5px solid #8f632b; border-radius: 12px; padding: 14px 16px; }
    .card h3 { margin: 0 0 6px; color: #ffd970; font-size: 15px; }
    .card p { margin: 0; color: #dfd0bc; font-size: 13px; line-height: 1.55; }
    .footer { margin-top: 32px; font-size: 12px; color: #9c8873; }
    .footer a { color: #d8ae64; }
  </style>
</head>
<body>
  <div class="hero">
    <span class="badge">v8.0 手机横竖双模正式版 · 免注册零氪金畅玩</span>
    <h1>🌱 星露物语：回响山谷</h1>
    <p class="sub">专为上班间隙、地铁通勤打造的 16-bit 治愈田园手游<br>支持竖屏单手种田 · 星露森灵离线挂机 · 珊瑚海岛度假 · 6位村民恋爱同居</p>
    <div class="cta-grid">
      <a class="btn btn-play" href="./index.html?v=80">🌐 手机网页免安装立即开玩</a>
      <a class="btn btn-apk" href="./EchoesOfEmbervale_v7_Mobile.apk" download="EchoesOfEmbervale_v7_Mobile.apk">📦 下载安卓原生安装包 (APK)</a>
    </div>
    <div class="features">
      <div class="card"><h3>🔄 横竖屏一键切换</h3><p>站地铁单手握持自动适配 720×1280 竖屏 5×2 大拇指栏；点击地面自动避障寻路收菜与对话。</p></div>
      <div class="card"><h3>🧚 森灵离线挂机 & 盲盒</h3><p>忙工作锁屏离开满 10 分钟~12 小时自动累积晨露礼金与鸡蛋咖啡豆，每日免费抽幸运星露盲盒！</p></div>
      <div class="card"><h3>🏖️ 九大地图与珊瑚群岛</h3><p>内置【🌟 毕业体验档(槽2)】，一秒畅游三阶庄园、四季温室、迷雾秘林与星露珊瑚群岛。</p></div>
    </div>
    <div class="footer">
      <a href="./privacy.html">用户隐私政策</a> ｜ <a href="https://github.com/xjiaming644-del/echoes-of-embervale-mobile">GitHub 开源与版本仓库</a>
    </div>
  </div>
</body>
</html>
"""

COPYWRITING_MD = """# 🏪《星露物语：回响山谷》多渠道商店上架填表文案与推进 SOP

## 一、核心填表字段（可直接复制粘贴至 TapTap / 微信小游戏 / itch.io 后台）

- **游戏名称（中文）**：星露物语：回响山谷
- **游戏名称（英文 / 副标题）**：Echoes of Embervale Mobile
- **包名（Package Name）**：`com.embervale.stardewmobile`
- **当前版本号**：`7.0.0` (`Version Code: 70`)
- **游戏类型 / 标签**：模拟经营 / 像素 / 种田 / 休闲放置 / 单机 / 治愈
- **一句话卖点（30字内）**：单手竖屏也能玩的16-bit治愈田园！离线森灵挂机，扬帆珊瑚海岛！
- **隐私政策网址（必填 HTTPS）**：`https://xjiaming644-del.github.io/echoes-of-embervale-mobile/privacy.html`
- **官方试玩/主页网址**：`https://xjiaming644-del.github.io/echoes-of-embervale-mobile/store.html`

### 商店详细介绍（500字标准版）
欢迎来到《星露物语：回响山谷》！这是一款专为手机碎片化时间深度打磨的 16-bit 暖系像素田园模拟经营独立游戏：
- **【横竖双模 · 地铁单手轻松收菜】**：支持横屏全景与竖屏单手掌中模式一键切换！单手点击成熟作物或村民即可自动寻路收获与交谈，切回微信/锁屏毫秒级自动存档。
- **【星露森灵值班 · 护肝离线挂机】**：上班忙碌锁屏离开也能稳步收益！小森灵根据你的庄园、阳光牧场与活水鱼塘规模自动累积礼金与鲜货，每日还能免费开启星露幸运盲盒。
- **【七大伴生共鸣 & 星露珊瑚群岛】**：独创植物伴生生态共鸣透镜（昼夜共生、热带蕉林等 7 大共鸣组合），乘渡船开辟四季如夏的第九区域「星露珊瑚群岛」，种植黄金凤梨与星露咖啡！
- **【6位村民恋爱同居 & 双终局奇观】**：扩建三阶星露庄园，与 6 位性格鲜明的村民培养羁绊、求婚同居，领养橘猫/柴犬随行寻宝！

---

## 二、预生成美宣图片与包体路径清单（位于 `releases/store_submission_pack/`）

1. **高清应用图标 (`512×512`)**：`icon_512x512.png`
2. **TapTap / 商店主视觉横幅 (`1920×1080`)**：`taptap_banner_1920x1080.png`
3. **TapTap 推荐位横卡 (`1080×608`)**：`taptap_card_1080x608.png`
4. **itch.io 商店封面 (`630×500`)**：`itch_cover_630x500.png`
5. **横屏实机宣传图集 (`1280×720 × 5`)**：`screenshots_landscape/`
6. **竖屏实机宣传图集 (`720×1280 × 1`)**：`screenshots_portrait/`
7. **安卓签名安装包 (`APK`)**：`../EchoesOfEmbervale_v7_Mobile.apk`
8. **H5 在线包 (`ZIP`)**：`../EchoesOfEmbervale_v7_Mobile_Web_PWA.zip`

---

## 三、分阶段渠道推进路线图

1. **第一站：TapTap 开发者中心（`https://developer.taptap.cn/` · 国内首选免版号开启「篝火测试 / 试玩预约」）**
   - 注册/登录开发者账号 → 点击「创建游戏（选择『测试/预约阶段』暂免版号）」→ 填入上方标题、简介与隐私政策 URL → 上传 `icon_512x512.png`、`taptap_banner_1920x1080.png`、实机截图与 `EchoesOfEmbervale_v7_Mobile.apk` 即可开启安卓玩家试玩下载与评分收集！
2. **第二站：itch.io 全球独立游戏商店（`https://itch.io/game/new` · 10分钟零门槛全球上线）**
   - Kind of project 选 `HTML` → 上传 `EchoesOfEmbervale_v7_Mobile_Web_PWA.zip`（勾选 *Mobile friendly* 与 *Play in browser*）并附加 `EchoesOfEmbervale_v7_Mobile.apk` → 上传 `itch_cover_630x500.png` → 点击 Public 即可生成全球公开商店页！
3. **第三站：微信小游戏 / 抖音小游戏（流量裂变放大器）**
   - 使用微信开发者工具打开 `releases/EchoesOfEmbervale_v7_WeChat_MiniGame_Kit.zip`，填入个人/企业小游戏 AppID 与激励视频广告位 `adUnitId`（绑定至 `window.EmbervaleAdSDK.adUnitId`）即可开启广告变现闭环！
"""


def build_store_pack() -> None:
    from PIL import Image
    if STORE_DIR.exists():
        shutil.rmtree(STORE_DIR)
    (STORE_DIR / "screenshots_landscape").mkdir(parents=True, exist_ok=True)
    (STORE_DIR / "screenshots_portrait").mkdir(parents=True, exist_ok=True)

    # 1) Copy 512x512 icon & generate 256x256 icon
    src_ic = ROOT / "game" / "assets" / "app_icon_512.png"
    shutil.copy2(src_ic, STORE_DIR / "icon_512x512.png")
    Image.open(src_ic).resize((256, 256), Image.Resampling.NEAREST).save(STORE_DIR / "icon_256x256.png")

    # 2) Generate store banners
    _compose_promo_banner(1920, 1080, STORE_DIR / "taptap_banner_1920x1080.png", "横竖屏单手种田 · 星露森灵离线挂机 · 珊瑚海岛度假 · 6位村民恋爱同居")
    _compose_promo_banner(1080, 608, STORE_DIR / "taptap_card_1080x608.png", "单手竖屏种田 · 森灵离线挂机 · 100% 16-bit 治愈像素")
    _compose_promo_banner(630, 500, STORE_DIR / "itch_cover_630x500.png", "Mobile & Web Farming RPG")

    # 3) Curate landscape & portrait screenshots
    for idx, name in enumerate([
        "13_mobile_touch_edition.png",
        "12_coral_island_paradise.png",
        "15_fairy_offline_idle_report.png",
        "10_farm_wonders_pond_pet.png",
        "07_sunny_ranch_livestock.png",
    ], 1):
        sp = SHOTS_DIR / name
        if sp.exists():
            shutil.copy2(sp, STORE_DIR / "screenshots_landscape" / f"0{idx}_{name}")

    port_sp = SHOTS_DIR / "14_mobile_portrait_onehand.png"
    if port_sp.exists():
        shutil.copy2(port_sp, STORE_DIR / "screenshots_portrait" / "01_mobile_portrait_onehand.png")

    # 4) Write privacy.html, store.html & copywriting pack (also stage into build/web/ if present)
    (STORE_DIR / "privacy.html").write_text(PRIVACY_HTML, encoding="utf-8")
    (STORE_DIR / "store.html").write_text(STORE_HTML, encoding="utf-8")
    (STORE_DIR / "store_copywriting_and_roadmap.md").write_text(COPYWRITING_MD, encoding="utf-8")
    if BUILD_WEB.exists():
        (BUILD_WEB / "privacy.html").write_text(PRIVACY_HTML, encoding="utf-8")
        (BUILD_WEB / "store.html").write_text(STORE_HTML, encoding="utf-8")
    print(f"[OK] 商店提审全套物料包构建完成: {STORE_DIR}")


def verify_store_pack() -> int:
    from PIL import Image
    expected_dims = {
        "icon_512x512.png": (512, 512),
        "taptap_banner_1920x1080.png": (1920, 1080),
        "taptap_card_1080x608.png": (1080, 608),
        "itch_cover_630x500.png": (630, 500),
    }
    for fname, dim in expected_dims.items():
        fp = STORE_DIR / fname
        if not fp.exists():
            print(f"[FAIL] 缺失商店宣传图: {fp}")
            return 1
        im = Image.open(fp)
        if im.size != dim:
            print(f"[FAIL] 商店图尺寸不符 {fname}: {im.size} != {dim}")
            return 1
    for doc_name in ("privacy.html", "store.html", "store_copywriting_and_roadmap.md"):
        if not (STORE_DIR / doc_name).exists():
            print(f"[FAIL] 缺失商店合规/文案文件: {doc_name}")
            return 1
    ls_cnt = len(list((STORE_DIR / "screenshots_landscape").glob("*.png")))
    pt_cnt = len(list((STORE_DIR / "screenshots_portrait").glob("*.png")))
    if ls_cnt < 5 or pt_cnt < 1:
        print(f"[FAIL] 商店实机截图数量不足: landscape={ls_cnt}, portrait={pt_cnt}")
        return 1
    print(f"[PASS] 商店提审宣发包校验通过: 4张标准尺寸大图 + {ls_cnt}横/{pt_cnt}竖实机图 + privacy.html + store.html + 提审文案SOP")
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(description="《星露物语：回响山谷》商店提审宣发包生成与校验")
    parser.add_argument("--check", action="store_true")
    args = parser.parse_args()
    if args.check:
        return verify_store_pack()
    build_store_pack()
    return verify_store_pack()


if __name__ == "__main__":
    sys.exit(main())
