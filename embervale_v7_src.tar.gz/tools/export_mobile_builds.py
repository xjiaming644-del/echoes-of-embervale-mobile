#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
《星露物语：回响山谷》v7.0 移动端本地直出构建器 (Local Web PWA + Signed Android APK + WeChat Mini-Game Adapter)
职责：
1) 利用 HTTP Range 按需精准拉取 Godot 4.6.1 官方导出模板中的 Web 与 Android 模板（免下载 1.1GB 全平台包，仅按需拉取 ~50MB）；
2) 本地直出构建免安装手机网页版 / 全屏 PWA (`releases/EchoesOfEmbervale_v7_Mobile_Web_PWA.zip`)；
3) 利用本机已安装的 Eclipse Adoptium JDK 21 + 官方 Google Maven `apksigner.jar` 本地直出构建 V2/V3 签名 Android 安装包 (`releases/EchoesOfEmbervale_v7_Mobile.apk`)；
4) 生成微信小游戏 / 抖音小游戏一键工程适配包 (`releases/EchoesOfEmbervale_v7_WeChat_MiniGame_Kit.zip`)。
"""
from __future__ import annotations

import argparse
import json
import os
import shutil
import struct
import subprocess
import sys
import urllib.request
import zlib
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
GAME_DIR = ROOT / "game"
BUILD_WEB = ROOT / "build" / "web"
BUILD_ANDROID = ROOT / "build" / "android"
BUILD_WX = ROOT / "build" / "wechat_minigame"
RELEASES_DIR = ROOT / "releases"
GODOT_CONSOLE = ROOT / "tools" / "godot" / "Godot_v4.6.1-stable_win64_console.exe"

TPZ_URL = "https://github.com/godotengine/godot/releases/download/4.6.1-stable/Godot_v4.6.1-stable_export_templates.tpz"
BUILD_TOOLS_ZIP_URL = "https://dl.google.com/android/repository/build-tools_r34-windows.zip"


def _http_range(url: str, start: int, end: int) -> bytes:
    req = urllib.request.Request(url, headers={
        "Range": f"bytes={start}-{end}",
        "User-Agent": "Mozilla/5.0 (Embervale-Builder/7.0)",
    })
    with urllib.request.urlopen(req, timeout=120) as resp:
        return resp.read()


def _get_content_length(url: str) -> int:
    req = urllib.request.Request(url, method="HEAD", headers={"User-Agent": "Mozilla/5.0"})
    with urllib.request.urlopen(req, timeout=30) as resp:
        return int(resp.headers["Content-Length"])


def ensure_godot_mobile_templates() -> Path:
    appdata = Path(os.environ["APPDATA"])
    tpl_dir = appdata / "Godot" / "export_templates" / "4.6.1.stable"
    tpl_dir.mkdir(parents=True, exist_ok=True)

    needed = ["web_nothreads_release.zip", "android_debug.apk"]
    missing = [n for n in needed if not (tpl_dir / n).exists() or (tpl_dir / n).stat().st_size < 100_000]
    if not missing:
        print(f"[OK] Godot 4.6.1 Web/Android 导出模板已就绪: {tpl_dir}")
        return tpl_dir

    print(f"[INFO] 正在通过 HTTP Range 从官方 Godot 4.6.1 Release 精准提取模板: {missing} ...")
    total_size = _get_content_length(TPZ_URL)
    tail_len = min(131072, total_size)
    tail = _http_range(TPZ_URL, total_size - tail_len, total_size - 1)

    # Locate End of Central Directory (EOCD) or ZIP64 EOCD Locator
    eocd_pos = tail.rfind(b"PK\x05\x06")
    if eocd_pos < 0:
        raise RuntimeError("Could not locate ZIP EOCD in .tpz")
    cd_size = struct.unpack_from("<I", tail, eocd_pos + 12)[0]
    cd_offset = struct.unpack_from("<I", tail, eocd_pos + 16)[0]
    if cd_offset == 0xFFFFFFFF or cd_size == 0xFFFFFFFF:
        loc_pos = tail.rfind(b"PK\x06\x07", 0, eocd_pos)
        z64_eocd_off = struct.unpack_from("<Q", tail, loc_pos + 8)[0]
        z64_buf = _http_range(TPZ_URL, z64_eocd_off, z64_eocd_off + 96)
        cd_size = struct.unpack_from("<Q", z64_buf, 40)[0]
        cd_offset = struct.unpack_from("<Q", z64_buf, 48)[0]

    cd_bytes = _http_range(TPZ_URL, cd_offset, cd_offset + cd_size - 1)
    pos = 0
    entries: dict[str, tuple[int, int, int, int]] = {}
    while pos + 46 <= len(cd_bytes):
        if cd_bytes[pos:pos + 4] != b"PK\x01\x02":
            break
        comp_method = struct.unpack_from("<H", cd_bytes, pos + 10)[0]
        comp_size = struct.unpack_from("<I", cd_bytes, pos + 20)[0]
        uncomp_size = struct.unpack_from("<I", cd_bytes, pos + 24)[0]
        fname_len = struct.unpack_from("<H", cd_bytes, pos + 28)[0]
        extra_len = struct.unpack_from("<H", cd_bytes, pos + 30)[0]
        comment_len = struct.unpack_from("<H", cd_bytes, pos + 32)[0]
        local_off = struct.unpack_from("<I", cd_bytes, pos + 42)[0]
        fname = cd_bytes[pos + 46:pos + 46 + fname_len].decode("utf-8", errors="replace")
        extra = cd_bytes[pos + 46 + fname_len:pos + 46 + fname_len + extra_len]
        if comp_size == 0xFFFFFFFF or uncomp_size == 0xFFFFFFFF or local_off == 0xFFFFFFFF:
            ep = 0
            while ep + 4 <= len(extra):
                eid, elen = struct.unpack_from("<HH", extra, ep)
                edata = extra[ep + 4:ep + 4 + elen]
                ep += 4 + elen
                if eid == 0x0001:
                    zp = 0
                    if uncomp_size == 0xFFFFFFFF and zp + 8 <= len(edata):
                        uncomp_size = struct.unpack_from("<Q", edata, zp)[0]
                        zp += 8
                    if comp_size == 0xFFFFFFFF and zp + 8 <= len(edata):
                        comp_size = struct.unpack_from("<Q", edata, zp)[0]
                        zp += 8
                    if local_off == 0xFFFFFFFF and zp + 8 <= len(edata):
                        local_off = struct.unpack_from("<Q", edata, zp)[0]
        entries[fname] = (comp_method, comp_size, uncomp_size, local_off)
        pos += 46 + fname_len + extra_len + comment_len

    for target_name in missing:
        zp_key = f"templates/{target_name}"
        if zp_key not in entries:
            raise KeyError(f"{zp_key} not found in Godot export templates")
        comp_method, comp_size, _uncomp_size, local_off = entries[zp_key]
        lhdr = _http_range(TPZ_URL, local_off, local_off + 128)
        lf_nlen = struct.unpack_from("<H", lhdr, 26)[0]
        lf_elen = struct.unpack_from("<H", lhdr, 28)[0]
        data_start = local_off + 30 + lf_nlen + lf_elen
        raw_comp = _http_range(TPZ_URL, data_start, data_start + comp_size - 1)
        if comp_method == 0:
            out_bytes = raw_comp
        elif comp_method == 8:
            out_bytes = zlib.decompress(raw_comp, -zlib.MAX_WBITS)
        else:
            raise RuntimeError(f"Unsupported compression method {comp_method} for {zp_key}")
        dst = tpl_dir / target_name
        dst.write_bytes(out_bytes)
        print(f"[OK] 提取完成: {dst.name} ({len(out_bytes) / (1024 * 1024):.1f} MB)")

    # Mirror release/debug variants so Godot preset validation is 100% happy
    if not (tpl_dir / "web_nothreads_debug.zip").exists():
        shutil.copy2(tpl_dir / "web_nothreads_release.zip", tpl_dir / "web_nothreads_debug.zip")
    if not (tpl_dir / "android_release.apk").exists():
        shutil.copy2(tpl_dir / "android_debug.apk", tpl_dir / "android_release.apk")
    (tpl_dir / "version.txt").write_text("4.6.1.stable\n", encoding="utf-8")
    return tpl_dir


def ensure_local_android_sdk_shim() -> tuple[Path, Path]:
    sdk_dir = ROOT / "build" / "android_sdk_min"
    bt_dir = sdk_dir / "build-tools" / "34.0.0"
    pt_dir = sdk_dir / "platform-tools"
    pf_dir = sdk_dir / "platforms" / "android-34"
    bt_dir.mkdir(parents=True, exist_ok=True)
    pt_dir.mkdir(parents=True, exist_ok=True)
    pf_dir.mkdir(parents=True, exist_ok=True)

    apksigner_jar = bt_dir / "lib" / "apksigner.jar"
    zipalign_exe = bt_dir / "zipalign.exe"
    apksigner_jar.parent.mkdir(parents=True, exist_ok=True)
    if not apksigner_jar.exists() or apksigner_jar.stat().st_size < 100_000:
        print("[INFO] 正在从官方 Android Build-Tools r34 按需提取 apksigner.jar 与 zipalign.exe (1.3 MB)...")
        bt_total = _get_content_length(BUILD_TOOLS_ZIP_URL)
        bt_tail_len = min(131072, bt_total)
        bt_tail = _http_range(BUILD_TOOLS_ZIP_URL, bt_total - bt_tail_len, bt_total - 1)
        eocd = bt_tail.rfind(b"PK\x05\x06")
        cd_sz = struct.unpack_from("<I", bt_tail, eocd + 12)[0]
        cd_off = struct.unpack_from("<I", bt_tail, eocd + 16)[0]
        cd_buf = _http_range(BUILD_TOOLS_ZIP_URL, cd_off, cd_off + cd_sz - 1)
        p = 0
        while p + 46 <= len(cd_buf) and cd_buf[p:p + 4] == b"PK\x01\x02":
            cm = struct.unpack_from("<H", cd_buf, p + 10)[0]
            csz = struct.unpack_from("<I", cd_buf, p + 20)[0]
            fn_len = struct.unpack_from("<H", cd_buf, p + 28)[0]
            ex_len = struct.unpack_from("<H", cd_buf, p + 30)[0]
            cm_len = struct.unpack_from("<H", cd_buf, p + 32)[0]
            loff = struct.unpack_from("<I", cd_buf, p + 42)[0]
            fn = cd_buf[p + 46:p + 46 + fn_len].decode("utf-8", errors="replace")
            p += 46 + fn_len + ex_len + cm_len
            target_dst = None
            if fn.endswith("/lib/apksigner.jar"):
                target_dst = apksigner_jar
            elif fn.endswith("/zipalign.exe"):
                target_dst = zipalign_exe
            if target_dst is not None:
                lh = _http_range(BUILD_TOOLS_ZIP_URL, loff, loff + 128)
                d_off = loff + 30 + struct.unpack_from("<H", lh, 26)[0] + struct.unpack_from("<H", lh, 28)[0]
                comp_data = _http_range(BUILD_TOOLS_ZIP_URL, d_off, d_off + csz - 1)
                raw_out = comp_data if cm == 0 else zlib.decompress(comp_data, -zlib.MAX_WBITS)
                target_dst.write_bytes(raw_out)
                print(f"[OK] 提取完成: {target_dst.name} ({len(raw_out) / 1024:.0f} KB)")

    # Find local JDK
    java_exe = shutil.which("java") or r"C:\Program Files\Eclipse Adoptium\jdk-21.0.11.10-hotspot\bin\java.exe"
    java_home = Path(java_exe).resolve().parent.parent
    keytool_exe = java_home / "bin" / "keytool.exe"

    # Write apksigner.bat & adb.exe so Godot 4.6 Android export preflight check passes on Windows!
    apksigner_bat = bt_dir / "apksigner.bat"
    apksigner_bat.write_text(
        f'@echo off\r\n"{java_exe}" -jar "%~dp0lib\\apksigner.jar" %*\r\n',
        encoding="utf-8",
    )
    adb_exe = pt_dir / "adb.exe"
    if not adb_exe.exists():
        # Copy harmless Windows where.exe/whoami.exe binary stub or minimal PE if Godot checks file_exists("platform-tools/adb.exe")
        sys_stub = Path(os.environ.get("SystemRoot", r"C:\Windows")) / "System32" / "systray.exe"
        if sys_stub.exists():
            shutil.copy2(sys_stub, adb_exe)
        else:
            adb_exe.write_bytes(b"MZ")

    keystore_path = sdk_dir / "debug.keystore"
    if not keystore_path.exists():
        subprocess.run([
            str(keytool_exe), "-genkeypair", "-v",
            "-keystore", str(keystore_path),
            "-alias", "androiddebugkey",
            "-keyalg", "RSA", "-keysize", "2048", "-validity", "10000",
            "-storepass", "android", "-keypass", "android",
            "-dname", "CN=Android Debug,O=Android,C=US",
        ], check=True)

    # Configure Godot 4.6 editor_settings-4.6.tres safely if Android SDK not yet configured
    ed_cfg = Path(os.environ["APPDATA"]) / "Godot" / "editor_settings-4.6.tres"
    ed_cfg.parent.mkdir(parents=True, exist_ok=True)
    sdk_posix = sdk_dir.as_posix()
    java_posix = java_home.as_posix()
    ks_posix = keystore_path.as_posix()
    if ed_cfg.exists():
        txt = ed_cfg.read_text(encoding="utf-8")
    else:
        txt = '[gd_resource type="EditorSettings" format=3]\n\n[resource]\n'

    overrides = {
        "export/android/android_sdk_path": f'"{sdk_posix}"',
        "export/android/java_sdk_path": f'"{java_posix}"',
        "export/android/debug_keystore": f'"{ks_posix}"',
        "export/android/debug_keystore_user": '"androiddebugkey"',
        "export/android/debug_keystore_pass": '"android"',
    }
    lines = txt.splitlines()
    filtered = [ln for ln in lines if not any(ln.strip().startswith(k + " ") or ln.strip().startswith(k + "=") for k in overrides)]
    for k, v in overrides.items():
        filtered.append(f"{k} = {v}")
    ed_cfg.write_text("\n".join(filtered) + "\n", encoding="utf-8")
    return sdk_dir, keystore_path


def build_all_mobile_artifacts() -> None:
    RELEASES_DIR.mkdir(parents=True, exist_ok=True)
    if BUILD_WEB.exists():
        shutil.rmtree(BUILD_WEB)
    if BUILD_ANDROID.exists():
        shutil.rmtree(BUILD_ANDROID)
    if BUILD_WX.exists():
        shutil.rmtree(BUILD_WX)
    BUILD_WEB.mkdir(parents=True, exist_ok=True)
    BUILD_ANDROID.mkdir(parents=True, exist_ok=True)
    BUILD_WX.mkdir(parents=True, exist_ok=True)

    ensure_godot_mobile_templates()
    sdk_dir, keystore_path = ensure_local_android_sdk_shim()

    # 1) Export Signed Android APK
    apk_out = BUILD_ANDROID / "EchoesOfEmbervale_v7_Mobile.apk"
    env = dict(os.environ)
    env["GODOT_ANDROID_KEYSTORE_DEBUG_PATH"] = str(keystore_path)
    env["GODOT_ANDROID_KEYSTORE_DEBUG_USER"] = "androiddebugkey"
    env["GODOT_ANDROID_KEYSTORE_DEBUG_PASSWORD"] = "android"
    print("[INFO] 正在使用 Godot 4.6.1 导出原生签名 Android APK...")
    subprocess.run([
        str(GODOT_CONSOLE), "--headless", "--path", str(GAME_DIR),
        "--export-debug", "Android", str(apk_out),
    ], check=True, env=env)
    rel_apk = RELEASES_DIR / "EchoesOfEmbervale_v7_Mobile.apk"
    shutil.copy2(apk_out, rel_apk)
    print(f"[OK] 原生签名 Android APK 构建成功: {rel_apk} ({rel_apk.stat().st_size / (1024 * 1024):.1f} MB)")

    # 2) Export Mobile Web H5 / Fullscreen PWA
    web_html = BUILD_WEB / "index.html"
    print("[INFO] 正在使用 Godot 4.6.1 导出手机端 Web H5 / 全屏 PWA...")
    subprocess.run([
        str(GODOT_CONSOLE), "--headless", "--path", str(GAME_DIR),
        "--export-release", "Web", str(web_html),
    ], check=True)
    subprocess.run([sys.executable, "-X", "utf8", str(ROOT / "tools" / "enhance_mobile_web_shell.py"), str(web_html)], check=True)
    shutil.copy2(rel_apk, BUILD_WEB / "EchoesOfEmbervale_v7_Mobile.apk")
    (BUILD_WEB / ".nojekyll").write_text("", encoding="utf-8")

    pwa_zip = RELEASES_DIR / "EchoesOfEmbervale_v7_Mobile_Web_PWA.zip"
    if pwa_zip.exists():
        pwa_zip.unlink()
    with zipfile.ZipFile(pwa_zip, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as zf:
        for fp in sorted(BUILD_WEB.rglob("*")):
            if fp.is_file() and not fp.name.endswith(".apk"):
                zf.write(fp, fp.relative_to(BUILD_WEB))
    print(f"[OK] 手机端免安装 Web H5 / PWA 发行包构建成功: {pwa_zip} ({pwa_zip.stat().st_size / (1024 * 1024):.1f} MB)")

    # 3) Build WeChat / Douyin Mini-Game Ready Adapter Kit
    for fp in BUILD_WEB.iterdir():
        if fp.is_file() and fp.suffix in (".wasm", ".pck", ".js", ".png"):
            shutil.copy2(fp, BUILD_WX / fp.name)
    (BUILD_WX / "game.json").write_text(json.dumps({
        "deviceOrientation": "landscape",
        "showStatusBar": False,
        "networkTimeout": {"request": 15000, "downloadFile": 60000},
        "subpackages": [],
    }, indent=2, ensure_ascii=False), encoding="utf-8")
    (BUILD_WX / "project.config.json").write_text(json.dumps({
        "description": "《星露物语：回响山谷》v7.0 微信小游戏适配工程",
        "setting": {"urlCheck": False, "es6": True, "minified": True},
        "compileType": "game",
        "appid": "touristappid",
        "projectname": "echoes-of-embervale-minigame",
    }, indent=2, ensure_ascii=False), encoding="utf-8")
    (BUILD_WX / "game.js").write_text(
        "// 《星露物语：回响山谷》v7.0 微信/抖音小游戏 WebGL2 启动桥接入口\n"
        "// 在微信开发者工具导入此目录并填入小游戏 AppID，配合 godot-wechat-adapter 即可一键真机预览与提审\n"
        "if (typeof wx !== 'undefined' && wx.showShareMenu) {\n"
        "  wx.showShareMenu({ withShareTicket: true, menus: ['shareAppMessage', 'shareTimeline'] });\n"
        "  wx.onShareAppMessage(() => ({\n"
        "    title: '我在《星露物语：回响山谷》开辟了珊瑚海岛庄园，快来一起通勤种田！',\n"
        "    imageUrl: 'index.icon.png'\n"
        "  }));\n"
        "}\n"
        "require('./index.js');\n",
        encoding="utf-8",
    )
    wx_zip = RELEASES_DIR / "EchoesOfEmbervale_v7_WeChat_MiniGame_Kit.zip"
    if wx_zip.exists():
        wx_zip.unlink()
    with zipfile.ZipFile(wx_zip, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as zf:
        for fp in sorted(BUILD_WX.rglob("*")):
            if fp.is_file():
                zf.write(fp, fp.relative_to(BUILD_WX))
    print(f"[OK] 微信/抖音小游戏适配工程包构建成功: {wx_zip} ({wx_zip.stat().st_size / (1024 * 1024):.1f} MB)")

    # 4) Create 1-click LAN Mobile Wi-Fi Play Launcher
    lan_bat = ROOT / "一键启动手机局域网扫码试玩.bat"
    lan_bat.write_text(
        "@echo off\r\n"
        "chcp 65001 >nul\r\n"
        "cd /d \"%~dp0\"\r\n"
        "echo ========================================================\r\n"
        "echo  📱《星露物语：回响山谷》v7.0 手机局域网极速试玩服务器\r\n"
        "echo  请让手机连接与电脑相同的 Wi-Fi，用手机浏览器访问下方本机 IP:8090\r\n"
        "echo  电脑本机可直接访问: http://127.0.0.1:8090\r\n"
        "echo ========================================================\r\n"
        "ipconfig | findstr /i \"IPv4\"\r\n"
        "start \"\" \"http://127.0.0.1:8090\"\r\n"
        "python -m http.server 8090 --directory \"%~dp0build\\web\"\r\n",
        encoding="utf-8",
    )


def verify_mobile_artifacts() -> int:
    apk_p = RELEASES_DIR / "EchoesOfEmbervale_v7_Mobile.apk"
    pwa_p = RELEASES_DIR / "EchoesOfEmbervale_v7_Mobile_Web_PWA.zip"
    wx_p = RELEASES_DIR / "EchoesOfEmbervale_v7_WeChat_MiniGame_Kit.zip"

    for p, min_mb in ((apk_p, 45.0), (pwa_p, 10.0), (wx_p, 10.0)):
        if not p.exists():
            print(f"[FAIL] 缺失移动端成品包: {p}")
            return 1
        sz_mb = p.stat().st_size / (1024 * 1024)
        if sz_mb < min_mb:
            print(f"[FAIL] 成品包体积异常偏小 ({sz_mb:.2f} MB < {min_mb} MB): {p.name}")
            return 1

    # 1) Verify Signed Android APK structure & V2+V3 cryptographic signature
    with zipfile.ZipFile(apk_p, "r") as zf:
        bad = zf.testzip()
        if bad is not None:
            print(f"[FAIL] APK CRC 损坏条目: {bad}")
            return 1
        apk_names = set(zf.namelist())
    for req_so in ("lib/arm64-v8a/libgodot_android.so", "lib/armeabi-v7a/libgodot_android.so", "META-INF/MANIFEST.MF"):
        if req_so not in apk_names:
            print(f"[FAIL] APK 缺失核心双架构库或签名清单: {req_so}")
            return 1
    apk_assets = [n for n in apk_names if n.startswith("assets/")]
    if len(apk_assets) < 400:
        print(f"[FAIL] APK 内置游戏资产数量不足: {len(apk_assets)} < 400")
        return 1

    apksigner_jar = ROOT / "build" / "android_sdk_min" / "build-tools" / "34.0.0" / "lib" / "apksigner.jar"
    java_exe = shutil.which("java") or r"C:\Program Files\Eclipse Adoptium\jdk-21.0.11.10-hotspot\bin\java.exe"
    if apksigner_jar.exists() and Path(java_exe).exists():
        sig_proc = subprocess.run(
            [str(java_exe), "-jar", str(apksigner_jar), "verify", "--verbose", str(apk_p)],
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=30,
        )
        sig_out = (sig_proc.stdout or "") + "\n" + (sig_proc.stderr or "")
        if sig_proc.returncode != 0 or "Verified using v2 scheme (APK Signature Scheme v2): true" not in sig_out:
            print(f"[FAIL] APK V2/V3 签名校验未通过: {sig_out[:240]}")
            return 1

    # 2) Verify Mobile Web PWA ZIP
    with zipfile.ZipFile(pwa_p, "r") as zf:
        bad_pwa = zf.testzip()
        if bad_pwa is not None:
            print(f"[FAIL] Web PWA ZIP CRC 损坏条目: {bad_pwa}")
            return 1
        pwa_names = set(zf.namelist())
        for req_w in ("index.html", "index.wasm", "index.pck", "index.js", "index.manifest.json", "index.service.worker.js", ".nojekyll"):
            if req_w not in pwa_names:
                print(f"[FAIL] Web PWA ZIP 缺失核心文件: {req_w}")
                return 1
        html_txt = zf.read("index.html").decode("utf-8", errors="replace")
        for marker in ("viewport-fit=cover", "__embervaleSetOrientation", "./EchoesOfEmbervale_v7_Mobile.apk", "width: max-content"):
            if marker not in html_txt:
                print(f"[FAIL] Web PWA index.html 缺失手机壳增强特性: {marker}")
                return 1
        js_txt = zf.read("index.js").decode("utf-8", errors="replace")
        if "__EMBERVALE_WEBVIEW_PATCHED__" not in js_txt or "var userAgent=false;" not in js_txt:
            print("[FAIL] Web PWA index.js 缺失微信 WebView UA/WASM/IDBFS 启动防卡死补丁")
            return 1

    # 3) Verify WeChat / Douyin Mini-Game Adapter Kit ZIP
    with zipfile.ZipFile(wx_p, "r") as zf:
        bad_wx = zf.testzip()
        if bad_wx is not None:
            print(f"[FAIL] 微信小游戏适配包 CRC 损坏条目: {bad_wx}")
            return 1
        wx_names = set(zf.namelist())
        for req_wx in ("game.js", "game.json", "project.config.json", "index.wasm", "index.pck", "index.js"):
            if req_wx not in wx_names:
                print(f"[FAIL] 微信小游戏适配包缺失核心文件: {req_wx}")
                return 1

    print(
        f"[PASS] v7.0 移动端三端成品包校验通过: "
        f"APK({apk_p.stat().st_size / (1024*1024):.1f}MB, V2+V3签名, arm64+v7a, {len(apk_assets)}资产) | "
        f"PWA({pwa_p.stat().st_size / (1024*1024):.1f}MB) | "
        f"MiniGame({wx_p.stat().st_size / (1024*1024):.1f}MB)"
    )
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(description="《星露物语：回响山谷》v7.0 移动端三端构建与只读校验工具")
    parser.add_argument("--check", action="store_true", help="只读校验 APK (含 V2/V3 签名)、Web PWA ZIP 与微信小游戏适配包完整性")
    args = parser.parse_args()
    if args.check:
        return verify_mobile_artifacts()
    build_all_mobile_artifacts()
    return verify_mobile_artifacts()


if __name__ == "__main__":
    sys.exit(main())
