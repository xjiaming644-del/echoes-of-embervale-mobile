#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""执行第一波 15 张无限画布资产自动拆解、5阶段作物条合成、四向角色行走图集合成与无缝地形图块落盘"""
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent))
import art_pipeline
import import_canvas_batch as icb

DL = Path(r"C:\Users\Administrator\.gemini\antigravity\brain\890972f1-824a-48c2-9a70-0d3d7ee94b51\browser_sandbox\downloads")
OBJ = Path(__file__).resolve().parent.parent / "art_dropin" / "sprites" / "objects"

WAVE1 = {
    "quad_crops_1": DL / "canvas-image-image-1795394138579-4clzw.png",
    "quad_crops_2": DL / "canvas-image-image-1795394182018-vg8ia.png",
    "quad_crops_3": DL / "canvas-image-image-1795394289840-94gfe.png",
    "quad_crops_4": DL / "canvas-image-image-1795394314072-0nwyv.png",
    "quad_objects_1": DL / "canvas-image-image-1795394322432-8lm17.png",
    "quad_objects_2": DL / "canvas-image-image-1795394339416-mr2d8.png",
    "quad_objects_3": DL / "canvas-image-image-1795394347408-bfma2.png",
    "terrain_quad": DL / "canvas-image-image-1795394380521-ymsp7.png",
    "char_player": DL / "canvas-image-image-1795394444976-m7w1h.png",
    "char_linxia": DL / "canvas-image-image-1795394482837-r8w6c.png",
    "char_horn": DL / "canvas-image-image-1795394533502-b2leq.png",
    "char_ache": DL / "canvas-image-image-1795394567610-vya8h.png",
    "char_mei": DL / "canvas-image-image-1795394595917-380ky.png",
    "char_suwan": DL / "canvas-image-image-1795394626053-lrswe.png",
    "char_kailuo": DL / "canvas-image-image-1795394650315-kj2k0.png",
}


def main():
    count = 0
    count += len(icb.import_quad_sheet(WAVE1["quad_crops_1"], [
        {"crop_id": "turnip"},
        {"crop_id": "sunbell"},
        {"crop_id": "moonberry"},
        {"crop_id": "clover"},
    ]))
    count += len(icb.import_quad_sheet(WAVE1["quad_crops_2"], [
        {"crop_id": "tomato"},
        {"crop_id": "blueberry"},
        {"crop_id": "summer_melon"},
        {"crop_id": "ember_pumpkin"},
    ]))
    count += len(icb.import_quad_sheet(WAVE1["quad_crops_3"], [
        {"crop_id": "cranberry"},
        {"crop_id": "garlic_mint"},
        {"crop_id": "snow_lotus"},
        {"crop_id": "winter_root"},
    ]))
    count += len(icb.import_quad_sheet(WAVE1["quad_crops_4"], [
        {"crop_id": "ancient_fruit"},
        {"targets": ["crops/giant_summer_melon.png"]},
        {"targets": ["crops/giant_ember_pumpkin.png"]},
        {"targets": ["objects/forage_wild_berry.png", "icons/wild_berry.png"]},
    ]))
    count += len(icb.import_quad_sheet(WAVE1["quad_objects_1"], [
        {"targets": ["objects/stump.png"]},
        {"targets": ["objects/weed.png", "icons/fiber.png"]},
        {"targets": ["objects/forage_echo_shell.png", "icons/echo_shell.png"]},
        {"targets": ["objects/forage_spring_herb.png", "icons/spring_herb.png"]},
    ]))
    count += len(icb.import_quad_sheet(WAVE1["quad_objects_2"], [
        {"targets": ["objects/machine_sprinkler.png", "icons/machine_sprinkler.png"]},
        {"targets": ["objects/machine_quality_sprinkler.png", "icons/machine_quality_sprinkler.png"]},
        {"targets": ["objects/torch.png", "icons/torch.png"]},
        {"targets": ["objects/tv.png"]},
    ]))
    count += len(icb.import_quad_sheet(WAVE1["quad_objects_3"], [
        {"targets": ["objects/ladder_down.png"]},
        {"targets": ["objects/ladder_up.png"]},
        {"targets": ["objects/elevator.png"]},
        {"targets": ["icons/fertilizer_speed.png"]},
    ]))

    icb.import_terrain_atlas_from_quad(WAVE1["terrain_quad"])
    count += 1

    char_map = {
        "char_player": "characters/player_sheet.png",
        "char_linxia": "characters/npc_linxia.png",
        "char_horn": "characters/npc_horn.png",
        "char_ache": "characters/npc_ache.png",
        "char_mei": "characters/npc_mei.png",
        "char_suwan": "characters/npc_suwan.png",
        "char_kailuo": "characters/npc_kailuo.png",
    }
    for k, rel in char_map.items():
        icb.import_character_sheet_from_quad(WAVE1[k], rel)
        count += 1

    print(f"[OK] Wave 1 imported {count} sprite sheets/icons!")
    res = art_pipeline.check_status()
    miss = [s["rel_path"] for s in res["sprites"] if s["source"] != "human_override"]
    print(f"Human sprites: {res['human_sprites']} / {res['total_sprites']} | Warnings: {len(res['warnings'])}")
    if res["warnings"]:
        for w in res["warnings"]:
            print("  WARN:", w)
    print(f"Remaining missing ({len(miss)}):", miss)


if __name__ == "__main__":
    main()
