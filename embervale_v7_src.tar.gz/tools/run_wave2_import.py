#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""执行第二波 13 张无限画布物品图标四宫格拆解，达成 175/175 (100%) 精灵热替换全覆盖"""
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent))
import art_pipeline
import import_canvas_batch as icb

DL = Path(r"C:\Users\Administrator\.gemini\antigravity\brain\890972f1-824a-48c2-9a70-0d3d7ee94b51\browser_sandbox\downloads")

QUADS = [
    ("canvas-image-image-1795395012397-d3qyp.png", ["icons/tool_hoe.png", "icons/tool_can.png", "icons/tool_axe.png", "icons/tool_pickaxe.png"]),
    ("canvas-image-image-1795395025732-dpd01.png", ["icons/tool_blade.png", "icons/tool_rod.png", "icons/bouquet.png", "icons/mermaid_pendant.png"]),
    ("canvas-image-image-1795395081053-buivl.png", ["icons/wood.png", "icons/hardwood.png", "icons/stone.png", "icons/hay.png"]),
    ("canvas-image-image-1795395093624-egnzm.png", ["icons/copper_ore.png", "icons/iron_ore.png", "icons/gold_ore.png", "icons/echo_crystal.png"]),
    ("canvas-image-image-1795395430201-sbcun.png", ["icons/copper_bar.png", "icons/iron_bar.png", "icons/gold_bar.png", "icons/slime_gel.png"]),
    ("canvas-image-image-1795395105440-ufeju.png", ["icons/bug_chitin.png", "icons/egg.png", "icons/milk.png", "icons/wool.png"]),
    ("canvas-image-image-1795395130907-79vh1.png", ["icons/artisan_pickles.png", "icons/artisan_jam.png", "icons/artisan_wine.png", "icons/herbal_tea.png"]),
    ("canvas-image-image-1795395143624-n93kd.png", ["icons/artisan_mayo.png", "icons/artisan_cheese.png", "icons/artisan_cloth.png", "icons/roasted_fish.png"]),
    ("canvas-image-image-1795395179955-impxa.png", ["icons/fish_roe.png", "icons/artisan_caviar.png", "icons/fish_crucian.png", "icons/fish_sakura_trout.png"]),
    ("canvas-image-image-1795395203083-1ypqg.png", ["icons/fish_gold_carp.png", "icons/fish_glow_eel.png", "icons/fish_catfish.png", "icons/fish_frost_salmon.png"]),
    ("canvas-image-image-1795395250009-c556f.png", ["icons/fish_sun_perch.png", "icons/fish_echo_dragon.png", "icons/dish_spring_salad.png", "icons/dish_omelet.png"]),
    ("canvas-image-image-1795395283820-do0gx.png", ["icons/dish_berry_muffin.png", "icons/dish_herb_fish.png", "icons/dish_pumpkin_soup.png", "icons/dish_cheese_gratin.png"]),
    ("canvas-image-image-1795395307998-spq3u.png", ["icons/dish_miner_stew.png", "icons/dish_valley_feast.png", "", ""]),
]


def main():
    total = 0
    for fname, targets in QUADS:
        actions = [{"targets": [t]} if t else {} for t in targets]
        written = icb.import_quad_sheet(DL / fname, actions)
        total += len(written)
    print(f"[OK] Wave 2 imported {total} icons!")
    res = art_pipeline.check_status()
    print(f"=== FINAL COVERAGE: Sprites {res['human_sprites']} / {res['total_sprites']} | Audio {res['human_audio']} / {res['total_audio']} | Warnings: {len(res['warnings'])} ===")
    if res["warnings"]:
        for w in res["warnings"]:
            print("  WARN:", w)


if __name__ == "__main__":
    main()
