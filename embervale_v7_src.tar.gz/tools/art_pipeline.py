#!/usr/bin/env python3
"""
《星露物语：回响山谷》人工美术 & 音频热替换校验与交接管线工具
用法:
  python tools/art_pipeline.py spec   -> 生成 art_dropin/README_美术与音频交接规范.md 并建立分类文件夹
  python tools/art_pipeline.py check  -> 校验 art_dropin/ 下人工放入的 PNG/WAV 尺寸与格式规范
"""
import argparse
import json
import sys
import wave
from pathlib import Path
from PIL import Image

ROOT = Path(__file__).resolve().parent.parent
MANIFEST_PATH = ROOT / "game" / "data" / "art_manifest.json"
DROPIN_DIR = ROOT / "art_dropin"
DROPIN_SPRITES = DROPIN_DIR / "sprites"
DROPIN_AUDIO = DROPIN_DIR / "audio"


def load_manifest() -> dict:
    if not MANIFEST_PATH.exists():
        print(f"[ERROR] 找不到资产清单 {MANIFEST_PATH}，请先运行 python tools/generate_placeholders.py")
        sys.exit(1)
    return json.loads(MANIFEST_PATH.read_text(encoding="utf-8"))


def cmd_spec():
    manifest = load_manifest()
    for sub in ["characters", "crops", "tiles", "objects", "monsters", "animals", "icons", "portraits"]:
        (DROPIN_SPRITES / sub).mkdir(parents=True, exist_ok=True)
    DROPIN_AUDIO.mkdir(parents=True, exist_ok=True)

    lines = [
        "# 《星露物语：回响山谷》人工美术与音频热替换交接规范",
        "",
        "## 使用方式（零代码热替换！）",
        "1. 保持文件名和相对路径与下表**完全一致**，导出透明底 PNG（或 16-bit 44.1kHz WAV）到对应目录：",
        "   - 图片放入：`d:\\星露谷物语\\art_dropin\\sprites\\<相对路径>`",
        "   - 音效放入：`d:\\星露谷物语\\art_dropin\\audio\\<文件名>.wav`",
        "2. **无需打开 Godot 编辑器，也无需重启游戏！** 游戏运行中直接按 **`F9` 键**即可实时热刷新画面与音效。",
        "3. 如果某张图需要高清绘制（如 2x / 4x 像素或手绘插画），请确保**宽高与下表成整数倍比例**（或至少与原尺寸长宽比一致），程序会按标准帧格切片并自适应绘制。",
        "4. 在控制台或工作台执行 `python tools/art_pipeline.py check` 可自动检查所有新放入资产的尺寸与格式合规性。",
        "",
        "## 一、核心精灵图集 / 建筑 / 植物 / 头像尺寸规格表",
        "",
        "| 相对路径 (置于 `art_dropin/sprites/` 下) | 分类 | 资产名称 | 标准总尺寸 (px) | 单帧尺寸 | 说明 |",
        "| :--- | :--- | :--- | :--- | :--- | :--- |",
    ]

    icons = []
    for sp in manifest["sprites"]:
        if sp["category"] == "icon":
            icons.append(sp)
            continue
        lines.append(
            f"| `{sp['rel_path']}` | {sp['category']} | {sp['name']} | `{sp['width']}×{sp['height']}` | `{sp['frame_w']}×{sp['frame_h']}` | {sp['notes']} |"
        )

    lines += [
        "",
        f"## 二、物品图标列表（共 {len(icons)} 项，统一规格 `32×32` 透明底 PNG）",
        "",
        "| 相对路径 (`art_dropin/sprites/`) | 物品名称 |",
        "| :--- | :--- |",
    ]
    for ic in icons:
        lines.append(f"| `{ic['rel_path']}` | {ic['name']} |")

    lines += [
        "",
        "## 三、音频与环境声列表（统一为 `.wav`，推荐 16-bit 44100Hz）",
        "",
        "| 相对路径 (`art_dropin/audio/`) | 音效名称 | 参考时长 | 说明 |",
        "| :--- | :--- | :--- | :--- |",
    ]
    for au in manifest["audio"]:
        lines.append(f"| `{au['rel_path']}` | {au['name']} | {au['duration_sec']}s | {au['notes']} |")

    out_path = DROPIN_DIR / "README_美术与音频交接规范.md"
    out_path.write_text("\n".join(lines), encoding="utf-8")
    print(f"[OK] 已生成美术与音频交接规范: {out_path}")


def check_status() -> dict:
    manifest = load_manifest()
    sprites_report = []
    audio_report = []
    warnings = []

    for sp in manifest["sprites"]:
        rel = sp["rel_path"]
        ext_file = DROPIN_SPRITES / rel
        entry = {
            "rel_path": rel,
            "name": sp["name"],
            "category": sp["category"],
            "expected_w": sp["width"],
            "expected_h": sp["height"],
            "source": "human_override" if ext_file.exists() else "ai_placeholder",
            "status": "ok",
            "message": "使用 AI 程序化占位资产",
        }
        if ext_file.exists():
            try:
                with Image.open(ext_file) as im:
                    w, h = im.size
                    ew, eh = sp["width"], sp["height"]
                    if w == ew and h == eh:
                        entry["message"] = f"人工资产尺寸精确匹配 ({w}x{h})"
                    elif w >= ew and h >= eh and w % ew == 0 and h % eh == 0 and (w // ew) == (h // eh):
                        scale = w // ew
                        entry["message"] = f"人工高清 {scale}x 等比资产 ({w}x{h})"
                    else:
                        entry["status"] = "warn"
                        entry["message"] = f"尺寸不匹配: 期望 {ew}x{eh} (或整数倍), 实际 {w}x{h}"
                        warnings.append(f"{rel}: {entry['message']}")
            except Exception as exc:
                entry["status"] = "error"
                entry["message"] = f"无法解析图片: {exc}"
                warnings.append(f"{rel}: {entry['message']}")
        sprites_report.append(entry)

    for au in manifest["audio"]:
        rel = au["rel_path"]
        ext_file = DROPIN_AUDIO / rel
        entry = {
            "rel_path": rel,
            "name": au["name"],
            "source": "human_override" if ext_file.exists() else "ai_placeholder",
            "status": "ok",
            "message": "使用 AI 合成 WAV",
        }
        if ext_file.exists():
            try:
                with wave.open(str(ext_file), "rb") as wf:
                    ch = wf.getnchannels()
                    sw = wf.getsampwidth()
                    sr = wf.getframerate()
                    if sw != 2:
                        entry["status"] = "warn"
                        entry["message"] = f"建议 16-bit PCM (当前 {sw*8}-bit)"
                        warnings.append(f"audio/{rel}: {entry['message']}")
                    else:
                        entry["message"] = f"人工 WAV 已就绪 ({ch}ch, {sr}Hz)"
            except Exception as exc:
                entry["status"] = "error"
                entry["message"] = f"无效 WAV 文件: {exc}"
                warnings.append(f"audio/{rel}: {entry['message']}")
        audio_report.append(entry)

    human_sprites = sum(1 for x in sprites_report if x["source"] == "human_override")
    human_audio = sum(1 for x in audio_report if x["source"] == "human_override")
    return {
        "total_sprites": len(sprites_report),
        "human_sprites": human_sprites,
        "total_audio": len(audio_report),
        "human_audio": human_audio,
        "warnings": warnings,
        "sprites": sprites_report,
        "audio": audio_report,
    }


def cmd_check():
    res = check_status()
    print("=== 《星露物语：回响山谷》美术与音频替换校验报告 ===")
    print(f"精灵资产: 人工已替换 {res['human_sprites']} / {res['total_sprites']}")
    print(f"音频资产: 人工已替换 {res['human_audio']} / {res['total_audio']}")
    if res["warnings"]:
        print("告警列表:")
        for w in res["warnings"]:
            print(f"  [WARN] {w}")
    else:
        print("[OK] 所有资产规格与路径校验完全通过！")


def import_ai_image(src_path: Path, target_rel: str, tolerance: int = 54, scale_mult: int = 0) -> Path:
    """
    将 AI 生成的大图（如 2048x2048 纯白/浅灰/纯色底 PNG/JPEG）自动执行：
    1) 四角采样 + 边缘连通泛洪抠除背景（保留内部白色高光如牛奶、鸡蛋、白木门、眼神光！）
    2) 2 轮 JPEG 边缘白边去光晕处理（消除白底压缩毛刺）
    3) 自动紧致裁剪主体包围盒
    4) 按类别自适应：
       - portrait: 2x (192x192) 星露谷胡桃木羊皮纸画框 + 底部对齐半身立绘
       - animal / monster (4帧横条): 单体角色自动合成 4 帧生动呼吸/跳跃动画条 (2x 高清像素)
       - object: 2x 高清最近邻像素对齐（建筑/树木/奇观自动底部锚定贴地）
       - icon: 1x (32x32) 锐利像素图标
    """
    from collections import deque
    from PIL import ImageDraw

    manifest = load_manifest()
    spec_map = {s["rel_path"]: s for s in manifest["sprites"]}
    if target_rel not in spec_map:
        raise ValueError(f"目标相对路径不在 art_manifest.json 中: {target_rel}")
    sp = spec_map[target_rel]
    cat = sp.get("category", "object")
    if scale_mult <= 0:
        scale_mult = 1 if cat == "icon" else 2

    tw = int(sp["width"]) * scale_mult
    th = int(sp["height"]) * scale_mult
    fw = int(sp.get("frame_w", sp["width"])) * scale_mult
    fh = int(sp.get("frame_h", sp["height"])) * scale_mult

    im = Image.open(src_path).convert("RGBA")
    w, h = im.size
    px = im.load()

    # Sample corner background color
    corners = [px[0, 0], px[w - 1, 0], px[0, h - 1], px[w - 1, h - 1]]
    bg_r = sum(c[0] for c in corners) // 4
    bg_g = sum(c[1] for c in corners) // 4
    bg_b = sum(c[2] for c in corners) // 4

    def is_bg(c):
        if c[3] < 20:
            return True
        return abs(c[0] - bg_r) + abs(c[1] - bg_g) + abs(c[2] - bg_b) <= tolerance * 3

    visited = bytearray(w * h)
    q = deque()
    for x in range(w):
        for y in (0, h - 1):
            idx = y * w + x
            if not visited[idx] and is_bg(px[x, y]):
                visited[idx] = 1
                q.append((x, y))
    for y in range(h):
        for x in (0, w - 1):
            idx = y * w + x
            if not visited[idx] and is_bg(px[x, y]):
                visited[idx] = 1
                q.append((x, y))

    while q:
        cx, cy = q.popleft()
        px[cx, cy] = (0, 0, 0, 0)
        for dx, dy in ((-1, 0), (1, 0), (0, -1), (0, 1)):
            nx, ny = cx + dx, cy + dy
            if 0 <= nx < w and 0 <= ny < h:
                nidx = ny * w + nx
                if not visited[nidx] and is_bg(px[nx, ny]):
                    visited[nidx] = 1
                    q.append((nx, ny))

    # 2-pass JPEG white-halo defringing at high source resolution
    if min(w, h) >= 256:
        for _pass in range(2):
            to_clear = []
            for y in range(1, h - 1):
                for x in range(1, w - 1):
                    c = px[x, y]
                    if c[3] > 0 and min(c[0], c[1], c[2]) >= 214 and (max(c[0], c[1], c[2]) - min(c[0], c[1], c[2])) <= 34:
                        if px[x - 1, y][3] == 0 or px[x + 1, y][3] == 0 or px[x, y - 1][3] == 0 or px[x, y + 1][3] == 0:
                            to_clear.append((x, y))
            for cx2, cy2 in to_clear:
                px[cx2, cy2] = (0, 0, 0, 0)

    bbox = im.getbbox()
    if bbox:
        im = im.crop(bbox)

    if cat == "portrait":
        out = Image.new("RGBA", (tw, th), (0, 0, 0, 0))
        d = ImageDraw.Draw(out)
        bw = max(2, 3 * scale_mult)
        d.rounded_rectangle([2, 2, tw - 3, th - 3], radius=8 * scale_mult, fill=(242, 224, 188, 255), outline=(92, 54, 28, 255), width=bw)
        inner = 5 * scale_mult
        d.rounded_rectangle([inner, inner, tw - 1 - inner, th - 1 - inner], radius=5 * scale_mult, fill=(224, 202, 162, 255), outline=(212, 162, 76, 255), width=max(1, scale_mult))
        avail_w = tw - (inner + 2) * 2
        avail_h = th - (inner + 2) * 2
        sc = min(avail_w / max(1, im.width), avail_h / max(1, im.height))
        nw = max(1, int(round(im.width * sc)))
        nh = max(1, int(round(im.height * sc)))
        resized = im.resize((nw, nh), Image.Resampling.NEAREST)
        out.paste(resized, ((tw - nw) // 2, th - inner - 1 - nh), resized)
    elif cat in ("animal", "monster") and tw == fw * 4 and th == fh and (im.width / max(1, im.height)) < 2.2:
        # Synthesize 4-frame animated horizontal strip from single creature sprite!
        out = Image.new("RGBA", (tw, th), (0, 0, 0, 0))
        pad = 2 * scale_mult
        avail_w = max(1, fw - pad * 2)
        avail_h = max(1, fh - pad * 2 - 2 * scale_mult)
        sc = min(avail_w / max(1, im.width), avail_h / max(1, im.height))
        nw = max(1, int(round(im.width * sc)))
        nh = max(1, int(round(im.height * sc)))
        base_sp = im.resize((nw, nh), Image.Resampling.NEAREST)
        for fi in range(4):
            y_off = 0
            sp_frame = base_sp
            if fi == 1:
                y_off = -2 * scale_mult
            elif fi == 3:
                sq_w = min(fw - 2, max(1, int(round(nw * 1.04))))
                sq_h = max(1, int(round(nh * 0.95)))
                sp_frame = im.resize((sq_w, sq_h), Image.Resampling.NEAREST)
            ox = fi * fw + (fw - sp_frame.width) // 2
            oy = fh - pad - sp_frame.height + y_off
            out.paste(sp_frame, (ox, max(0, oy)), sp_frame)
    elif cat == "crop" and tw == fw * 5 and th == fh and (im.width / max(1, im.height)) < 2.2:
        # Synthesize 5-stage Stardew 16-bit pixel-art crop strip (stages 0..3 serrated pixel foliage + stage 4 AI ripe crop)
        out = Image.new("RGBA", (tw, th), (0, 0, 0, 0))
        # Sample vivid flower/fruit accent color from AI crop (require real saturation >= 42 to avoid gray soil/edge pixels)
        bud_col = (246, 238, 192, 255)  # Warm cream-gold default blossom for pure-green herbs like clover
        small_probe = im.resize((24, 24), Image.Resampling.NEAREST)
        best_sat = 41
        green_samples: list[tuple[int, int, int]] = []
        for py_i in range(24):
            for px_i in range(24):
                pr, pg, pb, pa = small_probe.getpixel((px_i, py_i))
                if pa <= 180:
                    continue
                if pg > pr + 14 and pg > pb + 12 and 60 <= pg <= 225:
                    green_samples.append((pr, pg, pb))
                elif not (pg > pr + 16 and pg > pb + 16):
                    # Ignore dark brown soil/outlines when picking flower/fruit buds
                    is_soil = (pr > pb + 20 and pg < pr and pr < 145 and pg < 105)
                    sat = max(pr, pg, pb) - min(pr, pg, pb)
                    if not is_soil and sat > best_sat and max(pr, pg, pb) >= 105:
                        best_sat = sat
                        bud_col = (pr, pg, pb, 255)

        # Harmonize foliage greens subtly toward Stage 4's warm green palette
        if green_samples:
            avg_r = sum(c[0] for c in green_samples) // len(green_samples)
            avg_g = sum(c[1] for c in green_samples) // len(green_samples)
            avg_b = sum(c[2] for c in green_samples) // len(green_samples)
            leaf_mid = (
                max(42, min(115, (avg_r + 74) // 2)),
                max(138, min(198, (avg_g + 176) // 2)),
                max(34, min(92, (avg_b + 54) // 2)),
                255,
            )
        else:
            leaf_mid = (74, 174, 54, 255)
        leaf_dark = (max(24, leaf_mid[0] - 32), max(88, leaf_mid[1] - 52), max(20, leaf_mid[2] - 24), 255)
        leaf_deep = (max(18, leaf_mid[0] - 46), max(62, leaf_mid[1] - 80), max(14, leaf_mid[2] - 34), 255)
        leaf_light = (min(176, leaf_mid[0] + 46), min(232, leaf_mid[1] + 38), min(124, leaf_mid[2] + 28), 255)
        leaf_vein = (min(212, leaf_mid[0] + 78), min(246, leaf_mid[1] + 54), min(148, leaf_mid[2] + 44), 255)
        stem_col = (max(36, leaf_mid[0] - 18), max(112, leaf_mid[1] - 34), max(26, leaf_mid[2] - 16), 255)
        outline_c = (36, 22, 14, 255)
        bud_dark = (max(30, int(bud_col[0] * 0.68)), max(24, int(bud_col[1] * 0.68)), max(24, int(bud_col[2] * 0.68)), 255)
        bud_hi = (min(255, bud_col[0] + 38), min(255, bud_col[1] + 38), min(255, bud_col[2] + 34), 255)

        s = max(1, scale_mult)
        pad = 2 * s

        def _put(px_acc, x: int, y: int, col: tuple[int, int, int, int]) -> None:
            if 0 <= x < fw and 0 <= y < fh:
                px_acc[x, y] = col

        def _draw_soil_patch(px_acc, cx: int, by: int, rx: int, ry: int) -> None:
            soil_d = (86, 54, 30, 255)
            soil_m = (118, 78, 44, 255)
            soil_l = (152, 106, 64, 255)
            for dy_s in range(-ry, ry + 1):
                for dx_s in range(-rx, rx + 1):
                    # Irregular pixel-stepped soil mound (avoid smooth geometric oval)
                    jitter = ((abs(dx_s * 7 + dy_s * 13) % 5) - 2) * 0.08
                    norm_d = (dx_s / max(1.0, rx)) ** 2 + (dy_s / max(1.0, ry)) ** 2 + jitter
                    if norm_d <= 1.0:
                        col = soil_d if dy_s > 0 else soil_m
                        if (dx_s + dy_s * 3) % 7 == 0 and dy_s <= 0:
                            col = soil_l
                        elif (dx_s * 5 - dy_s) % 6 == 0:
                            col = soil_d
                        _put(px_acc, cx + dx_s, by + dy_s, col)

        def _draw_serrated_leaf(
            px_acc,
            x0: int,
            y0: int,
            dx_f: float,
            dy_f: float,
            length: int,
            half_w: float,
            droop: float,
            dark_tone: bool = False,
        ) -> None:
            import math
            c_lo = leaf_deep if dark_tone else leaf_dark
            c_md = leaf_dark if dark_tone else leaf_mid
            c_hi = leaf_mid if dark_tone else leaf_light
            c_vn = leaf_light if dark_tone else leaf_vein
            nx_f, ny_f = -dy_f, dx_f
            steps = max(4, length * 2)
            for st_i in range(steps + 1):
                u = st_i / float(steps)
                dist = u * length
                curve_y = droop * (u * u) * length
                bx_f = x0 + dx_f * dist
                by_f = y0 + dy_f * dist + curve_y
                # Pointed lanceolate profile with 16-bit serrated leaf teeth
                profile = math.sin(math.pi * (u ** 0.72))
                tooth = 0.85 if (int(dist) % 3 == 1 and 0.18 < u < 0.86) else 0.0
                w_here = max(0.0, half_w * profile + tooth)
                iw = int(round(w_here))
                for off in range(-iw, iw + 1):
                    px_x = int(round(bx_f + nx_f * off))
                    px_y = int(round(by_f + ny_f * off))
                    if iw >= 2 and off == iw:
                        col = leaf_deep
                    elif off == 0 and 0.12 < u < 0.82:
                        col = c_vn
                    elif off < 0:
                        col = c_hi
                    elif off > max(0, iw - 1):
                        col = c_lo
                    else:
                        col = c_md
                    _put(px_acc, px_x, px_y, col)
            # Crisp 1px dark axil/tip accent so overlapping leaves never merge into a flat blob
            tip_x = int(round(x0 + dx_f * length))
            tip_y = int(round(y0 + dy_f * length + droop * length))
            _put(px_acc, tip_x, tip_y, c_lo)

        def _draw_stem(px_acc, x0: int, y0: int, x1: int, y1: int, thick: int = 2) -> None:
            steps = max(abs(x1 - x0), abs(y1 - y0), 1)
            for i_s in range(steps + 1):
                u = i_s / float(steps)
                sx = int(round(x0 + (x1 - x0) * u))
                sy = int(round(y0 + (y1 - y0) * u))
                _put(px_acc, sx, sy, stem_col)
                if thick >= 2:
                    _put(px_acc, sx - 1, sy, leaf_light)
                if thick >= 3:
                    _put(px_acc, sx + 1, sy, leaf_dark)

        def _draw_pixel_bud(px_acc, bx: int, by: int, rad: int) -> None:
            # Sculpted pixel flower bud / young fruit with green calyx sepals & 1px dark contour
            for dy_b in range(-rad - 1, rad + 2):
                for dx_b in range(-rad - 1, rad + 2):
                    d2 = dx_b * dx_b + dy_b * dy_b
                    if d2 <= rad * rad:
                        if dx_b <= -1 and dy_b <= -1:
                            col = bud_hi
                        elif dx_b >= 1 or dy_b >= 1:
                            col = bud_dark
                        else:
                            col = bud_col
                        _put(px_acc, bx + dx_b, by + dy_b, col)
                    elif d2 <= (rad + 1) * (rad + 1) and abs(dx_b) + abs(dy_b) <= rad + 2:
                        _put(px_acc, bx + dx_b, by + dy_b, outline_c)
            # Calyx sepal pixels cradling bottom of bud
            _put(px_acc, bx - 1, by + rad, leaf_mid)
            _put(px_acc, bx, by + rad + 1, leaf_dark)
            _put(px_acc, bx + 1, by + rad, leaf_mid)

        cx = fw // 2
        base_y = fh - pad - 3 * s
        for stg in range(4):
            cell = Image.new("RGBA", (fw, fh), (0, 0, 0, 0))
            c_px = cell.load()
            if stg == 0:
                _draw_soil_patch(c_px, cx, base_y, 9 * s, 3 * s)
                seed_hi = (248, 228, 166, 255)
                seed_sh = (196, 156, 92, 255)
                for sx_o, sy_o in [(-5 * s, -1 * s), (-1 * s, 1 * s), (3 * s, -1 * s), (6 * s, 1 * s)]:
                    for dy_k in range(max(2, s + 1)):
                        for dx_k in range(max(2, s + 1)):
                            _put(c_px, cx + sx_o + dx_k, base_y + sy_o + dy_k, seed_hi if dy_k == 0 else seed_sh)
                # Tiny emerging green shoot tip in center
                _draw_stem(c_px, cx, base_y - 1, cx, base_y - 3 * s, thick=max(1, s))
                _put(c_px, cx - 1, base_y - 3 * s - 1, leaf_vein)
                _put(c_px, cx + 1, base_y - 3 * s, leaf_light)
            elif stg == 1:
                _draw_soil_patch(c_px, cx, base_y, 8 * s, 2 * s + 1)
                _draw_stem(c_px, cx, base_y, cx, base_y - 7 * s, thick=s)
                _draw_serrated_leaf(c_px, cx - 1, base_y - 4 * s, -0.88, -0.46, 6 * s, 1.8 * s, 0.22, dark_tone=True)
                _draw_serrated_leaf(c_px, cx + 1, base_y - 4 * s, 0.88, -0.46, 6 * s, 1.8 * s, 0.22, dark_tone=True)
                _draw_serrated_leaf(c_px, cx, base_y - 6 * s, -0.80, -0.60, 7 * s, 2.2 * s, 0.18, dark_tone=False)
                _draw_serrated_leaf(c_px, cx, base_y - 6 * s, 0.80, -0.60, 7 * s, 2.2 * s, 0.18, dark_tone=False)
                _draw_serrated_leaf(c_px, cx, base_y - 7 * s, 0.05, -0.98, 4 * s, 1.4 * s, 0.05, dark_tone=False)
            elif stg == 2:
                _draw_soil_patch(c_px, cx, base_y, 10 * s, 3 * s)
                _draw_stem(c_px, cx, base_y, cx, base_y - 12 * s, thick=s + 1)
                _draw_stem(c_px, cx, base_y - 5 * s, cx - 4 * s, base_y - 10 * s, thick=s)
                _draw_stem(c_px, cx, base_y - 5 * s, cx + 4 * s, base_y - 10 * s, thick=s)
                # Back dark emerald foliage layer
                for dx_f, dy_f, ln_m, y_m in [
                    (-0.94, -0.32, 9, 4),
                    (0.94, -0.32, 9, 4),
                    (-0.72, -0.68, 10, 8),
                    (0.72, -0.68, 10, 8),
                    (0.0, -1.0, 9, 10),
                ]:
                    _draw_serrated_leaf(c_px, cx, base_y - y_m * s, dx_f, dy_f, ln_m * s, 2.5 * s, 0.24, dark_tone=True)
                # Front sunlit serrated leaf rosette
                for ox_m, y_m, dx_f, dy_f, ln_m in [
                    (-1, 3, -0.92, -0.22, 8),
                    (1, 3, 0.92, -0.22, 8),
                    (-2, 7, -0.82, -0.56, 9),
                    (2, 7, 0.82, -0.56, 9),
                    (-1, 10, -0.46, -0.88, 8),
                    (1, 10, 0.46, -0.88, 8),
                ]:
                    _draw_serrated_leaf(c_px, cx + ox_m * s, base_y - y_m * s, dx_f, dy_f, ln_m * s, 2.3 * s, 0.20, dark_tone=False)
            elif stg == 3:
                _draw_soil_patch(c_px, cx, base_y, 11 * s, 3 * s)
                _draw_stem(c_px, cx, base_y, cx, base_y - 16 * s, thick=s + 1)
                _draw_stem(c_px, cx, base_y - 6 * s, cx - 6 * s, base_y - 13 * s, thick=s)
                _draw_stem(c_px, cx, base_y - 6 * s, cx + 6 * s, base_y - 13 * s, thick=s)
                # Back shadow canopy
                for dx_f, dy_f, ln_m, y_m in [
                    (-0.96, -0.25, 11, 4),
                    (0.96, -0.25, 11, 4),
                    (-0.80, -0.60, 12, 8),
                    (0.80, -0.60, 12, 8),
                    (-0.42, -0.90, 11, 12),
                    (0.42, -0.90, 11, 12),
                    (0.0, -1.0, 10, 13),
                ]:
                    _draw_serrated_leaf(c_px, cx, base_y - y_m * s, dx_f, dy_f, ln_m * s, 2.7 * s, 0.25, dark_tone=True)
                # Front sunlit foliage
                for ox_m, y_m, dx_f, dy_f, ln_m in [
                    (-2, 4, -0.92, -0.18, 10),
                    (2, 4, 0.92, -0.18, 10),
                    (-3, 8, -0.84, -0.52, 10),
                    (3, 8, 0.84, -0.52, 10),
                    (-2, 12, -0.55, -0.82, 9),
                    (2, 12, 0.55, -0.82, 9),
                    (0, 14, 0.04, -0.96, 8),
                ]:
                    _draw_serrated_leaf(c_px, cx + ox_m * s, base_y - y_m * s, dx_f, dy_f, ln_m * s, 2.4 * s, 0.22, dark_tone=False)
                # Sculpted 3-tone flower buds / immature fruits nestled among upper leaves
                bud_r = max(2, 2 * s)
                for bx_o, by_o in [(-6 * s, -13 * s), (5 * s, -12 * s), (0, -16 * s), (-2 * s, -9 * s), (4 * s, -7 * s)]:
                    _draw_pixel_bud(c_px, cx + bx_o, base_y + by_o, bud_r)

            # Crisp 1px dark brown Stardew pixel outline at native (fw x fh) resolution to match Stage 4!
            outlined = cell.copy()
            o_px = outlined.load()
            for oy_i in range(fh):
                for ox_i in range(fw):
                    if c_px[ox_i, oy_i][3] == 0:
                        for dx_i, dy_i in ((-1, 0), (1, 0), (0, -1), (0, 1)):
                            nx_i, ny_i = ox_i + dx_i, oy_i + dy_i
                            if 0 <= nx_i < fw and 0 <= ny_i < fh and c_px[nx_i, ny_i][3] > 20:
                                o_px[ox_i, oy_i] = outline_c
                                break
            out.paste(outlined, (stg * fw, 0), outlined)
        # Stage 4: AI-generated ripe crop plant anchored at bottom!
        avail_w = max(1, fw - pad * 2)
        avail_h = max(1, fh - pad * 2)
        sc = min(avail_w / max(1, im.width), avail_h / max(1, im.height))
        nw = max(1, int(round(im.width * sc)))
        nh = max(1, int(round(im.height * sc)))
        ripe_sp = im.resize((nw, nh), Image.Resampling.NEAREST)
        out.paste(ripe_sp, (4 * fw + (fw - nw) // 2, max(0, fh - pad - nh)), ripe_sp)
    else:
        out = Image.new("RGBA", (tw, th), (0, 0, 0, 0))
        pad = 2 * scale_mult if min(tw, th) >= 32 else 0
        avail_w = max(1, tw - pad * 2)
        avail_h = max(1, th - pad * 2)
        sc = min(avail_w / max(1, im.width), avail_h / max(1, im.height))
        nw = max(1, int(round(im.width * sc)))
        nh = max(1, int(round(im.height * sc)))
        resized = im.resize((nw, nh), Image.Resampling.NEAREST)
        py = (th - nh - pad) if cat == "object" else ((th - nh) // 2)
        out.paste(resized, ((tw - nw) // 2, max(0, py)), resized)

    dest = DROPIN_SPRITES / target_rel
    dest.parent.mkdir(parents=True, exist_ok=True)
    out.save(dest)
    return dest


def self_test_import_ai():
    import tempfile
    target_icon = DROPIN_SPRITES / "icons/tomato.png"
    target_crop = DROPIN_SPRITES / "crops/crop_tomato.png"
    bak_icon = target_icon.read_bytes() if target_icon.exists() else None
    bak_crop = target_crop.read_bytes() if target_crop.exists() else None
    try:
        with tempfile.TemporaryDirectory() as td:
            fake_ai = Path(td) / "raw_1024.png"
            im = Image.new("RGBA", (256, 256), (255, 255, 255, 255))
            for y in range(60, 196):
                for x in range(70, 186):
                    im.putpixel((x, y), (220, 80, 60, 255))
            # Inner white highlight that must NOT be erased!
            for y in range(100, 130):
                for x in range(110, 140):
                    im.putpixel((x, y), (255, 255, 255, 255))
            im.save(fake_ai)
            dest = import_ai_image(fake_ai, "icons/tomato.png")
            with Image.open(dest) as res_im:
                assert res_im.size == (32, 32), f"Expected 32x32, got {res_im.size}"
                assert res_im.getpixel((0, 0))[3] == 0, "Corner must be transparent"
                assert res_im.getpixel((16, 16))[3] == 255, "Center highlight must remain opaque"
            crop_dest = import_ai_image(fake_ai, "crops/crop_tomato.png")
            with Image.open(crop_dest) as crop_im:
                assert crop_im.size == (320, 64), f"Expected 320x64 5-stage strip, got {crop_im.size}"
    finally:
        if bak_icon is not None:
            target_icon.write_bytes(bak_icon)
        else:
            target_icon.unlink(missing_ok=True)
        if bak_crop is not None:
            target_crop.write_bytes(bak_crop)
        else:
            target_crop.unlink(missing_ok=True)
    print("[PASS] art_pipeline.py import-ai flood-matte, 5-stage pixel foliage & non-destructive self-test passed")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("cmd", choices=["spec", "check", "import-ai"], nargs="?", default="check")
    parser.add_argument("--input", type=str, default="", help="AI 生成原图路径")
    parser.add_argument("--target", type=str, default="", help="art_manifest.json 中的目标相对路径，例如 icons/turnip.png")
    parser.add_argument("--tolerance", type=int, default=44)
    parser.add_argument("--self-test", action="store_true")
    args = parser.parse_args()
    if args.self_test:
        self_test_import_ai()
        return
    if args.cmd == "spec":
        cmd_spec()
    elif args.cmd == "import-ai":
        if not args.input or not args.target:
            print("用法: python tools/art_pipeline.py import-ai --input 原图.png --target icons/turnip.png")
            sys.exit(1)
        out = import_ai_image(Path(args.input), args.target, args.tolerance)
        print(f"[OK] 已自动抠底并像素化对齐至: {out} (游戏内按 F9 即刻生效)")
    else:
        cmd_check()


if __name__ == "__main__":
    main()
