#!/usr/bin/env python3
"""
《星露物语：回响山谷》纯标准库 WAV 声效与田园氛围声合成器
输出 16-bit PCM 44100Hz WAV 文件至 game/assets/audio/。
"""
import math
import random
import struct
import wave
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
AUDIO_DIR = ROOT / "game" / "assets" / "audio"
SAMPLE_RATE = 44100


def write_wav(filename: str, samples: list[float]):
    AUDIO_DIR.mkdir(parents=True, exist_ok=True)
    path = AUDIO_DIR / filename
    with wave.open(str(path), "wb") as wf:
        wf.setnchannels(1)
        wf.setsampwidth(2)
        wf.setframerate(SAMPLE_RATE)
        frames = bytearray()
        for s in samples:
            clamped = max(-0.95, min(0.95, s))
            frames += struct.pack("<h", int(clamped * 32767))
        wf.writeframes(bytes(frames))


def env_ad(i: int, total: int, attack_s: float = 0.008) -> float:
    atk = max(1, int(attack_s * SAMPLE_RATE))
    if i < atk:
        return i / atk
    rem = max(1, total - atk)
    return max(0.0, 1.0 - (i - atk) / rem) ** 1.6


def synth_tone(freq_start: float, freq_end: float, dur: float, amp: float = 0.45, wave_type: str = "sine", noise_mix: float = 0.0, seed: int = 1):
    rng = random.Random(seed)
    n = int(dur * SAMPLE_RATE)
    out = []
    phase = 0.0
    for i in range(n):
        t = i / max(1, n - 1)
        f = freq_start + (freq_end - freq_start) * t
        phase += 2.0 * math.pi * f / SAMPLE_RATE
        if wave_type == "sine":
            val = math.sin(phase)
        elif wave_type == "tri":
            val = 2.0 * abs(2.0 * ((phase / (2.0 * math.pi)) % 1.0) - 1.0) - 1.0
        elif wave_type == "square":
            val = 0.6 if math.sin(phase) >= 0 else -0.6
        else:
            val = math.sin(phase)
        if noise_mix > 0.0:
            val = val * (1.0 - noise_mix) + rng.uniform(-1.0, 1.0) * noise_mix
        out.append(val * env_ad(i, n) * amp)
    return out


def synth_arpeggio(freqs: list[float], step_dur: float, tail_dur: float, amp: float = 0.35):
    total_dur = step_dur * len(freqs) + tail_dur
    n = int(total_dur * SAMPLE_RATE)
    out = [0.0] * n
    for idx, f in enumerate(freqs):
        start_i = int(idx * step_dur * SAMPLE_RATE)
        note_n = int((tail_dur + step_dur * 0.8) * SAMPLE_RATE)
        for j in range(note_n):
            if start_i + j >= n:
                break
            t = j / SAMPLE_RATE
            env = min(1.0, j / (0.008 * SAMPLE_RATE)) * math.exp(-t * 6.5)
            val = math.sin(2.0 * math.pi * f * t) + 0.25 * math.sin(4.0 * math.pi * f * t)
            out[start_i + j] += val * env * amp * 0.65
    return out


def synth_valley_breeze_loop(dur: float = 8.0):
    """8秒无缝循环：五声音阶柔美田园拨弦 + 微风滤噪"""
    rng = random.Random(77)
    n = int(dur * SAMPLE_RATE)
    out = [0.0] * n
    # Smooth low-passed breeze bed (periodic across loop)
    lp = 0.0
    raw = [rng.uniform(-1.0, 1.0) for _ in range(n)]
    for i in range(n * 2):
        idx = i % n
        lp = lp * 0.985 + raw[idx] * 0.015
        if i >= n:
            breeze = lp * 0.16 * (0.75 + 0.25 * math.sin(2.0 * math.pi * 2.0 * idx / n))
            out[idx] += breeze

    # Pentatonic harp notes (C4, D4, E4, G4, A4, C5, D5, E5)
    melody = [
        (0.0, 261.63), (0.5, 329.63), (1.0, 392.00), (1.5, 523.25),
        (2.0, 440.00), (2.5, 392.00), (3.0, 329.63), (3.5, 293.66),
        (4.0, 261.63), (4.5, 392.00), (5.0, 440.00), (5.5, 587.33),
        (6.0, 523.25), (6.5, 440.00), (7.0, 392.00), (7.5, 329.63),
    ]
    for onset, freq in melody:
        start_i = int(onset * SAMPLE_RATE)
        note_len = int(1.6 * SAMPLE_RATE)
        for j in range(note_len):
            idx = (start_i + j) % n
            t = j / SAMPLE_RATE
            env = min(1.0, j / (0.015 * SAMPLE_RATE)) * math.exp(-t * 2.6)
            val = 0.7 * math.sin(2.0 * math.pi * freq * t) + 0.22 * math.sin(4.0 * math.pi * freq * t)
            out[idx] += val * env * 0.16
    return out


def main():
    write_wav("till.wav", synth_tone(190, 95, 0.16, amp=0.45, wave_type="tri", noise_mix=0.45, seed=10))
    # Water splash: filtered noise + bubbling sine
    rng = random.Random(22)
    wn = int(0.28 * SAMPLE_RATE)
    lp = 0.0
    water_s = []
    for i in range(wn):
        t = i / SAMPLE_RATE
        lp = lp * 0.85 + rng.uniform(-1.0, 1.0) * 0.15
        bubble = math.sin(2.0 * math.pi * (420 + 280 * math.sin(t * 36.0)) * t) * 0.22
        water_s.append((lp * 1.8 + bubble) * env_ad(i, wn, 0.015) * 0.55)
    write_wav("water.wav", water_s)

    write_wav("plant.wav", synth_tone(320, 480, 0.12, amp=0.32, wave_type="sine", noise_mix=0.1, seed=3))
    write_wav("harvest.wav", synth_arpeggio([523.25, 659.25, 783.99], 0.055, 0.15, amp=0.38))
    write_wav("chop.wav", synth_tone(150, 70, 0.16, amp=0.52, wave_type="tri", noise_mix=0.35, seed=4))
    write_wav("mine_hit.wav", synth_tone(1180, 760, 0.18, amp=0.38, wave_type="sine", noise_mix=0.18, seed=5))
    write_wav("sword_swing.wav", synth_tone(520, 180, 0.14, amp=0.35, wave_type="sine", noise_mix=0.55, seed=6))
    write_wav("monster_hit.wav", synth_tone(240, 110, 0.15, amp=0.45, wave_type="square", noise_mix=0.2, seed=7))
    write_wav("coin.wav", synth_arpeggio([987.77, 1318.51], 0.06, 0.16, amp=0.36))
    write_wav("fish_cast.wav", synth_tone(640, 260, 0.25, amp=0.32, wave_type="sine", noise_mix=0.28, seed=8))
    write_wav("fish_catch.wav", synth_arpeggio([523.25, 659.25, 783.99, 1046.50], 0.07, 0.22, amp=0.40))
    write_wav("ui_click.wav", synth_tone(720, 540, 0.055, amp=0.28, wave_type="tri", noise_mix=0.05, seed=9))
    write_wav("rooster_morning.wav", synth_arpeggio([392.00, 493.88, 587.33, 783.99], 0.09, 0.35, amp=0.34))
    write_wav("valley_breeze_loop.wav", synth_valley_breeze_loop(8.0))
    write_wav("bgm_summer_loop.wav", synth_valley_breeze_loop(8.0))
    write_wav("bgm_autumn_loop.wav", synth_valley_breeze_loop(8.0))
    write_wav("bgm_winter_loop.wav", synth_valley_breeze_loop(8.0))
    write_wav("bgm_island_loop.wav", synth_valley_breeze_loop(8.0))
    print(f"Synthesized 18 WAV audio files in {AUDIO_DIR}")


if __name__ == "__main__":
    main()
