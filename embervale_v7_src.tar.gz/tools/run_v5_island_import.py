#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""导入 v5.0 星露珊瑚群岛无限画布 2x2 热带像素四宫格并归档高清原图"""
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent))
import archive_vault
import art_pipeline
import import_canvas_batch as icb

DL = Path(r"C:\Users\Administrator\.gemini\antigravity\brain\890972f1-824a-48c2-9a70-0d3d7ee94b51\browser_sandbox\downloads")


def main():
    w1 = icb.import_quad_sheet(DL / "canvas-image-image-1795397553508-9bv3j.png", [
        {"targets": ["objects/palm_tree.png"]},
        {"targets": ["objects/island_boat.png"]},
        {"crop_id": "pineapple"},
        {"crop_id": "star_coffee"},
    ])
    w2 = icb.import_quad_sheet(DL / "canvas-image-image-1795397698910-c7jv0.png", [
        {"targets": ["icons/artisan_espresso.png"]},
        {"targets": ["objects/forage_coral_pearl.png", "icons/coral_pearl.png"]},
        {"targets": ["objects/forage_starfish_shell.png", "icons/starfish_shell.png"]},
        {"targets": ["icons/fish_manta_ray.png"]},
    ])
    print(f"[OK] Imported {len(w1) + len(w2)} v5.0 Coral Island sprites!")
    archive_vault.archive_all()
    res = art_pipeline.check_status()
    print(f"=== COVERAGE: Sprites {res['human_sprites']} / {res['total_sprites']} | Audio {res['human_audio']} / {res['total_audio']} | Warnings: {len(res['warnings'])} ===")
    if res["warnings"]:
        for w in res["warnings"]:
            print("  WARN:", w)


if __name__ == "__main__":
    main()
