#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
为 Godot 4.6 导出的 Web (HTML5) index.html 与 index.js 注入手机端 / 微信内置浏览器兼容性与体验增强层：
1) 修复微信内置浏览器 (XWeb / WKWebView) 卡死在 100% 蓝条的核心 Bug：
   - 将 Godot 4.6 `index.js` 中对合成 `new Response(response.clone().body)` 的无 `.catch` `WebAssembly.instantiateStreaming`
     替换为全浏览器 100% 兼容的 `response.clone().arrayBuffer() -> WebAssembly.instantiate()` 并补齐 `.catch(reject)`；
   - 为 `GodotFS.init` (`IDBFS` IndexedDB 挂载同步) 增加 1800ms 超时兜底，防止微信沙盒限制 IndexedDB 时无限挂起；
   - 生成自销毁清理型 `index.service.worker.js` 并在页面启动时主动注销历史残留 ServiceWorker，杜绝旧缓存拦截；
2) 修复手机竖屏下顶部悬浮胶囊被挤成竖排大圆框的问题：
   - 加载期间隐藏顶栏，进入主界面后再显示单行紧凑胶囊 (`width: max-content; max-width: 94vw; margin: 0 auto`)；
   - 在 Godot 启动页进度条下方实时显示中文加载百分比与“正在初始化像素引擎”阶段提示；
3) 支持 `--self-test` 门禁自检。
"""
from __future__ import annotations

import argparse
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent

INJECT_HEAD = """
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
<meta name="apple-mobile-web-app-title" content="回响山谷">
<meta name="mobile-web-app-capable" content="yes">
<meta name="theme-color" content="#1c130d">
<link rel="manifest" href="index.manifest.json">
<script>
  // 1) Purge any previously cached ServiceWorker immediately so WeChat / mobile browsers always boot clean
  if ('serviceWorker' in navigator) {
    navigator.serviceWorker.getRegistrations().then(function(regs) {
      for (var i = 0; i < regs.length; i++) { regs[i].unregister(); }
    }).catch(function(){});
  }
  // 2) Commercial Rewarded Ad SDK Bridge (plug in WeChat/Douyin/TapADN adUnitId to monetize immediately)
  window.EmbervaleAdSDK = window.EmbervaleAdSDK || {
    adUnitId: "",
    triggerPlacement: function(placement) {
      console.log("[EmbervaleAdSDK] placement triggered:", placement);
    }
  };
  // 3) Zero-ServiceWorker IndexedDB Binary Asset Cache: 2nd+ visit in WeChat/Safari boots in ~1.5s from local RAM!
  (function() {
    if (!window.indexedDB || !window.fetch) return;
    var DB_NAME = "embervale_bin_cache_v80";
    var STORE = "blobs";
    var origFetch = window.fetch.bind(window);
    function openCacheDB() {
      return new Promise(function(resolve, reject) {
        var done = false;
        var timer = setTimeout(function(){ if (!done) { done = true; reject(new Error("idb_timeout")); } }, 1200);
        try {
          var req = indexedDB.open(DB_NAME, 1);
          req.onupgradeneeded = function(e) { e.target.result.createObjectStore(STORE); };
          req.onsuccess = function(e) { if (!done) { done = true; clearTimeout(timer); resolve(e.target.result); } };
          req.onerror = function() { if (!done) { done = true; clearTimeout(timer); reject(req.error); } };
        } catch (err) { if (!done) { done = true; clearTimeout(timer); reject(err); } }
      });
    }
    window.fetch = function(input, init) {
      var url = typeof input === "string" ? input : (input && input.url ? input.url : "");
      var key = "";
      if (url.indexOf("index.wasm") !== -1) key = "index.wasm_v80";
      else if (url.indexOf("index.pck") !== -1) key = "index.pck_v80";
      if (!key) return origFetch(input, init);
      return openCacheDB().then(function(db) {
        return new Promise(function(resolve, reject) {
          var tx = db.transaction(STORE, "readonly");
          var getReq = tx.objectStore(STORE).get(key);
          getReq.onsuccess = function() {
            var buf = getReq.result;
            if (buf && buf.byteLength > 100000) {
              var ltxt = document.getElementById("embervale-load-txt");
              if (ltxt) ltxt.textContent = "⚡ 已命中手机本地极速缓存，1秒秒进山谷...";
              var mime = key.indexOf("wasm") !== -1 ? "application/wasm" : "application/octet-stream";
              resolve(new Response(buf, { status: 200, headers: { "Content-Type": mime, "Content-Length": String(buf.byteLength) } }));
            } else {
              reject(new Error("cache_miss"));
            }
          };
          getReq.onerror = function() { reject(getReq.error); };
        });
      }).catch(function() {
        return origFetch(input, init).then(function(resp) {
          if (resp && resp.ok && resp.clone) {
            var copy = resp.clone();
            copy.arrayBuffer().then(function(ab) {
              openCacheDB().then(function(db) {
                var wtx = db.transaction(STORE, "readwrite");
                wtx.objectStore(STORE).put(ab, key);
              }).catch(function(){});
            }).catch(function(){});
          }
          return resp;
        });
      });
    };
  })();
</script>
<style>
  html, body {
    overscroll-behavior: none;
    touch-action: none;
    -webkit-user-select: none;
    user-select: none;
    -webkit-touch-callout: none;
    background-color: #16100b !important;
  }
  #embervale-load-txt {
    position: absolute;
    bottom: 4.5%;
    left: 12px;
    right: 12px;
    text-align: center;
    color: #ffe8a3;
    font: 600 13px/1.4 -apple-system, BlinkMacSystemFont, "PingFang SC", "Microsoft YaHei", sans-serif;
    z-index: 10;
    pointer-events: none;
  }
  #embervale-mobile-bar {
    position: fixed;
    top: env(safe-area-inset-top, 6px);
    left: 0;
    right: 0;
    width: max-content;
    max-width: 94vw;
    margin: 0 auto;
    z-index: 9999;
    display: none;
    flex-direction: row;
    flex-wrap: nowrap;
    gap: 6px;
    align-items: center;
    background: rgba(34, 22, 14, 0.92);
    border: 1.5px solid #dfa44b;
    border-radius: 999px;
    padding: 4px 10px;
    color: #fff5df;
    font: 600 12px/1.2 -apple-system, BlinkMacSystemFont, "PingFang SC", "Microsoft YaHei", sans-serif;
    box-shadow: 0 4px 14px rgba(0,0,0,0.45);
    white-space: nowrap;
  }
  #embervale-mobile-bar button, #embervale-mobile-bar a {
    background: #5b371e;
    color: #ffe8a3;
    border: 1px solid #e5b25d;
    border-radius: 999px;
    padding: 4px 9px;
    font-size: 12px;
    text-decoration: none;
    cursor: pointer;
    white-space: nowrap;
    flex-shrink: 0;
  }
</style>
"""

INJECT_BODY = """
<div id="embervale-mobile-bar">
  <button type="button" onclick="embervaleEnterFullscreen()">⛶ 全屏畅玩</button>
  <a href="./EchoesOfEmbervale_v7_Mobile.apk" download="EchoesOfEmbervale_v7_Mobile.apk">📦 安卓APK下载</a>
  <button type="button" onclick="document.getElementById('embervale-mobile-bar').style.display='none'">✕</button>
</div>
<script>
  window.__embervaleSetOrientation = function(mode) {
    if (screen.orientation && screen.orientation.lock) {
      screen.orientation.lock(mode === 'portrait' ? 'portrait' : 'landscape').catch(function(){});
    }
  };
  function embervaleEnterFullscreen() {
    var el = document.documentElement;
    var rfs = el.requestFullscreen || el.webkitRequestFullscreen;
    if (rfs) {
      Promise.resolve(rfs.call(el)).catch(function(){});
    }
    var bar = document.getElementById('embervale-mobile-bar');
    if (bar) setTimeout(function(){ bar.style.display = 'none'; }, 1000);
  }
</script>
"""

SELF_UNREGISTER_SW = """// Self-unregistering cleanup worker to clear any legacy PWA cache in WeChat / Mobile WebViews
self.addEventListener('install', function(e) {
  self.skipWaiting();
});
self.addEventListener('activate', function(e) {
  e.waitUntil(
    caches.keys().then(function(keys) {
      return Promise.all(keys.map(function(k) { return caches.delete(k); }));
    }).then(function() {
      return self.registration.unregister();
    })
  );
});
"""


def patch_index_js(js_path: Path) -> None:
    if not js_path.exists():
        return
    txt = js_path.read_text(encoding="utf-8")
    if "__EMBERVALE_WEBVIEW_PATCHED__" in txt:
        return

    # 0) Bypass Emscripten's broken User-Agent regex that misidentifies Android WeChat/WebView ("Version/4.0 Chrome/... Mobile Safari/537.36") as Safari v4.0 (v040000)!
    old_ua_check = 'var userAgent=typeof navigator!=="undefined"&&navigator.userAgent;if(!userAgent){return}'
    new_ua_check = 'var userAgent=false;if(!userAgent){return}'
    if old_ua_check in txt:
        txt = txt.replace(old_ua_check, new_ua_check, 1)
    txt = txt.replace('if(currentSafariVersion<150200){', 'if(false&&currentSafariVersion<150200){')

    # 1) Replace synthetic Response + instantiateStreaming (which rejects silently in WeChat XWeb / mobile WebViews!) with ArrayBuffer WebAssembly.instantiate
    old_stream_block = (
        "\t\t\t\tif (typeof (WebAssembly.instantiateStreaming) !== 'undefined') {\n"
        "\t\t\t\t\tWebAssembly.instantiateStreaming(Promise.resolve(r), imports).then(done);\n"
        "\t\t\t\t} else {\n"
        "\t\t\t\t\tr.arrayBuffer().then(function (buffer) {\n"
        "\t\t\t\t\t\tWebAssembly.instantiate(buffer, imports).then(done);\n"
        "\t\t\t\t\t});\n"
        "\t\t\t\t}"
    )
    new_stream_block = (
        "\t\t\t\t/* __EMBERVALE_WEBVIEW_PATCHED__ */\n"
        "\t\t\t\tif (r instanceof ArrayBuffer || ArrayBuffer.isView(r)) {\n"
        "\t\t\t\t\tWebAssembly.instantiate(r, imports).then(done, function (e) { console.error('WASM instantiate err:', e); });\n"
        "\t\t\t\t} else {\n"
        "\t\t\t\t\tr.arrayBuffer().then(function (buffer) {\n"
        "\t\t\t\t\t\treturn WebAssembly.instantiate(buffer, imports);\n"
        "\t\t\t\t\t}).then(done, function (e) { console.error('WASM buffer instantiate err:', e); });\n"
        "\t\t\t\t}"
    )
    if old_stream_block in txt:
        txt = txt.replace(old_stream_block, new_stream_block, 1)

    # 2) Patch doInit to pass clean ArrayBuffer, enforce 1800ms IDBFS timeout, and propagate .catch(reject)!
    old_do_init = (
        "\t\t\t\t\t\tpromise.then(function (response) {\n"
        "\t\t\t\t\t\t\tconst cloned = new Response(response.clone().body, { 'headers': [['content-type', 'application/wasm']] });\n"
        "\t\t\t\t\t\t\tGodot(me.config.getModuleConfig(loadPath, cloned)).then(function (module) {\n"
        "\t\t\t\t\t\t\t\tconst paths = me.config.persistentPaths;\n"
        "\t\t\t\t\t\t\t\tmodule['initFS'](paths).then(function (err) {\n"
        "\t\t\t\t\t\t\t\t\tme.rtenv = module;\n"
        "\t\t\t\t\t\t\t\t\tif (me.config.unloadAfterInit) {\n"
        "\t\t\t\t\t\t\t\t\t\tEngine.unload();\n"
        "\t\t\t\t\t\t\t\t\t}\n"
        "\t\t\t\t\t\t\t\t\tresolve();\n"
        "\t\t\t\t\t\t\t\t});\n"
        "\t\t\t\t\t\t\t});\n"
        "\t\t\t\t\t\t});"
    )
    new_do_init = (
        "\t\t\t\t\t\tpromise.then(function (response) {\n"
        "\t\t\t\t\t\t\treturn response.clone().arrayBuffer();\n"
        "\t\t\t\t\t\t}).then(function (wasmBuf) {\n"
        "\t\t\t\t\t\t\treturn Godot(me.config.getModuleConfig(loadPath, wasmBuf));\n"
        "\t\t\t\t\t\t}).then(function (module) {\n"
        "\t\t\t\t\t\t\tconst paths = me.config.persistentPaths;\n"
        "\t\t\t\t\t\t\treturn Promise.race([\n"
        "\t\t\t\t\t\t\t\tmodule['initFS'](paths),\n"
        "\t\t\t\t\t\t\t\tnew Promise(function (res) { setTimeout(function () { res('idbfs_timeout'); }, 1800); })\n"
        "\t\t\t\t\t\t\t]).then(function () {\n"
        "\t\t\t\t\t\t\t\tme.rtenv = module;\n"
        "\t\t\t\t\t\t\t\tif (me.config.unloadAfterInit) {\n"
        "\t\t\t\t\t\t\t\t\tEngine.unload();\n"
        "\t\t\t\t\t\t\t\t}\n"
        "\t\t\t\t\t\t\t\tresolve();\n"
        "\t\t\t\t\t\t\t});\n"
        "\t\t\t\t\t\t}).catch(reject);"
    )
    if old_do_init in txt:
        txt = txt.replace(old_do_init, new_do_init, 1)

    # 3) Also add safety timeout inside GodotFS.init itself
    old_syncfs = "return new Promise(function(resolve,reject){FS.syncfs(true,function(err){"
    new_syncfs = "return new Promise(function(resolve,reject){var _done=false;setTimeout(function(){if(!_done){_done=true;resolve(null)}},1800);FS.syncfs(true,function(err){if(_done)return;_done=true;"
    if old_syncfs in txt:
        txt = txt.replace(old_syncfs, new_syncfs, 1)

    js_path.write_text(txt, encoding="utf-8")
    print(f"[OK] Patched WeChat/Mobile WebView WASM & IDBFS boot resilience in {js_path}")


def enhance_html(html_path: Path) -> None:
    txt = html_path.read_text(encoding="utf-8")
    if "embervale-mobile-bar" not in txt:
        # Add live Chinese loading text inside #status
        txt = txt.replace(
            '<div id="status-notice"></div>',
            '<div id="embervale-load-txt">🌱 正在连接山谷服务器，准备加载资源...</div>\n\t\t\t<div id="status-notice"></div>',
            1,
        )
        # Strip serviceWorker from GODOT_CONFIG if present and cache-bust index.js for WeChat XWeb HTTP cache!
        txt = txt.replace(',"serviceWorker":"index.service.worker.js"', ',"serviceWorker":""')
        txt = txt.replace('<script src="index.js"></script>', '<script src="index.js?v=80"></script>')
        # Upgrade progress callback + show top mobile bar ONLY after game boots!
        old_prog = (
            "\t\t\t'onProgress': function (current, total) {\n"
            "\t\t\t\tif (current > 0 && total > 0) {\n"
            "\t\t\t\t\tstatusProgress.value = current;\n"
            "\t\t\t\t\tstatusProgress.max = total;\n"
            "\t\t\t\t} else {\n"
            "\t\t\t\t\tstatusProgress.removeAttribute('value');\n"
            "\t\t\t\t\tstatusProgress.removeAttribute('max');\n"
            "\t\t\t\t}\n"
            "\t\t\t},\n"
            "\t\t}).then(() => {\n"
            "\t\t\tsetStatusMode('hidden');"
        )
        new_prog = (
            "\t\t\t'onProgress': function (current, total) {\n"
            "\t\t\t\tvar ltxt = document.getElementById('embervale-load-txt');\n"
            "\t\t\t\tif (current > 0 && total > 0) {\n"
            "\t\t\t\t\tstatusProgress.value = current;\n"
            "\t\t\t\t\tstatusProgress.max = total;\n"
            "\t\t\t\t\tvar pct = Math.min(100, Math.round((current / total) * 100));\n"
            "\t\t\t\t\tvar mbCur = (current / 1048576).toFixed(1);\n"
            "\t\t\t\t\tvar mbTot = (total / 1048576).toFixed(1);\n"
            "\t\t\t\t\tif (ltxt) {\n"
            "\t\t\t\t\t\tltxt.textContent = pct >= 99\n"
            "\t\t\t\t\t\t\t? '⚡ 资源下载完毕 (100%)，正在启动像素引擎 (约 2~5 秒)...'\n"
            "\t\t\t\t\t\t\t: ('🌱 正在加载《星露物语：回响山谷》：' + pct + '% (' + mbCur + ' / ' + mbTot + ' MB)');\n"
            "\t\t\t\t\t}\n"
            "\t\t\t\t} else {\n"
            "\t\t\t\t\tstatusProgress.removeAttribute('value');\n"
            "\t\t\t\t\tstatusProgress.removeAttribute('max');\n"
            "\t\t\t\t}\n"
            "\t\t\t},\n"
            "\t\t}).then(() => {\n"
            "\t\t\tsetStatusMode('hidden');\n"
            "\t\t\tvar mbar = document.getElementById('embervale-mobile-bar');\n"
            "\t\t\tif (mbar) mbar.style.display = 'flex';"
        )
        txt = txt.replace(old_prog, new_prog, 1)
        txt = txt.replace("</head>", INJECT_HEAD + "\n</head>", 1)
        txt = txt.replace("</body>", INJECT_BODY + "\n</body>", 1)
        html_path.write_text(txt, encoding="utf-8")
        print(f"[OK] Injected WeChat-safe mobile shell & progress UI into {html_path}")

    # Patch sibling index.js, write lightweight manifest, and write cleanup index.service.worker.js
    patch_index_js(html_path.parent / "index.js")
    manifest_path = html_path.parent / "index.manifest.json"
    if not manifest_path.exists():
        manifest_path.write_text(
            '{\n'
            '  "name": "星露物语：回响山谷",\n'
            '  "short_name": "回响山谷",\n'
            '  "start_url": "./index.html",\n'
            '  "display": "fullscreen",\n'
            '  "orientation": "any",\n'
            '  "background_color": "#16100b",\n'
            '  "theme_color": "#1c130d",\n'
            '  "icons": [\n'
            '    {"src": "index.icon.png", "sizes": "192x192", "type": "image/png"},\n'
            '    {"src": "index.apple-touch-icon.png", "sizes": "180x180", "type": "image/png"}\n'
            '  ]\n'
            '}\n',
            encoding="utf-8",
        )
    sw_path = html_path.parent / "index.service.worker.js"
    sw_path.write_text(SELF_UNREGISTER_SW, encoding="utf-8")
    # Also emit compliance privacy.html & official mobile download landing page store.html into build/web/
    try:
        import generate_store_submission_pack as store_gen
        (html_path.parent / "privacy.html").write_text(store_gen.PRIVACY_HTML, encoding="utf-8")
        (html_path.parent / "store.html").write_text(store_gen.STORE_HTML, encoding="utf-8")
    except Exception as exc:
        print(f"[WARN] Skipped privacy/store HTML emission: {exc}")


def self_test() -> int:
    with tempfile.TemporaryDirectory() as td:
        td_p = Path(td)
        sample_html = td_p / "index.html"
        sample_js = td_p / "index.js"
        sample_html.write_text(
            '<!DOCTYPE html><html><head><title>Test</title></head><body>'
            '<div id="status"><div id="status-notice"></div></div>'
            '<canvas></canvas></body></html>',
            encoding="utf-8",
        )
        sample_js.write_text(
            'var userAgent=typeof navigator!=="undefined"&&navigator.userAgent;if(!userAgent){return}'
            'if(currentSafariVersion<150200){throw new Error("Safari")}\n'
            "\t\t\t\tif (typeof (WebAssembly.instantiateStreaming) !== 'undefined') {\n"
            "\t\t\t\t\tWebAssembly.instantiateStreaming(Promise.resolve(r), imports).then(done);\n"
            "\t\t\t\t} else {\n"
            "\t\t\t\t\tr.arrayBuffer().then(function (buffer) {\n"
            "\t\t\t\t\t\tWebAssembly.instantiate(buffer, imports).then(done);\n"
            "\t\t\t\t\t});\n"
            "\t\t\t\t}\n"
            "return new Promise(function(resolve,reject){FS.syncfs(true,function(err){resolve(err)})})",
            encoding="utf-8",
        )
        enhance_html(sample_html)
        first_out = sample_html.read_text(encoding="utf-8")
        js_out = sample_js.read_text(encoding="utf-8")
        assert "viewport-fit=cover" in first_out, "Missing viewport-fit=cover"
        assert './EchoesOfEmbervale_v7_Mobile.apk' in first_out, "Missing same-origin APK link"
        assert "width: max-content" in first_out, "Missing max-content fix for mobile top bar"
        assert "embervale_bin_cache_v80" in first_out, "Missing IndexedDB 1.5s repeat boot cache"
        assert "EmbervaleAdSDK" in first_out, "Missing commercial Ad SDK bridge"
        assert "__EMBERVALE_WEBVIEW_PATCHED__" in js_out, "Missing WebView WASM ArrayBuffer patch in index.js"
        assert "var userAgent=false;if(!userAgent){return}" in js_out, "Missing Emscripten Android WebView Version/4.0 Safari bypass"
        assert "1800" in js_out, "Missing IDBFS timeout guard in index.js"
        assert (td_p / "index.service.worker.js").exists(), "Missing cleanup service worker"
        # Idempotency check
        enhance_html(sample_html)
        assert sample_html.read_text(encoding="utf-8") == first_out, "enhance_html must be idempotent"

    presets_cfg = ROOT / "game" / "export_presets.cfg"
    assert presets_cfg.exists(), f"Missing {presets_cfg}"
    cfg_txt = presets_cfg.read_text(encoding="utf-8")
    for req in (
        'platform="Web"',
        "progressive_web_app/enabled=false",
        'platform="Android"',
        "architectures/arm64-v8a=true",
        "package/signed=true",
        "version/code=70",
        'version/name="7.0.0"',
    ):
        assert req in cfg_txt, f"export_presets.cfg missing required setting: {req}"
    for icon_name in ("app_icon_144.png", "app_icon_180.png", "app_icon_192.png", "app_icon_512.png"):
        icon_p = ROOT / "game" / "assets" / icon_name
        assert icon_p.exists(), f"Missing mobile app icon: {icon_p}"

    wf_yml = ROOT / ".github" / "workflows" / "build_mobile_web_and_apk.yml"
    assert wf_yml.exists(), f"Missing workflow {wf_yml}"
    wf_txt = wf_yml.read_text(encoding="utf-8")
    assert "EchoesOfEmbervale_v7_Mobile.apk" in wf_txt, "CI workflow must stage v7 APK into build/web/ for same-origin download"
    print("[PASS] enhance_mobile_web_shell.py WeChat WebView WASM/IDBFS patch, export_presets.cfg & CI self-test passed")
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(description="《星露物语：回响山谷》移动端与微信 WebView 兼容增强及校验工具")
    parser.add_argument("html_path", nargs="?", default="build/web/index.html", help="目标导出的 index.html 路径")
    parser.add_argument("--self-test", action="store_true", help="运行无副作用契约自检")
    args = parser.parse_args()
    if args.self_test:
        return self_test()
    enhance_html(Path(args.html_path))
    return 0


if __name__ == "__main__":
    sys.exit(main())
