#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
为 Godot 4.6 导出的 Web (HTML5/PWA) index.html 注入手机端专属体验增强层：
1) iOS Safari / 微信 / Android 全面屏刘海适配 (viewport-fit=cover, 禁止双指误缩放与橡皮筋回弹)；
2) 竖屏握持时的顶部轻量横屏建议条 + 一键全屏锁定横屏按钮 (⛶ 全屏横屏)；
3) 同源相对路径直链下载 Android APK 安装包 (`./EchoesOfEmbervale_v6_Mobile.apk`)，避免仓库迁移或 Fork 导致外部链接 404；
4) 支持 `--self-test` 门禁自检（校验 HTML 注入幂等性与 game/export_presets.cfg 移动端预设完整性）。
"""
from __future__ import annotations

import argparse
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent

INJECT_HEAD = """
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
<meta name="apple-mobile-web-app-title" content="回响山谷">
<meta name="mobile-web-app-capable" content="yes">
<meta name="theme-color" content="#1c130d">
<style>
  html, body {
    overscroll-behavior: none;
    touch-action: none;
    -webkit-user-select: none;
    user-select: none;
    -webkit-touch-callout: none;
    background-color: #16100b !important;
  }
  #embervale-mobile-bar {
    position: fixed;
    top: env(safe-area-inset-top, 6px);
    left: 50%;
    transform: translateX(-50%);
    z-index: 9999;
    display: flex;
    gap: 8px;
    align-items: center;
    background: rgba(34, 22, 14, 0.92);
    border: 2px solid #dfa44b;
    border-radius: 999px;
    padding: 5px 12px;
    color: #fff5df;
    font: 600 12px/1.2 -apple-system, BlinkMacSystemFont, "PingFang SC", "Microsoft YaHei", sans-serif;
    box-shadow: 0 4px 16px rgba(0,0,0,0.45);
  }
  #embervale-mobile-bar button, #embervale-mobile-bar a {
    background: #5b371e;
    color: #ffe8a3;
    border: 1px solid #e5b25d;
    border-radius: 999px;
    padding: 4px 10px;
    font-size: 12px;
    text-decoration: none;
    cursor: pointer;
    white-space: nowrap;
  }
  @media (orientation: landscape) and (min-width: 960px) {
    #embervale-portrait-tip { display: none; }
  }
</style>
"""

INJECT_BODY = """
<div id="embervale-mobile-bar">
  <span id="embervale-portrait-tip">📱 支持横屏全景 / 竖屏单手种田</span>
  <button type="button" onclick="embervaleEnterFullscreen()">⛶ 全屏畅玩</button>
  <a href="./EchoesOfEmbervale_v7_Mobile.apk" download="EchoesOfEmbervale_v7_Mobile.apk">📦 安卓APK下载</a>
  <button type="button" onclick="document.getElementById('embervale-mobile-bar').style.display='none'">✕</button>
</div>
<script>
  window.__embervaleSetOrientation = function(mode) {
    if (screen.orientation && screen.orientation.lock) {
      screen.orientation.lock(mode === 'portrait' ? 'portrait' : 'landscape').catch(function(){});
    }
  };
  function embervaleEnterFullscreen() {
    var el = document.documentElement;
    var rfs = el.requestFullscreen || el.webkitRequestFullscreen;
    if (rfs) {
      Promise.resolve(rfs.call(el)).catch(function(){});
    }
    var bar = document.getElementById('embervale-mobile-bar');
    if (bar) setTimeout(function(){ bar.style.display = 'none'; }, 1200);
  }
</script>
"""


def enhance_html(html_path: Path) -> None:
    txt = html_path.read_text(encoding="utf-8")
    if "embervale-mobile-bar" in txt:
        return
    txt = txt.replace("</head>", INJECT_HEAD + "\n</head>", 1)
    txt = txt.replace("</body>", INJECT_BODY + "\n</body>", 1)
    html_path.write_text(txt, encoding="utf-8")
    print(f"[OK] Injected mobile fullscreen/landscape/PWA bar into {html_path}")


def self_test() -> int:
    with tempfile.TemporaryDirectory() as td:
        sample_html = Path(td) / "index.html"
        sample_html.write_text("<!DOCTYPE html><html><head><title>Test</title></head><body><canvas></canvas></body></html>", encoding="utf-8")
        enhance_html(sample_html)
        first_out = sample_html.read_text(encoding="utf-8")
        assert "viewport-fit=cover" in first_out, "Missing viewport-fit=cover"
        assert './EchoesOfEmbervale_v7_Mobile.apk' in first_out, "Missing same-origin APK link"
        assert "embervaleEnterFullscreen" in first_out, "Missing fullscreen helper"
        assert "__embervaleSetOrientation" in first_out, "Missing orientation bridge"
        # Idempotency check
        enhance_html(sample_html)
        second_out = sample_html.read_text(encoding="utf-8")
        assert first_out == second_out, "enhance_html must be idempotent"

    presets_cfg = ROOT / "game" / "export_presets.cfg"
    assert presets_cfg.exists(), f"Missing {presets_cfg}"
    cfg_txt = presets_cfg.read_text(encoding="utf-8")
    for req in (
        'platform="Web"',
        "progressive_web_app/enabled=true",
        "progressive_web_app/orientation=0",
        'platform="Android"',
        "architectures/arm64-v8a=true",
        "package/signed=true",
        'version/name="7.0.0"',
    ):
        assert req in cfg_txt, f"export_presets.cfg missing required setting: {req}"
    for icon_name in ("app_icon_144.png", "app_icon_180.png", "app_icon_192.png", "app_icon_512.png"):
        icon_p = ROOT / "game" / "assets" / icon_name
        assert icon_p.exists(), f"Missing mobile app icon: {icon_p}"

    wf_yml = ROOT / ".github" / "workflows" / "build_mobile_web_and_apk.yml"
    assert wf_yml.exists(), f"Missing workflow {wf_yml}"
    wf_txt = wf_yml.read_text(encoding="utf-8")
    assert "EchoesOfEmbervale_v7_Mobile.apk" in wf_txt, "CI workflow must stage v7 APK into build/web/ for same-origin download"
    print("[PASS] enhance_mobile_web_shell.py PWA shell, export_presets.cfg & CI same-origin APK self-test passed")
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(description="《星露物语：回响山谷》移动端 Web PWA 壳增强与导出预设校验工具")
    parser.add_argument("html_path", nargs="?", default="build/web/index.html", help="目标导出的 index.html 路径")
    parser.add_argument("--self-test", action="store_true", help="运行无副作用契约自检")
    args = parser.parse_args()
    if args.self_test:
        return self_test()
    enhance_html(Path(args.html_path))
    return 0


if __name__ == "__main__":
    sys.exit(main())
