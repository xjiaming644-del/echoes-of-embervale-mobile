#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""生成《星露物语：回响山谷》手机桌面图标 (144/180/192/512px) 与手机扫码即玩二维码"""
from __future__ import annotations

from pathlib import Path
from PIL import Image, ImageDraw

ROOT = Path(__file__).resolve().parent.parent
ASSETS = ROOT / "game" / "assets"
SPRITES = ROOT / "art_dropin" / "sprites"
REPORTS = ROOT / "reports"

MOBILE_WEB_URL = "https://xjiaming644-del.github.io/echoes-of-embervale-mobile/"


def build_app_icons() -> None:
    base = Image.new("RGBA", (512, 512), (0, 0, 0, 0))
    d = ImageDraw.Draw(base)
    # Warm Stardew walnut-gold rounded app icon frame + sky/meadow background
    d.rounded_rectangle([8, 8, 503, 503], radius=96, fill=(76, 44, 24, 255))
    d.rounded_rectangle([24, 24, 487, 487], radius=82, fill=(132, 206, 246, 255), outline=(238, 186, 78, 255), width=10)
    # Sunlit meadow hill at bottom half
    d.pieslice([24, 250, 487, 560], 180, 360, fill=(104, 178, 74, 255))
    d.rounded_rectangle([24, 340, 487, 487], radius=82, fill=(92, 164, 66, 255))

    # Paste crisp 16-bit farmhouse + farmer + pet cat if present
    house_p = SPRITES / "objects" / "house_farm.png"
    if house_p.exists():
        hi = Image.open(house_p).convert("RGBA")
        bb = hi.getbbox()
        if bb:
            hi = hi.crop(bb)
        sc = min(310.0 / hi.width, 280.0 / hi.height)
        hs = hi.resize((int(hi.width * sc), int(hi.height * sc)), Image.Resampling.NEAREST)
        base.paste(hs, ((512 - hs.width) // 2, 395 - hs.height), hs)

    player_p = SPRITES / "characters" / "player_sheet.png"
    if player_p.exists():
        pi = Image.open(player_p).convert("RGBA")
        fw, fh = pi.width // 4, pi.height // 6
        front = pi.crop((0, 0, fw, fh))
        bb2 = front.getbbox()
        if bb2:
            front = front.crop(bb2)
        ps = front.resize((front.width * 3, front.height * 3), Image.Resampling.NEAREST)
        base.paste(ps, (108, 456 - ps.height), ps)

    cat_p = SPRITES / "animals" / "pet_cat.png"
    if cat_p.exists():
        ci = Image.open(cat_p).convert("RGBA")
        cf = ci.crop((0, 0, ci.width // 4, ci.height))
        bb3 = cf.getbbox()
        if bb3:
            cf = cf.crop(bb3)
        cs = cf.resize((cf.width * 2, cf.height * 2), Image.Resampling.NEAREST)
        base.paste(cs, (312, 458 - cs.height), cs)

    for sz in (144, 180, 192, 512):
        out = base.resize((sz, sz), Image.Resampling.NEAREST)
        out.save(ASSETS / f"app_icon_{sz}.png")
    print("[OK] Generated mobile PWA & Android app icons (144/180/192/512px)")


def build_qr_code() -> Path:
    try:
        import qrcode  # type: ignore
    except ImportError:
        import subprocess
        import sys
        subprocess.run([sys.executable, "-m", "pip", "install", "qrcode", "-q"], check=True)
        import qrcode  # type: ignore

    qr = qrcode.QRCode(version=3, error_correction=qrcode.constants.ERROR_CORRECT_H, box_size=10, border=3)
    qr.add_data(MOBILE_WEB_URL)
    qr.make(fit=True)
    qr_im = qr.make_image(fill_color="#3A2214", back_color="#FFF9EC").convert("RGBA")

    # Embed miniature farmer badge in center of high-ECC QR code
    icon_p = ASSETS / "app_icon_144.png"
    if icon_p.exists():
        ic = Image.open(icon_p).convert("RGBA").resize((68, 68), Image.Resampling.NEAREST)
        pad = Image.new("RGBA", (78, 78), (255, 249, 236, 255))
        pad.paste(ic, (5, 5), ic)
        qr_im.paste(pad, ((qr_im.width - 78) // 2, (qr_im.height - 78) // 2))

    REPORTS.mkdir(parents=True, exist_ok=True)
    out_qr = REPORTS / "mobile_play_qrcode.png"
    qr_im.save(out_qr)
    print(f"[OK] Generated scannable mobile QR code -> {out_qr}")
    return out_qr


if __name__ == "__main__":
    build_app_icons()
    build_qr_code()
