#!/usr/bin/env python3
"""
《星露物语：回响山谷》程序化像素风占位美术与资产清单生成器
生成全套带轮廓描边与光影层次的 PNG 精灵资产到 game/assets/sprites/，
并同步输出 game/data/art_manifest.json 供 Godot 运行时与人工美术交接校验。
"""
import json
import math
import os
import random
from pathlib import Path
from PIL import Image, ImageDraw

ROOT = Path(__file__).resolve().parent.parent
GAME_DIR = ROOT / "game"
DATA_DIR = GAME_DIR / "data"
SPRITES_DIR = GAME_DIR / "assets" / "sprites"


def hex_rgba(h: str, a: int = 255):
    h = h.lstrip("#")
    return (int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16), a)


def shade(rgba, factor: float):
    r, g, b, a = rgba
    return (
        max(0, min(255, int(r * factor))),
        max(0, min(255, int(g * factor))),
        max(0, min(255, int(b * factor))),
        a,
    )


def outline_image(img: Image.Image, outline_col=(36, 26, 22, 255)) -> Image.Image:
    w, h = img.size
    src = img.load()
    out = img.copy()
    dst = out.load()
    for y in range(h):
        for x in range(w):
            if src[x, y][3] == 0:
                has_opaque_neighbor = False
                for dx, dy in ((-1, 0), (1, 0), (0, -1), (0, 1)):
                    nx, ny = x + dx, y + dy
                    if 0 <= nx < w and 0 <= ny < h and src[nx, ny][3] > 20:
                        has_opaque_neighbor = True
                        break
                if has_opaque_neighbor:
                    dst[x, y] = outline_col
    return out


def draw_pixel_char_frame(
    shirt_col, hair_col, hat_col=None, direction=0, step=0, action=0
) -> Image.Image:
    """绘制精细 16-bit 星露谷风 32x32 像素角色单帧。direction: 0下,1左,2右,3上"""
    img = Image.new("RGBA", (32, 32), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    skin = (250, 214, 182, 255)
    skin_d = (224, 178, 142, 255)
    pants = (64, 94, 146, 255)
    pants_d = (46, 68, 112, 255)
    boots = (96, 58, 36, 255)
    eye = (38, 24, 28, 255)

    bob = -1 if step in (1, 3) else 0
    leg_l_off = -1 if step == 1 else (1 if step == 3 else 0)
    leg_r_off = 1 if step == 1 else (-1 if step == 3 else 0)

    # Soft ground shadow
    d.ellipse([9, 27, 23, 30], fill=(0, 0, 0, 72))

    # Boots & legs
    if direction in (0, 3):
        d.rectangle([11, 22 + bob, 14, 26 + leg_l_off], fill=pants_d)
        d.rectangle([17, 22 + bob, 20, 26 + leg_r_off], fill=pants_d)
        d.rectangle([10, 26 + leg_l_off, 14, 28 + leg_l_off], fill=boots)
        d.rectangle([17, 26 + leg_r_off, 21, 28 + leg_r_off], fill=boots)
    else:
        d.rectangle([13 + leg_l_off, 22 + bob, 16 + leg_l_off, 27], fill=pants_d)
        d.rectangle([15 + leg_r_off, 22 + bob, 18 + leg_r_off, 27], fill=pants)
        d.rectangle([12 + leg_l_off, 26, 18 + leg_l_off, 28], fill=boots)

    # Cozy Stardew tunic + overalls bib & brass buttons
    d.rounded_rectangle([9, 14 + bob, 22, 23 + bob], radius=2, fill=shirt_col)
    d.rectangle([10, 14 + bob, 21, 16 + bob], fill=shade(shirt_col, 1.15))
    d.rectangle([10, 19 + bob, 21, 23 + bob], fill=pants)
    d.rectangle([11, 15 + bob, 12, 20 + bob], fill=pants)
    d.rectangle([19, 15 + bob, 20, 20 + bob], fill=pants)
    d.point([(12, 18 + bob), (19, 18 + bob)], fill=(252, 218, 96, 255))

    # Arms
    arm_swing = -2 if step == 1 else (2 if step == 3 else 0)
    if action > 0:
        d.rectangle([20, 11 + bob, 25, 16 + bob], fill=skin)
        d.line([23, 13 + bob, 29, 5 + bob], fill=(230, 238, 250, 255), width=2)
    elif direction in (0, 3):
        d.rectangle([7, 15 + bob + (arm_swing // 2), 9, 20 + bob], fill=shade(shirt_col, 0.90))
        d.rectangle([7, 20 + bob + (arm_swing // 2), 9, 22 + bob], fill=skin)
        d.rectangle([22, 15 + bob - (arm_swing // 2), 24, 20 + bob], fill=shade(shirt_col, 0.90))
        d.rectangle([22, 20 + bob - (arm_swing // 2), 24, 22 + bob], fill=skin)
    else:
        d.rectangle([14 + arm_swing, 15 + bob, 17 + arm_swing, 20 + bob], fill=shade(shirt_col, 0.92))
        d.rectangle([14 + arm_swing, 20 + bob, 17 + arm_swing, 22 + bob], fill=skin)

    # Rounded Chibi Head with soft jaw shading & voluminous hair
    d.ellipse([8, 3 + bob, 23, 16 + bob], fill=skin)
    d.arc([9, 6 + bob, 22, 15 + bob], 20, 160, fill=skin_d, width=1)

    hair_hi = shade(hair_col, 1.28)
    hair_sh = shade(hair_col, 0.80)
    if direction == 0:  # Down
        d.ellipse([7, 2 + bob, 24, 10 + bob], fill=hair_col)
        d.line([10, 4 + bob, 20, 4 + bob], fill=hair_hi, width=1)
        d.rectangle([7, 6 + bob, 10, 13 + bob], fill=hair_sh)
        d.rectangle([21, 6 + bob, 24, 13 + bob], fill=hair_sh)
        d.polygon([(11, 6 + bob), (14, 9 + bob), (16, 6 + bob)], fill=hair_col)
        d.polygon([(16, 6 + bob), (19, 8 + bob), (21, 6 + bob)], fill=hair_col)
        # Sparkling Stardew 2x3 eyes + rosy cheeks
        for ex in (11, 18):
            d.rectangle([ex, 9 + bob, ex + 1, 11 + bob], fill=eye)
            d.point((ex, 9 + bob), fill=(255, 255, 255, 255))
        d.point([(10, 12 + bob), (21, 12 + bob)], fill=(248, 146, 142, 255))
        d.line([14, 13 + bob, 17, 13 + bob], fill=(196, 108, 96, 255))
    elif direction == 3:  # Up
        d.ellipse([7, 2 + bob, 24, 15 + bob], fill=hair_col)
        d.ellipse([10, 4 + bob, 21, 8 + bob], fill=hair_hi)
        d.arc([8, 8 + bob, 23, 15 + bob], 15, 165, fill=hair_sh, width=2)
    elif direction == 1:  # Left
        d.ellipse([9, 2 + bob, 24, 11 + bob], fill=hair_col)
        d.ellipse([15, 5 + bob, 24, 14 + bob], fill=hair_sh)
        d.line([12, 4 + bob, 20, 4 + bob], fill=hair_hi)
        d.rectangle([10, 9 + bob, 11, 11 + bob], fill=eye)
        d.point((10, 9 + bob), fill=(255, 255, 255, 255))
        d.point((12, 12 + bob), fill=(248, 146, 142, 255))
    elif direction == 2:  # Right
        d.ellipse([7, 2 + bob, 22, 11 + bob], fill=hair_col)
        d.ellipse([7, 5 + bob, 16, 14 + bob], fill=hair_sh)
        d.line([11, 4 + bob, 19, 4 + bob], fill=hair_hi)
        d.rectangle([20, 9 + bob, 21, 11 + bob], fill=eye)
        d.point((21, 9 + bob), fill=(255, 255, 255, 255))
        d.point((19, 12 + bob), fill=(248, 146, 142, 255))

    if hat_col:
        d.ellipse([6, 2 + bob, 25, 6 + bob], fill=hat_col)
        d.rounded_rectangle([9, 0 + bob, 22, 4 + bob], radius=2, fill=shade(hat_col, 1.14))
        d.line([9, 3 + bob, 22, 3 + bob], fill=(196, 68, 62, 255))

    return outline_image(img, (44, 26, 20, 255))


def generate_characters(manifest_sprites: list):
    # Player sheet: 128x192 (4 cols x 6 rows)
    # Rows 0-3: Down, Left, Right, Up walk; Row 4: Action swing (Down/Left/Right/Up); Row 5: Fishing/Celebrate
    p_sheet = Image.new("RGBA", (128, 192), (0, 0, 0, 0))
    for r in range(4):
        for c in range(4):
            fr = draw_pixel_char_frame(
                shirt_col=(214, 92, 74, 255),
                hair_col=(92, 58, 38, 255),
                hat_col=(224, 178, 86, 255),
                direction=r,
                step=c,
                action=0,
            )
            p_sheet.paste(fr, (c * 32, r * 32))
    for c in range(4):
        fr = draw_pixel_char_frame(
            shirt_col=(214, 92, 74, 255),
            hair_col=(92, 58, 38, 255),
            hat_col=(224, 178, 86, 255),
            direction=c,
            step=1,
            action=1,
        )
        p_sheet.paste(fr, (c * 32, 4 * 32))
        fr2 = draw_pixel_char_frame(
            shirt_col=(214, 92, 74, 255),
            hair_col=(92, 58, 38, 255),
            hat_col=(224, 178, 86, 255),
            direction=c,
            step=0,
            action=0,
        )
        p_sheet.paste(fr2, (c * 32, 5 * 32))
    p_sheet.save(SPRITES_DIR / "characters" / "player_sheet.png")
    manifest_sprites.append({
        "rel_path": "characters/player_sheet.png",
        "category": "character",
        "name": "主角精灵图集",
        "width": 128,
        "height": 192,
        "frame_w": 32,
        "frame_h": 32,
        "notes": "4列x6行(行0-3为下/左/右/上行走4帧，行4为工具挥动，行5为待机/钓鱼)",
    })

    npc_styles = {
        "linxia": {"shirt": (76, 175, 80, 255), "hair": (62, 44, 34, 255), "hat": (244, 211, 94, 255)},
        "horn": {"shirt": (210, 96, 56, 255), "hair": (128, 128, 136, 255), "hat": None},
        "ache": {"shirt": (41, 152, 214, 255), "hair": (46, 72, 118, 255), "hat": (176, 212, 232, 255)},
        "mei": {"shirt": (156, 84, 178, 255), "hair": (222, 224, 234, 255), "hat": (196, 164, 214, 255)},
        "suwan": {"shirt": (126, 87, 194, 255), "hair": (68, 42, 82, 255), "hat": (238, 196, 98, 255)},
        "kailuo": {"shirt": (214, 72, 68, 255), "hair": (118, 66, 38, 255), "hat": (92, 146, 84, 255)},
    }
    npcs_data = json.loads((DATA_DIR / "npcs.json").read_text(encoding="utf-8"))["npcs"]
    for npc in npcs_data:
        nid = npc["id"]
        st = npc_styles.get(nid, {"shirt": (150, 150, 180, 255), "hair": (70, 50, 40, 255), "hat": None})
        sheet = Image.new("RGBA", (128, 128), (0, 0, 0, 0))
        for r in range(4):
            for c in range(4):
                fr = draw_pixel_char_frame(st["shirt"], st["hair"], st["hat"], direction=r, step=c)
                sheet.paste(fr, (c * 32, r * 32))
        rel = f"characters/npc_{nid}.png"
        sheet.save(SPRITES_DIR / rel)
        manifest_sprites.append({
            "rel_path": rel,
            "category": "character",
            "name": f"NPC-{npc['name']}精灵图集",
            "width": 128,
            "height": 128,
            "frame_w": 32,
            "frame_h": 32,
            "notes": "4列x4行(下/左/右/上各4帧行走)",
        })

        # Portrait 96x96 (Warm Stardew wooden frame + detailed anime-pixel bust)
        port = Image.new("RGBA", (96, 96), (0, 0, 0, 0))
        pd = ImageDraw.Draw(port)
        bg = hex_rgba(npc["color"], 255)
        pd.rounded_rectangle([2, 2, 93, 93], radius=10, fill=(238, 220, 184, 255), outline=(92, 54, 28, 255), width=4)
        pd.rounded_rectangle([6, 6, 89, 89], radius=7, fill=shade(bg, 0.42), outline=(218, 164, 78, 255), width=2)
        # Back hair silhouette
        pd.rounded_rectangle([22, 18, 74, 68], radius=14, fill=shade(st["hair"], 0.82))
        # Shoulders, shirt & white collar/apron
        pd.rounded_rectangle([16, 60, 80, 90], radius=12, fill=st["shirt"], outline=(42, 26, 20, 255), width=2)
        pd.polygon([(38, 60), (48, 72), (58, 60)], fill=(250, 244, 232, 255))
        pd.rectangle([32, 68, 64, 88], fill=shade(st["shirt"], 0.85))
        # Neck & Soft Head
        pd.rectangle([42, 52, 54, 65], fill=(236, 196, 164, 255))
        pd.rounded_rectangle([27, 20, 69, 59], radius=15, fill=(250, 216, 186, 255), outline=(42, 26, 20, 255), width=2)
        # Layered Hair Bangs & Side locks
        pd.rounded_rectangle([25, 14, 71, 31], radius=10, fill=st["hair"], outline=(42, 26, 20, 255), width=2)
        pd.polygon([(27, 26), (36, 36), (42, 26)], fill=st["hair"])
        pd.polygon([(44, 26), (51, 35), (58, 26)], fill=st["hair"])
        pd.rectangle([25, 24, 32, 52], fill=st["hair"])
        pd.rectangle([64, 24, 71, 52], fill=st["hair"])
        pd.line([33, 20, 61, 20], fill=shade(st["hair"], 1.25), width=2)
        # Expressive Anime-Pixel Eyes, Blush & Gentle Smile
        for ex in (35, 55):
            pd.rounded_rectangle([ex, 36, ex + 7, 45], radius=2, fill=(38, 28, 36, 255))
            pd.rectangle([ex + 1, 37, ex + 3, 39], fill=(255, 255, 255, 255))
            pd.point((ex + 5, 43), fill=(180, 210, 245, 255))
            pd.line([ex - 1, 34, ex + 7, 34], fill=shade(st["hair"], 0.75), width=2)
        pd.ellipse([30, 45, 37, 49], fill=(246, 154, 148, 190))
        pd.ellipse([59, 45, 66, 49], fill=(246, 154, 148, 190))
        if nid == "horn":
            # Blacksmith hearty beard
            pd.rounded_rectangle([32, 48, 64, 60], radius=6, fill=(116, 112, 120, 255), outline=(42, 26, 20, 255), width=2)
            pd.arc([42, 48, 54, 55], 10, 170, fill=(245, 232, 220, 255), width=2)
        else:
            pd.arc([43, 46, 53, 53], 15, 165, fill=(184, 84, 78, 255), width=2)
        if st["hat"]:
            pd.rounded_rectangle([20, 13, 76, 22], radius=4, fill=st["hat"], outline=(42, 26, 20, 255), width=2)
            pd.rounded_rectangle([30, 6, 66, 16], radius=4, fill=shade(st["hat"], 1.12), outline=(42, 26, 20, 255), width=2)
            pd.line([31, 13, 65, 13], fill=(192, 68, 62, 255), width=2)
        rel_p = f"portraits/npc_{nid}.png"
        port.save(SPRITES_DIR / rel_p)
        manifest_sprites.append({
            "rel_path": rel_p,
            "category": "portrait",
            "name": f"NPC-{npc['name']}对话立绘",
            "width": 96,
            "height": 96,
            "frame_w": 96,
            "frame_h": 96,
            "notes": "对话框左侧半身像素立绘",
        })


def generate_crops(manifest_sprites: list):
    crops = json.loads((DATA_DIR / "crops.json").read_text(encoding="utf-8"))["crops"]
    for crop in crops:
        cid = crop["id"]
        col = hex_rgba(crop["color"])
        ctype = crop["crop_type"]
        sheet = Image.new("RGBA", (160, 32), (0, 0, 0, 0))
        for stage in range(5):
            fr = Image.new("RGBA", (32, 32), (0, 0, 0, 0))
            d = ImageDraw.Draw(fr)
            if stage == 0:
                # Seeds on soil mound
                d.ellipse([10, 22, 22, 28], fill=(120, 86, 54, 255))
                for sx, sy in [(13, 24), (17, 23), (15, 26)]:
                    d.rectangle([sx, sy, sx + 1, sy + 1], fill=(232, 210, 150, 255))
            elif stage == 1:
                # Tiny sprout
                d.rectangle([15, 19, 16, 27], fill=(72, 158, 66, 255))
                d.ellipse([11, 15, 16, 20], fill=(116, 210, 88, 255))
                d.ellipse([16, 16, 21, 21], fill=(96, 190, 74, 255))
            elif stage == 2:
                # Bushy foliage
                d.ellipse([9, 13, 23, 27], fill=(56, 148, 58, 255))
                d.ellipse([11, 10, 21, 20], fill=(92, 194, 78, 255))
            elif stage == 3:
                # Budding
                d.ellipse([7, 11, 25, 27], fill=(48, 136, 52, 255))
                d.ellipse([10, 8, 22, 21], fill=(78, 180, 68, 255))
                d.ellipse([13, 12, 19, 17], fill=shade(col, 0.9))
            else:
                # Ripe harvestable!
                d.ellipse([6, 12, 26, 28], fill=(46, 130, 50, 255))
                d.ellipse([9, 9, 23, 22], fill=(72, 176, 66, 255))
                if ctype == "flower":
                    for ang in range(0, 360, 60):
                        px = 16 + int(math.cos(math.radians(ang)) * 5)
                        py = 13 + int(math.sin(math.radians(ang)) * 5)
                        d.ellipse([px - 4, py - 4, px + 4, py + 4], fill=col)
                    d.ellipse([13, 10, 19, 16], fill=(255, 240, 130, 255))
                elif ctype == "fruit":
                    for fx, fy in [(11, 14), (20, 15), (15, 19)]:
                        d.ellipse([fx - 4, fy - 4, fx + 4, fy + 4], fill=col)
                        d.rectangle([fx - 2, fy - 2, fx - 1, fy - 1], fill=(255, 255, 255, 210))
                elif ctype == "herb":
                    d.ellipse([8, 10, 17, 21], fill=col)
                    d.ellipse([15, 10, 24, 21], fill=shade(col, 1.15))
                    d.ellipse([12, 7, 20, 17], fill=shade(col, 1.25))
                else:
                    # Root/vegetable
                    d.ellipse([10, 14, 22, 28], fill=col)
                    d.rectangle([13, 17, 15, 20], fill=shade(col, 1.25))
                    d.ellipse([10, 7, 22, 15], fill=(82, 188, 72, 255))
            sheet.paste(outline_image(fr), (stage * 32, 0))
        rel = f"crops/crop_{cid}.png"
        sheet.save(SPRITES_DIR / rel)
        manifest_sprites.append({
            "rel_path": rel,
            "category": "crop",
            "name": f"作物-{crop['name']}生长阶段条",
            "width": 160,
            "height": 32,
            "frame_w": 32,
            "frame_h": 32,
            "notes": "5帧横向条：种子/嫩芽/枝叶/含苞/成熟",
        })

        if crop.get("giant_capable"):
            g = Image.new("RGBA", (64, 64), (0, 0, 0, 0))
            gd = ImageDraw.Draw(g)
            gd.ellipse([8, 16, 56, 58], fill=col)
            gd.ellipse([14, 20, 32, 36], fill=shade(col, 1.25))
            gd.line([32, 16, 32, 58], fill=shade(col, 0.72), width=3)
            gd.line([20, 19, 20, 54], fill=shade(col, 0.78), width=2)
            gd.line([44, 19, 44, 54], fill=shade(col, 0.78), width=2)
            gd.ellipse([22, 6, 42, 18], fill=(76, 175, 80, 255))
            g = outline_image(g)
            rel_g = f"crops/giant_{cid}.png"
            g.save(SPRITES_DIR / rel_g)
            manifest_sprites.append({
                "rel_path": rel_g,
                "category": "crop",
                "name": f"巨型作物-{crop['name']}",
                "width": 64,
                "height": 64,
                "frame_w": 64,
                "frame_h": 64,
                "notes": "2x2合体巨型变异作物",
            })


def generate_terrain_atlas(manifest_sprites: list):
    # 10 cols x 2 rows of 32x32 = 320x64
    atlas = Image.new("RGBA", (320, 64), (0, 0, 0, 0))
    rng = random.Random(42)

    def make_tile(base, speck1, speck2, mode="noise"):
        t = Image.new("RGBA", (32, 32), base)
        d = ImageDraw.Draw(t)
        if mode == "noise":
            for _ in range(28):
                x, y = rng.randint(1, 30), rng.randint(1, 30)
                c = speck1 if rng.random() < 0.6 else speck2
                d.rectangle([x, y, x + 1, y], fill=c)
        elif mode == "flowers":
            for gx, gy in [(5, 18), (19, 7), (26, 24)]:
                d.line([gx, gy, gx, gy - 2], fill=speck1)
                d.line([gx + 2, gy, gx + 3, gy - 2], fill=speck1)
            for fx, fy, fc in [(9, 10, (255, 236, 118, 255)), (23, 17, (255, 172, 194, 255)), (14, 25, (250, 252, 245, 255))]:
                d.point([(fx - 1, fy), (fx + 1, fy), (fx, fy - 1), (fx, fy + 1)], fill=fc)
                d.point((fx, fy), fill=(255, 210, 72, 255))
        elif mode == "cobble":
            for by in range(0, 32, 8):
                off = 4 if (by // 8) % 2 else 0
                for bx in range(-4 + off, 32, 10):
                    d.rounded_rectangle([bx + 1, by + 1, bx + 8, by + 6], radius=2, fill=speck1, outline=speck2)
                    d.line([bx + 2, by + 2, bx + 6, by + 2], fill=shade(speck1, 1.08))
        elif mode == "wood":
            for py in range(0, 32, 8):
                d.rectangle([0, py, 31, py + 7], fill=base if (py // 8) % 2 == 0 else speck1)
                d.line([0, py + 7, 31, py + 7], fill=speck2)
                vx = (py * 3 + 9) % 28 + 2
                d.line([vx, py, vx, py + 7], fill=speck2)
        elif mode == "furrow":
            d.rounded_rectangle([2, 2, 29, 29], radius=4, fill=base, outline=speck2)
            for ry in (8, 15, 22):
                d.line([5, ry, 26, ry], fill=speck1, width=2)
        elif mode == "water":
            for wy, wx in [(7, 4), (16, 15), (25, 8)]:
                d.line([wx, wy, wx + 8, wy], fill=speck1)
                d.line([wx + 2, wy + 1, wx + 6, wy + 1], fill=speck2)
        return t

    row0 = [
        make_tile((106, 172, 74, 255), (90, 152, 60, 255), (124, 190, 86, 255), "noise"),         # 0 grass_1
        make_tile((106, 172, 74, 255), (86, 148, 56, 255), (124, 190, 86, 255), "flowers"),       # 1 grass_2 (exact same base green -> 0 square seams!)
        make_tile((202, 160, 108, 255), (184, 142, 92, 255), (218, 178, 126, 255), "noise"),      # 2 dirt_path
        make_tile((146, 138, 128, 255), (172, 164, 152, 255), (116, 108, 98, 255), "cobble"),     # 3 stone_paving (warm sandstone!)
        make_tile((168, 114, 68, 255), (152, 100, 58, 255), (108, 68, 38, 255), "wood"),          # 4 wood_floor
        make_tile((66, 62, 74, 255), (82, 78, 92, 255), (48, 44, 54, 255), "noise"),              # 5 mine_floor
        make_tile((156, 114, 72, 255), (130, 90, 52, 255), (112, 74, 42, 255), "furrow"),         # 6 tilled_dry
        make_tile((94, 62, 40, 255), (70, 44, 26, 255), (56, 34, 20, 255), "furrow"),             # 7 tilled_wet
        make_tile((56, 152, 212, 255), (122, 208, 246, 255), (196, 238, 255, 255), "water"),      # 8 water_1
        make_tile((52, 146, 206, 255), (142, 220, 252, 255), (212, 246, 255, 255), "water"),      # 9 water_2
    ]
    row1 = [
        make_tile((42, 36, 48, 255), (58, 52, 66, 255), (28, 24, 34, 255), "cobble"),           # 10 mine_wall
        make_tile((64, 122, 54, 255), (44, 92, 38, 255), (88, 152, 72, 255), "noise"),          # 11 hedge
        make_tile((116, 104, 92, 255), (92, 80, 70, 255), (140, 126, 112, 255), "cobble"),      # 12 cliff
        make_tile((222, 236, 246, 255), (198, 218, 234, 255), (245, 250, 255, 255), "noise"),   # 13 winter_snow
        make_tile((178, 134, 66, 255), (154, 112, 48, 255), (206, 158, 78, 255), "noise"),      # 14 autumn_grass
        make_tile((168, 68, 68, 255), (208, 158, 86, 255), (132, 48, 48, 255), "noise"),        # 15 farm_rug
        make_tile((120, 178, 78, 255), (142, 198, 92, 255), (104, 158, 66, 255), "noise"),      # 16 summer_grass
        make_tile((144, 98, 58, 255), (124, 82, 46, 255), (90, 56, 30, 255), "wood"),           # 17 dock
        make_tile((126, 184, 88, 255), (255, 200, 214, 255), (150, 204, 106, 255), "flowers"),  # 18 petal_grass
        make_tile((218, 196, 146, 255), (196, 174, 124, 255), (236, 216, 168, 255), "noise"),   # 19 sand_shore
    ]
    for i, t in enumerate(row0):
        atlas.paste(t, (i * 32, 0))
    for i, t in enumerate(row1):
        atlas.paste(t, (i * 32, 32))

    rel = "tiles/terrain_atlas.png"
    atlas.save(SPRITES_DIR / rel)
    manifest_sprites.append({
        "rel_path": rel,
        "category": "tile",
        "name": "地形图块图集",
        "width": 320,
        "height": 64,
        "frame_w": 32,
        "frame_h": 32,
        "notes": "10列x2行共20种32x32地表/耕地/水面/矿洞地块",
    })


def make_building(w, h, wall_c, roof_c, door_c, sign_c, style="house") -> Image.Image:
    img = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    # Soft ground shadow
    d.ellipse([6, h - 18, w - 6, h - 2], fill=(0, 0, 0, 82))
    # Stone foundation + Main timber-framed wall
    d.rectangle([12, h // 2 - 4, w - 13, h - 8], fill=wall_c, outline=(42, 26, 18, 255), width=2)
    d.rectangle([12, h - 16, w - 13, h - 8], fill=(124, 116, 110, 255), outline=(42, 26, 18, 255), width=1)
    # Timber corner beams
    d.rectangle([12, h // 2 - 4, 18, h - 16], fill=(116, 74, 42, 255))
    d.rectangle([w - 19, h // 2 - 4, w - 13, h - 16], fill=(116, 74, 42, 255))
    # Chimney
    if style in ("house", "smithy"):
        d.rectangle([w - 40, 10, w - 22, 46], fill=(142, 78, 64, 255), outline=(42, 26, 18, 255), width=2)
        d.rectangle([w - 42, 8, w - 20, 14], fill=(168, 96, 78, 255), outline=(42, 26, 18, 255), width=1)
    # Shingled pitched roof with warm eaves
    pts = [(4, h // 2 + 2), (w // 2, 8), (w - 5, h // 2 + 2)]
    d.polygon(pts, fill=roof_c, outline=(42, 26, 18, 255))
    for sy in range(18, h // 2, 8):
        half_span = int((sy - 8) * (w * 0.44) / max(1, (h // 2 - 8)))
        d.line([w // 2 - half_span + 4, sy, w // 2 + half_span - 4, sy], fill=shade(roof_c, 0.82), width=1)
    d.rectangle([8, h // 2 - 4, w - 9, h // 2 + 4], fill=shade(roof_c, 0.78), outline=(42, 26, 18, 255), width=2)
    # Door + step
    dx = w // 2 - 14
    d.rectangle([dx - 3, h - 10, dx + 31, h - 5], fill=(158, 148, 138, 255), outline=(42, 26, 18, 255))
    d.rounded_rectangle([dx, h - 46, dx + 28, h - 9], radius=4, fill=door_c, outline=(42, 26, 18, 255), width=2)
    d.ellipse([dx + 20, h - 27, dx + 24, h - 23], fill=(248, 214, 96, 255))
    # Warm sunlit windows + flower boxes
    for wx in (24, w - 50):
        d.rectangle([wx, h - 44, wx + 24, h - 24], fill=(255, 224, 138, 255), outline=(68, 42, 26, 255), width=2)
        d.rectangle([wx + 2, h - 42, wx + 10, h - 35], fill=(255, 246, 198, 255))
        d.line([wx + 12, h - 44, wx + 12, h - 24], fill=(68, 42, 26, 255), width=2)
        d.line([wx, h - 34, wx + 24, h - 34], fill=(68, 42, 26, 255), width=2)
        d.rectangle([wx - 2, h - 24, wx + 26, h - 19], fill=(128, 78, 42, 255), outline=(42, 26, 18, 255))
        for fx in (wx + 3, wx + 11, wx + 19):
            d.ellipse([fx - 2, h - 27, fx + 3, h - 22], fill=(82, 182, 78, 255))
            d.point((fx, h - 26), fill=(255, 118, 138, 255))
    # Sign badge
    d.rounded_rectangle([w // 2 - 18, h // 2 + 5, w // 2 + 18, h // 2 + 21], radius=3, fill=sign_c, outline=(42, 26, 18, 255), width=2)
    return img


def generate_objects_and_monsters(manifest_sprites: list):
    def save_obj(rel, img, name, notes):
        img.save(SPRITES_DIR / rel)
        manifest_sprites.append({
            "rel_path": rel,
            "category": "object",
            "name": name,
            "width": img.width,
            "height": img.height,
            "frame_w": img.width,
            "frame_h": img.height,
            "notes": notes,
        })

    # Tree 64x96 (Multi-cluster dappled 16-bit Stardew oak canopy + roots)
    tree = Image.new("RGBA", (64, 96), (0, 0, 0, 0))
    td = ImageDraw.Draw(tree)
    td.ellipse([12, 79, 52, 93], fill=(0, 0, 0, 78))
    # Trunk & roots
    td.polygon([(21, 88), (26, 52), (38, 52), (43, 88)], fill=(118, 74, 42, 255))
    td.rectangle([28, 54, 33, 86], fill=(146, 96, 56, 255))
    td.line([35, 58, 35, 84], fill=(88, 52, 28, 255), width=2)
    # Deep shadow leaf clusters
    for cx, cy, rx, ry in [(20, 46, 15, 13), (44, 46, 15, 13), (32, 50, 18, 12), (32, 28, 22, 18)]:
        td.ellipse([cx - rx, cy - ry, cx + rx, cy + ry], fill=(42, 112, 48, 255))
    # Mid emerald leaf clusters
    for cx, cy, rx, ry in [(19, 38, 14, 12), (45, 38, 14, 12), (32, 34, 19, 15), (26, 22, 14, 12), (39, 24, 13, 11)]:
        td.ellipse([cx - rx, cy - ry, cx + rx, cy + ry], fill=(68, 158, 62, 255))
    # Sunlit top-left leaf puffs
    for cx, cy, rx, ry in [(23, 20, 11, 9), (36, 19, 10, 8), (18, 33, 9, 7), (31, 29, 12, 9)]:
        td.ellipse([cx - rx, cy - ry, cx + rx, cy + ry], fill=(106, 198, 78, 255))
    for cx, cy in [(22, 16), (33, 15), (17, 29), (28, 25)]:
        td.ellipse([cx - 4, cy - 3, cx + 4, cy + 3], fill=(144, 222, 98, 255))
    save_obj("objects/tree.png", outline_image(tree), "松橡树", "锚点底部中心")

    # Stump 32x32
    stump = Image.new("RGBA", (32, 32), (0, 0, 0, 0))
    sd = ImageDraw.Draw(stump)
    sd.rectangle([9, 14, 23, 28], fill=(122, 82, 48, 255))
    sd.ellipse([8, 10, 24, 18], fill=(208, 166, 114, 255))
    sd.ellipse([12, 12, 20, 16], fill=(176, 134, 84, 255))
    save_obj("objects/stump.png", outline_image(stump), "树桩", "32x32")

    # Ancient Hardwood Stump 32x32
    hstump = Image.new("RGBA", (32, 32), (0, 0, 0, 0))
    hsd = ImageDraw.Draw(hstump)
    hsd.ellipse([4, 22, 28, 30], fill=(0, 0, 0, 75))
    hsd.polygon([(6, 27), (8, 12), (24, 12), (26, 27)], fill=(138, 52, 44, 255))
    hsd.ellipse([7, 8, 25, 17], fill=(218, 138, 96, 255))
    hsd.ellipse([11, 10, 21, 15], fill=(168, 76, 54, 255))
    hsd.ellipse([8, 20, 14, 26], fill=(82, 188, 96, 255))
    save_obj("objects/hardwood_stump.png", outline_image(hstump), "千年铁木古桩", "32x32")

    # Rocks & Ores 32x32
    def make_rock(base, vein=None):
        im = Image.new("RGBA", (32, 32), (0, 0, 0, 0))
        d = ImageDraw.Draw(im)
        d.ellipse([4, 18, 28, 28], fill=(0, 0, 0, 60))
        d.polygon([(6, 24), (7, 13), (15, 7), (24, 11), (26, 24)], fill=base)
        d.polygon([(9, 14), (15, 9), (21, 12), (17, 17)], fill=shade(base, 1.25))
        if vein:
            for vx, vy in [(11, 17), (18, 14), (16, 21), (21, 19)]:
                d.rectangle([vx, vy, vx + 3, vy + 3], fill=vein)
        return outline_image(im)

    save_obj("objects/rock.png", make_rock((132, 136, 146, 255)), "普通岩石", "32x32")
    save_obj("objects/ore_copper.png", make_rock((118, 114, 122, 255), (224, 128, 64, 255)), "铜矿脉", "32x32")
    save_obj("objects/ore_iron.png", make_rock((104, 108, 118, 255), (188, 212, 238, 255)), "铁矿脉", "32x32")
    save_obj("objects/ore_gold.png", make_rock((112, 106, 100, 255), (255, 216, 64, 255)), "金矿脉", "32x32")
    save_obj("objects/ore_crystal.png", make_rock((92, 88, 112, 255), (120, 236, 255, 255)), "回响水晶矿", "32x32")

    # Weed 32x32
    weed = Image.new("RGBA", (32, 32), (0, 0, 0, 0))
    wd = ImageDraw.Draw(weed)
    for px, h in [(8, 12), (13, 8), (18, 10), (23, 14)]:
        wd.polygon([(px, 26), (px - 3, h), (px + 3, 26)], fill=(76, 172, 68, 255))
    save_obj("objects/weed.png", outline_image(weed), "野草", "32x32")

    # Forageables
    for fid, col, shape in [
        ("wild_berry", (196, 48, 86, 255), "berry"),
        ("echo_shell", (244, 186, 212, 255), "shell"),
        ("spring_herb", (82, 214, 122, 255), "herb"),
        ("mystic_truffle", (156, 98, 246, 255), "truffle"),
    ]:
        im = Image.new("RGBA", (32, 32), (0, 0, 0, 0))
        d = ImageDraw.Draw(im)
        if shape == "berry":
            d.ellipse([7, 11, 25, 26], fill=(56, 146, 56, 255))
            for bx, by in [(11, 15), (19, 15), (15, 20)]:
                d.ellipse([bx - 3, by - 3, bx + 3, by + 3], fill=col)
        elif shape == "shell":
            d.polygon([(7, 23), (16, 8), (25, 23)], fill=col)
            d.line([16, 10, 16, 23], fill=shade(col, 0.75), width=2)
        elif shape == "truffle":
            d.ellipse([7, 11, 25, 26], fill=(94, 58, 148, 255))
            d.ellipse([9, 9, 23, 21], fill=col)
            for sx, sy in [(12, 13), (18, 12), (15, 17)]:
                d.ellipse([sx - 1, sy - 1, sx + 2, sy + 2], fill=(138, 252, 234, 255))
        else:
            d.ellipse([9, 10, 17, 22], fill=col)
            d.ellipse([15, 10, 23, 22], fill=shade(col, 0.85))
            d.rectangle([15, 18, 17, 27], fill=(56, 140, 62, 255))
        save_obj(f"objects/forage_{fid}.png", outline_image(im), f"采集物-{fid}", "32x32")

    # Shipping Bin 48x48
    sbin = Image.new("RGBA", (48, 48), (0, 0, 0, 0))
    d = ImageDraw.Draw(sbin)
    d.rectangle([6, 16, 42, 42], fill=(164, 106, 58, 255), outline=(42, 26, 18, 255), width=2)
    d.rectangle([4, 10, 44, 18], fill=(192, 130, 74, 255), outline=(42, 26, 18, 255), width=2)
    d.rectangle([10, 22, 38, 25], fill=(92, 58, 30, 255))
    d.rectangle([20, 16, 28, 22], fill=(224, 196, 82, 255))
    save_obj("objects/shipping_bin.png", sbin, "出货箱", "48x48")

    # Machines 32x32
    def save_machine(rel, name, fn):
        im = Image.new("RGBA", (32, 32), (0, 0, 0, 0))
        d = ImageDraw.Draw(im)
        fn(d)
        save_obj(rel, outline_image(im), name, "32x32")

    save_machine("objects/machine_sprinkler.png", "四向洒水器", lambda d: (
        d.rectangle([12, 12, 20, 26], fill=(182, 114, 62, 255)),
        d.rectangle([7, 13, 25, 17], fill=(138, 172, 194, 255)),
        d.ellipse([12, 7, 20, 15], fill=(98, 196, 242, 255)),
    ))
    save_machine("objects/machine_quality_sprinkler.png", "优质洒水器", lambda d: (
        d.rectangle([10, 12, 22, 26], fill=(196, 162, 62, 255)),
        d.rectangle([5, 12, 27, 17], fill=(116, 214, 248, 255)),
        d.ellipse([11, 5, 21, 15], fill=(134, 246, 255, 255)),
    ))
    save_machine("objects/machine_jar.png", "果酱腌制桶", lambda d: (
        d.rounded_rectangle([7, 9, 25, 27], radius=5, fill=(166, 108, 60, 255)),
        d.rectangle([6, 13, 26, 16], fill=(112, 116, 128, 255)),
        d.rectangle([6, 21, 26, 24], fill=(112, 116, 128, 255)),
        d.rectangle([9, 6, 23, 10], fill=(208, 148, 86, 255)),
    ))
    save_machine("objects/machine_keg.png", "橡木酿酒桶", lambda d: (
        d.ellipse([6, 6, 26, 28], fill=(144, 88, 48, 255)),
        d.rectangle([6, 12, 26, 15], fill=(214, 176, 78, 255)),
        d.rectangle([6, 20, 26, 23], fill=(214, 176, 78, 255)),
        d.rectangle([14, 22, 18, 27], fill=(214, 176, 78, 255)),
    ))
    save_machine("objects/machine_furnace.png", "矿石熔炉", lambda d: (
        d.polygon([(7, 27), (9, 8), (23, 8), (25, 27)], fill=(112, 116, 128, 255)),
        d.ellipse([11, 15, 21, 26], fill=(255, 126, 36, 255)),
        d.ellipse([13, 18, 19, 25], fill=(255, 224, 96, 255)),
    ))
    save_machine("objects/machine_chest.png", "储物木箱", lambda d: (
        d.rectangle([5, 10, 27, 27], fill=(168, 110, 56, 255)),
        d.rectangle([5, 15, 27, 17], fill=(74, 48, 28, 255)),
        d.rectangle([14, 13, 18, 19], fill=(242, 208, 76, 255)),
    ))
    save_machine("objects/torch.png", "萤火火把", lambda d: (
        d.rectangle([14, 13, 18, 28], fill=(138, 88, 48, 255)),
        d.ellipse([11, 5, 21, 15], fill=(255, 154, 44, 255)),
        d.ellipse([13, 7, 19, 13], fill=(255, 240, 134, 255)),
    ))
    save_machine("objects/ladder_down.png", "下行矿梯", lambda d: (
        d.rectangle([6, 6, 26, 27], fill=(26, 22, 32, 255)),
        d.rectangle([9, 6, 12, 27], fill=(176, 122, 70, 255)),
        d.rectangle([20, 6, 23, 27], fill=(176, 122, 70, 255)),
        d.rectangle([11, 10, 21, 13], fill=(198, 146, 86, 255)),
        d.rectangle([11, 17, 21, 20], fill=(198, 146, 86, 255)),
        d.rectangle([11, 23, 21, 26], fill=(198, 146, 86, 255)),
    ))
    save_machine("objects/ladder_up.png", "返回梯子", lambda d: (
        d.rectangle([9, 4, 12, 28], fill=(192, 138, 78, 255)),
        d.rectangle([20, 4, 23, 28], fill=(192, 138, 78, 255)),
        d.rectangle([11, 9, 21, 12], fill=(224, 172, 106, 255)),
        d.rectangle([11, 16, 21, 19], fill=(224, 172, 106, 255)),
        d.rectangle([11, 23, 21, 26], fill=(224, 172, 106, 255)),
    ))
    save_machine("objects/elevator.png", "矿洞电梯", lambda d: (
        d.rounded_rectangle([4, 4, 28, 28], radius=3, fill=(108, 118, 136, 255)),
        d.rectangle([8, 8, 24, 24], fill=(64, 72, 86, 255)),
        d.ellipse([13, 12, 19, 18], fill=(102, 238, 182, 255)),
    ))
    save_machine("objects/machine_mayo.png", "蛋黄酱机", lambda d: (
        d.rounded_rectangle([8, 10, 24, 27], radius=4, fill=(242, 234, 206, 255)),
        d.rectangle([7, 15, 25, 18], fill=(214, 168, 72, 255)),
        d.rectangle([10, 7, 22, 11], fill=(168, 108, 56, 255)),
        d.line([16, 3, 16, 8], fill=(198, 206, 218, 255), width=2),
        d.line([16, 4, 23, 4], fill=(168, 108, 56, 255), width=2),
    ))
    save_machine("objects/machine_cheese.png", "奶酪压制机", lambda d: (
        d.rectangle([7, 13, 25, 27], fill=(176, 118, 62, 255)),
        d.ellipse([9, 15, 23, 24], fill=(255, 212, 74, 255)),
        d.rectangle([9, 5, 11, 16], fill=(120, 128, 138, 255)),
        d.rectangle([21, 5, 23, 16], fill=(120, 128, 138, 255)),
        d.rectangle([7, 5, 25, 8], fill=(154, 98, 50, 255)),
        d.line([16, 3, 16, 14], fill=(218, 184, 78, 255), width=2),
    ))

    # Bed 48x64
    bed = Image.new("RGBA", (48, 64), (0, 0, 0, 0))
    bd = ImageDraw.Draw(bed)
    bd.rectangle([6, 6, 42, 58], fill=(138, 86, 48, 255), outline=(40, 26, 18, 255), width=2)
    bd.rectangle([10, 12, 38, 24], fill=(242, 240, 232, 255))
    bd.rectangle([10, 24, 38, 54], fill=(186, 72, 78, 255))
    bd.rectangle([10, 24, 38, 30], fill=(224, 118, 122, 255))
    save_obj("objects/bed.png", bed, "农舍床铺", "48x64")

    # TV 32x40
    tv = Image.new("RGBA", (32, 40), (0, 0, 0, 0))
    tvd = ImageDraw.Draw(tv)
    tvd.line([16, 10, 9, 3], fill=(160, 170, 184, 255), width=2)
    tvd.line([16, 10, 23, 3], fill=(160, 170, 184, 255), width=2)
    tvd.rounded_rectangle([3, 10, 29, 34], radius=4, fill=(116, 78, 48, 255), outline=(38, 24, 18, 255), width=2)
    tvd.rectangle([6, 13, 22, 28], fill=(92, 196, 228, 255))
    tvd.rectangle([24, 15, 27, 19], fill=(224, 180, 90, 255))
    save_obj("objects/tv.png", tv, "占卜电视", "32x40")

    # Buildings
    save_obj("objects/house_farm.png", make_building(160, 128, (232, 206, 166, 255), (178, 72, 66, 255), (124, 76, 44, 255), (240, 192, 92, 255), "house"), "农场小屋", "160x128")
    save_obj("objects/shop_linxia.png", make_building(160, 128, (238, 232, 212, 255), (68, 158, 92, 255), (112, 82, 54, 255), (124, 224, 128, 255), "shop"), "林夏种子杂货店", "160x128")
    save_obj("objects/smithy_horn.png", make_building(160, 128, (148, 144, 150, 255), (186, 94, 54, 255), (84, 62, 50, 255), (255, 166, 78, 255), "smithy"), "霍恩铁匠铺", "160x128")

    # Greenhouse 128x96
    gh = Image.new("RGBA", (128, 96), (0, 0, 0, 0))
    ghd = ImageDraw.Draw(gh)
    ghd.ellipse([6, 80, 122, 94], fill=(0, 0, 0, 75))
    ghd.rounded_rectangle([12, 26, 116, 86], radius=14, fill=(138, 216, 236, 210), outline=(86, 62, 42, 255), width=3)
    ghd.arc([12, 8, 116, 56], 180, 360, fill=(116, 82, 52, 255), width=4)
    for gx in (34, 64, 94):
        ghd.line([gx, 14, gx, 86], fill=(104, 74, 48, 220), width=2)
    ghd.line([12, 46, 116, 46], fill=(104, 74, 48, 220), width=2)
    for fx, fy in [(28, 62), (48, 66), (82, 64), (100, 62)]:
        ghd.ellipse([fx - 6, fy - 6, fx + 6, fy + 6], fill=(72, 186, 82, 255))
    ghd.rounded_rectangle([50, 56, 78, 86], radius=3, fill=(124, 82, 46, 255), outline=(44, 28, 18, 255), width=2)
    save_obj("objects/greenhouse.png", gh, "四季生态温室", "128x96")

    # Festival Judging Table 64x48
    ftb = Image.new("RGBA", (64, 48), (0, 0, 0, 0))
    ftd = ImageDraw.Draw(ftb)
    ftd.rectangle([6, 14, 58, 40], fill=(132, 78, 44, 255), outline=(42, 26, 16, 255), width=2)
    ftd.rectangle([8, 12, 56, 28], fill=(196, 48, 66, 255), outline=(244, 206, 88, 255), width=2)
    ftd.ellipse([26, 14, 38, 24], fill=(255, 222, 84, 255))
    save_obj("objects/festival_table.png", ftb, "丰收品鉴评比台", "64x48")

    # Cozy Red Gambrel Ranch Barn 192x160
    barn = Image.new("RGBA", (192, 160), (0, 0, 0, 0))
    bnd = ImageDraw.Draw(barn)
    bnd.ellipse([10, 138, 182, 156], fill=(0, 0, 0, 82))
    bnd.rectangle([18, 72, 174, 148], fill=(186, 56, 50, 255), outline=(44, 24, 18, 255), width=2)
    bnd.rectangle([18, 138, 174, 148], fill=(128, 120, 112, 255), outline=(44, 24, 18, 255), width=2)
    bnd.polygon([(8, 76), (38, 30), (96, 10), (154, 30), (184, 76)], fill=(148, 42, 38, 255), outline=(44, 24, 18, 255))
    bnd.line([(8, 76), (38, 30), (96, 10), (154, 30), (184, 76)], fill=(246, 238, 224, 255), width=3)
    # Hayloft window
    bnd.rounded_rectangle([78, 34, 114, 62], radius=4, fill=(68, 42, 28, 255), outline=(246, 238, 224, 255), width=2)
    bnd.ellipse([84, 48, 108, 61], fill=(238, 196, 86, 255))
    # White X barn double doors
    bnd.rectangle([68, 94, 124, 147], fill=(142, 40, 36, 255), outline=(246, 238, 224, 255), width=3)
    bnd.line([68, 94, 96, 147], fill=(246, 238, 224, 255), width=2)
    bnd.line([96, 94, 68, 147], fill=(246, 238, 224, 255), width=2)
    bnd.line([96, 94, 124, 147], fill=(246, 238, 224, 255), width=2)
    bnd.line([124, 94, 96, 147], fill=(246, 238, 224, 255), width=2)
    for wx in (30, 138):
        bnd.rectangle([wx, 94, wx + 22, 116], fill=(255, 226, 138, 255), outline=(246, 238, 224, 255), width=2)
    save_obj("objects/barn_ranch.png", barn, "阳光红顶畜牧舍", "192x160")

    # Farmhouse Kitchen Stove 64x48
    stv = Image.new("RGBA", (64, 48), (0, 0, 0, 0))
    std = ImageDraw.Draw(stv)
    std.rounded_rectangle([4, 14, 60, 44], radius=4, fill=(158, 102, 58, 255), outline=(42, 26, 18, 255), width=2)
    std.rectangle([6, 12, 58, 20], fill=(228, 216, 196, 255), outline=(42, 26, 18, 255), width=2)
    # Cast-iron stove & simmering pot
    std.rectangle([10, 22, 32, 40], fill=(58, 56, 64, 255), outline=(32, 28, 34, 255), width=2)
    std.ellipse([14, 27, 28, 37], fill=(255, 142, 48, 255))
    std.rounded_rectangle([12, 5, 30, 16], radius=3, fill=(196, 68, 58, 255), outline=(42, 26, 18, 255), width=2)
    std.ellipse([14, 4, 28, 9], fill=(255, 222, 118, 255))
    # Cutting board & veggies on right counter
    std.rectangle([38, 13, 54, 19], fill=(214, 166, 102, 255))
    std.ellipse([41, 11, 47, 17], fill=(232, 74, 68, 255))
    std.ellipse([48, 12, 53, 17], fill=(102, 194, 78, 255))
    save_obj("objects/kitchen_stove.png", stv, "乡野料理灶台", "64x48")

    # Feed Trough 64x36
    trg = Image.new("RGBA", (64, 36), (0, 0, 0, 0))
    trd = ImageDraw.Draw(trg)
    trd.ellipse([4, 24, 60, 34], fill=(0, 0, 0, 68))
    trd.rounded_rectangle([6, 12, 58, 30], radius=4, fill=(152, 96, 52, 255), outline=(42, 26, 18, 255), width=2)
    for hx in range(10, 54, 6):
        trd.ellipse([hx, 7, hx + 9, 19], fill=(238, 198, 78, 255))
    save_obj("objects/feed_trough.png", trg, "牧场饲草槽", "64x36")

    # Ranch Signpost 48x48
    rsg = Image.new("RGBA", (48, 48), (0, 0, 0, 0))
    rsd = ImageDraw.Draw(rsg)
    rsd.ellipse([14, 38, 34, 45], fill=(0, 0, 0, 70))
    rsd.rectangle([21, 20, 27, 43], fill=(126, 78, 42, 255), outline=(42, 26, 18, 255), width=2)
    rsd.rounded_rectangle([6, 6, 42, 26], radius=4, fill=(232, 194, 126, 255), outline=(72, 44, 24, 255), width=2)
    rsd.ellipse([17, 10, 31, 22], fill=(255, 248, 232, 255), outline=(72, 44, 24, 255))
    rsd.polygon([(20, 8), (24, 5), (28, 8)], fill=(224, 64, 64, 255))
    save_obj("objects/ranch_sign.png", rsg, "阳光牧场木牌", "48x48")

    # Echo Shrine 128x128
    shrine = Image.new("RGBA", (128, 128), (0, 0, 0, 0))
    sd2 = ImageDraw.Draw(shrine)
    sd2.ellipse([12, 22, 116, 116], fill=(134, 146, 142, 255), outline=(44, 48, 54, 255), width=3)
    sd2.ellipse([24, 34, 104, 104], fill=(106, 118, 116, 255), outline=(72, 178, 164, 255), width=2)
    for px, py in [(28, 36), (90, 36), (28, 80), (90, 80)]:
        sd2.rectangle([px, py, px + 12, py + 24], fill=(168, 176, 178, 255), outline=(44, 48, 54, 255), width=2)
        sd2.ellipse([px + 2, py - 6, px + 10, py + 4], fill=(116, 242, 226, 255))
    sd2.polygon([(64, 38), (78, 66), (64, 92), (50, 66)], fill=(120, 244, 232, 255), outline=(44, 90, 104, 255))
    save_obj("objects/echo_shrine.png", shrine, "回响祭坛", "128x128")

    # Quest Board 64x64
    qb = Image.new("RGBA", (64, 64), (0, 0, 0, 0))
    qbd = ImageDraw.Draw(qb)
    qbd.rectangle([10, 38, 16, 60], fill=(112, 72, 42, 255))
    qbd.rectangle([48, 38, 54, 60], fill=(112, 72, 42, 255))
    qbd.rectangle([6, 10, 58, 44], fill=(164, 110, 62, 255), outline=(44, 28, 18, 255), width=2)
    qbd.rectangle([12, 15, 30, 35], fill=(246, 234, 198, 255))
    qbd.rectangle([34, 17, 52, 37], fill=(238, 224, 182, 255))
    qbd.ellipse([19, 13, 23, 17], fill=(214, 66, 66, 255))
    qbd.ellipse([41, 15, 45, 19], fill=(66, 146, 214, 255))
    save_obj("objects/quest_board.png", qb, "镇广场悬赏栏", "64x64")

    # Fountain 96x96
    fn = Image.new("RGBA", (96, 96), (0, 0, 0, 0))
    fnd = ImageDraw.Draw(fn)
    fnd.ellipse([8, 16, 88, 86], fill=(162, 168, 176, 255), outline=(48, 52, 60, 255), width=2)
    fnd.ellipse([16, 24, 80, 78], fill=(68, 166, 224, 255), outline=(120, 128, 140, 255), width=2)
    fnd.rectangle([40, 28, 56, 56], fill=(176, 182, 190, 255), outline=(48, 52, 60, 255), width=2)
    fnd.ellipse([36, 18, 60, 32], fill=(122, 216, 252, 255))
    save_obj("objects/fountain.png", fn, "镇广场喷泉", "96x96")

    # Pet Bowl & Cozy Kennel 32x32
    pbowl = Image.new("RGBA", (32, 32), (0, 0, 0, 0))
    pbd = ImageDraw.Draw(pbowl)
    pbd.ellipse([4, 22, 28, 30], fill=(0, 0, 0, 70))
    pbd.rectangle([6, 13, 22, 26], fill=(218, 176, 124, 255), outline=(42, 26, 18, 255), width=2)
    pbd.polygon([(4, 15), (14, 5), (24, 15)], fill=(196, 68, 62, 255), outline=(42, 26, 18, 255))
    pbd.rounded_rectangle([11, 17, 17, 26], radius=3, fill=(64, 38, 28, 255))
    pbd.ellipse([21, 21, 29, 28], fill=(86, 178, 236, 255), outline=(42, 26, 18, 255))
    save_obj("objects/pet_bowl.png", pbowl, "萌宠温馨小窝", "32x32")

    # Ecological Fish Pond 96x64
    fpond = Image.new("RGBA", (96, 64), (0, 0, 0, 0))
    fpd = ImageDraw.Draw(fpond)
    fpd.ellipse([4, 8, 92, 60], fill=(142, 136, 128, 255), outline=(44, 38, 34, 255), width=2)
    for ang in range(0, 360, 28):
        rx = 48 + int(math.cos(math.radians(ang)) * 40)
        ry = 34 + int(math.sin(math.radians(ang)) * 22)
        fpd.ellipse([rx - 6, ry - 5, rx + 6, ry + 5], fill=(166, 158, 148, 255), outline=(54, 46, 40, 255))
    fpd.ellipse([13, 15, 83, 53], fill=(48, 158, 214, 255), outline=(88, 198, 242, 255), width=2)
    fpd.ellipse([22, 22, 36, 31], fill=(84, 192, 92, 255))
    fpd.ellipse([26, 20, 32, 26], fill=(255, 158, 188, 255))
    fpd.line([52, 28, 68, 28], fill=(176, 238, 255, 220), width=2)
    save_obj("objects/fish_pond.png", fpond, "活水生态鱼塘", "96x64")

    # Suwan Carpenter & Wonder Desk 64x48
    cdesk = Image.new("RGBA", (64, 48), (0, 0, 0, 0))
    cdd = ImageDraw.Draw(cdesk)
    cdd.rounded_rectangle([4, 14, 60, 42], radius=4, fill=(154, 98, 54, 255), outline=(42, 26, 18, 255), width=2)
    cdd.rectangle([10, 16, 42, 32], fill=(64, 124, 198, 255), outline=(238, 232, 214, 255), width=2)
    cdd.line([16, 24, 36, 24], fill=(214, 242, 255, 255), width=1)
    cdd.line([26, 18, 26, 30], fill=(214, 242, 255, 255), width=1)
    cdd.ellipse([46, 18, 55, 27], fill=(246, 208, 86, 255), outline=(42, 26, 18, 255))
    save_obj("objects/carpenter_desk.png", cdesk, "苏晚星象营造台", "64x48")

    # Warp Obelisk 64x96
    obel = Image.new("RGBA", (64, 96), (0, 0, 0, 0))
    obd = ImageDraw.Draw(obel)
    obd.ellipse([10, 78, 54, 92], fill=(0, 0, 0, 85))
    obd.rectangle([14, 74, 50, 88], fill=(96, 86, 126, 255), outline=(38, 28, 52, 255), width=2)
    obd.polygon([(18, 74), (22, 24), (32, 10), (42, 24), (46, 74)], fill=(116, 88, 186, 255), outline=(38, 28, 52, 255))
    obd.polygon([(26, 68), (28, 26), (32, 16), (36, 26), (38, 68)], fill=(142, 118, 224, 255))
    obd.polygon([(32, 26), (38, 38), (32, 50), (26, 38)], fill=(112, 248, 255, 255))
    obd.ellipse([28, 2, 36, 10], fill=(255, 236, 118, 255))
    save_obj("objects/obelisk.png", obel, "回响方尖传送塔", "64x96")

    # Golden Clock Wonder 64x96
    gclk = Image.new("RGBA", (64, 96), (0, 0, 0, 0))
    gcd = ImageDraw.Draw(gclk)
    gcd.ellipse([10, 78, 54, 92], fill=(0, 0, 0, 85))
    gcd.rectangle([14, 72, 50, 88], fill=(214, 162, 46, 255), outline=(58, 36, 14, 255), width=2)
    gcd.rectangle([18, 28, 46, 74], fill=(246, 198, 68, 255), outline=(58, 36, 14, 255), width=2)
    gcd.polygon([(12, 30), (32, 8), (52, 30)], fill=(255, 218, 86, 255), outline=(58, 36, 14, 255))
    gcd.ellipse([20, 34, 44, 58], fill=(255, 250, 232, 255), outline=(148, 96, 24, 255), width=2)
    gcd.line([32, 46, 32, 38], fill=(58, 36, 14, 255), width=2)
    gcd.line([32, 46, 39, 46], fill=(196, 48, 56, 255), width=2)
    gcd.ellipse([28, 2, 36, 10], fill=(116, 244, 255, 255))
    save_obj("objects/golden_clock.png", gclk, "黄金丰饶钟", "64x96")

    # Monsters
    slime = Image.new("RGBA", (128, 32), (0, 0, 0, 0))
    for i in range(4):
        fr = Image.new("RGBA", (32, 32), (0, 0, 0, 0))
        d = ImageDraw.Draw(fr)
        squash = [0, 3, -2, 1][i]
        d.ellipse([5 - squash // 2, 10 + squash, 27 + squash // 2, 28], fill=(82, 212, 118, 255))
        d.ellipse([9, 13 + squash, 16, 18 + squash], fill=(174, 252, 190, 255))
        d.rectangle([10, 18 + squash // 2, 12, 21 + squash // 2], fill=(24, 38, 28, 255))
        d.rectangle([19, 18 + squash // 2, 21, 21 + squash // 2], fill=(24, 38, 28, 255))
        slime.paste(outline_image(fr), (i * 32, 0))
    slime.save(SPRITES_DIR / "monsters" / "slime.png")
    manifest_sprites.append({
        "rel_path": "monsters/slime.png",
        "category": "monster",
        "name": "绿史莱姆4帧动画",
        "width": 128,
        "height": 32,
        "frame_w": 32,
        "frame_h": 32,
        "notes": "4列x1行弹性跳跃动画",
    })

    bug = Image.new("RGBA", (128, 32), (0, 0, 0, 0))
    for i in range(4):
        fr = Image.new("RGBA", (32, 32), (0, 0, 0, 0))
        d = ImageDraw.Draw(fr)
        leg_off = -1 if i % 2 == 0 else 1
        for ly in (12, 17, 22):
            d.line([4, ly + leg_off, 10, ly], fill=(74, 54, 96, 255), width=2)
            d.line([22, ly, 28, ly - leg_off], fill=(74, 54, 96, 255), width=2)
        d.ellipse([8, 7, 24, 26], fill=(108, 62, 152, 255))
        d.ellipse([11, 10, 21, 22], fill=(148, 92, 198, 255))
        d.rectangle([12, 9, 14, 11], fill=(255, 110, 120, 255))
        d.rectangle([18, 9, 20, 11], fill=(255, 110, 120, 255))
        bug.paste(outline_image(fr), (i * 32, 0))
    bug.save(SPRITES_DIR / "monsters" / "shadow_bug.png")
    manifest_sprites.append({
        "rel_path": "monsters/shadow_bug.png",
        "category": "monster",
        "name": "暗影甲虫4帧动画",
        "width": 128,
        "height": 32,
        "frame_w": 32,
        "frame_h": 32,
        "notes": "4列x1行爬行动画",
    })

    # Echo Boss 192x48 (4 frames of 48x48)
    boss = Image.new("RGBA", (192, 48), (0, 0, 0, 0))
    for i in range(4):
        fr = Image.new("RGBA", (48, 48), (0, 0, 0, 0))
        bd = ImageDraw.Draw(fr)
        bob = [0, -2, 0, 2][i]
        bd.ellipse([8, 38, 40, 46], fill=(0, 0, 0, 90))
        bd.polygon([(10, 38 + bob), (6, 20 + bob), (24, 6 + bob), (42, 20 + bob), (38, 38 + bob)], fill=(88, 64, 154, 255))
        bd.polygon([(14, 34 + bob), (12, 20 + bob), (24, 10 + bob), (36, 20 + bob), (34, 34 + bob)], fill=(118, 214, 252, 255))
        # Crown crystals
        bd.polygon([(18, 10 + bob), (24, 2 + bob), (30, 10 + bob)], fill=(255, 216, 78, 255))
        # Glowing eyes
        bd.rectangle([16, 21 + bob, 20, 25 + bob], fill=(255, 92, 118, 255))
        bd.rectangle([28, 21 + bob, 32, 25 + bob], fill=(255, 92, 118, 255))
        boss.paste(outline_image(fr), (i * 48, 0))
    boss.save(SPRITES_DIR / "monsters" / "echo_boss.png")
    manifest_sprites.append({
        "rel_path": "monsters/echo_boss.png",
        "category": "monster",
        "name": "回响晶甲王Boss 4帧动画",
        "width": 192,
        "height": 48,
        "frame_w": 48,
        "frame_h": 48,
        "notes": "4列x1行矿洞第10层Boss悬浮动画",
    })

    # Forest Wisp 128x32 (4 frames of 32x32)
    wisp = Image.new("RGBA", (128, 32), (0, 0, 0, 0))
    for i in range(4):
        fr = Image.new("RGBA", (32, 32), (0, 0, 0, 0))
        wd2 = ImageDraw.Draw(fr)
        bob = [-1, 1, -2, 0][i]
        wing = 2 if i % 2 == 0 else -1
        wd2.ellipse([4, 11 + bob - wing, 13, 21 + bob], fill=(164, 252, 214, 220))
        wd2.ellipse([19, 11 + bob - wing, 28, 21 + bob], fill=(164, 252, 214, 220))
        wd2.ellipse([9, 8 + bob, 23, 24 + bob], fill=(76, 218, 146, 255))
        wd2.ellipse([12, 6 + bob, 20, 12 + bob], fill=(255, 196, 112, 255))
        wd2.rectangle([12, 14 + bob, 14, 17 + bob], fill=(28, 42, 34, 255))
        wd2.rectangle([18, 14 + bob, 20, 17 + bob], fill=(28, 42, 34, 255))
        wisp.paste(outline_image(fr), (i * 32, 0))
    wisp.save(SPRITES_DIR / "monsters" / "forest_wisp.png")
    manifest_sprites.append({
        "rel_path": "monsters/forest_wisp.png",
        "category": "monster",
        "name": "秘林花妖4帧动画",
        "width": 128, "height": 32, "frame_w": 32, "frame_h": 32,
        "notes": "4列x1行迷雾秘林花妖振翅动画",
    })

    # Ancient Treant Boss 192x48 (4 frames of 48x48)
    treant = Image.new("RGBA", (192, 48), (0, 0, 0, 0))
    for i in range(4):
        fr = Image.new("RGBA", (48, 48), (0, 0, 0, 0))
        td2 = ImageDraw.Draw(fr)
        bob = [0, -1, 0, 1][i]
        td2.ellipse([6, 38, 42, 46], fill=(0, 0, 0, 90))
        td2.polygon([(11, 42), (14, 16 + bob), (34, 16 + bob), (37, 42)], fill=(116, 72, 44, 255))
        for cx, cy, r in [(16, 14, 9), (24, 10, 11), (32, 14, 9)]:
            td2.ellipse([cx - r, cy - r + bob, cx + r, cy + r + bob], fill=(56, 158, 76, 255))
        td2.ellipse([21, 6 + bob, 27, 12 + bob], fill=(138, 106, 255, 255))
        td2.rectangle([17, 23 + bob, 21, 27 + bob], fill=(126, 255, 168, 255))
        td2.rectangle([27, 23 + bob, 31, 27 + bob], fill=(126, 255, 168, 255))
        treant.paste(outline_image(fr), (i * 48, 0))
    treant.save(SPRITES_DIR / "monsters" / "ancient_treant.png")
    manifest_sprites.append({
        "rel_path": "monsters/ancient_treant.png",
        "category": "monster",
        "name": "远古树精守护者Boss 4帧动画",
        "width": 192, "height": 48, "frame_w": 48, "frame_h": 48,
        "notes": "4列x1行迷雾秘林远古树精Boss动画",
    })

    # Livestock Animals (4 frames each)
    chk = Image.new("RGBA", (128, 32), (0, 0, 0, 0))
    for i in range(4):
        fr = Image.new("RGBA", (32, 32), (0, 0, 0, 0))
        cd = ImageDraw.Draw(fr)
        bob = -1 if i in (1, 3) else 0
        leg = -1 if i == 1 else (1 if i == 3 else 0)
        cd.line([14 + leg, 24, 14 + leg, 28], fill=(236, 168, 52, 255), width=2)
        cd.line([19 - leg, 24, 19 - leg, 28], fill=(236, 168, 52, 255), width=2)
        cd.ellipse([8, 13 + bob, 23, 25 + bob], fill=(252, 246, 228, 255))
        cd.ellipse([11, 16 + bob, 19, 22 + bob], fill=(238, 224, 194, 255))
        cd.ellipse([16, 8 + bob, 25, 17 + bob], fill=(254, 250, 238, 255))
        cd.ellipse([18, 5 + bob, 23, 9 + bob], fill=(228, 58, 58, 255))
        cd.polygon([(24, 12 + bob), (28, 13 + bob), (24, 15 + bob)], fill=(246, 184, 52, 255))
        cd.point((21, 11 + bob), fill=(32, 24, 24, 255))
        chk.paste(outline_image(fr), (i * 32, 0))
    chk.save(SPRITES_DIR / "animals" / "chicken.png")
    manifest_sprites.append({
        "rel_path": "animals/chicken.png", "category": "animal", "name": "牧场小母鸡4帧动画",
        "width": 128, "height": 32, "frame_w": 32, "frame_h": 32, "notes": "4列x1行行走啄米动画",
    })

    cow = Image.new("RGBA", (192, 48), (0, 0, 0, 0))
    for i in range(4):
        fr = Image.new("RGBA", (48, 48), (0, 0, 0, 0))
        cd = ImageDraw.Draw(fr)
        bob = -1 if i in (1, 3) else 0
        leg = -2 if i == 1 else (2 if i == 3 else 0)
        for lx in (13 + leg, 19 - leg, 28 + leg, 34 - leg):
            cd.rectangle([lx, 32, lx + 3, 42], fill=(242, 238, 232, 255))
            cd.rectangle([lx, 40, lx + 3, 43], fill=(74, 56, 48, 255))
        cd.rounded_rectangle([9, 18 + bob, 37, 35 + bob], radius=7, fill=(250, 248, 242, 255))
        cd.ellipse([13, 20 + bob, 23, 28 + bob], fill=(78, 58, 48, 255))
        cd.ellipse([25, 24 + bob, 33, 31 + bob], fill=(78, 58, 48, 255))
        # Cute cow head & pink muzzle
        cd.rounded_rectangle([29, 11 + bob, 43, 26 + bob], radius=5, fill=(250, 248, 242, 255))
        cd.rounded_rectangle([31, 19 + bob, 44, 26 + bob], radius=4, fill=(248, 182, 188, 255))
        cd.point([(35, 22 + bob), (40, 22 + bob)], fill=(142, 78, 84, 255))
        cd.rectangle([33, 14 + bob, 35, 16 + bob], fill=(32, 26, 28, 255))
        cd.rectangle([39, 14 + bob, 41, 16 + bob], fill=(32, 26, 28, 255))
        cd.polygon([(31, 11 + bob), (29, 7 + bob), (34, 10 + bob)], fill=(232, 208, 152, 255))
        cd.polygon([(41, 11 + bob), (43, 7 + bob), (38, 10 + bob)], fill=(232, 208, 152, 255))
        cow.paste(outline_image(fr), (i * 48, 0))
    cow.save(SPRITES_DIR / "animals" / "cow.png")
    manifest_sprites.append({
        "rel_path": "animals/cow.png", "category": "animal", "name": "花斑奶牛4帧动画",
        "width": 192, "height": 48, "frame_w": 48, "frame_h": 48, "notes": "4列x1行牧场漫步动画",
    })

    shp = Image.new("RGBA", (160, 40), (0, 0, 0, 0))
    for i in range(4):
        fr = Image.new("RGBA", (40, 40), (0, 0, 0, 0))
        cd = ImageDraw.Draw(fr)
        bob = -1 if i in (1, 3) else 0
        leg = -1 if i == 1 else (1 if i == 3 else 0)
        for lx in (12 + leg, 17 - leg, 23 + leg, 28 - leg):
            cd.rectangle([lx, 27, lx + 2, 35], fill=(82, 64, 58, 255))
        for cx, cy, r in [(14, 21, 7), (21, 18, 8), (27, 21, 7), (18, 24, 7), (24, 24, 7)]:
            cd.ellipse([cx - r, cy - r + bob, cx + r, cy + r + bob], fill=(252, 248, 238, 255))
        cd.rounded_rectangle([26, 13 + bob, 36, 23 + bob], radius=4, fill=(92, 72, 64, 255))
        cd.ellipse([28, 10 + bob, 35, 15 + bob], fill=(252, 248, 238, 255))
        cd.point((33, 16 + bob), fill=(255, 255, 255, 255))
        shp.paste(outline_image(fr), (i * 40, 0))
    shp.save(SPRITES_DIR / "animals" / "sheep.png")
    manifest_sprites.append({
        "rel_path": "animals/sheep.png", "category": "animal", "name": "云朵绵羊4帧动画",
        "width": 160, "height": 40, "frame_w": 40, "frame_h": 40, "notes": "4列x1行牧场漫步动画",
    })

    # Loyal Pet Orange Cat 128x32
    pcat = Image.new("RGBA", (128, 32), (0, 0, 0, 0))
    for i in range(4):
        fr = Image.new("RGBA", (32, 32), (0, 0, 0, 0))
        cd = ImageDraw.Draw(fr)
        bob = -1 if i in (1, 3) else 0
        tail_y = -2 if i % 2 == 0 else 1
        cd.arc([4, 11 + tail_y, 13, 23], 90, 290, fill=(238, 146, 56, 255), width=3)
        cd.rounded_rectangle([9, 15 + bob, 22, 25 + bob], radius=4, fill=(246, 162, 68, 255))
        cd.line([13, 16 + bob, 13, 21 + bob], fill=(196, 104, 36, 255), width=2)
        cd.line([17, 16 + bob, 17, 21 + bob], fill=(196, 104, 36, 255), width=2)
        for lx in (11, 19):
            cd.rectangle([lx, 24, lx + 2, 28], fill=(252, 238, 214, 255))
        cd.rounded_rectangle([16, 9 + bob, 27, 19 + bob], radius=4, fill=(248, 168, 74, 255))
        cd.polygon([(17, 10 + bob), (19, 5 + bob), (21, 10 + bob)], fill=(236, 138, 54, 255))
        cd.polygon([(23, 10 + bob), (25, 5 + bob), (27, 10 + bob)], fill=(236, 138, 54, 255))
        cd.point([(20, 13 + bob), (24, 13 + bob)], fill=(34, 26, 24, 255))
        cd.point((22, 15 + bob), fill=(246, 128, 142, 255))
        pcat.paste(outline_image(fr), (i * 32, 0))
    pcat.save(SPRITES_DIR / "animals" / "pet_cat.png")
    manifest_sprites.append({
        "rel_path": "animals/pet_cat.png", "category": "animal", "name": "萌宠橘猫团子4帧动画",
        "width": 128, "height": 32, "frame_w": 32, "frame_h": 32, "notes": "4列x1行随行橘猫奔跑待机动画",
    })

    # Loyal Pet Shiba Dog 128x32
    pdog = Image.new("RGBA", (128, 32), (0, 0, 0, 0))
    for i in range(4):
        fr = Image.new("RGBA", (32, 32), (0, 0, 0, 0))
        cd = ImageDraw.Draw(fr)
        bob = -1 if i in (1, 3) else 0
        cd.ellipse([5, 12 + bob, 12, 19 + bob], fill=(218, 148, 66, 255))
        cd.rounded_rectangle([9, 15 + bob, 22, 25 + bob], radius=4, fill=(224, 156, 72, 255))
        cd.rectangle([16, 15 + bob, 22, 24 + bob], fill=(250, 242, 224, 255))
        for lx in (11, 19):
            cd.rectangle([lx, 24, lx + 2, 28], fill=(250, 242, 224, 255))
        cd.rounded_rectangle([16, 8 + bob, 27, 18 + bob], radius=4, fill=(224, 156, 72, 255))
        cd.ellipse([18, 13 + bob, 27, 18 + bob], fill=(250, 242, 224, 255))
        cd.line([16, 17 + bob, 23, 17 + bob], fill=(216, 56, 56, 255), width=2)
        cd.polygon([(17, 9 + bob), (19, 4 + bob), (21, 9 + bob)], fill=(196, 126, 48, 255))
        cd.polygon([(23, 9 + bob), (25, 4 + bob), (27, 9 + bob)], fill=(196, 126, 48, 255))
        cd.point([(20, 12 + bob), (24, 12 + bob)], fill=(32, 24, 24, 255))
        cd.point((25, 14 + bob), fill=(42, 32, 32, 255))
        pdog.paste(outline_image(fr), (i * 32, 0))
    pdog.save(SPRITES_DIR / "animals" / "pet_dog.png")
    manifest_sprites.append({
        "rel_path": "animals/pet_dog.png", "category": "animal", "name": "萌宠柴犬旺财4帧动画",
        "width": 128, "height": 32, "frame_w": 32, "frame_h": 32, "notes": "4列x1行随行柴犬奔跑待机动画",
    })

    # v5.0 Coral Island Tropical Objects
    palm = Image.new("RGBA", (64, 96), (0, 0, 0, 0))
    pmd = ImageDraw.Draw(palm)
    pmd.polygon([(24, 92), (30, 34), (37, 34), (34, 92)], fill=(154, 102, 56, 255))
    for fr_ang in (-55, -20, 15, 50, 130, 165, 205):
        ex_p = 33 + int(math.cos(math.radians(fr_ang)) * 24)
        ey_p = 30 + int(math.sin(math.radians(fr_ang)) * 16)
        pmd.line([33, 30, ex_p, ey_p], fill=(64, 176, 72, 255), width=6)
    outline_image(palm).save(SPRITES_DIR / "objects" / "palm_tree.png")
    manifest_sprites.append({
        "rel_path": "objects/palm_tree.png", "category": "object", "name": "海岛椰林棕榈树",
        "width": 64, "height": 96, "frame_w": 64, "frame_h": 96, "notes": "珊瑚群岛热带椰子树",
    })

    boat = Image.new("RGBA", (80, 64), (0, 0, 0, 0))
    btd = ImageDraw.Draw(boat)
    btd.polygon([(10, 42), (70, 42), (60, 58), (20, 58)], fill=(142, 88, 48, 255))
    btd.line([40, 10, 40, 42], fill=(112, 68, 36, 255), width=3)
    btd.polygon([(42, 12), (66, 36), (42, 36)], fill=(250, 238, 214, 255))
    btd.polygon([(38, 15), (18, 36), (38, 36)], fill=(224, 92, 76, 255))
    outline_image(boat).save(SPRITES_DIR / "objects" / "island_boat.png")
    manifest_sprites.append({
        "rel_path": "objects/island_boat.png", "category": "object", "name": "星海木帆渡船",
        "width": 80, "height": 64, "frame_w": 80, "frame_h": 64, "notes": "往返低语湖栈桥与星露珊瑚群岛的渡船",
    })

    pearl_f = Image.new("RGBA", (32, 32), (0, 0, 0, 0))
    pfd = ImageDraw.Draw(pearl_f)
    pfd.ellipse([5, 10, 27, 27], fill=(168, 138, 212, 255))
    pfd.ellipse([11, 14, 21, 24], fill=(255, 232, 246, 255))
    outline_image(pearl_f).save(SPRITES_DIR / "objects" / "forage_coral_pearl.png")
    manifest_sprites.append({
        "rel_path": "objects/forage_coral_pearl.png", "category": "object", "name": "滩涂拾荒-南海星光珍珠",
        "width": 32, "height": 32, "frame_w": 32, "frame_h": 32, "notes": "珊瑚群岛滩涂珠贝",
    })

    starf = Image.new("RGBA", (32, 32), (0, 0, 0, 0))
    sfd = ImageDraw.Draw(starf)
    sfd.polygon([(16, 4), (20, 13), (29, 14), (22, 20), (24, 28), (16, 23), (8, 28), (10, 20), (3, 14), (12, 13)], fill=(246, 112, 68, 255))
    outline_image(starf).save(SPRITES_DIR / "objects" / "forage_starfish_shell.png")
    manifest_sprites.append({
        "rel_path": "objects/forage_starfish_shell.png", "category": "object", "name": "滩涂拾荒-珊瑚红海星",
        "width": 32, "height": 32, "frame_w": 32, "frame_h": 32, "notes": "珊瑚群岛金沙滩海星",
    })


def generate_icons(manifest_sprites: list):
    items = json.loads((DATA_DIR / "items.json").read_text(encoding="utf-8"))["items"]
    crops_map = {
        c["id"]: hex_rgba(c["color"])
        for c in json.loads((DATA_DIR / "crops.json").read_text(encoding="utf-8"))["crops"]
    }

    for item in items:
        iid = item["icon_id"]
        cat = item["category"]
        im = Image.new("RGBA", (32, 32), (0, 0, 0, 0))
        d = ImageDraw.Draw(im)

        if cat == "tool":
            # Wooden handle diagonal
            d.line([6, 26, 20, 12], fill=(154, 98, 52, 255), width=3)
            tt = item.get("tool_type", "")
            if tt == "hoe":
                d.polygon([(16, 8), (27, 7), (25, 15), (18, 12)], fill=(182, 192, 208, 255))
            elif tt == "can":
                d.rectangle([10, 12, 23, 23], fill=(214, 134, 72, 255))
                d.line([23, 17, 28, 12], fill=(214, 134, 72, 255), width=3)
                d.arc([10, 8, 22, 16], 180, 360, fill=(214, 134, 72, 255), width=2)
            elif tt == "axe":
                d.polygon([(17, 6), (27, 10), (24, 19), (17, 14)], fill=(192, 202, 218, 255))
            elif tt == "pickaxe":
                d.arc([10, 5, 28, 22], 220, 40, fill=(176, 190, 212, 255), width=4)
            elif tt == "blade":
                d.line([11, 21, 26, 6], fill=(218, 230, 246, 255), width=4)
                d.line([10, 16, 16, 22], fill=(224, 184, 74, 255), width=3)
            elif tt == "rod":
                d.line([5, 27, 25, 5], fill=(194, 152, 84, 255), width=2)
                d.line([25, 5, 25, 22], fill=(230, 240, 255, 255), width=1)
                d.ellipse([23, 21, 27, 25], fill=(230, 72, 72, 255))
        elif cat == "seed":
            cid = item.get("crop_id", "")
            col = crops_map.get(cid, (140, 200, 90, 255))
            d.rounded_rectangle([6, 5, 26, 27], radius=3, fill=(228, 208, 166, 255))
            d.rectangle([6, 5, 26, 10], fill=(182, 154, 106, 255))
            d.ellipse([10, 13, 22, 23], fill=col)
        elif cat == "crop":
            col = crops_map.get(item["id"], (120, 200, 100, 255))
            d.ellipse([7, 8, 25, 26], fill=col)
            d.ellipse([11, 11, 17, 17], fill=shade(col, 1.25))
            d.ellipse([11, 4, 21, 11], fill=(78, 188, 72, 255))
        elif cat == "fish":
            fc = {
                "fish_crucian": (164, 188, 206, 255),
                "fish_sakura_trout": (244, 158, 184, 255),
                "fish_gold_carp": (255, 198, 56, 255),
                "fish_glow_eel": (92, 234, 214, 255),
                "fish_catfish": (118, 128, 148, 255),
                "fish_frost_salmon": (136, 214, 248, 255),
                "fish_sun_perch": (244, 132, 68, 255),
                "fish_echo_dragon": (166, 118, 255, 255),
            }.get(item["id"], (120, 180, 220, 255))
            d.ellipse([8, 10, 26, 22], fill=fc)
            d.polygon([(3, 10), (10, 16), (3, 22)], fill=shade(fc, 0.85))
            d.rectangle([20, 13, 22, 15], fill=(24, 24, 34, 255))
        elif cat in ("mineral", "bar"):
            mc = {
                "copper_ore": (218, 116, 64, 255),
                "iron_ore": (184, 204, 224, 255),
                "gold_ore": (255, 212, 64, 255),
                "echo_crystal": (114, 238, 255, 255),
                "copper_bar": (224, 122, 66, 255),
                "iron_bar": (194, 212, 232, 255),
                "gold_bar": (255, 218, 74, 255),
            }.get(item["id"], (160, 160, 170, 255))
            if cat == "bar":
                d.polygon([(5, 20), (10, 11), (26, 11), (22, 20)], fill=mc)
                d.polygon([(5, 20), (22, 20), (26, 24), (9, 24)], fill=shade(mc, 0.75))
            elif item["id"] == "echo_crystal":
                d.polygon([(16, 4), (24, 14), (19, 27), (12, 27), (8, 15)], fill=mc)
            else:
                d.polygon([(7, 23), (8, 11), (17, 7), (25, 13), (24, 24)], fill=(116, 116, 126, 255))
                d.rectangle([11, 13, 17, 19], fill=mc)
                d.rectangle([17, 16, 21, 21], fill=mc)
        elif cat == "ranch":
            if item["id"] == "egg":
                d.ellipse([9, 7, 23, 26], fill=(252, 244, 224, 255))
                d.ellipse([12, 10, 17, 16], fill=(255, 252, 245, 255))
            elif item["id"] == "milk":
                d.rounded_rectangle([9, 10, 23, 27], radius=3, fill=(246, 250, 255, 255))
                d.rectangle([11, 5, 21, 11], fill=(214, 232, 248, 255))
                d.rectangle([10, 4, 22, 6], fill=(224, 84, 84, 255))
            elif item["id"] == "fish_roe":
                for rx, ry in [(12, 19), (18, 19), (15, 14), (10, 15), (20, 15), (15, 22)]:
                    d.ellipse([rx - 4, ry - 4, rx + 4, ry + 4], fill=(255, 146, 56, 255))
                    d.point((rx - 1, ry - 1), fill=(255, 238, 196, 255))
            else:  # wool
                for wx, wy in [(12, 17), (19, 15), (16, 21), (20, 21)]:
                    d.ellipse([wx - 6, wy - 6, wx + 6, wy + 6], fill=(250, 246, 236, 255))
        elif cat == "dish":
            # Warm ceramic plate + colorful cooked food
            d.ellipse([4, 13, 28, 27], fill=(244, 240, 230, 255))
            d.ellipse([7, 15, 25, 25], fill=(224, 216, 200, 255))
            dc = {
                "dish_spring_salad": (106, 204, 88, 255),
                "dish_omelet": (255, 208, 68, 255),
                "dish_berry_muffin": (182, 92, 198, 255),
                "dish_herb_fish": (228, 146, 72, 255),
                "dish_pumpkin_soup": (244, 136, 48, 255),
                "dish_cheese_gratin": (252, 192, 62, 255),
                "dish_miner_stew": (186, 96, 58, 255),
                "dish_valley_feast": (238, 86, 78, 255),
            }.get(item["id"], (240, 176, 76, 255))
            d.ellipse([8, 9, 24, 23], fill=dc)
            d.ellipse([11, 11, 18, 16], fill=shade(dc, 1.2))
            d.point([(14, 13), (19, 15)], fill=(116, 212, 96, 255))
        elif cat == "artisan" or cat == "consumable":
            ac = {
                "artisan_pickles": (116, 194, 86, 255),
                "artisan_jam": (216, 68, 96, 255),
                "artisan_wine": (152, 54, 132, 255),
                "artisan_mayo": (252, 238, 174, 255),
                "artisan_cheese": (255, 204, 64, 255),
                "artisan_cloth": (146, 196, 242, 255),
                "herbal_tea": (114, 206, 148, 255),
                "roasted_fish": (224, 148, 72, 255),
            }.get(item["id"], (200, 160, 100, 255))
            if item["id"] == "artisan_cheese":
                d.polygon([(6, 22), (16, 9), (26, 18), (26, 25), (6, 25)], fill=ac)
                d.ellipse([13, 17, 17, 21], fill=shade(ac, 0.8))
                d.ellipse([20, 19, 23, 22], fill=shade(ac, 0.8))
            elif item["id"] == "artisan_cloth":
                d.rounded_rectangle([6, 10, 26, 24], radius=4, fill=ac)
                d.ellipse([20, 10, 26, 24], fill=shade(ac, 0.82))
            elif item["id"] == "artisan_wine":
                d.rectangle([13, 4, 19, 12], fill=(82, 124, 72, 255))
                d.rounded_rectangle([9, 11, 23, 27], radius=3, fill=(82, 124, 72, 255))
                d.rectangle([11, 15, 21, 22], fill=ac)
            elif item["id"] == "herbal_tea":
                d.ellipse([7, 14, 24, 26], fill=(238, 234, 222, 255))
                d.ellipse([9, 13, 22, 18], fill=ac)
            elif item["id"] == "roasted_fish":
                d.ellipse([5, 11, 26, 22], fill=ac)
                d.line([11, 14, 14, 19], fill=(92, 48, 24, 255), width=2)
                d.line([17, 14, 20, 19], fill=(92, 48, 24, 255), width=2)
            elif item["id"] == "bouquet":
                d.polygon([(12, 16), (20, 16), (17, 28), (15, 28)], fill=(238, 214, 168, 255))
                d.line([13, 22, 19, 22], fill=(228, 76, 108, 255), width=2)
                for fx, fy, fc in [(11, 11, (255, 112, 146, 255)), (20, 11, (255, 214, 78, 255)), (16, 8, (168, 118, 255, 255)), (16, 14, (255, 146, 178, 255))]:
                    d.ellipse([fx - 4, fy - 4, fx + 4, fy + 4], fill=fc)
            elif item["id"] == "mermaid_pendant":
                d.arc([9, 4, 23, 18], 180, 360, fill=(246, 208, 86, 255), width=2)
                d.polygon([(16, 10), (24, 19), (16, 28), (8, 19)], fill=(96, 226, 248, 255))
                d.ellipse([13, 15, 19, 22], fill=(196, 252, 255, 255))
            elif item["id"] == "artisan_caviar":
                d.rounded_rectangle([8, 10, 24, 27], radius=4, fill=(44, 46, 62, 255))
                d.rectangle([9, 15, 23, 21], fill=(246, 204, 74, 255))
                d.rectangle([9, 6, 23, 10], fill=(246, 204, 74, 255))
            else:
                d.rounded_rectangle([8, 9, 24, 27], radius=4, fill=ac)
                d.rectangle([10, 6, 22, 10], fill=(224, 190, 110, 255))
        elif cat == "machine":
            obj_src = SPRITES_DIR / "objects" / f"{item['id']}.png"
            if obj_src.exists():
                im = Image.open(obj_src).convert("RGBA").resize((32, 32), Image.Resampling.NEAREST)
            else:
                d.rectangle([6, 6, 26, 26], fill=(160, 120, 80, 255))
        else:
            # Resource / Forage / Fertilizer
            rc = {
                "wood": (158, 104, 58, 255),
                "hardwood": (148, 56, 46, 255),
                "hay": (236, 196, 76, 255),
                "stone": (138, 142, 152, 255),
                "fiber": (106, 178, 72, 255),
                "fertilizer_speed": (236, 184, 68, 255),
                "wild_berry": (196, 48, 86, 255),
                "echo_shell": (244, 186, 212, 255),
                "spring_herb": (82, 214, 122, 255),
                "mystic_truffle": (152, 92, 242, 255),
                "slime_gel": (88, 218, 126, 255),
                "bug_chitin": (122, 74, 168, 255),
            }.get(item["id"], (180, 180, 180, 255))
            if item["id"] in ("wood", "hardwood"):
                d.rounded_rectangle([5, 10, 27, 21], radius=3, fill=rc)
                d.ellipse([21, 10, 27, 21], fill=(226, 158, 106, 255) if item["id"] == "hardwood" else (214, 172, 122, 255))
            else:
                d.ellipse([7, 8, 25, 25], fill=rc)
                d.ellipse([11, 11, 17, 16], fill=shade(rc, 1.25))

        if cat != "machine":
            im = outline_image(im)
        rel = f"icons/{iid}.png"
        im.save(SPRITES_DIR / rel)
        manifest_sprites.append({
            "rel_path": rel,
            "category": "icon",
            "name": f"图标-{item['name']}",
            "width": 32,
            "height": 32,
            "frame_w": 32,
            "frame_h": 32,
            "notes": "物品栏/快捷栏/商店显示图标",
        })


def main():
    for sub in ["characters", "crops", "tiles", "objects", "monsters", "animals", "icons", "portraits"]:
        (SPRITES_DIR / sub).mkdir(parents=True, exist_ok=True)

    manifest_sprites = []
    generate_characters(manifest_sprites)
    generate_crops(manifest_sprites)
    generate_terrain_atlas(manifest_sprites)
    generate_objects_and_monsters(manifest_sprites)
    generate_icons(manifest_sprites)

    audio_list = [
        {"rel_path": "till.wav", "name": "锄地翻土", "duration_sec": 0.16, "notes": "16-bit 44100Hz 单声道/立体声 WAV"},
        {"rel_path": "water.wav", "name": "水壶浇水", "duration_sec": 0.28, "notes": "清脆水波声"},
        {"rel_path": "plant.wav", "name": "播种轻响", "duration_sec": 0.12, "notes": "轻快弹响"},
        {"rel_path": "harvest.wav", "name": "收获提示音", "duration_sec": 0.24, "notes": "双音上扬和弦"},
        {"rel_path": "chop.wav", "name": "伐木砍击", "duration_sec": 0.16, "notes": "木质钝击"},
        {"rel_path": "mine_hit.wav", "name": "镐击矿石", "duration_sec": 0.18, "notes": "金属清脆撞击"},
        {"rel_path": "sword_swing.wav", "name": "挥剑破空", "duration_sec": 0.14, "notes": "气浪呼啸"},
        {"rel_path": "monster_hit.wav", "name": "怪物受击", "duration_sec": 0.15, "notes": "弹性击打声"},
        {"rel_path": "coin.wav", "name": "金币结算", "duration_sec": 0.22, "notes": "高音叮当"},
        {"rel_path": "fish_cast.wav", "name": "抛竿落水", "duration_sec": 0.25, "notes": "咻+水花"},
        {"rel_path": "fish_catch.wav", "name": "成功钓鱼", "duration_sec": 0.45, "notes": "胜利琶音"},
        {"rel_path": "ui_click.wav", "name": "界面按钮点击", "duration_sec": 0.06, "notes": "柔和木质轻叩"},
        {"rel_path": "rooster_morning.wav", "name": "清晨唤醒", "duration_sec": 0.65, "notes": "温暖晨钟三和弦"},
        {"rel_path": "valley_breeze_loop.wav", "name": "春季晨露田园背景乐", "duration_sec": 8.0, "notes": "可无缝循环的温柔木吉他竖琴+微风鸟鸣"},
        {"rel_path": "bgm_summer_loop.wav", "name": "盛夏晴空田园背景乐", "duration_sec": 8.0, "notes": "欢快尤克里里与马林巴夏风循环"},
        {"rel_path": "bgm_autumn_loop.wav", "name": "金秋麦浪田园背景乐", "duration_sec": 8.0, "notes": "温暖指弹木吉他与秋叶竖琴循环"},
        {"rel_path": "bgm_winter_loop.wav", "name": "冬日星雪田园背景乐", "duration_sec": 8.0, "notes": "晶莹钢片琴八音盒与竖琴循环"},
        {"rel_path": "bgm_island_loop.wav", "name": "珊瑚群岛热带海风背景乐", "duration_sec": 8.0, "notes": "加勒比热带马林巴尼龙吉他与海浪循环"}
    ]

    manifest = {
        "base_tile_size": 32,
        "dropin_sprites_dir": "art_dropin/sprites",
        "dropin_audio_dir": "art_dropin/audio",
        "sprites": manifest_sprites,
        "audio": audio_list,
    }
    (DATA_DIR / "art_manifest.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(f"Generated {len(manifest_sprites)} sprite sheets/icons and updated art_manifest.json.")


if __name__ == "__main__":
    main()
