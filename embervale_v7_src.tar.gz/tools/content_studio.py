#!/usr/bin/env python3
"""
《星露物语：回响山谷》本地 Web 策划数据与人工美术管理工作台 (零外部依赖)
启动后监听 http://127.0.0.1:8765 ，提供：
1) 作物/物品/生态共鸣/配方/NPC JSON 在线可视化编辑并一键保存写回 game/data/
2) 人工美术替换进度看板（展示 AI 占位图 vs art_dropin 人工覆盖状态、尺寸校验）
3) 一键触发经济平衡模拟器并查看报告
支持 --self-test 快速自检模式。
"""
import argparse
import base64
import json
import mimetypes
import os
import subprocess
import sys
import threading
import urllib.parse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import art_pipeline
import balance_simulator

ROOT = Path(__file__).resolve().parent.parent
DATA_DIR = ROOT / "game" / "data"
SPRITES_RES = ROOT / "game" / "assets" / "sprites"
SPRITES_DROPIN = ROOT / "art_dropin" / "sprites"
SCREENSHOTS_DIR = ROOT / "reports" / "screenshots"
GODOT_GUI_EXE = ROOT / "tools" / "godot" / "Godot_v4.6.1-stable_win64.exe"
EVOLVE_CFG = ROOT / "tools" / "auto_evolve_config.json"
BACKLOG_FILE = ROOT / "reports" / "evolution_backlog.json"
EVOLVE_LOG = ROOT / "reports" / "evolution_log.md"

EDITABLE_FILES = [
    "crops.json",
    "items.json",
    "ecology_rules.json",
    "recipes.json",
    "npcs.json",
    "fish.json",
    "quests_and_bundles.json",
]

HTML_PAGE = r"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8" />
<title>回响山谷 — AI程序×人工美术 工作台</title>
<style>
  :root {
    --bg: #131820; --panel: #1b222d; --panel2: #222b38; --border: #334155;
    --text: #e2e8f0; --muted: #94a3b8; --accent: #34d399; --gold: #fbbf24; --warn: #f87171;
  }
  * { box-sizing: border-box; }
  body { margin: 0; font-family: "Microsoft YaHei", sans-serif; background: var(--bg); color: var(--text); }
  header { display: flex; justify-content: space-between; align-items: center; padding: 14px 24px; background: #0f141b; border-bottom: 1px solid var(--border); }
  header h1 { margin: 0; font-size: 18px; color: var(--accent); }
  .badge { background: rgba(52,211,153,0.14); color: var(--accent); border: 1px solid rgba(52,211,153,0.35); padding: 4px 10px; border-radius: 999px; font-size: 12px; }
  nav { display: flex; gap: 8px; padding: 12px 24px; background: var(--panel); border-bottom: 1px solid var(--border); }
  nav button { background: var(--panel2); color: var(--text); border: 1px solid var(--border); padding: 8px 16px; border-radius: 8px; cursor: pointer; font-weight: bold; }
  nav button.active { background: var(--accent); color: #0b1410; border-color: var(--accent); }
  main { padding: 20px 24px; max-width: 1400px; margin: 0 auto; }
  .grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(260px, 1fr)); gap: 14px; }
  .card { background: var(--panel); border: 1px solid var(--border); border-radius: 10px; padding: 14px; }
  .card.human { border-color: var(--accent); box-shadow: 0 0 0 1px rgba(52,211,153,0.25); }
  .card.warn { border-color: var(--warn); }
  .thumb-wrap { display: flex; align-items: center; gap: 12px; margin-bottom: 8px; }
  .thumb { width: 56px; height: 56px; image-rendering: pixelated; object-fit: contain; background: #0d1117; border: 1px solid var(--border); border-radius: 6px; padding: 4px; }
  .tag { display: inline-block; font-size: 11px; padding: 2px 7px; border-radius: 4px; margin-right: 4px; }
  .tag.ai { background: #334155; color: #cbd5e1; }
  .tag.human { background: rgba(52,211,153,0.2); color: var(--accent); }
  .tag.warn { background: rgba(248,113,113,0.2); color: var(--warn); }
  textarea { width: 100%; height: 540px; background: #0d1117; color: #d1fae5; border: 1px solid var(--border); border-radius: 8px; padding: 14px; font-family: Consolas, monospace; font-size: 13px; line-height: 1.5; }
  .btn { background: var(--accent); color: #0a1410; border: none; padding: 8px 16px; border-radius: 6px; cursor: pointer; font-weight: bold; }
  .btn.sec { background: var(--panel2); color: var(--text); border: 1px solid var(--border); }
  .row { display: flex; gap: 10px; align-items: center; margin-bottom: 12px; flex-wrap: wrap; }
  pre { background: #0d1117; border: 1px solid var(--border); padding: 16px; border-radius: 8px; overflow-x: auto; white-space: pre-wrap; line-height: 1.55; }
</style>
</head>
<body>
<header>
  <h1>🌱 星露物语：回响山谷 — 试玩启动器 & 策划美术工作台</h1>
  <div class="row" style="margin:0;">
    <button class="btn" style="font-size:14px;padding:9px 18px;" onclick="launchGame()">🎮 立即弹开游戏窗口试玩</button>
    <button class="btn sec" onclick="openFolder()">📂 打开 D:\星露谷物语 文件夹</button>
    <button class="btn sec" onclick="launchEditor()">🛠️ 打开 Godot 编辑器</button>
    <span id="launchMsg" style="color:var(--gold);font-size:13px;font-weight:bold;"></span>
    <div class="badge" id="statsBadge">加载中...</div>
  </div>
</header>
<nav>
  <button class="active" onclick="showTab('play', this)">🎮 实机画面预览与一键试玩</button>
  <button onclick="showTab('art', this)">🎨 人工美术热替换看板</button>
  <button onclick="showTab('data', this)">📊 策划数据表 JSON 编辑</button>
  <button onclick="showTab('eco', this)">⚖️ 四季经济平衡模拟器</button>
  <button onclick="showTab('evo', this)">⚖️ 自动裁判与演进看板</button>
</nav>
<main>
  <section id="tab-play">
    <div class="card human" style="margin-bottom:16px;display:flex;justify-content:space-between;align-items:center;gap:16px;flex-wrap:wrap;">
      <div>
        <div style="font-size:17px;font-weight:bold;color:var(--accent);margin-bottom:6px;">🚀 点击右侧按钮，立即在电脑屏幕中央弹出《星露物语：回响山谷》游戏窗口！</div>
        <div style="font-size:13px;color:var(--muted);line-height:1.6;">
          操作速查：<b>WASD</b> 移动 ｜ <b>鼠标左键/空格</b> 使用工具或挥剑 ｜ <b>E/右键</b> 收获·对话·进门 ｜ <b>1~9</b> 切快捷栏 ｜ <b>Tab</b> 生态共鸣透视镜 ｜ <b>I</b> 背包与手工 ｜ <b>F9</b> 零重启热刷新美术与数值
        </div>
      </div>
      <button class="btn" style="font-size:16px;padding:12px 26px;" onclick="launchGame()">▶️ 点我启动游戏试玩</button>
    </div>
    <div class="grid" id="shotGrid" style="grid-template-columns: repeat(auto-fill, minmax(380px, 1fr));"></div>
  </section>

  <section id="tab-art" style="display:none">
    <div class="row">
      <button class="btn" onclick="loadArt()">🔄 重新扫描 art_dropin 目录</button>
      <span id="uploadMsg" style="color:var(--gold);font-size:13px;font-weight:bold;"></span>
      <span style="color:var(--muted);font-size:13px;">点击任意卡片上的 <b>✨ 上传AI大图自动抠底换皮</b> 选择白底/纯色底原图，自动泛洪抠图+最近邻像素对齐写入 <code>art_dropin/sprites/</code>，游戏内按 <b>F9</b> 即刻生效！</span>
    </div>
    <input type="file" id="aiFilePicker" accept="image/*" style="display:none" onchange="onAiFilePicked(event)" />
    <div class="grid" id="artGrid"></div>
  </section>

  <section id="tab-data" style="display:none">
    <div class="row">
      <label>选择数据表：</label>
      <select id="fileSelect" onchange="loadJsonFile()" style="background:#1b222d;color:#fff;padding:7px 12px;border:1px solid #334155;border-radius:6px;"></select>
      <button class="btn" onclick="saveJsonFile()">💾 保存修改 (游戏内按 F9 即时生效)</button>
      <span id="saveMsg" style="color:var(--accent);font-size:13px;"></span>
    </div>
    <textarea id="jsonEditor"></textarea>
  </section>

  <section id="tab-eco" style="display:none">
    <div class="row">
      <button class="btn" onclick="runSim()">⚡ 运行 28天×四季 经济模拟器</button>
    </div>
    <pre id="ecoReport">点击上方按钮运行模拟并生成最新平衡报告...</pre>
  </section>

  <section id="tab-evo" style="display:none">
    <div class="row">
      <button class="btn" onclick="runRefereeNow()">⚖️ 立即运行五维自动裁判巡检</button>
      <button class="btn sec" id="evoToggleBtn" onclick="toggleEvolution()">🔄 切换对话自动裁判开关</button>
      <label>单次最大自动轮数：</label>
      <input id="evoMaxRounds" type="number" min="1" max="20" value="4" style="width:70px;background:#1b222d;color:#fff;padding:6px;border:1px solid #334155;border-radius:6px;" />
      <button class="btn sec" onclick="saveMaxRounds()">保存轮数上限</button>
      <span id="evoStatusMsg" style="color:var(--accent);font-size:13px;"></span>
    </div>
    <pre id="refereeReportPre" style="margin-bottom:16px;border-color:var(--accent);">正在加载最新自动裁判报告...</pre>
    <div class="grid" id="evoBacklogGrid" style="margin-bottom:16px;"></div>
    <pre id="evoLogPre">加载演进日志...</pre>
  </section>
</main>
<script>
const FILES = ["crops.json","items.json","ecology_rules.json","recipes.json","npcs.json","fish.json","quests_and_bundles.json"];
const sel = document.getElementById("fileSelect");
FILES.forEach(f => { const o = document.createElement("option"); o.value = f; o.textContent = f; sel.appendChild(o); });

function showTab(name, btn) {
  document.querySelectorAll("nav button").forEach(b => b.classList.remove("active"));
  btn.classList.add("active");
  ["play","art","data","eco","evo"].forEach(t => document.getElementById("tab-" + t).style.display = (t === name ? "block" : "none"));
  if (name === "play") loadShots();
  if (name === "art") loadArt();
  if (name === "data" && !document.getElementById("jsonEditor").value) loadJsonFile();
  if (name === "eco") runSim();
  if (name === "evo") loadEvolution();
}

async function copyCmd(txt) {
  try { await navigator.clipboard.writeText(txt); } catch (e) {
    const ta = document.createElement("textarea"); ta.value = txt; document.body.appendChild(ta); ta.select(); document.execCommand("copy"); ta.remove();
  }
}

async function launchGame() {
  document.getElementById("launchMsg").textContent = "⏳ 正在准备启动...";
  const r = await fetch("/api/launch_game", { method: "POST" });
  const d = await r.json();
  if (d.copy_cmd) await copyCmd(d.copy_cmd);
  document.getElementById("launchMsg").textContent = d.message || "✅ 已启动！请看屏幕中央或底部任务栏";
}

async function launchEditor() {
  const r = await fetch("/api/launch_editor", { method: "POST" });
  const d = await r.json();
  if (d.copy_cmd) await copyCmd(d.copy_cmd);
  document.getElementById("launchMsg").textContent = d.message || "✅ 已启动 Godot 编辑器";
}

async function openFolder() {
  const r = await fetch("/api/open_folder", { method: "POST" });
  const d = await r.json();
  if (d.copy_cmd) await copyCmd(d.copy_cmd);
  document.getElementById("launchMsg").textContent = d.message || "✅ 已打开项目文件夹";
}

const SHOT_LABELS = {
  "00_title_screen.png": "① 游戏主菜单欢迎界面（v4.0 终局完全体）",
  "01_farm_ecology_lens.png": "② 星露谷暖系农场 + 圆角包边地形 + 伴生生态镜",
  "02_town_dialogue.png": "③ 溪木镇广场 + 精修村民像素半身立绘对话",
  "03_mine_combat.png": "④ 回响矿洞暖光火把照明与怪物即时战斗",
  "04_inventory_crafting.png": "⑤ 原木羊皮纸36格背包（一键分类整理 & Shift拆分）",
  "05_smithy_tool_upgrades.png": "⑥ 霍恩铁匠铺：四阶工具升级锻造",
  "06_mine_floor10_boss.png": "⑦ 矿洞第10层首领战：回响晶甲王",
  "07_sunny_ranch_livestock.png": "⑧ 阳光牧场：红顶畜舍与小鸡奶牛绵羊养殖",
  "08_kitchen_cooking_buffs.png": "⑨ 农舍料理灶台：8道星露谷美食与探索Buff",
  "09_secret_woods_treant.png": "⑩ 【v4.0新增】第八区域「迷雾回响秘林」与远古树精王首领战",
  "10_farm_wonders_pond_pet.png": "⑪ 【v4.0新增】终局双奇观（黄金丰饶钟&方尖传送塔）+ 活水鱼塘 + 萌宠随行",
  "11_perfection_and_marriage.png": "⑫ 【v4.0新增】二阶双人婚房浪漫求婚同居 & 山谷完美度徽章总览"
};

async function loadShots() {
  const r = await fetch("/api/screenshots");
  const d = await r.json();
  const grid = document.getElementById("shotGrid");
  grid.innerHTML = "";
  (d.files || []).forEach(fn => {
    const c = document.createElement("div");
    c.className = "card";
    const title = SHOT_LABELS[fn] || fn;
    c.innerHTML = `
      <div style="font-weight:bold;margin-bottom:8px;color:var(--gold);">${title}</div>
      <img src="/api/screenshot?name=${encodeURIComponent(fn)}&t=${Date.now()}" style="width:100%;border-radius:6px;border:1px solid var(--border);" />
    `;
    grid.appendChild(c);
  });
}

let _pendingUploadRel = "";
function triggerUploadAi(relPath) {
  _pendingUploadRel = relPath;
  const picker = document.getElementById("aiFilePicker");
  picker.value = "";
  picker.click();
}

async function onAiFilePicked(ev) {
  const file = ev.target.files && ev.target.files[0];
  if (!file || !_pendingUploadRel) return;
  document.getElementById("uploadMsg").textContent = `⏳ 正在为 ${_pendingUploadRel} 自动泛洪抠底与像素对齐...`;
  const buf = await file.arrayBuffer();
  const r = await fetch("/api/upload_ai_sprite?target=" + encodeURIComponent(_pendingUploadRel), {
    method: "POST",
    headers: { "Content-Type": "application/octet-stream" },
    body: buf
  });
  const d = await r.json();
  document.getElementById("uploadMsg").textContent = d.ok
    ? `✅ 已自动抠底换皮：${_pendingUploadRel}（游戏内按 F9 即刻热刷新！）`
    : (`❌ 上传失败：${d.error}`);
  await loadArt();
}

async function revertSprite(relPath) {
  const r = await fetch("/api/revert_sprite?target=" + encodeURIComponent(relPath), { method: "POST" });
  const d = await r.json();
  if (d.ok) {
    document.getElementById("uploadMsg").textContent = `↩️ 已恢复默认占位图：${relPath}`;
    await loadArt();
  }
}

async function loadArt() {
  const r = await fetch("/api/art_status");
  const d = await r.json();
  document.getElementById("statsBadge").textContent =
    `精灵人工覆盖 ${d.human_sprites}/${d.total_sprites} · 音频人工覆盖 ${d.human_audio}/${d.total_audio}`;
  const grid = document.getElementById("artGrid");
  grid.innerHTML = "";
  d.sprites.forEach(sp => {
    const card = document.createElement("div");
    card.className = "card " + (sp.source === "human_override" ? "human" : "") + (sp.status === "warn" ? " warn" : "");
    const tagCls = sp.source === "human_override" ? "human" : "ai";
    const tagTxt = sp.source === "human_override" ? "人工已替换" : "AI占位图";
    const safeRel = sp.rel_path.replace(/'/g, "\\'");
    card.innerHTML = `
      <div class="thumb-wrap">
        <img class="thumb" src="/api/sprite?rel=${encodeURIComponent(sp.rel_path)}&t=${Date.now()}" />
        <div>
          <div style="font-weight:bold;font-size:14px;">${sp.name}</div>
          <div style="font-size:12px;color:var(--muted);">${sp.rel_path}</div>
          <div style="font-size:12px;color:var(--gold);">规格: ${sp.expected_w}×${sp.expected_h}</div>
        </div>
      </div>
      <div style="margin-bottom:8px;">
        <span class="tag ${tagCls}">${tagTxt}</span>
        ${sp.status !== "ok" ? `<span class="tag warn">${sp.message}</span>` : `<span style="font-size:12px;color:var(--muted);">${sp.message}</span>`}
      </div>
      <div style="display:flex;gap:6px;flex-wrap:wrap;">
        <button class="btn sec" style="font-size:12px;padding:5px 10px;" onclick="triggerUploadAi('${safeRel}')">✨ 上传AI大图自动抠底换皮</button>
        ${sp.source === "human_override" ? `<button class="btn sec" style="font-size:12px;padding:5px 8px;color:var(--warn);" onclick="revertSprite('${safeRel}')">↩️ 恢复默认</button>` : ""}
      </div>`;
    grid.appendChild(card);
  });
}

async function loadJsonFile() {
  const f = sel.value;
  const r = await fetch("/api/data?file=" + encodeURIComponent(f));
  document.getElementById("jsonEditor").value = await r.text();
  document.getElementById("saveMsg").textContent = "";
}

async function saveJsonFile() {
  const f = sel.value;
  const body = document.getElementById("jsonEditor").value;
  const r = await fetch("/api/data?file=" + encodeURIComponent(f), { method: "POST", body });
  const res = await r.json();
  document.getElementById("saveMsg").textContent = res.ok ? "✅ 保存成功！" : ("❌ " + res.error);
}

async function runSim() {
  const r = await fetch("/api/run_sim", { method: "POST" });
  const d = await r.json();
  document.getElementById("ecoReport").textContent = d.report;
}

async function runRefereeNow() {
  document.getElementById("refereeReportPre").textContent = "⏳ 正在实跑 GDScript 静态扫描、美术规格、经济模拟与 Godot 4.6 无头测试门禁...";
  const r = await fetch("/api/run_referee", { method: "POST" });
  const d = await r.json();
  document.getElementById("refereeReportPre").textContent = d.report || "";
}

async function loadEvolution() {
  const r = await fetch("/api/evolution");
  const d = await r.json();
  const cfg = d.config || {};
  document.getElementById("evoMaxRounds").value = cfg.max_rounds_per_turn || 4;
  document.getElementById("evoStatusMsg").textContent = cfg.enabled ? "🟢 自动裁判闭环：已开启" : "⏸️ 自动裁判闭环：已暂停";
  document.getElementById("refereeReportPre").textContent = d.referee_report || "点击上方「⚖️ 立即运行五维自动裁判巡检」生成最新客观门禁裁决报告。";
  const grid = document.getElementById("evoBacklogGrid");
  grid.innerHTML = "";
  (d.backlog.items || []).forEach(it => {
    const c = document.createElement("div");
    c.className = "card " + (it.status === "completed" ? "human" : "");
    c.innerHTML = `<div style="font-weight:bold;">${it.title}</div>
      <div style="font-size:12px;color:var(--muted);margin:6px 0;">${it.rationale}</div>
      <span class="tag ${it.status === 'completed' ? 'human' : 'ai'}">${it.status}</span>`;
    grid.appendChild(c);
  });
  document.getElementById("evoLogPre").textContent = d.log || "";
}

async function toggleEvolution() {
  await fetch("/api/evolution_toggle", { method: "POST", body: JSON.stringify({ toggle: true }) });
  loadEvolution();
}

async function saveMaxRounds() {
  const n = parseInt(document.getElementById("evoMaxRounds").value || "4", 10);
  await fetch("/api/evolution_toggle", { method: "POST", body: JSON.stringify({ max_rounds_per_turn: n }) });
  loadEvolution();
}

loadShots();
loadArt();
</script>
</body>
</html>
"""


def _is_sandbox_desktop() -> bool:
    if os.name != "nt":
        return False
    try:
        import ctypes
        h_desk = ctypes.windll.user32.GetThreadDesktop(ctypes.windll.kernel32.GetCurrentThreadId())
        buf = ctypes.create_unicode_buffer(256)
        needed = ctypes.c_ulong(0)
        ctypes.windll.user32.GetUserObjectInformationW(h_desk, 2, buf, 512, ctypes.byref(needed))
        return buf.value.lower() != "default"
    except Exception:
        return False


class StudioHandler(BaseHTTPRequestHandler):
    def log_message(self, format, *args):
        return

    def _send(self, code: int, body: bytes, ctype: str = "application/json; charset=utf-8"):
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)
        qs = urllib.parse.parse_qs(parsed.query)
        if parsed.path == "/":
            self._send(200, HTML_PAGE.encode("utf-8"), "text/html; charset=utf-8")
        elif parsed.path == "/api/screenshots":
            files = sorted([p.name for p in SCREENSHOTS_DIR.glob("*.png")]) if SCREENSHOTS_DIR.exists() else []
            self._send(200, json.dumps({"files": files}, ensure_ascii=False).encode("utf-8"))
        elif parsed.path == "/api/screenshot":
            fn = Path(qs.get("name", [""])[0]).name
            target = SCREENSHOTS_DIR / fn
            if fn and target.exists():
                self._send(200, target.read_bytes(), "image/png")
            else:
                self._send(404, b"not found", "text/plain")
        elif parsed.path == "/api/art_status":
            res = art_pipeline.check_status()
            self._send(200, json.dumps(res, ensure_ascii=False).encode("utf-8"))
        elif parsed.path == "/api/sprite":
            rel = qs.get("rel", [""])[0]
            safe_rel = Path(rel)
            if safe_rel.is_absolute() or ".." in safe_rel.parts:
                self._send(400, b"bad path", "text/plain")
                return
            ext_p = SPRITES_DROPIN / safe_rel
            res_p = SPRITES_RES / safe_rel
            target = ext_p if ext_p.exists() else res_p
            if target.exists():
                self._send(200, target.read_bytes(), "image/png")
            else:
                self._send(404, b"not found", "text/plain")
        elif parsed.path == "/api/data":
            fn = qs.get("file", [""])[0]
            if fn not in EDITABLE_FILES:
                self._send(403, b"forbidden", "text/plain")
                return
            self._send(200, (DATA_DIR / fn).read_bytes(), "application/json; charset=utf-8")
        elif parsed.path == "/api/evolution":
            cfg = json.loads(EVOLVE_CFG.read_text(encoding="utf-8")) if EVOLVE_CFG.exists() else {}
            bl = json.loads(BACKLOG_FILE.read_text(encoding="utf-8")) if BACKLOG_FILE.exists() else {"items": []}
            lg = EVOLVE_LOG.read_text(encoding="utf-8") if EVOLVE_LOG.exists() else ""
            ref_md_p = ROOT / "reports" / "referee_latest_report.md"
            ref_md = ref_md_p.read_text(encoding="utf-8") if ref_md_p.exists() else ""
            self._send(200, json.dumps({"config": cfg, "backlog": bl, "log": lg, "referee_report": ref_md}, ensure_ascii=False).encode("utf-8"))
        else:
            self._send(404, b"not found", "text/plain")

    def do_POST(self):
        parsed = urllib.parse.urlparse(self.path)
        qs = urllib.parse.parse_qs(parsed.query)
        length = int(self.headers.get("Content-Length", "0"))
        raw = self.rfile.read(length) if length > 0 else b""
        if parsed.path == "/api/launch_game":
            exe_cmd = str(ROOT / "开始游戏（双击直接玩）.exe")
            if _is_sandbox_desktop():
                self._send(200, json.dumps({
                    "ok": True,
                    "copy_cmd": exe_cmd,
                    "message": "📋 已复制启动路径！请按键盘 Win + R，粘贴 (Ctrl+V) 后按回车即可弹开游戏！"
                }, ensure_ascii=False).encode("utf-8"))
            else:
                subprocess.Popen(
                    [str(GODOT_GUI_EXE), "--path", str(ROOT / "game"), "--position", "128,48"],
                    cwd=str(ROOT / "game"),
                )
                self._send(200, json.dumps({"ok": True, "message": "✅ 游戏窗口已弹出！请看电脑屏幕中央或底部任务栏"}, ensure_ascii=False).encode("utf-8"))
        elif parsed.path == "/api/launch_editor":
            ed_cmd = str(ROOT / "启动Godot编辑器.bat")
            if _is_sandbox_desktop():
                self._send(200, json.dumps({
                    "ok": True,
                    "copy_cmd": ed_cmd,
                    "message": "📋 已复制编辑器路径！请按 Win + R 粘贴回车启动编辑器！"
                }, ensure_ascii=False).encode("utf-8"))
            else:
                subprocess.Popen(
                    [str(GODOT_GUI_EXE), "-e", "--path", str(ROOT / "game")],
                    cwd=str(ROOT / "game"),
                )
                self._send(200, json.dumps({"ok": True, "message": "✅ Godot 4.6 编辑器已启动！"}, ensure_ascii=False).encode("utf-8"))
        elif parsed.path == "/api/open_folder":
            if _is_sandbox_desktop():
                self._send(200, json.dumps({
                    "ok": True,
                    "copy_cmd": str(ROOT),
                    "message": "📋 已复制 D:\\星露谷物语 路径！请按 Win + R 粘贴回车直接打开文件夹！"
                }, ensure_ascii=False).encode("utf-8"))
            else:
                if os.name == "nt":
                    os.startfile(str(ROOT))
                self._send(200, json.dumps({"ok": True, "message": "✅ 已打开 D:\\星露谷物语 文件夹！"}, ensure_ascii=False).encode("utf-8"))
        elif parsed.path == "/api/data":
            fn = qs.get("file", [""])[0]
            if fn not in EDITABLE_FILES:
                self._send(403, json.dumps({"ok": False, "error": "禁止访问该文件"}).encode("utf-8"))
                return
            try:
                parsed_json = json.loads(raw.decode("utf-8"))
                (DATA_DIR / fn).write_text(json.dumps(parsed_json, ensure_ascii=False, indent=2), encoding="utf-8")
                self._send(200, json.dumps({"ok": True}).encode("utf-8"))
            except Exception as exc:
                self._send(400, json.dumps({"ok": False, "error": str(exc)}, ensure_ascii=False).encode("utf-8"))
        elif parsed.path == "/api/run_sim":
            balance_simulator.main()
            rpt = balance_simulator.REPORT_PATH.read_text(encoding="utf-8")
            self._send(200, json.dumps({"ok": True, "report": rpt}, ensure_ascii=False).encode("utf-8"))
        elif parsed.path == "/api/upload_ai_sprite":
            import tempfile
            target_rel = qs.get("target", [""])[0]
            safe_rel = Path(target_rel)
            if not target_rel or safe_rel.is_absolute() or ".." in safe_rel.parts:
                self._send(400, json.dumps({"ok": False, "error": "非法路径"}, ensure_ascii=False).encode("utf-8"))
                return
            try:
                with tempfile.NamedTemporaryFile(suffix=".png", delete=False) as tf:
                    tf.write(raw)
                    tmp_path = Path(tf.name)
                try:
                    dest = art_pipeline.import_ai_image(tmp_path, target_rel.replace("\\", "/"))
                finally:
                    if tmp_path.exists():
                        tmp_path.unlink()
                self._send(200, json.dumps({"ok": True, "dest": str(dest)}, ensure_ascii=False).encode("utf-8"))
            except Exception as exc:
                self._send(400, json.dumps({"ok": False, "error": str(exc)}, ensure_ascii=False).encode("utf-8"))
        elif parsed.path == "/api/revert_sprite":
            target_rel = qs.get("target", [""])[0]
            safe_rel = Path(target_rel)
            if not target_rel or safe_rel.is_absolute() or ".." in safe_rel.parts:
                self._send(400, json.dumps({"ok": False, "error": "非法路径"}, ensure_ascii=False).encode("utf-8"))
                return
            ext_p = SPRITES_DROPIN / safe_rel
            if ext_p.exists():
                ext_p.unlink()
            self._send(200, json.dumps({"ok": True}, ensure_ascii=False).encode("utf-8"))
        elif parsed.path == "/api/run_referee":
            import auto_referee
            st = auto_referee.run_referee_audit(include_godot=True)
            self._send(200, json.dumps({"ok": True, "state": st, "report": auto_referee.render_markdown(st)}, ensure_ascii=False).encode("utf-8"))
        elif parsed.path == "/api/evolution_toggle":
            cfg = json.loads(EVOLVE_CFG.read_text(encoding="utf-8")) if EVOLVE_CFG.exists() else {"enabled": True, "max_rounds_per_turn": 4}
            req_d = json.loads(raw.decode("utf-8")) if raw else {}
            if req_d.get("toggle"):
                cfg["enabled"] = not bool(cfg.get("enabled", True))
            if "max_rounds_per_turn" in req_d:
                cfg["max_rounds_per_turn"] = max(1, min(20, int(req_d["max_rounds_per_turn"])))
            EVOLVE_CFG.write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")
            self._send(200, json.dumps({"ok": True, "config": cfg}, ensure_ascii=False).encode("utf-8"))
        else:
            self._send(404, b"not found", "text/plain")


def self_test():
    import io
    import urllib.request
    from PIL import Image
    bouquet_path = SPRITES_DROPIN / "icons" / "bouquet.png"
    bouquet_bak = bouquet_path.read_bytes() if bouquet_path.exists() else None
    srv = ThreadingHTTPServer(("127.0.0.1", 0), StudioHandler)
    port = srv.server_address[1]
    t = threading.Thread(target=srv.serve_forever, daemon=True)
    t.start()
    try:
        for path in ["/", "/api/screenshots", "/api/art_status", "/api/data?file=crops.json", "/api/sprite?rel=characters/player_sheet.png", "/api/evolution"]:
            with urllib.request.urlopen(f"http://127.0.0.1:{port}{path}", timeout=5) as resp:
                assert resp.status == 200, f"HTTP {resp.status} for {path}"
        # Test AI image upload flood-matte & revert endpoints (non-destructive backup/restore)
        im = Image.new("RGBA", (128, 128), (255, 255, 255, 255))
        for yy in range(32, 96):
            for xx in range(32, 96):
                im.putpixel((xx, yy), (240, 120, 80, 255))
        buf = io.BytesIO()
        im.save(buf, format="PNG")
        req_up = urllib.request.Request(
            f"http://127.0.0.1:{port}/api/upload_ai_sprite?target=icons/bouquet.png",
            data=buf.getvalue(),
            method="POST",
            headers={"Content-Type": "application/octet-stream"},
        )
        with urllib.request.urlopen(req_up, timeout=5) as r_up:
            assert json.loads(r_up.read().decode("utf-8")).get("ok") is True
        req_rev = urllib.request.Request(
            f"http://127.0.0.1:{port}/api/revert_sprite?target=icons/bouquet.png",
            data=b"",
            method="POST",
        )
        with urllib.request.urlopen(req_rev, timeout=5) as r_rev:
            assert json.loads(r_rev.read().decode("utf-8")).get("ok") is True
        print(f"[PASS] content_studio.py HTTP & AI upload self-test passed on ephemeral port {port}")
    finally:
        if bouquet_bak is not None:
            bouquet_path.parent.mkdir(parents=True, exist_ok=True)
            bouquet_path.write_bytes(bouquet_bak)
        srv.shutdown()
        srv.server_close()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--port", type=int, default=8765)
    parser.add_argument("--self-test", action="store_true")
    args = parser.parse_args()
    if args.self_test:
        self_test()
        return
    srv = ThreadingHTTPServer(("127.0.0.1", args.port), StudioHandler)
    print(f"=======================================================")
    print(f"  星露物语：回响山谷 - 策划数据与人工美术热替换工作台")
    print(f"  浏览器打开: http://127.0.0.1:{args.port}")
    print(f"  按 Ctrl+C 停止工作台")
    print(f"=======================================================")
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        srv.server_close()


if __name__ == "__main__":
    main()
