#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
《星露物语：回响山谷》Windows 独立免安装发行包一键构建与完整性校验工具 (Standalone Release Packager & Verifier)
功能：
1) 将无黑框运行引擎、game/ 主工程（自动剔除编辑器大型临时缓存）、art_dropin/ 全套热替换美术与音效、双击启动器与试玩指南打包为独立免安装目录与 ZIP 压缩包；
2) 输出至 d:/星露谷物语/releases/星露物语_回响山谷_v5_Windows独立版.zip，解压即玩，支持 F9 零代码美术热替换；
3) 支持 `--check` 只读完整性门禁校验：验证 ZIP CRC 无损、核心启动器与指南及毕业体验档齐全、189+ 精灵与 18+ WAV 完备且零临时缓存文件泄漏。
"""
from __future__ import annotations

import argparse
import shutil
import sys
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
RELEASES_DIR = ROOT / "releases"
PKG_NAME = "星露物语_回响山谷_v5_Windows独立版"


def build_release() -> Path:
    RELEASES_DIR.mkdir(parents=True, exist_ok=True)
    stage_dir = RELEASES_DIR / PKG_NAME
    if stage_dir.exists():
        shutil.rmtree(stage_dir)
    stage_dir.mkdir(parents=True, exist_ok=True)

    # 1. Copy clean Godot runtime binary (GUI zero-console executable)
    rt_dir = stage_dir / "runtime"
    rt_dir.mkdir(parents=True, exist_ok=True)
    godot_gui = ROOT / "tools" / "godot" / "Godot_v4.6.1-stable_win64.exe"
    if not godot_gui.exists():
        raise FileNotFoundError(f"Missing Godot runtime: {godot_gui}")
    shutil.copy2(godot_gui, rt_dir / "EchoesOfEmbervale_Engine.exe")

    # 2. Copy game/ (keep .godot/imported so textures/fonts work immediately without re-import, skip editor/shader_cache bloat)
    def _ignore_game(dirpath: str, names: list[str]) -> set[str]:
        p = Path(dirpath)
        ignored: set[str] = set()
        if p.name == ".godot":
            for n in names:
                if n in ("editor", "shader_cache", "uid_cache.bin.tmp"):
                    ignored.add(n)
        for n in names:
            if n.endswith(".tmp") or n in ("__pycache__", "shader_cache"):
                ignored.add(n)
        return ignored

    shutil.copytree(ROOT / "game", stage_dir / "game", ignore=_ignore_game)

    # 3. Copy art_dropin/ (all 16-bit Stardew sprites & studio acoustic WAVs + artist guide)
    def _ignore_dropin(_dirpath: str, names: list[str]) -> set[str]:
        return {n for n in names if n.endswith(".tmp") or n == "__pycache__"}

    shutil.copytree(ROOT / "art_dropin", stage_dir / "art_dropin", ignore=_ignore_dropin)

    # 4. Copy user guide & write 1-click zero-console VBScript + BAT launchers
    guide_src = ROOT / "试玩与操作指南.md"
    if not guide_src.exists():
        raise FileNotFoundError(f"Missing player guide: {guide_src}")
    shutil.copy2(guide_src, stage_dir / "试玩与操作指南.md")

    vbs_launcher = (
        'Set fso = CreateObject("Scripting.FileSystemObject")\r\n'
        'base = fso.GetParentFolderName(WScript.ScriptFullName)\r\n'
        'Set sh = CreateObject("WScript.Shell")\r\n'
        'sh.CurrentDirectory = base\r\n'
        'cmd = Chr(34) & base & "\\runtime\\EchoesOfEmbervale_Engine.exe" & Chr(34) & " --path " & Chr(34) & base & "\\game" & Chr(34)\r\n'
        'sh.Run cmd, 1, False\r\n'
    )
    (stage_dir / "双击开始游戏（无黑框畅玩）.vbs").write_text(vbs_launcher, encoding="utf-8")

    bat_launcher = (
        "@echo off\r\n"
        "chcp 65001 >nul\r\n"
        "cd /d \"%~dp0\"\r\n"
        "start \"\" \"%~dp0runtime\\EchoesOfEmbervale_Engine.exe\" --path \"%~dp0game\"\r\n"
    )
    (stage_dir / "启动游戏.bat").write_text(bat_launcher, encoding="utf-8")

    # 5. Compress into portable .zip
    zip_path = RELEASES_DIR / f"{PKG_NAME}.zip"
    if zip_path.exists():
        zip_path.unlink()
    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as zf:
        for file_p in sorted(stage_dir.rglob("*")):
            if file_p.is_file():
                zf.write(file_p, file_p.relative_to(RELEASES_DIR))

    size_mb = zip_path.stat().st_size / (1024 * 1024)
    print(f"[OK] Windows 独立免安装发行包构建完成: {zip_path} ({size_mb:.1f} MB)")
    return zip_path


def verify_release(zip_path: Path | None = None) -> int:
    zp = zip_path or (RELEASES_DIR / f"{PKG_NAME}.zip")
    if not zp.exists():
        print(f"[FAIL] 独立发行包不存在: {zp}")
        return 1
    size_mb = zp.stat().st_size / (1024 * 1024)
    if size_mb < 20.0:
        print(f"[FAIL] 独立发行包体积异常过小 ({size_mb:.2f} MB): {zp}")
        return 1

    with zipfile.ZipFile(zp, "r") as zf:
        bad_member = zf.testzip()
        if bad_member is not None:
            print(f"[FAIL] ZIP CRC 校验损坏条目: {bad_member}")
            return 1
        names = [n.replace("\\", "/") for n in zf.namelist()]

    name_set = set(names)
    required_entries = [
        f"{PKG_NAME}/runtime/EchoesOfEmbervale_Engine.exe",
        f"{PKG_NAME}/双击开始游戏（无黑框畅玩）.vbs",
        f"{PKG_NAME}/启动游戏.bat",
        f"{PKG_NAME}/试玩与操作指南.md",
        f"{PKG_NAME}/game/project.godot",
        f"{PKG_NAME}/game/export_presets.cfg",
        f"{PKG_NAME}/game/saves/slot_2.json",
        f"{PKG_NAME}/game/assets/fonts/embervale_cjk_subset.ttf",
        f"{PKG_NAME}/game/assets/fonts/embervale_emoji_subset.ttf",
    ]
    missing = [req for req in required_entries if req not in name_set]
    if missing:
        print(f"[FAIL] ZIP 缺失核心交付条目: {missing}")
        return 1

    sprite_pngs = [
        n for n in names
        if n.startswith(f"{PKG_NAME}/art_dropin/sprites/") and n.lower().endswith(".png")
    ]
    audio_wavs = [
        n for n in names
        if n.startswith(f"{PKG_NAME}/art_dropin/audio/") and n.lower().endswith(".wav")
    ]
    if len(sprite_pngs) < 189:
        print(f"[FAIL] ZIP 内 art_dropin/sprites PNG 数量不足: {len(sprite_pngs)} < 189")
        return 1
    if len(audio_wavs) < 18:
        print(f"[FAIL] ZIP 内 art_dropin/audio WAV 数量不足: {len(audio_wavs)} < 18")
        return 1

    leaked = [
        n for n in names
        if n.endswith(".tmp") or "/__pycache__/" in n or "/shader_cache/" in n
    ]
    if leaked:
        print(f"[FAIL] ZIP 存在临时缓存文件泄漏: {leaked[:5]}")
        return 1

    print(
        f"[PASS] 独立发行包校验通过: {zp.name} ({size_mb:.1f} MB) | "
        f"CRC=OK | 精灵={len(sprite_pngs)} | 原声WAV={len(audio_wavs)} | 试玩指南=OK | 0 临时缓存泄漏"
    )
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(description="《星露物语：回响山谷》Windows 独立免安装发行包构建与校验工具")
    parser.add_argument("--check", action="store_true", help="只读校验独立发行包 ZIP 完整性与无泄漏门禁")
    args = parser.parse_args()
    if args.check:
        return verify_release()
    zp = build_release()
    return verify_release(zp)


if __name__ == "__main__":
    sys.exit(main())
