#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
《星露物语：回响山谷》工作室级暖系原声合成器 (Studio Acoustic Drop-in Audio Generator)
将 14 首高保真立体声 16-bit 44100Hz 原声级音效与田园木吉他竖琴循环背景乐写入 art_dropin/audio/，
通过 AudioManager 的双轨优先机制零代码热替换生效（游戏内按 F9 即刻热重载）。
"""
from __future__ import annotations

import math
import random
import struct
import wave
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DROPIN_AUDIO = ROOT / "art_dropin" / "audio"
SAMPLE_RATE = 44100


def write_stereo_wav(filename: str, left: list[float], right: list[float]) -> Path:
    DROPIN_AUDIO.mkdir(parents=True, exist_ok=True)
    path = DROPIN_AUDIO / filename
    n = min(len(left), len(right))
    frames = bytearray(n * 4)
    offset = 0
    for i in range(n):
        lv = max(-0.96, min(0.96, left[i]))
        rv = max(-0.96, min(0.96, right[i]))
        struct.pack_into("<hh", frames, offset, int(lv * 32767), int(rv * 32767))
        offset += 4
    with wave.open(str(path), "wb") as wf:
        wf.setnchannels(2)
        wf.setsampwidth(2)
        wf.setframerate(SAMPLE_RATE)
        wf.writeframes(bytes(frames))
    return path


def karplus_pluck(freq: float, dur: float, amp: float = 0.45, brightness: float = 0.496, seed: int = 1) -> list[float]:
    """Karplus-Strong 物理建模原声木吉他/竖琴拨弦音色"""
    rng = random.Random(seed + int(freq * 10))
    n = int(dur * SAMPLE_RATE)
    delay = max(4, int(round(SAMPLE_RATE / max(35.0, freq))))
    buf = [rng.uniform(-1.0, 1.0) for _ in range(delay)]
    # Smooth initial pick excitation for warm nylon/acoustic tone
    for i in range(1, delay):
        buf[i] = buf[i] * 0.65 + buf[i - 1] * 0.35
    out = [0.0] * n
    idx = 0
    for i in range(n):
        cur = buf[idx]
        nxt = buf[(idx + 1) % delay]
        buf[idx] = (cur + nxt) * brightness
        idx = (idx + 1) % delay
        # Soft body resonance fundamental boost
        body = math.sin(2.0 * math.pi * freq * (i / SAMPLE_RATE)) * math.exp(-(i / SAMPLE_RATE) * 5.2) * 0.25
        fade = 1.0 if i < n - 800 else max(0.0, (n - i) / 800.0)
        out[i] = (cur * 0.82 + body) * amp * fade
    return out


def marimba_hit(freq: float, dur: float, amp: float = 0.42) -> list[float]:
    """温暖木琴/马林巴泛音（1:4:10 泛音比 + 柔和木槌包络）"""
    n = int(dur * SAMPLE_RATE)
    out = [0.0] * n
    for i in range(n):
        t = i / SAMPLE_RATE
        atk = min(1.0, i / max(1.0, 0.004 * SAMPLE_RATE))
        env1 = atk * math.exp(-t * 11.0)
        env4 = atk * math.exp(-t * 32.0)
        val = math.sin(2.0 * math.pi * freq * t) * env1 + 0.34 * math.sin(2.0 * math.pi * (freq * 3.98) * t) * env4
        out[i] = val * amp
    return out


def mix_into(dst_l: list[float], dst_r: list[float], mono: list[float], start_sec: float = 0.0, pan: float = 0.0) -> None:
    """pan in [-1.0, 1.0]"""
    start_i = int(start_sec * SAMPLE_RATE)
    gl = math.cos((pan + 1.0) * math.pi * 0.25)
    gr = math.sin((pan + 1.0) * math.pi * 0.25)
    limit = min(len(dst_l), len(dst_r))
    for i, s in enumerate(mono):
        pos = start_i + i
        if 0 <= pos < limit:
            dst_l[pos] += s * gl
            dst_r[pos] += s * gr


def apply_warm_room(left: list[float], right: list[float], wet: float = 0.16) -> tuple[list[float], list[float]]:
    """轻柔木屋早反射空间感"""
    n = len(left)
    out_l = left[:]
    out_r = right[:]
    taps = [(int(0.023 * SAMPLE_RATE), 0.55), (int(0.041 * SAMPLE_RATE), 0.35), (int(0.067 * SAMPLE_RATE), 0.20)]
    for d, g in taps:
        for i in range(d, n):
            out_l[i] += right[i - d] * g * wet
            out_r[i] += left[i - d] * g * wet
    return out_l, out_r


def gen_till() -> tuple[list[float], list[float]]:
    n = int(0.18 * SAMPLE_RATE)
    rng = random.Random(101)
    l, r = [0.0] * n, [0.0] * n
    lp = 0.0
    for i in range(n):
        t = i / SAMPLE_RATE
        env = min(1.0, i / 180.0) * math.exp(-t * 15.0)
        lp = lp * 0.78 + rng.uniform(-1.0, 1.0) * 0.22
        thump = math.sin(2.0 * math.pi * (155.0 - 78.0 * (i / n)) * t) * math.exp(-t * 20.0)
        gravel = math.sin(2.0 * math.pi * 420.0 * t + lp * 4.0) * 0.18 * env
        s = (thump * 0.58 + lp * 0.65 * env + gravel) * 0.72
        l[i] = s * 1.02
        r[i] = s * 0.96
    return apply_warm_room(l, r, 0.10)


def gen_water() -> tuple[list[float], list[float]]:
    n = int(0.32 * SAMPLE_RATE)
    rng = random.Random(202)
    l, r = [0.0] * n, [0.0] * n
    lp = 0.0
    for i in range(n):
        t = i / SAMPLE_RATE
        env = min(1.0, i / 400.0) * math.exp(-t * 6.8)
        lp = lp * 0.86 + rng.uniform(-1.0, 1.0) * 0.14
        drop1 = math.sin(2.0 * math.pi * (520.0 + 260.0 * t) * t) * math.exp(-abs(t - 0.06) * 45.0) * 0.26
        drop2 = math.sin(2.0 * math.pi * (680.0 + 310.0 * t) * t) * math.exp(-abs(t - 0.15) * 42.0) * 0.24
        l[i] = (lp * 1.35 * env + drop1 + drop2 * 0.7) * 0.68
        r[i] = (lp * 1.30 * env + drop1 * 0.7 + drop2) * 0.68
    return apply_warm_room(l, r, 0.18)


def gen_plant() -> tuple[list[float], list[float]]:
    n = int(0.16 * SAMPLE_RATE)
    l, r = [0.0] * n, [0.0] * n
    mix_into(l, r, marimba_hit(392.00, 0.14, 0.36), 0.0, -0.15)
    mix_into(l, r, marimba_hit(587.33, 0.12, 0.32), 0.035, 0.20)
    return apply_warm_room(l, r, 0.14)


def gen_harvest() -> tuple[list[float], list[float]]:
    n = int(0.34 * SAMPLE_RATE)
    l, r = [0.0] * n, [0.0] * n
    # Crisp Stardew pop + warm major triad harp pluck
    for idx, (f, onset, pan) in enumerate([(523.25, 0.0, -0.25), (659.25, 0.045, 0.0), (783.99, 0.09, 0.25), (1046.50, 0.135, 0.1)]):
        mix_into(l, r, karplus_pluck(f, 0.20, 0.34, 0.497, seed=10 + idx), onset, pan)
        mix_into(l, r, marimba_hit(f, 0.14, 0.20), onset, -pan)
    return apply_warm_room(l, r, 0.20)


def gen_chop() -> tuple[list[float], list[float]]:
    n = int(0.18 * SAMPLE_RATE)
    rng = random.Random(303)
    l, r = [0.0] * n, [0.0] * n
    for i in range(n):
        t = i / SAMPLE_RATE
        crack = rng.uniform(-1.0, 1.0) * math.exp(-t * 45.0) * 0.45
        wood = (math.sin(2.0 * math.pi * 142.0 * t) + 0.5 * math.sin(2.0 * math.pi * 295.0 * t)) * math.exp(-t * 22.0) * 0.45
        l[i] = crack + wood * 1.04
        r[i] = crack * 0.92 + wood * 0.96
    return apply_warm_room(l, r, 0.12)


def gen_mine_hit() -> tuple[list[float], list[float]]:
    n = int(0.22 * SAMPLE_RATE)
    l, r = [0.0] * n, [0.0] * n
    for i in range(n):
        t = i / SAMPLE_RATE
        atk = min(1.0, i / 60.0)
        bell = (
            math.sin(2.0 * math.pi * 1140.0 * t) * math.exp(-t * 18.0) * 0.34
            + math.sin(2.0 * math.pi * 1790.0 * t) * math.exp(-t * 26.0) * 0.24
            + math.sin(2.0 * math.pi * 2640.0 * t) * math.exp(-t * 38.0) * 0.16
        ) * atk
        l[i] = bell * 1.03
        r[i] = bell * 0.97
    return apply_warm_room(l, r, 0.18)


def gen_sword_swing() -> tuple[list[float], list[float]]:
    n = int(0.16 * SAMPLE_RATE)
    rng = random.Random(404)
    l, r = [0.0] * n, [0.0] * n
    bp = 0.0
    for i in range(n):
        t = i / SAMPLE_RATE
        env = math.sin(math.pi * min(1.0, i / n)) ** 1.4
        bp = bp * 0.72 + rng.uniform(-1.0, 1.0) * 0.28
        whoosh = math.sin(2.0 * math.pi * (560.0 - 340.0 * (i / n)) * t) * 0.24
        s = (bp * 0.78 + whoosh) * env * 0.65
        pan_t = i / n
        l[i] = s * (1.1 - 0.4 * pan_t)
        r[i] = s * (0.7 + 0.4 * pan_t)
    return apply_warm_room(l, r, 0.10)


def gen_monster_hit() -> tuple[list[float], list[float]]:
    n = int(0.16 * SAMPLE_RATE)
    l, r = [0.0] * n, [0.0] * n
    for i in range(n):
        t = i / SAMPLE_RATE
        f = 260.0 - 145.0 * (i / n)
        boing = math.sin(2.0 * math.pi * f * t + 1.6 * math.sin(2.0 * math.pi * 48.0 * t)) * math.exp(-t * 17.0) * 0.56
        l[i] = boing
        r[i] = boing * 0.95
    return apply_warm_room(l, r, 0.12)


def gen_coin() -> tuple[list[float], list[float]]:
    n = int(0.28 * SAMPLE_RATE)
    l, r = [0.0] * n, [0.0] * n
    for onset, f, pan in [(0.0, 987.77, -0.18), (0.062, 1318.51, 0.18)]:
        start_i = int(onset * SAMPLE_RATE)
        for j in range(n - start_i):
            t = j / SAMPLE_RATE
            s = (math.sin(2.0 * math.pi * f * t) + 0.32 * math.sin(2.0 * math.pi * f * 2.0 * t)) * math.exp(-t * 14.0) * 0.34
            l[start_i + j] += s * (0.9 - pan * 0.3)
            r[start_i + j] += s * (0.9 + pan * 0.3)
    return apply_warm_room(l, r, 0.18)


def gen_fish_cast() -> tuple[list[float], list[float]]:
    n = int(0.28 * SAMPLE_RATE)
    rng = random.Random(505)
    l, r = [0.0] * n, [0.0] * n
    lp = 0.0
    for i in range(n):
        t = i / SAMPLE_RATE
        if t < 0.13:
            whip = math.sin(2.0 * math.pi * (780.0 - 3800.0 * t) * t) * math.sin(math.pi * (t / 0.13)) * 0.36
            l[i] = whip
            r[i] = whip * 0.9
        else:
            dt = t - 0.13
            lp = lp * 0.82 + rng.uniform(-1.0, 1.0) * 0.18
            plop = math.sin(2.0 * math.pi * (320.0 + 420.0 * dt) * dt) * math.exp(-dt * 26.0) * 0.38
            sp = (lp * math.exp(-dt * 14.0) * 0.85 + plop)
            l[i] = sp * 0.95
            r[i] = sp * 1.05
    return apply_warm_room(l, r, 0.18)


def gen_fish_catch() -> tuple[list[float], list[float]]:
    n = int(0.52 * SAMPLE_RATE)
    l, r = [0.0] * n, [0.0] * n
    notes = [(523.25, 0.0, -0.3), (659.25, 0.065, -0.1), (783.99, 0.13, 0.1), (1046.50, 0.195, 0.3), (1318.51, 0.26, 0.0)]
    for idx, (f, onset, pan) in enumerate(notes):
        mix_into(l, r, karplus_pluck(f, 0.25, 0.35, 0.498, seed=40 + idx), onset, pan)
        mix_into(l, r, marimba_hit(f * 0.5, 0.22, 0.22), onset, -pan * 0.5)
    return apply_warm_room(l, r, 0.22)


def gen_ui_click() -> tuple[list[float], list[float]]:
    n = int(0.065 * SAMPLE_RATE)
    l, r = [0.0] * n, [0.0] * n
    mix_into(l, r, marimba_hit(660.0, 0.06, 0.32), 0.0, 0.0)
    return l, r


def gen_rooster_morning() -> tuple[list[float], list[float]]:
    n = int(0.75 * SAMPLE_RATE)
    l, r = [0.0] * n, [0.0] * n
    # Warm pastoral G-major acoustic guitar & Celtic harp morning chord arpeggio
    chord = [
        (392.00, 0.00, -0.35),
        (493.88, 0.07, -0.15),
        (587.33, 0.14, 0.05),
        (783.99, 0.21, 0.25),
        (987.77, 0.29, 0.35),
        (1174.66, 0.37, 0.0),
    ]
    for idx, (f, onset, pan) in enumerate(chord):
        mix_into(l, r, karplus_pluck(f, 0.38, 0.33, 0.498, seed=80 + idx), onset, pan)
    return apply_warm_room(l, r, 0.25)


def gen_valley_breeze_loop(dur: float = 8.0) -> tuple[list[float], list[float]]:
    """8.0秒无缝立体声循环：星露谷风温暖木吉他分解和弦 + 凯尔特竖琴泛音 + 柔和山谷微风 + 远景清脆鸟鸣"""
    n = int(dur * SAMPLE_RATE)
    rng = random.Random(777)
    l = [0.0] * n
    r = [0.0] * n

    # 1) Seamless stereo filtered gentle valley breeze
    raw_l = [rng.uniform(-1.0, 1.0) for _ in range(n)]
    raw_r = [rng.uniform(-1.0, 1.0) for _ in range(n)]
    lp_l, lp_r = 0.0, 0.0
    for i in range(n * 2):
        idx = i % n
        lp_l = lp_l * 0.988 + raw_l[idx] * 0.012
        lp_r = lp_r * 0.988 + raw_r[idx] * 0.012
        if i >= n:
            swell = 0.72 + 0.28 * math.sin(2.0 * math.pi * 2.0 * idx / n)
            l[idx] += lp_l * 0.11 * swell
            r[idx] += lp_r * 0.11 * swell

    # 2) Warm Cmaj7 -> Fmaj7 -> G6 -> Cadd9 pastoral acoustic guitar & harp progression (16 eighth-notes over 8.0s)
    # Seamless wraparound tail so t=8.0 -> t=0.0 has zero click!
    progression = [
        # Bar 1: Cmaj7 (C3, G3, B3, E4, G4, E4, B3, G3)
        (0.0, 130.81, -0.25, 0.22), (0.5, 196.00, 0.15, 0.18), (1.0, 246.94, -0.20, 0.18), (1.5, 329.63, 0.28, 0.21),
        (2.0, 392.00, -0.12, 0.20), (2.5, 329.63, 0.22, 0.17), (3.0, 246.94, -0.18, 0.17), (3.5, 196.00, 0.12, 0.16),
        # Bar 2: Fmaj7 -> G6 (F3, C4, E4, A4, G3, D4, B4, G4)
        (4.0, 174.61, -0.28, 0.22), (4.5, 261.63, 0.16, 0.18), (5.0, 329.63, -0.15, 0.19), (5.5, 440.00, 0.30, 0.21),
        (6.0, 196.00, -0.22, 0.21), (6.5, 293.66, 0.18, 0.18), (7.0, 493.88, 0.26, 0.19), (7.5, 392.00, -0.14, 0.18),
    ]
    for idx_n, (onset, freq, pan, amp) in enumerate(progression):
        pluck = karplus_pluck(freq, 1.85, amp=amp, brightness=0.4975, seed=500 + idx_n)
        start_i = int(onset * SAMPLE_RATE)
        gl = math.cos((pan + 1.0) * math.pi * 0.25)
        gr = math.sin((pan + 1.0) * math.pi * 0.25)
        for j, s in enumerate(pluck):
            pos = (start_i + j) % n
            l[pos] += s * gl
            r[pos] += s * gr

    # 3) Delicate high harp harmonics & soft distant meadow bird twitters
    bird_events = [(1.82, 2350.0, 0.35), (1.96, 2680.0, 0.35), (5.75, 2180.0, -0.35), (5.90, 2520.0, -0.35)]
    for onset, bf, pan in bird_events:
        start_i = int(onset * SAMPLE_RATE)
        bn = int(0.09 * SAMPLE_RATE)
        gl = math.cos((pan + 1.0) * math.pi * 0.25)
        gr = math.sin((pan + 1.0) * math.pi * 0.25)
        for j in range(bn):
            t = j / SAMPLE_RATE
            env = math.sin(math.pi * (j / bn)) ** 1.6
            chirp = math.sin(2.0 * math.pi * (bf + 420.0 * math.sin(t * 55.0)) * t) * env * 0.045
            pos = (start_i + j) % n
            l[pos] += chirp * gl
            r[pos] += chirp * gr

    return apply_warm_room(l, r, 0.22)


def gen_bgm_summer_loop(dur: float = 8.0) -> tuple[list[float], list[float]]:
    """8.0秒无缝立体声循环：盛夏明亮 D 大调尤克里里轻快拨弦 + 马林巴清脆高音"""
    n = int(dur * SAMPLE_RATE)
    l, r = [0.0] * n, [0.0] * n
    # Bright D -> A -> Bm7 -> G summer progression
    prog = [
        (0.0, 293.66, -0.25), (0.25, 369.99, 0.18), (0.5, 440.00, -0.15), (0.75, 587.33, 0.25),
        (1.0, 440.00, -0.10), (1.5, 369.99, 0.20),
        (2.0, 220.00, -0.28), (2.25, 329.63, 0.15), (2.5, 440.00, -0.18), (2.75, 554.37, 0.26),
        (3.0, 440.00, -0.12), (3.5, 329.63, 0.18),
        (4.0, 246.94, -0.25), (4.25, 369.99, 0.18), (4.5, 493.88, -0.15), (4.75, 587.33, 0.28),
        (5.0, 493.88, -0.14), (5.5, 369.99, 0.20),
        (6.0, 196.00, -0.26), (6.25, 293.66, 0.16), (6.5, 392.00, -0.16), (6.75, 587.33, 0.28),
        (7.0, 493.88, 0.22), (7.5, 440.00, -0.15),
    ]
    for idx_n, (onset, freq, pan) in enumerate(prog):
        pluck = karplus_pluck(freq, 1.35, amp=0.20, brightness=0.498, seed=610 + idx_n)
        m_hit = marimba_hit(freq * 2.0 if idx_n % 4 == 3 else freq, 0.22, amp=0.09)
        start_i = int(onset * SAMPLE_RATE)
        gl = math.cos((pan + 1.0) * math.pi * 0.25)
        gr = math.sin((pan + 1.0) * math.pi * 0.25)
        for j, s in enumerate(pluck):
            pos = (start_i + j) % n
            ms = m_hit[j] if j < len(m_hit) else 0.0
            l[pos] += (s + ms) * gl
            r[pos] += (s + ms) * gr
    return apply_warm_room(l, r, 0.20)


def gen_bgm_autumn_loop(dur: float = 8.0) -> tuple[list[float], list[float]]:
    """8.0秒无缝立体声循环：金秋温润 Am9 -> Fmaj7 -> C -> E7sus4 指弹木吉他"""
    n = int(dur * SAMPLE_RATE)
    l, r = [0.0] * n, [0.0] * n
    prog = [
        (0.0, 110.00, -0.22, 0.24), (0.5, 220.00, 0.14, 0.19), (1.0, 261.63, -0.18, 0.19), (1.5, 329.63, 0.25, 0.20),
        (2.0, 493.88, -0.12, 0.18), (2.5, 329.63, 0.20, 0.17), (3.0, 261.63, -0.16, 0.17), (3.5, 220.00, 0.12, 0.16),
        (4.0, 174.61, -0.26, 0.23), (4.5, 261.63, 0.15, 0.18), (5.0, 329.63, -0.15, 0.19), (5.5, 392.00, 0.26, 0.20),
        (6.0, 164.81, -0.22, 0.22), (6.5, 246.94, 0.16, 0.18), (7.0, 329.63, 0.24, 0.19), (7.5, 293.66, -0.14, 0.18),
    ]
    for idx_n, (onset, freq, pan, amp) in enumerate(prog):
        pluck = karplus_pluck(freq, 2.0, amp=amp, brightness=0.4965, seed=710 + idx_n)
        start_i = int(onset * SAMPLE_RATE)
        gl = math.cos((pan + 1.0) * math.pi * 0.25)
        gr = math.sin((pan + 1.0) * math.pi * 0.25)
        for j, s in enumerate(pluck):
            pos = (start_i + j) % n
            l[pos] += s * gl
            r[pos] += s * gr
    return apply_warm_room(l, r, 0.26)


def gen_bgm_winter_loop(dur: float = 8.0) -> tuple[list[float], list[float]]:
    """8.0秒无缝立体声循环：冬日星雪晶莹钢片琴/八音盒泛音 + 柔和凯尔特竖琴"""
    n = int(dur * SAMPLE_RATE)
    l, r = [0.0] * n, [0.0] * n
    notes = [
        (0.0, 659.25, -0.25), (0.5, 783.99, 0.20), (1.0, 987.77, -0.15), (1.5, 1174.66, 0.28),
        (2.0, 1046.50, -0.20), (2.5, 783.99, 0.18), (3.0, 659.25, -0.18), (3.5, 587.33, 0.15),
        (4.0, 523.25, -0.26), (4.5, 659.25, 0.20), (5.0, 783.99, -0.15), (5.5, 1046.50, 0.28),
        (6.0, 987.77, -0.20), (6.5, 783.99, 0.22), (7.0, 659.25, -0.14), (7.5, 587.33, 0.18),
    ]
    for idx_n, (onset, freq, pan) in enumerate(notes):
        start_i = int(onset * SAMPLE_RATE)
        cn = int(1.5 * SAMPLE_RATE)
        gl = math.cos((pan + 1.0) * math.pi * 0.25)
        gr = math.sin((pan + 1.0) * math.pi * 0.25)
        harp = karplus_pluck(freq * 0.5, 1.5, amp=0.14, brightness=0.497, seed=810 + idx_n)
        for j in range(cn):
            t = j / SAMPLE_RATE
            atk = min(1.0, j / 120.0)
            celesta = (math.sin(2.0 * math.pi * freq * t) * math.exp(-t * 3.8) + 0.28 * math.sin(2.0 * math.pi * freq * 3.0 * t) * math.exp(-t * 9.5)) * atk * 0.14
            pos = (start_i + j) % n
            s = celesta + harp[j]
            l[pos] += s * gl
            r[pos] += s * gr
    return apply_warm_room(l, r, 0.30)


def gen_bgm_island_loop(dur: float = 8.0) -> tuple[list[float], list[float]]:
    """8.0秒无缝立体声循环：星露珊瑚群岛加勒比阳光马林巴钢鼓 + 尼龙吉他 + 轻柔海浪"""
    n = int(dur * SAMPLE_RATE)
    rng = random.Random(909)
    l, r = [0.0] * n, [0.0] * n
    # Gentle rhythmic ocean surf wash
    raw_l = [rng.uniform(-1.0, 1.0) for _ in range(n)]
    raw_r = [rng.uniform(-1.0, 1.0) for _ in range(n)]
    lp_l, lp_r = 0.0, 0.0
    for i in range(n * 2):
        idx = i % n
        lp_l = lp_l * 0.986 + raw_l[idx] * 0.014
        lp_r = lp_r * 0.986 + raw_r[idx] * 0.014
        if i >= n:
            wave_env = 0.55 + 0.45 * math.sin(2.0 * math.pi * idx / n)
            l[idx] += lp_l * 0.13 * wave_env
            r[idx] += lp_r * 0.13 * wave_env
    # Upbeat F -> Bb -> C -> F calypso syncopation
    calypso = [
        (0.0, 349.23, -0.25), (0.375, 440.00, 0.22), (0.75, 523.25, -0.18), (1.25, 587.33, 0.26), (1.625, 523.25, -0.12),
        (2.0, 466.16, -0.26), (2.375, 587.33, 0.22), (2.75, 698.46, -0.18), (3.25, 587.33, 0.24), (3.625, 466.16, -0.15),
        (4.0, 523.25, -0.24), (4.375, 659.25, 0.24), (4.75, 783.99, -0.18), (5.25, 659.25, 0.22), (5.625, 523.25, -0.14),
        (6.0, 349.23, -0.25), (6.375, 523.25, 0.20), (6.75, 698.46, 0.28), (7.25, 587.33, -0.18), (7.625, 440.00, 0.14),
    ]
    for idx_n, (onset, freq, pan) in enumerate(calypso):
        m_hit = marimba_hit(freq, 0.34, amp=0.22)
        nylon = karplus_pluck(freq * 0.5, 0.95, amp=0.16, brightness=0.497, seed=920 + idx_n)
        start_i = int(onset * SAMPLE_RATE)
        gl = math.cos((pan + 1.0) * math.pi * 0.25)
        gr = math.sin((pan + 1.0) * math.pi * 0.25)
        for j, s in enumerate(nylon):
            pos = (start_i + j) % n
            ms = m_hit[j] if j < len(m_hit) else 0.0
            l[pos] += (s + ms) * gl
            r[pos] += (s + ms) * gr
    return apply_warm_room(l, r, 0.22)


def main() -> None:
    generators = {
        "till.wav": gen_till,
        "water.wav": gen_water,
        "plant.wav": gen_plant,
        "harvest.wav": gen_harvest,
        "chop.wav": gen_chop,
        "mine_hit.wav": gen_mine_hit,
        "sword_swing.wav": gen_sword_swing,
        "monster_hit.wav": gen_monster_hit,
        "coin.wav": gen_coin,
        "fish_cast.wav": gen_fish_cast,
        "fish_catch.wav": gen_fish_catch,
        "ui_click.wav": gen_ui_click,
        "rooster_morning.wav": gen_rooster_morning,
        "valley_breeze_loop.wav": gen_valley_breeze_loop,
        "bgm_summer_loop.wav": gen_bgm_summer_loop,
        "bgm_autumn_loop.wav": gen_bgm_autumn_loop,
        "bgm_winter_loop.wav": gen_bgm_winter_loop,
        "bgm_island_loop.wav": gen_bgm_island_loop,
    }
    for fname, fn in generators.items():
        l, r = fn()
        write_stereo_wav(fname, l, r)
    print(f"[OK] 已生成 {len(generators)} 首立体声原声级木吉他/竖琴/拟音 WAV 至 {DROPIN_AUDIO}")


if __name__ == "__main__":
    main()
