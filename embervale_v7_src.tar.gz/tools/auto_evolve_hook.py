#!/usr/bin/env python3
"""
《星露物语：回响山谷》Antigravity 自动持续优化代理钩子 (SessionStart + Stop)
- SessionStart: 注入持续诊断协议，要求每次回答产出可执行优化建议并同步至 reports/evolution_backlog.json
- Stop: 代替用户充当“自动监工代理”，检查待办清单与回复内容，若仍有高价值优化点则自动发送 continue 指令驱动代理继续实操、测试与验证，直到收敛 ([OPTIMIZATION_CONVERGED]) 或达到单轮最大循环次数。
"""
import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
CONFIG_PATH = ROOT / "tools" / "auto_evolve_config.json"
BACKLOG_PATH = ROOT / "reports" / "evolution_backlog.json"

SESSION_INSTRUCTION = (
    "[自动裁判与协同优化协议已激活] 你当前处于《星露物语：回响山谷》Executor × Referee 自动裁判闭环工作区。"
    "每次对话回复必须充当客观裁判与交付官，输出：\n"
    "1) **本轮协同交付物清单**（带可点击文件路径）；\n"
    "2) **`## 本轮可优化点与裁判推荐`**（从玩法深度、UI/UX手感、经济数值、村民AI叙事、美术热替换管线、QA测试覆盖六维做 ROI 评估，显式区分「可直接代码/测试自动化解决」与「需人工/外部平台/付费确认」）；\n"
    "3) 若存在高性价比可自动化优化点（ROI >= 5.2），写入 `reports/evolution_backlog.json`（status='pending'），Stop 裁判钩子将自动校验客观门禁并驱动下一轮循环实操，直到全部门禁全绿且再无高价值改进项（输出 `[OPTIMIZATION_CONVERGED]`）。"
)


def load_config() -> dict:
    try:
        if CONFIG_PATH.exists():
            return json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
    except Exception:
        pass
    return {"enabled": True, "max_rounds_per_turn": 4, "require_headless_qa": True}


def save_config(cfg: dict) -> None:
    CONFIG_PATH.write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")


def load_pending_items() -> list:
    try:
        if BACKLOG_PATH.exists():
            data = json.loads(BACKLOG_PATH.read_text(encoding="utf-8"))
            items = [it for it in data.get("items", []) if it.get("status") == "pending"]
            items.sort(key=lambda x: int(x.get("priority", 99)))
            return items
    except Exception:
        pass
    return []


def read_last_model_text(transcript_path: str) -> str:
    if not transcript_path:
        return ""
    p = Path(transcript_path)
    if not p.exists():
        return ""
    try:
        lines = p.read_text(encoding="utf-8", errors="replace").splitlines()
        for raw in reversed(lines[-40:]):
            raw = raw.strip()
            if not raw:
                continue
            try:
                obj = json.loads(raw)
            except Exception:
                continue
            if obj.get("source") == "MODEL" or obj.get("type") == "PLANNER_RESPONSE":
                txt = str(obj.get("content", "") or "")
                if txt.strip():
                    return txt
    except Exception:
        pass
    return ""


def handle_hook_payload(payload: dict) -> dict:
    cfg = load_config()
    if not bool(cfg.get("enabled", True)):
        if payload.get("hookEventName") == "SessionStart":
            return {}
        return {"decision": "allow"}

    event_name = str(payload.get("hookEventName", ""))
    if event_name == "SessionStart":
        return {
            "injectSteps": [
                {
                    "systemMessage": {
                        "systemMessage": SESSION_INSTRUCTION
                    }
                }
            ]
        }

    if event_name == "Stop":
        term_reason = str(payload.get("terminationReason", ""))
        fully_idle = bool(payload.get("fullyIdle", True))
        err = str(payload.get("error", "") or "")
        exec_num = int(payload.get("executionNum", 0))
        max_rounds = int(cfg.get("max_rounds_per_turn", 4))

        if term_reason != "NO_TOOL_CALL" or not fully_idle or err:
            return {"decision": "allow"}

        if exec_num >= max_rounds:
            return {"decision": "allow"}

        last_text = read_last_model_text(str(payload.get("transcriptPath", "")))
        if "[SKIP_AUTO_EVOLVE]" in last_text:
            return {"decision": "allow"}

        # Objective Referee Fast Gate Lock (GDScript 4.6 lint + art_dropin spec check)
        try:
            sys.path.insert(0, str(ROOT / "tools"))
            import auto_referee
            import art_pipeline
            ok_lint, msg_lint = auto_referee.lint_gdscript_constraints()
            if not ok_lint:
                return {
                    "decision": "continue",
                    "reason": f"[自动裁判驳回 · REWORK_REQUIRED] GDScript 4.6 强约束门禁未通过：{msg_lint}。请立即修复并重跑无头测试！",
                }
            art_st = art_pipeline.check_status()
            if art_st.get("warnings"):
                return {
                    "decision": "continue",
                    "reason": f"[自动裁判驳回 · REWORK_REQUIRED] 美术热替换规格门禁存在告警：{art_st['warnings'][:2]}。请立即修正！",
                }
        except Exception:
            pass

        pending = load_pending_items()
        if pending:
            top = pending[0]
            tid = top.get("id", "unknown")
            title = top.get("title", "优化项")
            rationale = top.get("rationale", "")
            next_round = exec_num + 1
            reason_msg = (
                f"[自动优化代理代用户执行 · 第 {next_round}/{max_rounds} 轮] "
                f"检测到待落地优化项 `{tid}`【{title}】（{rationale}）。"
                f"请立即代替用户按该建议实操修改代码、补充或运行 Godot 无头全系统测试"
                f"（Godot_v4.6.1-stable_win64_console.exe --headless --path game res://scenes/headless_test_runner.tscn），"
                f"验证通过后将 `reports/evolution_backlog.json` 中 `{tid}` 的 status 更新为 `completed`，"
                f"并将本轮改动记录追加到 `reports/evolution_log.md`，然后继续评估是否还有下一项可优化点。"
                f"若全部高价值项已完成，请在答复末尾输出 `[OPTIMIZATION_CONVERGED]`。"
            )
            return {"decision": "continue", "reason": reason_msg}

        if "[OPTIMIZATION_CONVERGED]" in last_text:
            return {"decision": "allow"}

        # If model proposed optimizations in text without updating backlog or declaring convergence
        has_suggestions = any(kw in last_text for kw in ("可优化", "优化建议", "改进建议", "优化点"))
        if has_suggestions:
            next_round = exec_num + 1
            reason_msg = (
                f"[自动优化代理代用户执行 · 第 {next_round}/{max_rounds} 轮] "
                "你刚刚提出了可优化点与建议，但尚未将其加入 `reports/evolution_backlog.json` 并动手落地。"
                "请选出性价比最高的一项立即实操修改并运行 Godot 无头测试验证；"
                "如果确认当前已无更高价值的实质优化点需要实操，请明确回复 `[OPTIMIZATION_CONVERGED]`。"
            )
            return {"decision": "continue", "reason": reason_msg}

        return {"decision": "allow"}

    return {}


def run_self_test() -> int:
    import tempfile

    print("=== 运行 auto_evolve_hook.py 契约自检 ===")
    # Case 1: SessionStart
    out1 = handle_hook_payload({"hookEventName": "SessionStart"})
    assert "injectSteps" in out1 and len(out1["injectSteps"]) == 1, f"Case 1 failed: {out1}"
    print("[PASS] 1) SessionStart 注入持续诊断协议")

    # Case 2: Stop with pending backlog item -> continue
    out2 = handle_hook_payload({
        "hookEventName": "Stop",
        "terminationReason": "NO_TOOL_CALL",
        "fullyIdle": True,
        "executionNum": 0,
        "transcriptPath": "",
    })
    pending = load_pending_items()
    if pending:
        assert out2.get("decision") == "continue", f"Case 2 failed: {out2}"
        print("[PASS] 2) Stop 存在 pending 项时自动触发 decision=continue 代执行")
    else:
        print("[PASS] 2) Stop 逻辑校验通过（当前 backlog 无 pending）")

    # Case 3: Stop with USER_CANCELED or max rounds -> allow
    out3a = handle_hook_payload({
        "hookEventName": "Stop",
        "terminationReason": "USER_CANCELED",
        "fullyIdle": True,
        "executionNum": 0,
    })
    out3b = handle_hook_payload({
        "hookEventName": "Stop",
        "terminationReason": "NO_TOOL_CALL",
        "fullyIdle": True,
        "executionNum": 99,
    })
    assert out3a.get("decision") == "allow" and out3b.get("decision") == "allow"
    print("[PASS] 3) Stop 遇到用户取消或达到最大轮次上限时安全放行 (allow)")

    # Case 4: Stop with [OPTIMIZATION_CONVERGED] in transcript when no pending
    global BACKLOG_PATH
    orig_bp = BACKLOG_PATH
    with tempfile.NamedTemporaryFile("w", suffix=".jsonl", delete=False, encoding="utf-8") as tf:
        tf.write(json.dumps({"source": "MODEL", "type": "PLANNER_RESPONSE", "content": "优化完成。[OPTIMIZATION_CONVERGED]"}, ensure_ascii=False) + "\n")
        tmp_path = tf.name
    try:
        BACKLOG_PATH = Path(tmp_path + ".missing.json")
        out4 = handle_hook_payload({
            "hookEventName": "Stop",
            "terminationReason": "NO_TOOL_CALL",
            "fullyIdle": True,
            "executionNum": 0,
            "transcriptPath": tmp_path,
        })
        assert out4.get("decision") == "allow", f"Case 4 failed: {out4}"
        assert "ensure_ascii" or isinstance(json.dumps(out1, ensure_ascii=True), str)
    finally:
        BACKLOG_PATH = orig_bp
        Path(tmp_path).unlink(missing_ok=True)
    print("[PASS] 4) 已收敛 ([OPTIMIZATION_CONVERGED]) 放行与 JSON 编码校验")
    return 0


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--self-test", action="store_true")
    parser.add_argument("--toggle", action="store_true")
    parser.add_argument("--status", action="store_true")
    args = parser.parse_args()

    if args.self_test:
        sys.exit(run_self_test())

    if args.status:
        cfg = load_config()
        pending = load_pending_items()
        state = "开启" if cfg.get("enabled", True) else "暂停"
        print(f"自动持续优化状态: {state} | 单次最大循环轮数: {cfg.get('max_rounds_per_turn', 4)} | 当前待执行优化项: {len(pending)}")
        return

    if args.toggle:
        cfg = load_config()
        cfg["enabled"] = not bool(cfg.get("enabled", True))
        save_config(cfg)
        state = "已开启" if cfg["enabled"] else "已暂停"
        print(f"[OK] 自动持续优化开关{state}！")
        return

    try:
        raw = sys.stdin.read()
        payload = json.loads(raw) if raw.strip() else {}
        res = handle_hook_payload(payload)
        print(json.dumps(res, ensure_ascii=True))
    except Exception:
        print(json.dumps({}, ensure_ascii=True))


if __name__ == "__main__":
    main()
