#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
《星露物语：回响山谷》无限画布 (api1.shop) 2x2 象限图集智能拆解与全品类热替换导入器
支持：
1) 2x2 四宫格单品/作物/世界物件自动去边、四角泛洪抠底、去 JPEG 白边光晕并落盘
2) 单张成熟作物自动联动生成：crops/crop_<id>.png (5阶段2x生长条) + icons/<id>.png + icons/seed_<id>.png (印有真实作物徽章的星露谷牛皮纸种子袋)
3) 2x2 四向角色设定图 (下/左/右/上) 自动合成 4x4 (NPC 256x256) 或 4x6 (主角 256x384) 16-bit 行走与挥砍精灵图集
4) 2x2 地表材质图 (草地/暖砂石板/橡木地板/清澈水面) 自动无缝边缘融合合成 640x128 (2x) 20格 terrain_atlas.png
"""
from __future__ import annotations

import json
import tempfile
from collections import deque
from pathlib import Path
from PIL import Image, ImageDraw, ImageEnhance

import art_pipeline

ROOT = Path(__file__).resolve().parent.parent
DROPIN_SPRITES = ROOT / "art_dropin" / "sprites"
CROPS_JSON = ROOT / "game" / "data" / "crops.json"


def extract_quad_subimages(src_path: Path, trim_outer: int = 12, trim_center: int = 12) -> list[Image.Image]:
    """将 2x2 象限大图安全切分为 [左上, 右上, 左下, 右下] 4 张带纯白安全外框的子图"""
    im = Image.open(src_path).convert("RGBA")
    w, h = im.size
    mx, my = w // 2, h // 2
    boxes = [
        (trim_outer, trim_outer, mx - trim_center, my - trim_center),
        (mx + trim_center, trim_outer, w - trim_outer, my - trim_center),
        (trim_outer, my + trim_center, mx - trim_center, h - trim_outer),
        (mx + trim_center, my + trim_center, w - trim_outer, h - trim_outer),
    ]
    subs: list[Image.Image] = []
    for bx in boxes:
        sub = im.crop(bx)
        padded = Image.new("RGBA", (sub.width + 16, sub.height + 16), (255, 255, 255, 255))
        padded.paste(sub, (8, 8))
        subs.append(padded)
    return subs


def flood_matte_clean(im: Image.Image, tolerance: int = 54) -> Image.Image:
    """四角采样泛洪抠白底 + 2轮去白边光晕 + 紧致包围盒裁剪"""
    im = im.copy().convert("RGBA")
    w, h = im.size
    px = im.load()
    corners = [px[0, 0], px[w - 1, 0], px[0, h - 1], px[w - 1, h - 1]]
    bg_r = sum(c[0] for c in corners) // 4
    bg_g = sum(c[1] for c in corners) // 4
    bg_b = sum(c[2] for c in corners) // 4

    def is_bg(c):
        if c[3] < 20:
            return True
        return abs(c[0] - bg_r) + abs(c[1] - bg_g) + abs(c[2] - bg_b) <= tolerance * 3

    visited = bytearray(w * h)
    q = deque()
    for x in range(w):
        for y in (0, h - 1):
            idx = y * w + x
            if not visited[idx] and is_bg(px[x, y]):
                visited[idx] = 1
                q.append((x, y))
    for y in range(h):
        for x in (0, w - 1):
            idx = y * w + x
            if not visited[idx] and is_bg(px[x, y]):
                visited[idx] = 1
                q.append((x, y))

    while q:
        cx, cy = q.popleft()
        px[cx, cy] = (0, 0, 0, 0)
        for dx, dy in ((-1, 0), (1, 0), (0, -1), (0, 1)):
            nx, ny = cx + dx, cy + dy
            if 0 <= nx < w and 0 <= ny < h:
                nidx = ny * w + nx
                if not visited[nidx] and is_bg(px[nx, ny]):
                    visited[nidx] = 1
                    q.append((nx, ny))

    if min(w, h) >= 180:
        for _ in range(2):
            to_clear = []
            for y in range(1, h - 1):
                for x in range(1, w - 1):
                    c = px[x, y]
                    if c[3] > 0 and min(c[0], c[1], c[2]) >= 214 and (max(c[0], c[1], c[2]) - min(c[0], c[1], c[2])) <= 34:
                        if px[x - 1, y][3] == 0 or px[x + 1, y][3] == 0 or px[x, y - 1][3] == 0 or px[x, y + 1][3] == 0:
                            to_clear.append((x, y))
            for cx2, cy2 in to_clear:
                px[cx2, cy2] = (0, 0, 0, 0)

    bbox = im.getbbox()
    return im.crop(bbox) if bbox else im


def make_seed_packet_from_crop_icon(crop_id: str, season: str = "spring") -> Path:
    """利用真实 AI 作物图标合成星露谷经典牛皮纸封口种子袋 icons/seed_<crop_id>.png (32x32)"""
    season_headers = {
        "spring": (94, 182, 84, 255),
        "summer": (236, 178, 56, 255),
        "autumn": (216, 102, 52, 255),
        "winter": (88, 168, 224, 255),
    }
    hdr_col = season_headers.get(season, (138, 102, 198, 255))
    pkt = Image.new("RGBA", (32, 32), (0, 0, 0, 0))
    d = ImageDraw.Draw(pkt)
    # Dark brown pixel outline + warm kraft bag body
    d.rounded_rectangle([5, 4, 26, 28], radius=3, fill=(228, 196, 146, 255), outline=(48, 30, 20, 255), width=1)
    # Inner kraft shading & top crimped seal band
    d.rectangle([6, 24, 25, 27], fill=(204, 168, 118, 255))
    d.rectangle([6, 5, 25, 9], fill=hdr_col)
    d.line([6, 9, 25, 9], fill=(78, 50, 32, 255))
    # Cream label patch in center
    d.rounded_rectangle([8, 11, 23, 25], radius=2, fill=(250, 242, 222, 255), outline=(168, 134, 92, 255))
    # Composite miniature real AI crop icon onto the seed packet label!
    crop_icon_path = DROPIN_SPRITES / "icons" / f"{crop_id}.png"
    if crop_icon_path.exists():
        ci = Image.open(crop_icon_path).convert("RGBA")
        bb = ci.getbbox()
        if bb:
            ci = ci.crop(bb)
        sc = min(13.0 / max(1, ci.width), 13.0 / max(1, ci.height))
        nw = max(1, int(round(ci.width * sc)))
        nh = max(1, int(round(ci.height * sc)))
        mini = ci.resize((nw, nh), Image.Resampling.NEAREST)
        pkt.paste(mini, (16 - nw // 2, 18 - nh // 2), mini)
    dest = DROPIN_SPRITES / "icons" / f"seed_{crop_id}.png"
    dest.parent.mkdir(parents=True, exist_ok=True)
    pkt.save(dest)
    return dest


def import_quad_sheet(src_path: Path, actions: list[dict], tolerance: int = 54) -> list[Path]:
    """
    actions 为长度 4 的列表（对应左上/右上/左下/右下），每项支持：
      - {"targets": ["objects/stump.png", "icons/wood.png"]}
      - {"crop_id": "turnip"}  -> 自动生成 crops/crop_turnip.png + icons/turnip.png + icons/seed_turnip.png
    """
    crops_meta = {}
    if CROPS_JSON.exists():
        for c in json.loads(CROPS_JSON.read_text(encoding="utf-8")).get("crops", []):
            crops_meta[c["id"]] = (c.get("seasons") or ["spring"])[0]

    subs = extract_quad_subimages(src_path)
    written: list[Path] = []
    with tempfile.TemporaryDirectory() as td:
        for idx, act in enumerate(actions):
            if not act:
                continue
            q_file = Path(td) / f"quad_{idx}.png"
            subs[idx].save(q_file)
            if "crop_id" in act:
                cid = act["crop_id"]
                written.append(art_pipeline.import_ai_image(q_file, f"crops/crop_{cid}.png", tolerance=tolerance))
                written.append(art_pipeline.import_ai_image(q_file, f"icons/{cid}.png", tolerance=tolerance))
                written.append(make_seed_packet_from_crop_icon(cid, crops_meta.get(cid, "spring")))
            for tgt in act.get("targets", []):
                written.append(art_pipeline.import_ai_image(q_file, tgt, tolerance=tolerance))
    return written


def import_character_sheet_from_quad(src_path: Path, target_rel: str, tolerance: int = 54) -> Path:
    """
    从 2x2 四向角色图 ([左上:正面朝下, 右上:侧面朝左, 左下:侧面朝右, 右下:背面朝上])
    合成 2x 高清星露谷风行走图集：
      - NPC: 256x256 (4列x4行, 单帧 64x64)
      - Player: 256x384 (4列x6行, 含行4挥动工具与行5庆贺/垂钓帧)
    """
    is_player = target_rel.endswith("player_sheet.png")
    fw, fh = 64, 64
    rows = 6 if is_player else 4
    sheet = Image.new("RGBA", (fw * 4, fh * rows), (0, 0, 0, 0))

    subs = extract_quad_subimages(src_path, trim_outer=10, trim_center=10)
    views = [flood_matte_clean(s, tolerance=tolerance) for s in subs]

    # Normalize all 4 directional sprites to unified character height (56px inside 64x64 cell)
    norm_views: list[Image.Image] = []
    for v in views:
        sc = min(52.0 / max(1, v.width), 56.0 / max(1, v.height))
        nw = max(1, int(round(v.width * sc)))
        nh = max(1, int(round(v.height * sc)))
        norm_views.append(v.resize((nw, nh), Image.Resampling.NEAREST))

    # Synthesize 4-step walk cycle for each direction row (0:Down, 1:Left, 2:Right, 3:Up)
    for r_dir in range(4):
        base = norm_views[r_dir]
        bw, bh = base.size
        split_y = int(bh * 0.68)  # Upper body vs legs/boots stride
        upper = base.crop((0, 0, bw, split_y))
        lower = base.crop((0, split_y, bw, bh))
        lw_half = max(1, bw // 2)

        for step in range(4):
            cell = Image.new("RGBA", (fw, fh), (0, 0, 0, 0))
            bob = -2 if step in (1, 3) else 0
            ox = (fw - bw) // 2
            oy = fh - 3 - bh + bob
            cell.paste(upper, (ox, max(0, oy)), upper)

            if step == 0 or step == 2:
                cell.paste(lower, (ox, max(0, oy + split_y)), lower)
            else:
                stride = 2 if step == 1 else -2
                if r_dir in (0, 3):
                    # Alternating left/right boot lift
                    l_leg = lower.crop((0, 0, lw_half, lower.height))
                    r_leg = lower.crop((lw_half, 0, bw, lower.height))
                    l_lift = -2 if step == 1 else 0
                    r_lift = -2 if step == 3 else 0
                    cell.paste(l_leg, (ox, max(0, oy + split_y + l_lift)), l_leg)
                    cell.paste(r_leg, (ox + lw_half, max(0, oy + split_y + r_lift)), r_leg)
                else:
                    # Profile stride spread
                    cell.paste(lower, (ox + stride, max(0, oy + split_y - 1)), lower)

            sheet.paste(cell, (step * fw, r_dir * fh))

    if is_player:
        # Row 4: Tool action swing per direction [Down, Left, Right, Up]
        for c_dir in range(4):
            base = norm_views[c_dir]
            bw, bh = base.size
            cell = Image.new("RGBA", (fw, fh), (0, 0, 0, 0))
            lean_x = -2 if c_dir == 1 else (2 if c_dir == 2 else 0)
            lean_y = 2 if c_dir == 0 else (-2 if c_dir == 3 else 0)
            ox = (fw - bw) // 2 + lean_x
            oy = fh - 3 - bh + lean_y
            cell.paste(base, (max(0, ox), max(0, oy)), base)
            sheet.paste(cell, (c_dir * fw, 4 * fh))

        # Row 5: Joyful harvest / fishing stance per direction
        for c_dir in range(4):
            base = norm_views[c_dir]
            bw, bh = base.size
            cell = Image.new("RGBA", (fw, fh), (0, 0, 0, 0))
            ox = (fw - bw) // 2
            oy = fh - 6 - bh
            cell.paste(base, (ox, max(0, oy)), base)
            sheet.paste(cell, (c_dir * fw, 5 * fh))

    dest = DROPIN_SPRITES / target_rel
    dest.parent.mkdir(parents=True, exist_ok=True)
    sheet.save(dest)
    return dest


def _make_seamless_64(patch: Image.Image) -> Image.Image:
    """将采样纹理块缩放为 64x64 并通过环形偏移混合消除接缝"""
    base = patch.convert("RGBA").resize((64, 64), Image.Resampling.NEAREST)
    px_a = base.load()
    out = Image.new("RGBA", (64, 64))
    px_o = out.load()
    for y in range(64):
        wy = abs(y - 31.5) / 31.5
        for x in range(64):
            wx = abs(x - 31.5) / 31.5
            edge_w = max(wx, wy)
            if edge_w <= 0.65:
                px_o[x, y] = px_a[x, y]
            else:
                k = (edge_w - 0.65) / 0.35 * 0.5
                c1 = px_a[x, y]
                c2 = px_a[(x + 32) % 64, (y + 32) % 64]
                px_o[x, y] = (
                    int(c1[0] * (1.0 - k) + c2[0] * k),
                    int(c1[1] * (1.0 - k) + c2[1] * k),
                    int(c1[2] * (1.0 - k) + c2[2] * k),
                    255,
                )
    return out


def _recolor_tile(tile: Image.Image, target_rgb: tuple[int, int, int], blend: float = 0.62, contrast: float = 1.05) -> Image.Image:
    im = ImageEnhance.Contrast(tile.convert("RGB")).enhance(contrast).convert("RGBA")
    px = im.load()
    tr, tg, tb = target_rgb
    for y in range(im.height):
        for x in range(im.width):
            r, g, b, _ = px[x, y]
            lum = (r * 0.299 + g * 0.587 + b * 0.114) / 145.0
            nr = max(0, min(255, int(r * (1.0 - blend) + tr * lum * blend)))
            ng = max(0, min(255, int(g * (1.0 - blend) + tg * lum * blend)))
            nb = max(0, min(255, int(b * (1.0 - blend) + tb * lum * blend)))
            px[x, y] = (nr, ng, nb, 255)
    return im


def import_terrain_atlas_from_quad(src_path: Path) -> Path:
    """
    从 2x2 像素地表纹理大图 ([左上:草地, 右上:暖砂鹅卵石路, 左下:橡木地板, 右下:清澈湖水])
    构建 2x 高清 (640x128, 10x2格 64x64) 无接缝 art_dropin/sprites/tiles/terrain_atlas.png
    """
    im = Image.open(src_path).convert("RGBA")
    w, h = im.size
    q_centers = [
        (w // 4, h // 4),
        (3 * w // 4, h // 4),
        (w // 4, 3 * h // 4),
        (3 * w // 4, 3 * h // 4),
    ]
    half_span = min(w, h) // 6
    patches = []
    for cx, cy in q_centers:
        raw_p = im.crop((cx - half_span, cy - half_span, cx + half_span, cy + half_span))
        patches.append(_make_seamless_64(raw_p))

    grass_base, cobble_base, wood_base, water_base = patches
    grass_1 = _recolor_tile(grass_base, (106, 172, 74), blend=0.45, contrast=1.02)
    # grass_2: exact same seamless grass_1 + tiny Stardew meadow wildflowers
    grass_2 = grass_1.copy()
    gd = ImageDraw.Draw(grass_2)
    for fx, fy, fc in [(16, 18, (255, 236, 118, 255)), (44, 34, (255, 176, 198, 255)), (28, 50, (250, 252, 245, 255))]:
        gd.rectangle([fx - 2, fy, fx + 3, fy + 1], fill=fc)
        gd.rectangle([fx, fy - 2, fx + 1, fy + 3], fill=fc)
        gd.rectangle([fx, fy, fx + 1, fy + 1], fill=(255, 206, 68, 255))

    dirt_path = _recolor_tile(grass_base, (202, 160, 108), blend=0.78, contrast=0.92)
    stone_paving = _recolor_tile(cobble_base, (162, 152, 140), blend=0.45, contrast=1.06)
    wood_floor = _recolor_tile(wood_base, (172, 116, 68), blend=0.42, contrast=1.05)
    mine_floor = _recolor_tile(grass_base, (68, 64, 78), blend=0.82, contrast=1.08)

    tilled_dry = _recolor_tile(grass_base, (156, 114, 72), blend=0.80, contrast=0.95)
    td_d = ImageDraw.Draw(tilled_dry)
    for ry in (14, 30, 46):
        td_d.rectangle([8, ry, 55, ry + 3], fill=(122, 82, 46, 255))

    tilled_wet = _recolor_tile(grass_base, (92, 60, 38), blend=0.84, contrast=0.98)
    tw_d = ImageDraw.Draw(tilled_wet)
    for ry in (14, 30, 46):
        tw_d.rectangle([8, ry, 55, ry + 3], fill=(64, 40, 24, 255))

    water_1 = _recolor_tile(water_base, (58, 156, 216), blend=0.42, contrast=1.04)
    # water_2 shifted by 16px horizontally for gentle water ripple animation!
    water_2 = Image.new("RGBA", (64, 64))
    water_2.paste(water_1.crop((16, 0, 64, 64)), (0, 0))
    water_2.paste(water_1.crop((0, 0, 16, 64)), (48, 0))

    mine_wall = _recolor_tile(cobble_base, (46, 40, 54), blend=0.82, contrast=1.15)
    hedge = _recolor_tile(grass_base, (60, 120, 50), blend=0.72, contrast=1.18)
    cliff = _recolor_tile(cobble_base, (118, 104, 90), blend=0.72, contrast=1.10)
    winter_snow = _recolor_tile(grass_base, (226, 238, 248), blend=0.84, contrast=0.88)
    autumn_grass = _recolor_tile(grass_base, (182, 136, 66), blend=0.74, contrast=1.02)
    farm_rug = _recolor_tile(wood_base, (172, 68, 68), blend=0.78, contrast=1.04)
    summer_grass = _recolor_tile(grass_base, (120, 180, 78), blend=0.58, contrast=1.02)
    dock = _recolor_tile(wood_base, (144, 98, 58), blend=0.58, contrast=1.06)
    petal_grass = grass_2.copy()
    pg_d = ImageDraw.Draw(petal_grass)
    for px_i, py_i in [(10, 42), (36, 14), (52, 48), (24, 28)]:
        pg_d.rectangle([px_i, py_i, px_i + 3, py_i + 2], fill=(255, 192, 212, 255))
    sand_shore = _recolor_tile(grass_base, (220, 198, 148), blend=0.82, contrast=0.90)

    row0 = [grass_1, grass_2, dirt_path, stone_paving, wood_floor, mine_floor, tilled_dry, tilled_wet, water_1, water_2]
    row1 = [mine_wall, hedge, cliff, winter_snow, autumn_grass, farm_rug, summer_grass, dock, petal_grass, sand_shore]

    atlas = Image.new("RGBA", (640, 128), (0, 0, 0, 0))
    for i, t in enumerate(row0):
        atlas.paste(t, (i * 64, 0))
    for i, t in enumerate(row1):
        atlas.paste(t, (i * 64, 64))

    dest = DROPIN_SPRITES / "tiles" / "terrain_atlas.png"
    dest.parent.mkdir(parents=True, exist_ok=True)
    atlas.save(dest)
    return dest
