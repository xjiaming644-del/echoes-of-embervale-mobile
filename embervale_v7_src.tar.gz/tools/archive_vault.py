#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
《星露物语：回响山谷》全量原画与工程快照归档工具 (Vault Archiver)
职责：
1) 将无限画布 (api1.shop) 生成的原始高清 1024x1024 母图归档至 archives/canvas_raw_originals/ 并生成溯源索引 index.json；
2) 将当前游戏用户目录存档备份至 archives/saves_backup/；
3) 输出归档摘要供版本控制与团队交接查阅。
"""
from __future__ import annotations

import hashlib
import json
import os
import shutil
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
VAULT_DIR = ROOT / "archives"
RAW_DIR = VAULT_DIR / "canvas_raw_originals"
SAVE_BAK_DIR = VAULT_DIR / "saves_backup"

SANDBOX_DL = Path(r"C:\Users\Administrator\.gemini\antigravity\brain\890972f1-824a-48c2-9a70-0d3d7ee94b51\browser_sandbox\downloads")


def archive_all() -> dict:
    RAW_DIR.mkdir(parents=True, exist_ok=True)
    SAVE_BAK_DIR.mkdir(parents=True, exist_ok=True)

    copied_raw = 0
    if SANDBOX_DL.exists():
        for f in sorted(SANDBOX_DL.glob("*")):
            if f.is_file() and f.suffix.lower() in (".png", ".jpg", ".jpeg", ".webp"):
                dest = RAW_DIR / f.name
                if not dest.exists() or dest.stat().st_size != f.stat().st_size:
                    shutil.copy2(f, dest)
                    copied_raw += 1

    raw_entries = []
    for f in sorted(RAW_DIR.glob("*")):
        if f.is_file() and f.name != "index.json":
            h = hashlib.sha256(f.read_bytes()).hexdigest()[:16]
            raw_entries.append({
                "filename": f.name,
                "size_bytes": f.stat().st_size,
                "sha256_16": h,
            })

    # Also backup any existing Godot user:// saves on this machine
    appdata = os.environ.get("APPDATA", "")
    godot_user_dir = Path(appdata) / "Godot" / "app_userdata" / "星露物语：回响山谷"
    backed_saves = []
    if godot_user_dir.exists():
        for sf in sorted(godot_user_dir.glob("slot_*.json*")):
            if sf.is_file() and not sf.name.endswith(".tmp"):
                shutil.copy2(sf, SAVE_BAK_DIR / sf.name)
                backed_saves.append(sf.name)

    manifest = {
        "archived_at": datetime.now().isoformat(timespec="seconds"),
        "raw_canvas_originals_count": len(raw_entries),
        "newly_copied_count": copied_raw,
        "backed_up_saves": backed_saves,
        "raw_files": raw_entries,
    }
    (RAW_DIR / "index.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"[OK] 原画与存档保险库归档完成: 共永久保存 {len(raw_entries)} 张无限画布高清母图 (新增 {copied_raw} 张), 备份存档 {len(backed_saves)} 份 -> {VAULT_DIR}")
    return manifest


if __name__ == "__main__":
    archive_all()
