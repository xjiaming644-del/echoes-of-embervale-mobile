#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
《星露物语：回响山谷》内置自动裁判闭环程序 (Auto-Referee Automation Program)
职责：
1) 充当客观独立“裁判（Referee）”，对每轮对话产出的【协同交付物】与【优化建议推荐】进行 ROI 评分、去重防抖与红线分流；
2) 自动实跑 5 道客观子进程验证门禁（GDScript 强约束静态扫描、美术规格校验、四季经济模拟、Web工作台自检、Godot 4.6 无头全系统测试）；
3) 与 .agents/hooks.json (auto_evolve_hook.py) 联动：只要门禁未全绿 (REWORK_REQUIRED) 或仍存在高性价比待改进项 (CONTINUE)，自动驱动代理下一轮继续迭代，直到达成最完美的 CONVERGED_COMPLETE (100/100)！
"""
from __future__ import annotations

import argparse
import json
import os
import re
import subprocess
import sys
import time
from datetime import datetime
from difflib import SequenceMatcher
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parent.parent
GAME_DIR = ROOT / "game"
REPORTS_DIR = ROOT / "reports"
STATE_PATH = REPORTS_DIR / "referee_state.json"
REPORT_MD_PATH = REPORTS_DIR / "referee_latest_report.md"
BACKLOG_PATH = REPORTS_DIR / "evolution_backlog.json"
GODOT_CONSOLE = ROOT / "tools" / "godot" / "Godot_v4.6.1-stable_win64_console.exe"

REDLINE_KEYWORDS = (
    "付费生成",
    "充值",
    "购买服务器",
    "手动登录",
    ".env",
    "实录配乐采购",
    "steam上架费",
)


def compute_roi(impact: float, confidence: float, effort: float) -> float:
    return round((float(impact) * 0.6 + float(confidence) * 0.4) - (float(effort) * 0.15), 2)


def _norm(txt: str) -> str:
    return re.sub(r"[\s\-_.:：，。、「」【】()（）\[\]/\\]+", "", str(txt or "").lower())


def is_duplicate(title: str, history: list[str]) -> bool:
    nt = _norm(title)
    if not nt:
        return True
    for h in history:
        nh = _norm(h)
        if nh and (nt == nh or SequenceMatcher(None, nt, nh).ratio() >= 0.78):
            return True
    return False


def lint_gdscript_constraints() -> tuple[bool, str]:
    """静态检查 AGENTS.md GDScript 4.6 三大强约束"""
    issues: list[str] = []
    autoload_dir = GAME_DIR / "scripts" / "autoload"
    if autoload_dir.exists():
        for gd in sorted(autoload_dir.glob("*.gd")):
            txt = gd.read_text(encoding="utf-8")
            for idx, line in enumerate(txt.splitlines(), 1):
                if line.strip().startswith("class_name "):
                    issues.append(f"{gd.name}:{idx} Autoload 禁止声明 class_name")

    for gd in sorted((GAME_DIR / "scripts").rglob("*.gd")):
        txt = gd.read_text(encoding="utf-8")
        for idx, line in enumerate(txt.splitlines(), 1):
            stripped = line.strip()
            if stripped.startswith("#"):
                continue
            if 'load("res://assets/sprites/' in stripped or 'preload("res://assets/sprites/' in stripped:
                issues.append(f"{gd.name}:{idx} 禁止绕过 AssetRegistry 硬编码加载 sprites")
            if re.search(r":=\s*JSON\.parse_string\(", stripped):
                issues.append(f"{gd.name}:{idx} 禁止对 JSON.parse_string Variant 使用 :=")

    if issues:
        return False, "; ".join(issues[:5])
    return True, f"Scanned {len(list((GAME_DIR / 'scripts').rglob('*.gd')))} GDScript files: 0 constraint violations"


def run_all_gates(include_godot: bool = True) -> dict[str, Any]:
    results: list[dict[str, Any]] = []
    env = dict(os.environ)
    env["PYTHONIOENCODING"] = "utf-8"

    # Gate 1: GDScript static constraint lint
    t0 = time.monotonic()
    ok_lint, msg_lint = lint_gdscript_constraints()
    results.append({
        "label": "gdscript_46_static_lint",
        "passed": ok_lint,
        "duration_ms": int((time.monotonic() - t0) * 1000),
        "summary": msg_lint,
    })

    # Subprocess gates
    sub_gates = [
        ("art_dropin_spec_check", [sys.executable, "-X", "utf8", str(ROOT / "tools" / "art_pipeline.py"), "check"]),
        ("economy_balance_sim", [sys.executable, "-X", "utf8", str(ROOT / "tools" / "balance_simulator.py")]),
        ("web_studio_selftest", [sys.executable, "-X", "utf8", str(ROOT / "tools" / "content_studio.py"), "--self-test"]),
        ("mobile_web_pwa_shell_selftest", [sys.executable, "-X", "utf8", str(ROOT / "tools" / "enhance_mobile_web_shell.py"), "--self-test"]),
        ("mobile_release_artifacts_check", [sys.executable, "-X", "utf8", str(ROOT / "tools" / "export_mobile_builds.py"), "--check"]),
        ("standalone_release_zip_check", [sys.executable, "-X", "utf8", str(ROOT / "tools" / "package_release.py"), "--check"]),
    ]
    if include_godot and GODOT_CONSOLE.exists():
        sub_gates.append((
            "godot_headless_qa_suite",
            [str(GODOT_CONSOLE), "--headless", "--path", str(GAME_DIR), "res://scenes/headless_test_runner.tscn"],
        ))

    for label, cmd in sub_gates:
        st = time.monotonic()
        proc = subprocess.run(
            cmd,
            cwd=str(ROOT),
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=90,
            env=env,
        )
        dur = int((time.monotonic() - st) * 1000)
        combined = ((proc.stdout or "") + "\n" + (proc.stderr or "")).strip()
        script_err = "SCRIPT ERROR:" in combined or "[FAIL]" in combined
        passed = (proc.returncode == 0) and (not script_err)
        tail = [ln.strip() for ln in combined.splitlines() if ln.strip()][-3:]
        results.append({
            "label": label,
            "passed": passed,
            "duration_ms": dur,
            "summary": " | ".join(tail) if tail else "(ok)",
        })

    passed_cnt = sum(1 for r in results if r["passed"])
    return {
        "checked_at": datetime.now().isoformat(timespec="seconds"),
        "total_gates": len(results),
        "passed_gates": passed_cnt,
        "all_passed": passed_cnt == len(results),
        "results": results,
    }


def load_completed_history() -> list[str]:
    titles: list[str] = []
    if BACKLOG_PATH.exists():
        try:
            bl = json.loads(BACKLOG_PATH.read_text(encoding="utf-8"))
            for it in bl.get("items", []):
                if it.get("status") == "completed":
                    titles.append(str(it.get("title", "")))
        except Exception:
            pass
    if STATE_PATH.exists():
        try:
            st = json.loads(STATE_PATH.read_text(encoding="utf-8"))
            titles.extend(st.get("completed_titles", []))
        except Exception:
            pass
    return titles


def evaluate_suggestions(suggestions: list[dict[str, Any]], completed_titles: list[str]) -> dict[str, list[dict[str, Any]]]:
    approved: list[dict[str, Any]] = []
    rejected: list[dict[str, Any]] = []
    deferred: list[dict[str, Any]] = []
    seen = list(completed_titles)

    for idx, raw in enumerate(suggestions or [], 1):
        item = dict(raw)
        title = str(item.get("title", "")).strip()
        impact = float(item.get("impact", 5.0))
        confidence = float(item.get("confidence", 5.0))
        effort = float(item.get("effort", 3.0))
        score = compute_roi(impact, confidence, effort)
        item["priority_score"] = score

        hay = f"{title} {item.get('rationale', '')}".lower()
        if bool(item.get("requires_human_or_paid_action")) or any(k in hay for k in REDLINE_KEYWORDS):
            item["decision"] = "DEFERRED_TO_USER"
            item["reason"] = "涉及外部人工确认、平台额度或付费采购，安全分流交由用户定夺"
            deferred.append(item)
            continue

        if is_duplicate(title, seen):
            item["decision"] = "REJECTED_LOW_ROI"
            item["reason"] = "与已完成改进项重复（防原地打转）"
            rejected.append(item)
            continue

        if impact < 6.0 or score < 5.2:
            item["decision"] = "REJECTED_LOW_ROI"
            item["reason"] = f"ROI 评分 ({score}) 低于自动实操阈值 5.2"
            rejected.append(item)
            continue

        seen.append(title)
        item["decision"] = "APPROVED_FOR_NEXT_ROUND"
        item["reason"] = f"高价值客观改进项 (ROI={score})"
        approved.append(item)

    approved.sort(key=lambda x: -float(x["priority_score"]))
    return {"approved": approved, "rejected": rejected, "deferred": deferred}


def run_referee_audit(suggestions: list[dict[str, Any]] | None = None, deliverables: list[str] | None = None, include_godot: bool = True) -> dict[str, Any]:
    REPORTS_DIR.mkdir(parents=True, exist_ok=True)
    gates = run_all_gates(include_godot=include_godot)
    history = load_completed_history()

    # Also include any pending items from evolution_backlog.json
    merged_suggestions = list(suggestions or [])
    if BACKLOG_PATH.exists():
        try:
            bl = json.loads(BACKLOG_PATH.read_text(encoding="utf-8"))
            for it in bl.get("items", []):
                if it.get("status") == "pending":
                    merged_suggestions.append({
                        "id": it.get("id", ""),
                        "title": it.get("title", ""),
                        "rationale": it.get("rationale", ""),
                        "impact": float(it.get("impact", 8.0)),
                        "confidence": float(it.get("confidence", 9.0)),
                        "effort": float(it.get("effort", 3.0)),
                    })
        except Exception:
            pass

    routed = evaluate_suggestions(merged_suggestions, history)
    if not gates["all_passed"]:
        verdict = "REWORK_REQUIRED"
        readiness = int(round(80.0 * gates["passed_gates"] / max(1, gates["total_gates"])))
    elif routed["approved"]:
        verdict = "CONTINUE"
        readiness = 90
    else:
        verdict = "CONVERGED_COMPLETE"
        readiness = 100

    state = {
        "updated_at": datetime.now().isoformat(timespec="seconds"),
        "verdict": verdict,
        "readiness_score": readiness,
        "deliverables": list(deliverables or []),
        "gates": gates,
        "approved": routed["approved"],
        "rejected": routed["rejected"],
        "deferred": routed["deferred"],
        "completed_titles": history,
    }
    STATE_PATH.write_text(json.dumps(state, ensure_ascii=False, indent=2), encoding="utf-8")
    REPORT_MD_PATH.write_text(render_markdown(state), encoding="utf-8")
    return state


def render_markdown(state: dict[str, Any]) -> str:
    gates = state["gates"]
    lines = [
        "# ⚖️《星露物语：回响山谷》自动裁判最新裁决报告",
        "",
        f"- **裁决时间**：`{state['updated_at']}`",
        f"- **裁判结论（Verdict）**：**`{state['verdict']}`**",
        f"- **完美度就绪评分（Readiness）**：**`{state['readiness_score']} / 100`**",
        f"- **客观门禁通过率**：`{gates['passed_gates']} / {gates['total_gates']}`",
        "",
        "## 一、八维客观验证门禁实跑结果",
        "",
        "| 门禁项 | 状态 | 耗时 | 输出摘要 |",
        "| :--- | :---: | :---: | :--- |",
    ]
    for g in gates["results"]:
        st = "✅ PASS" if g["passed"] else "❌ FAIL"
        lines.append(f"| `{g['label']}` | {st} | {g['duration_ms']}ms | `{g['summary'][:95]}` |")

    if state.get("approved"):
        lines += ["", "## 二、裁判批准继续迭代的高价值建议 (`APPROVED_FOR_NEXT_ROUND`)"]
        for ap in state["approved"]:
            lines.append(f"- **{ap['title']}** (ROI `{ap['priority_score']}`) — {ap.get('rationale', '')}")

    if state.get("deferred"):
        lines += ["", "## 三、需人工/外部平台确认事项 (`DEFERRED_TO_USER`)"]
        for df in state["deferred"]:
            lines.append(f"- **{df['title']}** — {df.get('reason', '')}")

    return "\n".join(lines) + "\n"


def self_test() -> int:
    ok_lint, msg_lint = lint_gdscript_constraints()
    assert ok_lint, f"GDScript static lint failed: {msg_lint}"
    import enhance_mobile_web_shell
    assert enhance_mobile_web_shell.self_test() == 0
    routed = evaluate_suggestions([
        {"title": "新增F11无边框全屏切换与静音键", "rationale": "提升桌面试玩体验", "impact": 8, "confidence": 9, "effort": 2},
        {"title": "微调1像素按钮阴影", "rationale": "纯装饰", "impact": 3, "confidence": 5, "effort": 3},
        {"title": "充值购买外部付费配乐包", "rationale": "付费采购", "impact": 8, "confidence": 8, "effort": 2, "requires_human_or_paid_action": True},
    ], completed_titles=[])
    assert len(routed["approved"]) == 1 and len(routed["rejected"]) == 1 and len(routed["deferred"]) == 1
    print(f"[PASS] auto_referee.py self-test & GDScript static lint passed ({msg_lint})")
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(description="回响山谷自动裁判闭环程序")
    parser.add_argument("--self-test", action="store_true")
    parser.add_argument("--fast", action="store_true", help="跳过 Godot 子进程做快速门禁校验")
    args = parser.parse_args()
    if args.self_test:
        return self_test()
    st = run_referee_audit(include_godot=not args.fast)
    print(render_markdown(st))
    return 0 if st["verdict"] != "REWORK_REQUIRED" else 1


if __name__ == "__main__":
    raise SystemExit(main())
