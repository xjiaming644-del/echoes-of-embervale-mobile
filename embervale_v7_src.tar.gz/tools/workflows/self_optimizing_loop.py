#!/usr/bin/env python3
"""
《星露物语：回响山谷》多代理自动持续优化编排工作流 (Critic -> Builder -> Verifier)
可通过 Antigravity 的 run_workflow 工具加载本脚本，实现独立多代理多轮自主演进直到收敛。
"""
import json
from pathlib import Path

ROOT = Path(WORKSPACES[0]) if "WORKSPACES" in globals() and WORKSPACES else Path(r"d:\星露谷物语")
MAX_ROUNDS = int(args.get("max_rounds", 3)) if "args" in globals() else 3

CRITIC_SCHEMA = {
    "type": "object",
    "properties": {
        "converged": {"type": "boolean"},
        "suggestions": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "id": {"type": "string"},
                    "title": {"type": "string"},
                    "target_files": {"type": "array", "items": {"type": "string"}},
                    "rationale": {"type": "string"},
                },
                "required": ["id", "title", "rationale"],
            },
        },
        "summary": {"type": "string"},
    },
    "required": ["converged", "suggestions", "summary"],
}

phase("Continuous Self-Optimization Loop")
critic = agent(
    "你是《星露物语：回响山谷》的首席主审策划与架构评论员（Critic）。"
    "请阅读 game/、tools/ 与 reports/，从玩家乐趣、操作手感、经济平衡、NPC 活人感与人工美术热替换体验出发，"
    "评估是否还有高价值的实际可优化点。严禁吹毛求疵，若当前体验已非常完善则将 converged 设为 true。",
    role="Lead Game Critic",
)

for rnd in range(1, MAX_ROUNDS + 1):
    phase(f"Round {rnd}: Critic -> Builder -> Verifier")
    critique = await critic(
        f"第 {rnd} 轮审查：请检查当前 d:\\星露谷物语 工程状态与 reports/evolution_log.md，"
        "给出最多 1 项当前最值得落地的高性价比优化建议（若无则 converged=true）。",
        CRITIC_SCHEMA,
    )
    log(f"[Round {rnd}] Critic summary: {critique.get('summary')}")
    if critique.get("converged") or not critique.get("suggestions"):
        log(f"[CONVERGED] No further high-value optimizations at round {rnd}.")
        break

    top = critique["suggestions"][0]
    impl_res = await agent(
        f"你是资深 Godot 4.6 全栈工程师。请根据 Critic 意见落地优化 `{top['id']}`【{top['title']}】："
        f"{top['rationale']}。\n"
        "严守 GDScript 4.6 约束（禁止对 Variant 使用 :=，Autoload 不加同名 class_name）。"
        "完成后更新 reports/evolution_log.md。",
        schema={"type": "string"},
        role=f"Builder Round {rnd}",
    )
    log(f"[Round {rnd}] Builder: {impl_res}")

    qa_res = await agent(
        "你是自动化 QA 验证代理。请运行：\n"
        "1) tools/godot/Godot_v4.6.1-stable_win64_console.exe --headless --path game res://scenes/headless_test_runner.tscn\n"
        "2) python tools/art_pipeline.py check\n"
        "3) python tools/balance_simulator.py\n"
        "如有 SCRIPT ERROR 或测试失败请直接修复后重测，直到全部通过并返回总结。",
        schema={"type": "string"},
        role=f"QA Verifier Round {rnd}",
    )
    log(f"[Round {rnd}] QA: {qa_res}")

del critic
