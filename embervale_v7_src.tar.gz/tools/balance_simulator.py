#!/usr/bin/env python3
"""
《星露物语：回响山谷》v5.0 四季 & 珊瑚群岛经济平衡与伴生生态收益模拟器
读取 game/data/*.json，模拟 28 天每季下【单一种植】vs【伴生混种】vs【工匠深加工（含三倍浓缩咖啡链）】收益曲线，
并评估珊瑚群岛恒温热带庄园全年产出，输出至 reports/economy_balance_report.md。
"""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DATA_DIR = ROOT / "game" / "data"
REPORT_PATH = ROOT / "reports" / "economy_balance_report.md"
SEASON_DAYS = 28


def load_json(name: str) -> dict:
    return json.loads((DATA_DIR / name).read_text(encoding="utf-8"))


def simulate_crop(crop: dict, items_map: dict, speed_bonus: float = 0.0, quality_bonus: float = 0.0, extra_yield: int = 0) -> dict:
    cid = crop["id"]
    seed = items_map[crop["seed_id"]]
    prod = items_map[cid]
    seed_cost = seed["buy_price"]
    base_sell = prod["sell_price"]
    avg_yield = 0.5 * (crop["harvest_min"] + crop["harvest_max"]) + extra_yield

    days_need = float(crop["days_to_grow"])
    regrow = int(crop["regrow_days"])
    rate_per_day = 1.0 + speed_bonus

    harvests = 0
    progress = 0.0
    mature = False
    regrow_cd = 0.0
    total_seed_cost = seed_cost

    for day in range(1, SEASON_DAYS + 1):
        if not mature:
            progress += rate_per_day
            if progress >= days_need - 1e-6:
                harvests += 1
                if regrow > 0:
                    mature = True
                    regrow_cd = 0.0
                else:
                    rem = SEASON_DAYS - day
                    if rem * rate_per_day >= days_need:
                        progress = 0.0
                        total_seed_cost += seed_cost
                    else:
                        break
        else:
            regrow_cd += rate_per_day
            if regrow_cd >= regrow - 1e-6:
                harvests += 1
                regrow_cd = 0.0

    # Baseline silver=0.20, gold=0.10 -> avg ~1.10; with quality_bonus +0.35 -> avg ~1.28
    qual_mult = 1.10 + quality_bonus * 0.48
    total_units = harvests * avg_yield
    gross = total_units * base_sell * qual_mult
    net = gross - total_seed_cost
    g_per_day = net / SEASON_DAYS

    # 工匠加工估算（严格对齐 recipes.json：星露咖啡豆在酿酒桶为 3 豆 -> 1 杯皇家三倍浓缩咖啡 290G / 3小时极速周转）
    ctype = crop["crop_type"]
    if ctype in ("vegetable", "herb"):
        jar_unit = float(int(base_sell * 2.0 + 40))
    else:
        jar_unit = float(int(base_sell * 2.2 + 50))

    if cid == "star_coffee" and "artisan_espresso" in items_map:
        espresso_sell = float(items_map["artisan_espresso"]["sell_price"])
        keg_unit = espresso_sell / 3.0  # 3 颗咖啡豆精萃 1 杯浓缩咖啡（3小时周转 + 45%极速移速Buff）
        espresso_cups = total_units / 3.0
        espresso_g_day = (espresso_cups * espresso_sell - total_seed_cost) / SEASON_DAYS
    else:
        keg_unit = float(int(base_sell * 3.0))
        espresso_g_day = 0.0

    artisan_best = max(jar_unit, keg_unit)
    artisan_net = total_units * artisan_best - total_seed_cost
    artisan_g_day = artisan_net / SEASON_DAYS

    return {
        "harvests": harvests,
        "total_units": round(total_units, 1),
        "seed_cost": total_seed_cost,
        "net": round(net, 1),
        "g_per_day": round(g_per_day, 2),
        "artisan_g_day": round(artisan_g_day, 2),
        "espresso_g_day": round(espresso_g_day, 2),
    }


def main():
    items_data = load_json("items.json")["items"]
    items_map = {x["id"]: x for x in items_data}
    crops = load_json("crops.json")["crops"]

    lines = [
        "# 《星露物语：回响山谷》v5.0 四季与珊瑚群岛经济平衡模拟报告",
        "",
        f"- 模拟周期：每季 `{SEASON_DAYS}` 天（全额每日浇水）",
        "- 对比场景：",
        "  - **常规单种**：无伴生加成，且连片单一导致地力消耗加速",
        "  - **伴生共鸣**：结合 `昼夜共生(+35%生长)` / `热带蕉林共鸣(+40%生长)` / `寒梅映雪(+30%生长)` / `根瘤固氮(+35%品质)` / `瓜果互促(+1产量)` 生态布局",
        "  - **工匠深加工**：将成熟作物投入果酱腌制桶或橡木酿酒桶陈酿后的单位地块日均净收益（含星露咖啡豆 3 合 1 萃取 `皇家三倍浓缩咖啡` 专项测算）",
        "",
        "| 作物 | 适用季节 | 种子价 | 基础售价 | 生长期/复果 | 单种收获次 | 单种净G/天 | 伴生共鸣G/天 | 工匠加工G/天 |",
        "| :--- | :--- | ---: | ---: | :--- | ---: | ---: | ---: | ---: |",
    ]

    season_best = {"spring": [], "summer": [], "autumn": [], "winter": [], "coral_island": []}
    tropical_summary = {}
    for crop in crops:
        cid = crop["id"]
        base_sim = simulate_crop(crop, items_map, speed_bonus=0.0, quality_bonus=0.0, extra_yield=0)
        if cid in ("pineapple", "star_coffee"):
            sp_b = 0.40  # 热带蕉林共鸣 +40% 生长速率
        elif cid in ("sunbell", "moonberry"):
            sp_b = 0.35  # 昼夜共生 +35% 生长速率
        elif cid in ("snow_lotus", "winter_root"):
            sp_b = 0.30  # 寒梅映雪 +30% 生长速率
        else:
            sp_b = 0.0
        q_b = 0.35 if cid != "clover" else 0.15
        y_b = 1 if cid in ("tomato", "ember_pumpkin") else 0
        eco_sim = simulate_crop(crop, items_map, speed_bonus=sp_b, quality_bonus=q_b, extra_yield=y_b)
        seed_price = items_map[crop["seed_id"]]["buy_price"]
        sell_price = items_map[cid]["sell_price"]
        reg_str = f"{crop['days_to_grow']}d" + (f" (复果{crop['regrow_days']}d)" if crop["regrow_days"] > 0 else "")
        seasons_str = "/".join(crop["seasons"]) + (" (+海岛全年)" if cid in ("pineapple", "star_coffee") else "")

        lines.append(
            f"| {crop['name']} (`{cid}`) | {seasons_str} | {seed_price}G | {sell_price}G | {reg_str} | "
            f"{base_sim['harvests']} | **{base_sim['g_per_day']}** | **{eco_sim['g_per_day']}** | **{eco_sim['artisan_g_day']}** |"
        )
        for s in crop["seasons"]:
            season_best[s].append((crop["name"], eco_sim["g_per_day"], eco_sim["artisan_g_day"]))
        if cid in ("pineapple", "star_coffee", "ancient_fruit"):
            season_best["coral_island"].append((crop["name"], eco_sim["g_per_day"], eco_sim["artisan_g_day"]))
        if cid in ("pineapple", "star_coffee"):
            tropical_summary[cid] = eco_sim

    lines += [
        "",
        "## 分季节与珊瑚群岛最优耕作策略分析",
        "",
    ]
    for s in ("spring", "summer", "autumn", "winter", "coral_island"):
        rows = season_best[s]
        if not rows:
            continue
        rows.sort(key=lambda x: x[1], reverse=True)
        top = rows[0]
        rows_art = sorted(rows, key=lambda x: x[2], reverse=True)[0]
        label = "🏖️ 珊瑚群岛（恒温全年）" if s == "coral_island" else f"{s.upper()} 季"
        lines.append(f"- **{label}**：鲜卖日均最优 `{top[0]}` ({top[1]} G/天)；配合酿酒/腌制深加工最高 `{rows_art[0]}` ({rows_art[2]} G/天)。")

    if "pineapple" in tropical_summary and "star_coffee" in tropical_summary:
        pa = tropical_summary["pineapple"]
        cf = tropical_summary["star_coffee"]
        esp_price = items_map["artisan_espresso"]["sell_price"]
        lines += [
            "",
            "## 🏖️ v5.0 珊瑚群岛热带作物与皇家三倍浓缩咖啡专项评估",
            "",
            f"- **黄金凤梨 (`pineapple`)**：在【热带蕉林共鸣 (`+40%` 生长)】加持下，单季 28 天可收获 `{pa['harvests']}` 轮，鲜果净收益 **{pa['g_per_day']} G/天**，投入橡木酿酒桶陈酿凤梨果酒可达 **{pa['artisan_g_day']} G/天**，且在珊瑚群岛无视严冬跨季永续复果；",
            f"- **星露咖啡豆 (`star_coffee`) → 皇家三倍浓缩咖啡 (`artisan_espresso`)**：伴生共鸣下 28 天可串收 `{cf['total_units']}` 颗咖啡豆；若按 `3:1` 投入酿酒桶（仅需 `3` 小时极速萃取，周转效率为普通果酒的 4 倍），日均稳定产出 `{round(cf['total_units'] / 3.0 / SEASON_DAYS, 2)}` 杯 **{esp_price}G 皇家三倍浓缩咖啡**（日均净收益 **{cf['espresso_g_day']} G/天**，自饮更可全天保持 `+45%` 极速移速 Buff）；若追求纯金币最大化，亦可单颗投入果酱桶熬制咖啡果冻达 **{cf['artisan_g_day']} G/天**。",
        ]

    lines += [
        "",
        "## 平衡性结论",
        "1. 速生作物（白萝卜、固氮三叶草）前 4 天即可回本，适合春初快速滚雪球积攒第一桶金与恢复地力；",
        "2. 七大伴生组合（向阳铃+月露莓、黄金凤梨+星露咖啡豆、番茄+烬火南瓜、任意作物+固氮三叶草等）可稳定提升 **25%~45%** 的地块综合收益，避免单调单一铺场；",
        "3. 中后期解锁【星露珊瑚群岛】与【四季温室】后，黄金凤梨果酒、三倍浓缩咖啡（跑图效率核心）与远古星露果酒共同构成平滑的终局黄金丰饶钟（15,000G）资金回收梯度。",
    ]

    REPORT_PATH.parent.mkdir(parents=True, exist_ok=True)
    REPORT_PATH.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(f"[OK] 已生成四季经济模拟报告: {REPORT_PATH}")


if __name__ == "__main__":
    main()
