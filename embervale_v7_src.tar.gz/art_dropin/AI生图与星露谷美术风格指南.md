# 《星露物语：回响山谷》AI 生图 × 人工精修美术风格圣经与对接指南

你们团队采用 **“AI 生成初稿 + 人工微调定稿 → 放入 `art_dropin/` 按 `F9` 实时换皮”** 是目前 2D 独立游戏最高效的工业化方案！为了彻底避免常见 AI 生图出现的“风格割裂、黑边脏点、透视打架、尺寸不对”四大坑，特整理本实战指南。

---

## 一、全项目统一视觉铁律（发给美工/写进 AI 固定前缀）

1. **统一视角（最关键！）**：
   - 所有建筑、树木、机器、人物、动物必须统一采用 **经典 16-bit JRPG 3/4 俯视斜角（Top-Down 3/4 RPG Perspective，约 45° 俯角，能同时看到物体正立面与顶面）**，严禁混入纯正视横版图或纯 90° 顶视图。
2. **统一光源与暖调色板**：
   - 全局光源统一为 **左上角 45° 温暖阳光**。
   - **禁止纯黑描边 (`#000000`)**！星露谷之所以温馨柔和，是因为外轮廓线统一使用 **深浓咖啡棕 (`#2A1A14` ~ `#3B2318`)**，暗部往暖紫棕偏移，亮部往暖奶油黄偏移。
3. **像素颗粒度一致（1x 基准 = `32×32` 像素格）**：
   - 无论 AI 原图是 `1024×1024` 还是人工手绘，缩回游戏规格（`32×32` 图标、`64×96` 树木、`160×128` 建筑、`96×96` 立绘）时必须使用 **最近邻插值（Nearest Neighbor）**，不要用双线性模糊缩放，否则进游戏会发虚。

---

## 二、直接复制可用的 AI 生图提示词模板（Midjourney / GPT-Image / Flux / ComfyUI）

### 1. 道具 / 作物 / 料理小图标（目标：`icons/*.png`，32×32）
> `16-bit cozy pixel art game icon of [具体物品，如: a plump golden pumpkin / a jar of strawberry jam / a sunny-side-up omelet on ceramic plate], Stardew Valley aesthetic, warm sunlit palette, dark espresso brown pixel outline (#2A1A14), clean crisp pixel clusters, top-left warm lighting, centered single object, isolated on pure solid white background #FFFFFF, no shadow on background, no text`

### 2. 户外建筑（目标：`objects/house_farm.png`、`barn_ranch.png` 等）
> `16-bit SNES cozy pixel art RPG building, [具体建筑，如: rustic wooden farmhouse cottage with red shingled roof, stone chimney, warm glowing yellow windows with flower boxes / red gambrel roof wooden livestock barn with white X-trim double doors], 3/4 top-down RPG perspective (45-degree overhead view), Stardew Valley style, warm autumn-gold and honey-wood tones, crisp pixel art, isolated on solid white background #FFFFFF`

### 3. 村民对话半身立绘（目标：`portraits/npc_*.png`，96×96 或 192×192 / 384×384 等比）
> `16-bit cozy pixel art character bust portrait of [角色描述，如: a cheerful young female botanist with straw hat, dark brown hair, green gardener apron, gentle warm smile], Stardew Valley portrait style, expressive pixel eyes with catchlights, warm cozy palette, framed from chest up, clean pixel shading`

### 4. 树木 / 矿石 / 工匠机器（目标：`objects/*.png`）
> `16-bit pixel art game prop, [具体物件，如: lush rounded oak tree with clustered emerald foliage and warm brown trunk / wooden oak wine keg with brass hoops], 3/4 top-down RPG view, Stardew Valley style, dark brown outline, isolated on pure solid white background #FFFFFF`

---

## 三、一秒去白底 + 像素对齐神器（专为 AI 大图准备！）

AI 生图工具导出的往往是 `1024×1024` 带纯白底（或纯色底）的大图。你们**不需要手动开 PS 一张张抠图改尺寸**，本工程已内置全自动边缘泛洪抠底工具（会自动保留鸡蛋、牛奶、眼神光等内部白色，只抠除外部背景！）：

```powershell
python tools/art_pipeline.py import-ai --input "你的AI原图.png" --target "icons/turnip.png"
```

执行后：
1. 自动识别四角背景色并连通抠成透明底；
2. 自动裁掉多余白边并按 `art_manifest.json` 标准尺寸做最近邻像素缩放；
3. 自动放入 `art_dropin/sprites/...`，你在开着的游戏里直接按 **`F9`** 当场生效！

---

## 四、最高性价比的美术替换先后顺序建议

不要一上来同时铺开 150 张图！按以下 **4 个批次**替换，每一批都能让游戏质感肉眼可见飙升：
1. **第一批（仅 5 张图，改变 70% 观感！）**：
   - `tiles/terrain_atlas.png`（草地、泥土路、石板路、水波，决定满屏底色）
   - `characters/player_sheet.png`（主角时刻在屏幕正中央）
   - `objects/tree.png`、`objects/house_farm.png`、`objects/barn_ranch.png`
2. **第二批（4 张立绘 + 4 张村民行走图 + 3 只牧场动物）**：
   - `portraits/npc_*.png` 与 `animals/chicken.png, cow.png, sheep.png`
3. **第三批（12 种作物的 5 阶段生长条 `crops/crop_*.png` + 常用机器）**
4. **第四批（批量 AI 生成 80+ 个 `32×32` 背包小图标，配合 `import-ai` 脚本 10 分钟批处理搞定）**
