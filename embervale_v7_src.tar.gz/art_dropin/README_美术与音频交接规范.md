# 《星露物语：回响山谷》人工美术与音频热替换交接规范

## 使用方式（零代码热替换！）
1. 保持文件名和相对路径与下表**完全一致**，导出透明底 PNG（或 16-bit 44.1kHz WAV）到对应目录：
   - 图片放入：`d:\星露谷物语\art_dropin\sprites\<相对路径>`
   - 音效放入：`d:\星露谷物语\art_dropin\audio\<文件名>.wav`
2. **无需打开 Godot 编辑器，也无需重启游戏！** 游戏运行中直接按 **`F9` 键**即可实时热刷新画面与音效。
3. 如果某张图需要高清绘制（如 2x / 4x 像素或手绘插画），请确保**宽高与下表成整数倍比例**（或至少与原尺寸长宽比一致），程序会按标准帧格切片并自适应绘制。
4. 在控制台或工作台执行 `python tools/art_pipeline.py check` 可自动检查所有新放入资产的尺寸与格式合规性。

## 一、核心精灵图集 / 建筑 / 植物 / 头像尺寸规格表

| 相对路径 (置于 `art_dropin/sprites/` 下) | 分类 | 资产名称 | 标准总尺寸 (px) | 单帧尺寸 | 说明 |
| :--- | :--- | :--- | :--- | :--- | :--- |
| `characters/player_sheet.png` | character | 主角精灵图集 | `128×192` | `32×32` | 4列x6行(行0-3为下/左/右/上行走4帧，行4为工具挥动，行5为待机/钓鱼) |
| `characters/npc_linxia.png` | character | NPC-林夏精灵图集 | `128×128` | `32×32` | 4列x4行(下/左/右/上各4帧行走) |
| `portraits/npc_linxia.png` | portrait | NPC-林夏对话立绘 | `96×96` | `96×96` | 对话框左侧半身像素立绘 |
| `characters/npc_horn.png` | character | NPC-霍恩精灵图集 | `128×128` | `32×32` | 4列x4行(下/左/右/上各4帧行走) |
| `portraits/npc_horn.png` | portrait | NPC-霍恩对话立绘 | `96×96` | `96×96` | 对话框左侧半身像素立绘 |
| `characters/npc_ache.png` | character | NPC-阿澈精灵图集 | `128×128` | `32×32` | 4列x4行(下/左/右/上各4帧行走) |
| `portraits/npc_ache.png` | portrait | NPC-阿澈对话立绘 | `96×96` | `96×96` | 对话框左侧半身像素立绘 |
| `characters/npc_mei.png` | character | NPC-梅婆婆精灵图集 | `128×128` | `32×32` | 4列x4行(下/左/右/上各4帧行走) |
| `portraits/npc_mei.png` | portrait | NPC-梅婆婆对话立绘 | `96×96` | `96×96` | 对话框左侧半身像素立绘 |
| `characters/npc_suwan.png` | character | NPC-苏晚精灵图集 | `128×128` | `32×32` | 4列x4行(下/左/右/上各4帧行走) |
| `portraits/npc_suwan.png` | portrait | NPC-苏晚对话立绘 | `96×96` | `96×96` | 对话框左侧半身像素立绘 |
| `characters/npc_kailuo.png` | character | NPC-凯洛精灵图集 | `128×128` | `32×32` | 4列x4行(下/左/右/上各4帧行走) |
| `portraits/npc_kailuo.png` | portrait | NPC-凯洛对话立绘 | `96×96` | `96×96` | 对话框左侧半身像素立绘 |
| `crops/crop_turnip.png` | crop | 作物-白萝卜生长阶段条 | `160×32` | `32×32` | 5帧横向条：种子/嫩芽/枝叶/含苞/成熟 |
| `crops/crop_sunbell.png` | crop | 作物-向阳铃生长阶段条 | `160×32` | `32×32` | 5帧横向条：种子/嫩芽/枝叶/含苞/成熟 |
| `crops/crop_moonberry.png` | crop | 作物-月露莓生长阶段条 | `160×32` | `32×32` | 5帧横向条：种子/嫩芽/枝叶/含苞/成熟 |
| `crops/crop_clover.png` | crop | 作物-固氮三叶草生长阶段条 | `160×32` | `32×32` | 5帧横向条：种子/嫩芽/枝叶/含苞/成熟 |
| `crops/crop_tomato.png` | crop | 作物-红番茄生长阶段条 | `160×32` | `32×32` | 5帧横向条：种子/嫩芽/枝叶/含苞/成熟 |
| `crops/crop_blueberry.png` | crop | 作物-晴空蓝莓生长阶段条 | `160×32` | `32×32` | 5帧横向条：种子/嫩芽/枝叶/含苞/成熟 |
| `crops/crop_summer_melon.png` | crop | 作物-蜜纹甜瓜生长阶段条 | `160×32` | `32×32` | 5帧横向条：种子/嫩芽/枝叶/含苞/成熟 |
| `crops/giant_summer_melon.png` | crop | 巨型作物-蜜纹甜瓜 | `64×64` | `64×64` | 2x2合体巨型变异作物 |
| `crops/crop_ember_pumpkin.png` | crop | 作物-烬火南瓜生长阶段条 | `160×32` | `32×32` | 5帧横向条：种子/嫩芽/枝叶/含苞/成熟 |
| `crops/giant_ember_pumpkin.png` | crop | 巨型作物-烬火南瓜 | `64×64` | `64×64` | 2x2合体巨型变异作物 |
| `crops/crop_cranberry.png` | crop | 作物-霜红蔓越莓生长阶段条 | `160×32` | `32×32` | 5帧横向条：种子/嫩芽/枝叶/含苞/成熟 |
| `crops/crop_garlic_mint.png` | crop | 作物-清风薄荷蒜生长阶段条 | `160×32` | `32×32` | 5帧横向条：种子/嫩芽/枝叶/含苞/成熟 |
| `crops/crop_snow_lotus.png` | crop | 作物-雪晶莲生长阶段条 | `160×32` | `32×32` | 5帧横向条：种子/嫩芽/枝叶/含苞/成熟 |
| `crops/crop_winter_root.png` | crop | 作物-冬藏甜根生长阶段条 | `160×32` | `32×32` | 5帧横向条：种子/嫩芽/枝叶/含苞/成熟 |
| `crops/crop_ancient_fruit.png` | crop | 作物-远古星露果生长阶段条 | `160×32` | `32×32` | 5帧横向条：种子/嫩芽/枝叶/含苞/成熟 |
| `crops/crop_pineapple.png` | crop | 作物-黄金凤梨生长阶段条 | `160×32` | `32×32` | 5帧横向条：种子/嫩芽/枝叶/含苞/成熟 |
| `crops/crop_star_coffee.png` | crop | 作物-星露咖啡豆生长阶段条 | `160×32` | `32×32` | 5帧横向条：种子/嫩芽/枝叶/含苞/成熟 |
| `tiles/terrain_atlas.png` | tile | 地形图块图集 | `320×64` | `32×32` | 10列x2行共20种32x32地表/耕地/水面/矿洞地块 |
| `objects/tree.png` | object | 松橡树 | `64×96` | `64×96` | 锚点底部中心 |
| `objects/stump.png` | object | 树桩 | `32×32` | `32×32` | 32x32 |
| `objects/hardwood_stump.png` | object | 千年铁木古桩 | `32×32` | `32×32` | 32x32 |
| `objects/rock.png` | object | 普通岩石 | `32×32` | `32×32` | 32x32 |
| `objects/ore_copper.png` | object | 铜矿脉 | `32×32` | `32×32` | 32x32 |
| `objects/ore_iron.png` | object | 铁矿脉 | `32×32` | `32×32` | 32x32 |
| `objects/ore_gold.png` | object | 金矿脉 | `32×32` | `32×32` | 32x32 |
| `objects/ore_crystal.png` | object | 回响水晶矿 | `32×32` | `32×32` | 32x32 |
| `objects/weed.png` | object | 野草 | `32×32` | `32×32` | 32x32 |
| `objects/forage_wild_berry.png` | object | 采集物-wild_berry | `32×32` | `32×32` | 32x32 |
| `objects/forage_echo_shell.png` | object | 采集物-echo_shell | `32×32` | `32×32` | 32x32 |
| `objects/forage_spring_herb.png` | object | 采集物-spring_herb | `32×32` | `32×32` | 32x32 |
| `objects/forage_mystic_truffle.png` | object | 采集物-mystic_truffle | `32×32` | `32×32` | 32x32 |
| `objects/shipping_bin.png` | object | 出货箱 | `48×48` | `48×48` | 48x48 |
| `objects/machine_sprinkler.png` | object | 四向洒水器 | `32×32` | `32×32` | 32x32 |
| `objects/machine_quality_sprinkler.png` | object | 优质洒水器 | `32×32` | `32×32` | 32x32 |
| `objects/machine_jar.png` | object | 果酱腌制桶 | `32×32` | `32×32` | 32x32 |
| `objects/machine_keg.png` | object | 橡木酿酒桶 | `32×32` | `32×32` | 32x32 |
| `objects/machine_furnace.png` | object | 矿石熔炉 | `32×32` | `32×32` | 32x32 |
| `objects/machine_chest.png` | object | 储物木箱 | `32×32` | `32×32` | 32x32 |
| `objects/torch.png` | object | 萤火火把 | `32×32` | `32×32` | 32x32 |
| `objects/ladder_down.png` | object | 下行矿梯 | `32×32` | `32×32` | 32x32 |
| `objects/ladder_up.png` | object | 返回梯子 | `32×32` | `32×32` | 32x32 |
| `objects/elevator.png` | object | 矿洞电梯 | `32×32` | `32×32` | 32x32 |
| `objects/machine_mayo.png` | object | 蛋黄酱机 | `32×32` | `32×32` | 32x32 |
| `objects/machine_cheese.png` | object | 奶酪压制机 | `32×32` | `32×32` | 32x32 |
| `objects/bed.png` | object | 农舍床铺 | `48×64` | `48×64` | 48x64 |
| `objects/tv.png` | object | 占卜电视 | `32×40` | `32×40` | 32x40 |
| `objects/house_farm.png` | object | 农场小屋 | `160×128` | `160×128` | 160x128 |
| `objects/shop_linxia.png` | object | 林夏种子杂货店 | `160×128` | `160×128` | 160x128 |
| `objects/smithy_horn.png` | object | 霍恩铁匠铺 | `160×128` | `160×128` | 160x128 |
| `objects/greenhouse.png` | object | 四季生态温室 | `128×96` | `128×96` | 128x96 |
| `objects/festival_table.png` | object | 丰收品鉴评比台 | `64×48` | `64×48` | 64x48 |
| `objects/barn_ranch.png` | object | 阳光红顶畜牧舍 | `192×160` | `192×160` | 192x160 |
| `objects/kitchen_stove.png` | object | 乡野料理灶台 | `64×48` | `64×48` | 64x48 |
| `objects/feed_trough.png` | object | 牧场饲草槽 | `64×36` | `64×36` | 64x36 |
| `objects/ranch_sign.png` | object | 阳光牧场木牌 | `48×48` | `48×48` | 48x48 |
| `objects/echo_shrine.png` | object | 回响祭坛 | `128×128` | `128×128` | 128x128 |
| `objects/quest_board.png` | object | 镇广场悬赏栏 | `64×64` | `64×64` | 64x64 |
| `objects/fountain.png` | object | 镇广场喷泉 | `96×96` | `96×96` | 96x96 |
| `objects/pet_bowl.png` | object | 萌宠温馨小窝 | `32×32` | `32×32` | 32x32 |
| `objects/fish_pond.png` | object | 活水生态鱼塘 | `96×64` | `96×64` | 96x64 |
| `objects/carpenter_desk.png` | object | 苏晚星象营造台 | `64×48` | `64×48` | 64x48 |
| `objects/obelisk.png` | object | 回响方尖传送塔 | `64×96` | `64×96` | 64x96 |
| `objects/golden_clock.png` | object | 黄金丰饶钟 | `64×96` | `64×96` | 64x96 |
| `monsters/slime.png` | monster | 绿史莱姆4帧动画 | `128×32` | `32×32` | 4列x1行弹性跳跃动画 |
| `monsters/shadow_bug.png` | monster | 暗影甲虫4帧动画 | `128×32` | `32×32` | 4列x1行爬行动画 |
| `monsters/echo_boss.png` | monster | 回响晶甲王Boss 4帧动画 | `192×48` | `48×48` | 4列x1行矿洞第10层Boss悬浮动画 |
| `monsters/forest_wisp.png` | monster | 秘林花妖4帧动画 | `128×32` | `32×32` | 4列x1行迷雾秘林花妖振翅动画 |
| `monsters/ancient_treant.png` | monster | 远古树精守护者Boss 4帧动画 | `192×48` | `48×48` | 4列x1行迷雾秘林远古树精Boss动画 |
| `animals/chicken.png` | animal | 牧场小母鸡4帧动画 | `128×32` | `32×32` | 4列x1行行走啄米动画 |
| `animals/cow.png` | animal | 花斑奶牛4帧动画 | `192×48` | `48×48` | 4列x1行牧场漫步动画 |
| `animals/sheep.png` | animal | 云朵绵羊4帧动画 | `160×40` | `40×40` | 4列x1行牧场漫步动画 |
| `animals/pet_cat.png` | animal | 萌宠橘猫团子4帧动画 | `128×32` | `32×32` | 4列x1行随行橘猫奔跑待机动画 |
| `animals/pet_dog.png` | animal | 萌宠柴犬旺财4帧动画 | `128×32` | `32×32` | 4列x1行随行柴犬奔跑待机动画 |
| `objects/palm_tree.png` | object | 海岛椰林棕榈树 | `64×96` | `64×96` | 珊瑚群岛热带椰子树 |
| `objects/island_boat.png` | object | 星海木帆渡船 | `80×64` | `80×64` | 往返低语湖栈桥与星露珊瑚群岛的渡船 |
| `objects/forage_coral_pearl.png` | object | 滩涂拾荒-南海星光珍珠 | `32×32` | `32×32` | 珊瑚群岛滩涂珠贝 |
| `objects/forage_starfish_shell.png` | object | 滩涂拾荒-珊瑚红海星 | `32×32` | `32×32` | 珊瑚群岛金沙滩海星 |

## 二、物品图标列表（共 99 项，统一规格 `32×32` 透明底 PNG）

| 相对路径 (`art_dropin/sprites/`) | 物品名称 |
| :--- | :--- |
| `icons/tool_hoe.png` | 图标-精铁锄头 |
| `icons/tool_can.png` | 图标-铜制水壶 |
| `icons/tool_axe.png` | 图标-伐木斧 |
| `icons/tool_pickaxe.png` | 图标-矿工十字镐 |
| `icons/tool_blade.png` | 图标-猎镰短剑 |
| `icons/tool_rod.png` | 图标-竹制钓竿 |
| `icons/seed_turnip.png` | 图标-白萝卜种子 |
| `icons/seed_sunbell.png` | 图标-向阳铃种子 |
| `icons/seed_moonberry.png` | 图标-月露莓种子 |
| `icons/seed_clover.png` | 图标-固氮三叶草种子 |
| `icons/seed_tomato.png` | 图标-红番茄种子 |
| `icons/seed_blueberry.png` | 图标-晴空蓝莓种子 |
| `icons/seed_summer_melon.png` | 图标-蜜纹甜瓜种子 |
| `icons/seed_ember_pumpkin.png` | 图标-烬火南瓜种子 |
| `icons/seed_cranberry.png` | 图标-霜红蔓越莓种子 |
| `icons/seed_garlic_mint.png` | 图标-清风薄荷蒜种子 |
| `icons/seed_snow_lotus.png` | 图标-雪晶莲种子 |
| `icons/seed_winter_root.png` | 图标-冬藏甜根种子 |
| `icons/turnip.png` | 图标-白萝卜 |
| `icons/sunbell.png` | 图标-向阳铃 |
| `icons/moonberry.png` | 图标-月露莓 |
| `icons/clover.png` | 图标-固氮三叶草 |
| `icons/tomato.png` | 图标-红番茄 |
| `icons/blueberry.png` | 图标-晴空蓝莓 |
| `icons/summer_melon.png` | 图标-蜜纹甜瓜 |
| `icons/ember_pumpkin.png` | 图标-烬火南瓜 |
| `icons/cranberry.png` | 图标-霜红蔓越莓 |
| `icons/garlic_mint.png` | 图标-清风薄荷蒜 |
| `icons/snow_lotus.png` | 图标-雪晶莲 |
| `icons/winter_root.png` | 图标-冬藏甜根 |
| `icons/wild_berry.png` | 图标-山谷野莓 |
| `icons/echo_shell.png` | 图标-回响贝壳 |
| `icons/spring_herb.png` | 图标-星露草药 |
| `icons/slime_gel.png` | 图标-史莱姆凝胶 |
| `icons/bug_chitin.png` | 图标-暗影甲壳 |
| `icons/wood.png` | 图标-木材 |
| `icons/stone.png` | 图标-石料 |
| `icons/fiber.png` | 图标-植物纤维 |
| `icons/copper_ore.png` | 图标-铜矿石 |
| `icons/iron_ore.png` | 图标-铁矿石 |
| `icons/gold_ore.png` | 图标-金矿石 |
| `icons/echo_crystal.png` | 图标-回响水晶 |
| `icons/copper_bar.png` | 图标-铜锭 |
| `icons/iron_bar.png` | 图标-铁锭 |
| `icons/gold_bar.png` | 图标-金锭 |
| `icons/fertilizer_speed.png` | 图标-星露生长肥 |
| `icons/machine_sprinkler.png` | 图标-四向洒水器 |
| `icons/machine_quality_sprinkler.png` | 图标-八向优质洒水器 |
| `icons/machine_jar.png` | 图标-果酱腌制桶 |
| `icons/machine_keg.png` | 图标-橡木酿酒桶 |
| `icons/machine_furnace.png` | 图标-矿石熔炉 |
| `icons/machine_chest.png` | 图标-储物木箱 |
| `icons/torch.png` | 图标-萤火火把 |
| `icons/artisan_pickles.png` | 图标-风味腌菜 |
| `icons/artisan_jam.png` | 图标-浓香果酱 |
| `icons/artisan_wine.png` | 图标-回响果酒 |
| `icons/herbal_tea.png` | 图标-林夏草药茶 |
| `icons/roasted_fish.png` | 图标-香烤鲜鱼 |
| `icons/fish_crucian.png` | 图标-溪流鲫鱼 |
| `icons/fish_sakura_trout.png` | 图标-春樱鳟鱼 |
| `icons/fish_gold_carp.png` | 图标-黄金锦鲤 |
| `icons/fish_glow_eel.png` | 图标-夜光鳗 |
| `icons/fish_catfish.png` | 图标-深潭雨鲶 |
| `icons/fish_frost_salmon.png` | 图标-冰晶鲑鱼 |
| `icons/fish_sun_perch.png` | 图标-艳阳鲈鱼 |
| `icons/fish_echo_dragon.png` | 图标-回响龙鱼王 |
| `icons/hay.png` | 图标-清香牧草 |
| `icons/egg.png` | 图标-鲜鸡蛋 |
| `icons/milk.png` | 图标-鲜牛奶 |
| `icons/wool.png` | 图标-蓬松羊毛 |
| `icons/machine_mayo.png` | 图标-蛋黄酱机 |
| `icons/machine_cheese.png` | 图标-奶酪压制机 |
| `icons/artisan_mayo.png` | 图标-香浓蛋黄酱 |
| `icons/artisan_cheese.png` | 图标-醇熟奶酪 |
| `icons/artisan_cloth.png` | 图标-星露绒布 |
| `icons/dish_spring_salad.png` | 图标-春露鲜蔬盘 |
| `icons/dish_omelet.png` | 图标-田园煎蛋卷 |
| `icons/dish_berry_muffin.png` | 图标-甜莓鲜奶松饼 |
| `icons/dish_herb_fish.png` | 图标-薄荷香煎鲜鱼 |
| `icons/dish_pumpkin_soup.png` | 图标-奶油南瓜浓汤 |
| `icons/dish_cheese_gratin.png` | 图标-醇香芝士焗菜 |
| `icons/dish_miner_stew.png` | 图标-矿工能量炖锅 |
| `icons/dish_valley_feast.png` | 图标-星露回响盛宴 |
| `icons/bouquet.png` | 图标-定情花束 |
| `icons/mermaid_pendant.png` | 图标-回响人鱼吊坠 |
| `icons/hardwood.png` | 图标-千年铁木 |
| `icons/mystic_truffle.png` | 图标-星露荧光松露 |
| `icons/seed_ancient_fruit.png` | 图标-远古星露种子 |
| `icons/ancient_fruit.png` | 图标-远古星露果 |
| `icons/fish_roe.png` | 图标-晶莹鱼籽 |
| `icons/artisan_caviar.png` | 图标-黄金鱼籽酱 |
| `icons/seed_pineapple.png` | 图标-黄金凤梨种苗 |
| `icons/pineapple.png` | 图标-黄金凤梨 |
| `icons/seed_star_coffee.png` | 图标-星露咖啡豆种 |
| `icons/star_coffee.png` | 图标-星露咖啡豆 |
| `icons/artisan_espresso.png` | 图标-皇家三倍浓缩咖啡 |
| `icons/coral_pearl.png` | 图标-南海星光珍珠 |
| `icons/starfish_shell.png` | 图标-珊瑚红海星 |
| `icons/fish_manta_ray.png` | 图标-星海蝠鲼 |

## 三、音频与环境声列表（统一为 `.wav`，推荐 16-bit 44100Hz）

| 相对路径 (`art_dropin/audio/`) | 音效名称 | 参考时长 | 说明 |
| :--- | :--- | :--- | :--- |
| `till.wav` | 锄地翻土 | 0.16s | 16-bit 44100Hz 单声道/立体声 WAV |
| `water.wav` | 水壶浇水 | 0.28s | 清脆水波声 |
| `plant.wav` | 播种轻响 | 0.12s | 轻快弹响 |
| `harvest.wav` | 收获提示音 | 0.24s | 双音上扬和弦 |
| `chop.wav` | 伐木砍击 | 0.16s | 木质钝击 |
| `mine_hit.wav` | 镐击矿石 | 0.18s | 金属清脆撞击 |
| `sword_swing.wav` | 挥剑破空 | 0.14s | 气浪呼啸 |
| `monster_hit.wav` | 怪物受击 | 0.15s | 弹性击打声 |
| `coin.wav` | 金币结算 | 0.22s | 高音叮当 |
| `fish_cast.wav` | 抛竿落水 | 0.25s | 咻+水花 |
| `fish_catch.wav` | 成功钓鱼 | 0.45s | 胜利琶音 |
| `ui_click.wav` | 界面按钮点击 | 0.06s | 柔和木质轻叩 |
| `rooster_morning.wav` | 清晨唤醒 | 0.65s | 温暖晨钟三和弦 |
| `valley_breeze_loop.wav` | 春季晨露田园背景乐 | 8.0s | 可无缝循环的温柔木吉他竖琴+微风鸟鸣 |
| `bgm_summer_loop.wav` | 盛夏晴空田园背景乐 | 8.0s | 欢快尤克里里与马林巴夏风循环 |
| `bgm_autumn_loop.wav` | 金秋麦浪田园背景乐 | 8.0s | 温暖指弹木吉他与秋叶竖琴循环 |
| `bgm_winter_loop.wav` | 冬日星雪田园背景乐 | 8.0s | 晶莹钢片琴八音盒与竖琴循环 |
| `bgm_island_loop.wav` | 珊瑚群岛热带海风背景乐 | 8.0s | 加勒比热带马林巴尼龙吉他与海浪循环 |